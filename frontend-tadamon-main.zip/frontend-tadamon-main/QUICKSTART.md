# ⚡ Guide de Démarrage Rapide - TADAMON

Ce guide vous permet de lancer le projet en **5 minutes**.

---

## 1️⃣ Cloner et Installer

```bash
# Cloner le repo
git clone <url-du-repo>
cd tadamon

# Installer Backend
cd backend
npm install

# Installer Frontend
cd ../frontend
npm install
```

---

## 2️⃣ Configurer la Base de Données

### Créer le fichier `.env.local` dans `/backend`

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=VOTRE_MOT_DE_PASSE_MYSQL
DB_NAME=tadamon_db
DB_PORT=3306

JWT_SECRET=tadamon_secret_key_2025_very_secure
JWT_EXPIRES_IN=7d

PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
```

### Créer la base de données

```bash
# Dans MySQL
mysql -u root -p

# Exécuter ces commandes SQL
CREATE DATABASE tadamon_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
exit;

# Importer le schéma et les données
cd backend
mysql -u root -p tadamon_db < database/schema.sql
mysql -u root -p tadamon_db < database/seed.sql
```

---

## 3️⃣ Lancer le Projet

### Terminal 1 - Backend
```bash
cd backend
npm run dev
```
✅ Vous devriez voir : `🚀 LKHEDMA Social API Running on http://localhost:5000`

### Terminal 2 - Frontend
```bash
cd frontend
npm run dev
```
✅ Vous devriez voir : `VITE ready in XXXms → http://localhost:5173`

---

## 4️⃣ Tester

### Ouvrir dans le navigateur

| URL | Description |
|-----|-------------|
| http://localhost:5173 | Application Frontend |
| http://localhost:5000/api-docs | Documentation API |

### Comptes de test

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| Admin | `admin@lkhedma.ma` | `Admin123!` |
| Travailleur | `worker@test.com` | `password123` |
| Établissement | `establishment@test.com` | `password123` |

---

## 🆘 Problèmes Courants

### ❌ "Cannot connect to MySQL"
→ Vérifiez que MySQL est démarré et que les credentials dans `.env.local` sont corrects

### ❌ "Port 5000 already in use"
→ Fermez l'autre application ou changez le port dans `.env.local`

### ❌ "CORS error"
→ Vérifiez que `FRONTEND_URL=http://localhost:5173` dans `.env.local`

---

## 📚 Documentation Complète

Voir [README.md](README.md) pour la documentation détaillée.
