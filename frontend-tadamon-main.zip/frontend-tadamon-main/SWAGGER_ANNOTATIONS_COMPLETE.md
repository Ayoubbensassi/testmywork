# 📚 TADAMON API Documentation

Documentation complète de l'API REST TADAMON - Plateforme de mise en relation entre travailleurs sociaux et établissements.

---

## 🚀 Accès à la Documentation

### Swagger UI (Interactive)
```
http://localhost:5000/api-docs
```

### Swagger JSON
```
http://localhost:5000/api-docs.json
```

---

## 🔐 Authentification

L'API utilise **JWT (JSON Web Tokens)** pour l'authentification.

### Obtenir un Token
```bash
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
```

### Utiliser le Token
```bash
Authorization: Bearer <votre_token>
```

---

## 📋 Endpoints Documentés

### 🔐 Auth (`/auth`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/auth/register` | Inscription |
| POST | `/auth/login` | Connexion |
| GET | `/auth/me` | Profil utilisateur |
| GET | `/auth/verify-email/:token` | Vérification email |
| POST | `/auth/resend-verification` | Renvoyer vérification |
| POST | `/auth/forgot-password` | Mot de passe oublié |
| POST | `/auth/reset-password/:token` | Réinitialiser mot de passe |
| GET | `/auth/google` | OAuth Google |
| GET | `/auth/google/status` | Statut OAuth |

### 👷 Workers (`/workers`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/workers` | Liste des travailleurs |
| POST | `/workers/profile` | Créer profil |
| GET | `/workers/profile` | Mon profil |
| PUT | `/workers/profile` | Modifier profil |
| POST | `/workers/profile/documents` | Upload documents |
| POST | `/workers/specialties` | Ajouter spécialité |
| DELETE | `/workers/specialties/:id` | Retirer spécialité |
| GET | `/workers/profile/:id` | Profil public |
| GET | `/workers/search` | Rechercher |

### 🏢 Establishments (`/establishments`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/establishments` | Liste établissements |
| POST | `/establishments/profile` | Créer profil |
| GET | `/establishments/profile` | Mon profil |
| PUT | `/establishments/profile` | Modifier profil |
| POST | `/establishments/profile/logo` | Upload logo |
| POST | `/establishments/profile/documents` | Upload documents vérification |
| GET | `/establishments/profile/:id` | Profil public |

### 📋 Missions (`/missions`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/missions` | Liste missions |
| GET | `/missions/search` | Rechercher |
| POST | `/missions` | Créer mission |
| GET | `/missions/my` | Mes missions |
| GET | `/missions/:id` | Détails mission |
| PUT | `/missions/:id` | Modifier mission |
| DELETE | `/missions/:id` | Supprimer mission |

### 📝 Applications (`/applications`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/applications` | Postuler |
| GET | `/applications/my` | Mes candidatures |
| GET | `/applications/received` | Candidatures reçues |
| GET | `/applications/mission/:id` | Candidatures mission |
| PATCH | `/applications/:id/accept` | Accepter |
| PATCH | `/applications/:id/reject` | Refuser |
| DELETE | `/applications/:id` | Retirer |

### ⭐ Reviews (`/reviews`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/reviews` | Créer avis |
| GET | `/reviews/worker/:id` | Avis travailleur |
| GET | `/reviews/establishment/:id` | Avis établissement |
| GET | `/reviews/my` | Mes avis |

### 💬 Messages (`/messages`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/messages/conversations` | Mes conversations |
| GET | `/messages/conversations/:id` | Messages conversation |
| POST | `/messages/send` | Envoyer message |
| PATCH | `/messages/:id/read` | Marquer lu |

### 📅 Availabilities (`/availabilities`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/availabilities` | Définir disponibilité |
| POST | `/availabilities/bulk` | Définir en masse |
| GET | `/availabilities/my` | Mes disponibilités |
| DELETE | `/availabilities/:date` | Supprimer |
| GET | `/availabilities/worker/:id` | Disponibilités travailleur |
| GET | `/availabilities/search` | Rechercher disponibles |

### 🎓 Diplomas (`/diplomas`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/diplomas` | Ajouter diplôme |
| GET | `/diplomas/my` | Mes diplômes |
| PUT | `/diplomas/:id` | Modifier |
| DELETE | `/diplomas/:id` | Supprimer |
| GET | `/diplomas/worker/:id` | Diplômes travailleur |
| PATCH | `/diplomas/:id/verify` | Vérifier (admin) |

### 🔔 Notifications (`/notifications`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/notifications` | Mes notifications |
| PATCH | `/notifications/:id/read` | Marquer lue |
| PATCH | `/notifications/read-all` | Tout marquer lu |
| DELETE | `/notifications/:id` | Supprimer |
| DELETE | `/notifications/read/all` | Supprimer lues |

### 🗺️ Regions (`/regions`, `/cities`, `/specialties`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/regions` | Liste régions |
| GET | `/regions/:id/cities` | Villes d'une région |
| GET | `/cities` | Toutes les villes |
| GET | `/specialties` | Spécialités |

### 📊 Stats (`/stats`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/stats/public` | Stats publiques |
| GET | `/stats/worker` | Stats travailleur |
| GET | `/stats/establishment` | Stats établissement |

### 👑 Admin (`/admin`)
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/admin/dashboard` | Dashboard stats |
| GET | `/admin/workers/pending` | Travailleurs en attente |
| PATCH | `/admin/workers/:id/approve` | Approuver travailleur |
| PATCH | `/admin/workers/:id/reject` | Rejeter travailleur |
| GET | `/admin/workers/labeled` | Travailleurs labellisés |
| PATCH | `/admin/workers/:id/label` | Accorder label |
| PATCH | `/admin/workers/:id/unlabel` | Retirer label |
| GET | `/admin/diplomas/pending` | Diplômes en attente |
| PATCH | `/admin/diplomas/:id/verify` | Vérifier diplôme |
| GET | `/admin/establishments/pending` | Établissements en attente |
| PATCH | `/admin/establishments/:id/approve` | Approuver établissement |
| PATCH | `/admin/establishments/:id/reject` | Rejeter établissement |
| GET | `/admin/users` | Liste utilisateurs |
| GET | `/admin/applications` | Toutes candidatures |

---

## 🚦 Rate Limiting

| Endpoint | Limite | Fenêtre |
|----------|--------|---------|
| Général | 100 req | 15 min |
| Auth (login) | 5 req | 15 min |
| Inscription | 5 req | 1 heure |
| Upload | 20 req | 1 heure |
| Candidatures | 10 req | 1 heure |
| Admin | 500 req | 15 min |

---

## 📊 Codes de Réponse

| Code | Description |
|------|-------------|
| 200 | Succès |
| 201 | Ressource créée |
| 400 | Requête invalide |
| 401 | Non authentifié |
| 403 | Accès refusé |
| 404 | Non trouvé |
| 429 | Rate limit dépassé |
| 500 | Erreur serveur |

---

## 📁 Upload de Fichiers

- **Formats:** JPEG, PNG, PDF
- **Taille max:** 5 MB
- **Accès:** `/uploads/<chemin>`

---

## 🔧 Démarrage

```bash
# Backend
cd backend
npm install
npm run dev

# Accéder à Swagger
open http://localhost:5000/api-docs
```

---

## 📞 Support

- **Email:** support@tadamon.ma
- **Documentation:** https://docs.tadamon.ma

---

*Documentation générée automatiquement via Swagger/OpenAPI 3.0*
