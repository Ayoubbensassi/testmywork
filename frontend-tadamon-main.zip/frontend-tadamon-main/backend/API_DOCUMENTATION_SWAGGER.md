# 📚 API Documentation - TADAMON Platform

## Interactive API Documentation

The API documentation is available in **interactive Swagger format** at:

**🔗 http://localhost:5000/api-docs**

This provides:
- ✅ Interactive API testing
- ✅ Request/Response examples
- ✅ Authentication testing
- ✅ Schema definitions
- ✅ Try-it-out functionality

---

## Quick Start

### 1. Start the Backend Server
```bash
cd backend
npm run dev
```

### 2. Access Swagger UI
Open your browser and navigate to:
```
http://localhost:5000/api-docs
```

### 3. Authenticate
1. Use the `/auth/login` endpoint to get a JWT token
2. Click the "Authorize" button at the top of Swagger UI
3. Enter: `Bearer <your-token>`
4. Click "Authorize" to authenticate all requests

---

## Base URL

```
http://localhost:5000/api
```

---

## Authentication

Most endpoints require JWT authentication. Include the token in the Authorization header:

```
Authorization: Bearer <token>
```

### Getting a Token

**POST** `/auth/login`

```json
{
  "email": "worker@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": 1,
      "email": "worker@example.com",
      "role": "worker"
    }
  }
}
```

---

## API Endpoints Overview

### 🔐 Authentication (`/auth`)
- `POST /auth/register` - Register new user
- `POST /auth/login` - Login and get JWT token
- `GET /auth/me` - Get current user info
- `GET /auth/verify-email/:token` - Verify email
- `POST /auth/forgot-password` - Request password reset
- `POST /auth/reset-password/:token` - Reset password

### 👷 Workers (`/workers`)
- `GET /workers/profile` - Get worker profile
- `POST /workers/profile` - Create worker profile
- `PUT /workers/profile` - Update worker profile
- `GET /workers/search` - Search workers (establishments only)
- `GET /workers/:id` - Get public worker profile

### 🏢 Establishments (`/establishments`)
- `GET /establishments/profile` - Get establishment profile
- `POST /establishments/profile` - Create establishment profile
- `PUT /establishments/profile` - Update establishment profile

### 📋 Missions (`/missions`)
- `GET /missions` - List all missions (public)
- `GET /missions/search` - Search missions
- `GET /missions/:id` - Get mission details
- `POST /missions` - Create mission (establishment only)
- `PUT /missions/:id` - Update mission (establishment only)
- `DELETE /missions/:id` - Delete mission (establishment only)
- `GET /missions/my` - Get my missions (establishment only)

### 📝 Applications (`/applications`)
- `POST /applications` - Apply to mission (worker only)
- `GET /applications/my` - Get my applications (worker only)
- `GET /applications/received` - Get received applications (establishment only)
- `GET /applications/mission/:id` - Get applications for a mission
- `PATCH /applications/:id/accept` - Accept application (establishment only)
- `PATCH /applications/:id/reject` - Reject application (establishment only)
- `DELETE /applications/:id` - Withdraw application (worker only)

### ⭐ Reviews (`/reviews`)
- `POST /reviews` - Create review
- `GET /reviews/worker/:workerId` - Get worker reviews
- `GET /reviews/establishment/:establishmentId` - Get establishment reviews

### 📅 Availabilities (`/availabilities`)
- `POST /availabilities` - Set availability (worker only)
- `POST /availabilities/bulk` - Bulk set availabilities (worker only)
- `GET /availabilities/my` - Get my availabilities (worker only)
- `PUT /availabilities/:id` - Update availability (worker only)
- `DELETE /availabilities/:id` - Delete availability (worker only)

### 🎓 Diplomas (`/diplomas`)
- `GET /diplomas/my` - Get my diplomas (worker only)
- `POST /diplomas` - Add diploma (worker only)
- `POST /diplomas/upload` - Upload diploma file (worker only)
- `PUT /diplomas/:id` - Update diploma (worker only)
- `DELETE /diplomas/:id` - Delete diploma (worker only)

### 💼 Experiences (`/experiences`)
- `GET /experiences/my` - Get my experiences (worker only)
- `POST /experiences` - Add experience (worker only)
- `PUT /experiences/:id` - Update experience (worker only)
- `DELETE /experiences/:id` - Delete experience (worker only)

### 🌍 Regions (`/regions`)
- `GET /regions` - Get all regions
- `GET /regions/:id/cities` - Get cities by region
- `GET /cities` - Get all cities
- `GET /specialties` - Get all specialties

### 👨‍💼 Admin (`/admin`)
- `GET /admin/dashboard` - Get admin dashboard stats
- `GET /admin/users` - Get all users
- `GET /admin/workers/pending` - Get pending workers
- `PATCH /admin/workers/:id/approve` - Approve worker
- `PATCH /admin/workers/:id/reject` - Reject worker
- `PATCH /admin/workers/:id/label` - Grant label to worker
- `GET /admin/establishments/pending` - Get pending establishments
- `PATCH /admin/establishments/:id/approve` - Approve establishment
- `GET /admin/diplomas/pending` - Get pending diplomas
- `PATCH /admin/diplomas/:id/verify` - Verify diploma

### 📊 Stats (`/stats`)
- `GET /stats/public` - Get public statistics

### 💬 Messages (`/messages`)
- `GET /messages/conversations` - Get conversations
- `GET /messages/conversation/:id` - Get messages in conversation
- `POST /messages` - Send message
- `POST /messages/start` - Start new conversation

### 🔔 Notifications (`/notifications`)
- `GET /notifications` - Get notifications
- `PATCH /notifications/:id/read` - Mark notification as read
- `PATCH /notifications/read-all` - Mark all as read

---

## Response Format

### Success Response
```json
{
  "status": "success",
  "message": "Operation successful",
  "data": {
    // Response data
  }
}
```

### Error Response
```json
{
  "status": "error",
  "message": "Error description"
}
```

---

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `500` - Internal Server Error

---

## Rate Limiting

- **General API**: 100 requests per 15 minutes
- **Authentication**: 5 requests per 15 minutes
- **Registration**: 5 requests per hour
- **File Uploads**: 20 requests per hour
- **Applications**: 10 requests per hour

---

## File Uploads

### Supported File Types
- PDF (`.pdf`)
- Images (`.jpg`, `.jpeg`, `.png`)

### Maximum File Size
- 5MB per file

### Upload Endpoints
- `POST /diplomas/upload` - Upload diploma PDF
- `POST /workers/profile/documents` - Upload worker documents (CIN, CV)

---

## WebSocket (Real-time Messaging)

The API supports real-time messaging via Socket.io:

**Connection:**
```javascript
const socket = io('http://localhost:5000');

// Join with user ID
socket.emit('user:join', userId);

// Send message
socket.emit('message:send', {
  recipientId: 123,
  content: 'Hello!',
  senderId: userId
});

// Receive message
socket.on('message:receive', (data) => {
  console.log('New message:', data);
});
```

---

## Testing with Swagger UI

1. **Open Swagger UI**: http://localhost:5000/api-docs
2. **Login**: Use `/auth/login` to get a token
3. **Authorize**: Click "Authorize" button and enter `Bearer <token>`
4. **Test Endpoints**: Click "Try it out" on any endpoint
5. **View Responses**: See real responses from your API

---

## Additional Resources

- **Health Check**: `GET /api/health`
- **Swagger JSON**: `GET /api-docs.json`
- **Swagger UI**: `GET /api-docs`

---

## Support

For questions or issues:
- Check the interactive Swagger documentation
- Review the code comments in route files
- Contact: elmouddenlhoussen324@gmail.com

---

*Last updated: $(date)*

