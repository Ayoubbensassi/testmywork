# 📚 API DOCUMENTATION - LKHEDMA SOCIAL

## Base URL
```
http://localhost:5000/api
```

## Authentication
All protected routes require a JWT token in the header:
```
Authorization: Bearer <token>
```

---

## 🔐 AUTH ENDPOINTS

### Register
```http
POST /auth/register
```
**Body:**
```json
{
  "email": "user@example.com",
  "password": "Password123",
  "role": "worker" | "establishment"
}
```

### Login
```http
POST /auth/login
```
**Body:**
```json
{
  "email": "user@example.com",
  "password": "Password123"
}
```
**Response:** Returns JWT token

### Get Current User
```http
GET /auth/me
```
**Auth:** Required

---

## 👷 WORKER ENDPOINTS

### Create Profile
```http
POST /workers/profile
```
**Auth:** Worker only
**Body:**
```json
{
  "first_name": "Ahmed",
  "last_name": "Benali",
  "cin": "A123456",
  "phone": "0612345678",
  "birth_date": "1990-01-15",
  "region_id": 6,
  "city_id": 1,
  "address": "123 Rue Example",
  "mobility_radius": 50,
  "bio": "Éducateur spécialisé avec 5 ans d'expérience",
  "daily_rate": 500
}
```

### Get My Profile
```http
GET /workers/profile
```
**Auth:** Worker only

### Update Profile
```http
PUT /workers/profile
```
**Auth:** Worker only

### Upload Documents
```http
POST /workers/profile/documents
```
**Auth:** Worker only
**Content-Type:** multipart/form-data
**Fields:** cin_front, cin_back, cv, profile_picture

### Add Specialty
```http
POST /workers/specialties
```
**Auth:** Worker only
**Body:**
```json
{
  "specialty_id": 1,
  "years_experience": 3,
  "proficiency_level": "expert"
}
```

### Search Workers (for Establishments)
```http
GET /workers/search?region_id=6&is_labeled=true&min_experience=2&specialty_id=1
```
**Auth:** Establishment/Admin
**Query Params:**
- region_id, city_id
- is_labeled (true/false) - Filter by "Label Réseau"
- min_experience
- min_rating
- specialty_id
- search (name search)

---

## 🏢 ESTABLISHMENT ENDPOINTS

### Create Profile
```http
POST /establishments/profile
```
**Auth:** Establishment only
**Body:**
```json
{
  "name": "Association Solidarité",
  "ice": "123456789012345",
  "type": "association",
  "phone": "0522123456",
  "region_id": 6,
  "city_id": 1,
  "address": "456 Boulevard Example",
  "description": "Association d'aide aux personnes handicapées"
}
```

### Get/Update Profile
```http
GET /establishments/profile
PUT /establishments/profile
```
**Auth:** Establishment only

---

## 📋 MISSION ENDPOINTS

### Create Mission
```http
POST /missions
```
**Auth:** Establishment only
**Body:**
```json
{
  "title": "Éducateur spécialisé - Remplacement",
  "description": "Remplacement congé maternité...",
  "mission_type": "remplacement",
  "start_date": "2025-02-01",
  "end_date": "2025-04-30",
  "salary_min": 400,
  "salary_max": 600,
  "region_id": 6,
  "city_id": 1,
  "required_experience": 2,
  "is_urgent": true
}
```

### List Missions
```http
GET /missions?status=open&region_id=6&is_urgent=true
```
**Auth:** Required

### Search Missions
```http
GET /missions/search?search=éducateur&region_id=6
```
**Auth:** Required

### Publish Mission
```http
PATCH /missions/:id/publish
```
**Auth:** Establishment (owner)

---

## 📝 APPLICATION ENDPOINTS

### Apply to Mission
```http
POST /applications
```
**Auth:** Worker only
**Body:**
```json
{
  "mission_id": 1,
  "cover_letter": "Je suis intéressé par cette mission...",
  "proposed_rate": 500
}
```

### Get My Applications
```http
GET /applications/my
```
**Auth:** Worker only

### Get Mission Applications
```http
GET /missions/:id/applications
```
**Auth:** Establishment (owner)

### Accept/Reject Application
```http
PATCH /applications/:id/accept
PATCH /applications/:id/reject
```
**Auth:** Establishment (owner)

---

## 📅 AVAILABILITY ENDPOINTS

### Set Availability
```http
POST /availabilities
```
**Auth:** Worker only
**Body:**
```json
{
  "date": "2025-01-15",
  "start_time": "08:00",
  "end_time": "18:00",
  "is_available": true
}
```

### Bulk Set Availabilities
```http
POST /availabilities/bulk
```
**Auth:** Worker only
**Body:**
```json
{
  "availabilities": [
    { "date": "2025-01-15", "is_available": true },
    { "date": "2025-01-16", "is_available": true },
    { "date": "2025-01-17", "is_available": false }
  ]
}
```

### Get My Availabilities
```http
GET /availabilities/my?year=2025&month=1
```
**Auth:** Worker only

### Find Available Workers
```http
GET /availabilities/search?start_date=2025-01-15&end_date=2025-01-20&region_id=6
```
**Auth:** Establishment only

---

## 🎓 DIPLOMA ENDPOINTS

### Add Diploma
```http
POST /diplomas
```
**Auth:** Worker only
**Content-Type:** multipart/form-data
**Fields:** title, institution, obtained_date, diploma (file)

### Get My Diplomas
```http
GET /diplomas/my
```
**Auth:** Worker only

---

## 💼 EXPERIENCE ENDPOINTS

### Add Experience
```http
POST /experiences
```
**Auth:** Worker only
**Body:**
```json
{
  "job_title": "Éducateur spécialisé",
  "employer": "Association ABC",
  "start_date": "2020-01-01",
  "end_date": "2023-12-31",
  "is_current": false,
  "description": "Accompagnement de jeunes en difficulté"
}
```

### Get My Experiences
```http
GET /experiences/my
```
**Auth:** Worker only

---

## ⭐ REVIEW ENDPOINTS

### Create Review
```http
POST /reviews
```
**Auth:** Required (after mission completion)
**Body:**
```json
{
  "mission_id": 1,
  "reviewee_id": 5,
  "rating": 5,
  "comment": "Excellent travail, très professionnel"
}
```

### Get Worker Reviews
```http
GET /reviews/worker/:workerId
```

### Get Establishment Reviews
```http
GET /reviews/establishment/:establishmentId
```

---

## 💬 MESSAGE ENDPOINTS

### Get My Conversations
```http
GET /messages/conversations
```
**Auth:** Required

### Get Conversation Messages
```http
GET /messages/conversations/:id
```
**Auth:** Required

### Send Message
```http
POST /messages
```
**Auth:** Required
**Body:**
```json
{
  "conversation_id": 1,
  "content": "Bonjour, je suis intéressé..."
}
```

---

## 🔔 NOTIFICATION ENDPOINTS

### Get My Notifications
```http
GET /notifications?unread_only=true
```
**Auth:** Required

### Mark as Read
```http
PATCH /notifications/:id/read
PATCH /notifications/read-all
```
**Auth:** Required

---

## 🛡️ ADMIN ENDPOINTS

### Dashboard Stats
```http
GET /admin/dashboard
```
**Auth:** Admin only

### Pending Workers
```http
GET /admin/workers/pending
```

### Approve/Reject Worker
```http
PATCH /admin/workers/:id/approve
PATCH /admin/workers/:id/reject
```
**Body (reject):**
```json
{
  "reason": "Documents non conformes"
}
```

### Grant/Revoke Label Réseau
```http
PATCH /admin/workers/:id/label
PATCH /admin/workers/:id/unlabel
```

### Pending Diplomas
```http
GET /admin/diplomas/pending
```

### Verify Diploma
```http
PATCH /admin/diplomas/:id/verify
```

### Issue Warning
```http
POST /admin/warnings
```
**Body:**
```json
{
  "user_id": 5,
  "rule_id": 1,
  "reason": "Annulation de 3 missions sans préavis"
}
```

---

## 🌍 REGION ENDPOINTS

### Get All Regions
```http
GET /regions
```

### Get Cities by Region
```http
GET /regions/:regionId/cities
```

### Get All Specialties
```http
GET /specialties
```

---

## Error Responses

All errors follow this format:
```json
{
  "status": "error",
  "message": "Description de l'erreur"
}
```

### Common HTTP Status Codes
- 200: Success
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 403: Forbidden
- 404: Not Found
- 409: Conflict
- 500: Server Error
