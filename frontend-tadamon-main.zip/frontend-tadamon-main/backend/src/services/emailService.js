const nodemailer = require('nodemailer');

// Initialize Nodemailer - supports Gmail or Mailtrap
let transporter = null;

if (process.env.MAILTRAP_USER && process.env.MAILTRAP_PASS) {
  // Mailtrap for testing (free, no restrictions)
  transporter = nodemailer.createTransport({
    host: 'sandbox.smtp.mailtrap.io',
    port: 587,
    auth: {
      user: process.env.MAILTRAP_USER,
      pass: process.env.MAILTRAP_PASS
    }
  });
  console.log('✅ Email service initialized (Mailtrap)');
} else if (process.env.GMAIL_USER && process.env.GMAIL_APP_PASSWORD) {
  // Gmail for production
  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_APP_PASSWORD
    }
  });
  console.log('✅ Email service initialized (Gmail)');
} else {
  console.log('⚠️ Email not configured - emails will be logged to console');
}

const FROM_EMAIL = 'LKHEDMA Social <noreply@lkhedma.ma>';

/**
 * Send verification email to new user
 */
async function sendVerificationEmail(to, verificationToken, userName) {
  const verificationUrl = `${process.env.FRONTEND_URL}/verify-email?token=${verificationToken}`;
  
  if (!transporter) {
    console.log('📧 [EMAIL SIMULATION] Verification email would be sent to:', to);
    console.log('🔗 Verification URL:', verificationUrl);
    return { success: true, data: { message: 'Email logged to console' } };
  }
  
  try {
    const info = await transporter.sendMail({
      from: FROM_EMAIL,
      to: to,
      subject: 'Vérifiez votre email - LKHEDMA Social',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
            .header { background: linear-gradient(135deg, #1B68F8 0%, #003EB0 100%); padding: 40px 30px; text-align: center; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { padding: 40px 30px; }
            .content h2 { color: #1e293b; margin-top: 0; }
            .content p { color: #64748b; line-height: 1.6; }
            .btn { display: inline-block; background: linear-gradient(135deg, #1B68F8 0%, #003EB0 100%); color: white; padding: 14px 32px; text-decoration: none; border-radius: 10px; font-weight: 600; margin: 20px 0; }
            .footer { background: #f8fafc; padding: 20px 30px; text-align: center; color: #94a3b8; font-size: 14px; }
            .code { background: #f1f5f9; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 14px; text-align: center; margin: 20px 0; word-break: break-all; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🤝 LKHEDMA Social</h1>
            </div>
            <div class="content">
              <h2>Bienvenue ${userName || ''} !</h2>
              <p>Merci de vous être inscrit sur LKHEDMA Social, la plateforme de mise en relation pour les travailleurs sociaux au Maroc.</p>
              <p>Pour activer votre compte, veuillez vérifier votre adresse email en cliquant sur le bouton ci-dessous :</p>
              <div style="text-align: center;">
                <a href="${verificationUrl}" class="btn">Vérifier mon email</a>
              </div>
              <p style="font-size: 14px; color: #94a3b8;">Si le bouton ne fonctionne pas, copiez ce lien :</p>
              <div class="code">${verificationUrl}</div>
              <p style="font-size: 14px; color: #94a3b8;">Ce lien expire dans 24 heures.</p>
            </div>
            <div class="footer">
              <p>© 2025 LKHEDMA Social - Réseau de travailleurs sociaux</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log('✅ Verification email sent to:', to);
    return { success: true, data: info };
  } catch (error) {
    console.error('❌ Email send error:', error);
    return { success: false, error };
  }
}


/**
 * Send password reset email
 */
async function sendPasswordResetEmail(to, resetToken, userName) {
  const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;
  
  if (!transporter) {
    console.log('📧 [EMAIL SIMULATION] Password reset email would be sent to:', to);
    console.log('🔗 Reset URL:', resetUrl);
    return { success: true, data: { message: 'Email logged to console' } };
  }
  
  try {
    const info = await transporter.sendMail({
      from: FROM_EMAIL,
      to: to,
      subject: 'Réinitialisation de mot de passe - LKHEDMA Social',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
            .header { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); padding: 40px 30px; text-align: center; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { padding: 40px 30px; }
            .content h2 { color: #1e293b; margin-top: 0; }
            .content p { color: #64748b; line-height: 1.6; }
            .btn { display: inline-block; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 14px 32px; text-decoration: none; border-radius: 10px; font-weight: 600; margin: 20px 0; }
            .footer { background: #f8fafc; padding: 20px 30px; text-align: center; color: #94a3b8; font-size: 14px; }
            .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; border-radius: 0 8px 8px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🔐 Réinitialisation</h1>
            </div>
            <div class="content">
              <h2>Bonjour ${userName || ''}</h2>
              <p>Vous avez demandé la réinitialisation de votre mot de passe sur LKHEDMA Social.</p>
              <div style="text-align: center;">
                <a href="${resetUrl}" class="btn">Réinitialiser mon mot de passe</a>
              </div>
              <div class="warning">
                <strong>⚠️ Important :</strong> Ce lien expire dans 1 heure.
              </div>
            </div>
            <div class="footer">
              <p>© 2025 LKHEDMA Social</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log('✅ Password reset email sent to:', to);
    return { success: true, data: info };
  } catch (error) {
    console.error('❌ Email send error:', error);
    return { success: false, error };
  }
}

/**
 * Send welcome email after verification
 */
async function sendWelcomeEmail(to, userName, role) {
  const dashboardUrl = `${process.env.FRONTEND_URL}/dashboard/${role === 'worker' ? 'travailleur' : 'etablissement'}`;
  
  if (!transporter) {
    console.log('📧 [EMAIL SIMULATION] Welcome email would be sent to:', to);
    return { success: true, data: { message: 'Email logged to console' } };
  }
  
  try {
    const info = await transporter.sendMail({
      from: FROM_EMAIL,
      to: to,
      subject: 'Bienvenue sur LKHEDMA Social ! 🎉',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 40px 30px; text-align: center; }
            .header h1 { color: white; margin: 0; font-size: 28px; }
            .content { padding: 40px 30px; }
            .btn { display: inline-block; background: linear-gradient(135deg, #1B68F8 0%, #003EB0 100%); color: white; padding: 14px 32px; text-decoration: none; border-radius: 10px; font-weight: 600; }
            .footer { background: #f8fafc; padding: 20px 30px; text-align: center; color: #94a3b8; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Compte activé !</h1>
            </div>
            <div class="content">
              <h2 style="color: #1e293b;">Félicitations ${userName || ''} !</h2>
              <p style="color: #64748b;">Votre compte LKHEDMA Social est maintenant activé.</p>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${dashboardUrl}" class="btn">Accéder à mon tableau de bord</a>
              </div>
            </div>
            <div class="footer">
              <p>© 2025 LKHEDMA Social</p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log('✅ Welcome email sent to:', to);
    return { success: true, data: info };
  } catch (error) {
    console.error('❌ Email send error:', error);
    return { success: false, error };
  }
}

/**
 * Send notification email for new application
 */
async function sendApplicationNotification(to, establishmentName, workerName, missionTitle) {
  if (!transporter) {
    console.log('📧 [EMAIL SIMULATION] Application notification to:', to);
    return { success: true, data: { message: 'Email logged to console' } };
  }
  
  try {
    const info = await transporter.sendMail({
      from: FROM_EMAIL,
      to: to,
      subject: `Nouvelle candidature - ${missionTitle}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head><meta charset="utf-8"></head>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
          <div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
            <div style="background: linear-gradient(135deg, #1B68F8 0%, #003EB0 100%); padding: 30px; text-align: center;">
              <h1 style="color: white; margin: 0;">📩 Nouvelle candidature</h1>
            </div>
            <div style="padding: 30px;">
              <p>Bonjour ${establishmentName},</p>
              <div style="background: #dbeafe; padding: 20px; border-radius: 12px; margin: 20px 0;">
                <p style="margin: 0;"><strong>${workerName}</strong> a postulé à :</p>
                <p style="margin: 10px 0 0 0; font-size: 18px; color: #1B68F8;"><strong>${missionTitle}</strong></p>
              </div>
              <div style="text-align: center;">
                <a href="${process.env.FRONTEND_URL}/dashboard/etablissement" style="display: inline-block; background: #1B68F8; color: white; padding: 12px 28px; text-decoration: none; border-radius: 10px; font-weight: 600;">Voir la candidature</a>
              </div>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    return { success: true, data: info };
  } catch (error) {
    return { success: false, error };
  }
}

module.exports = {
  sendVerificationEmail,
  sendPasswordResetEmail,
  sendWelcomeEmail,
  sendApplicationNotification,
};
