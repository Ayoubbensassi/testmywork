const { validationResult } = require('express-validator');

/**
 * Middleware to check for validation errors
 * Should be placed after the validation chain arrays
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    // Return 400 Bad Request with error details
    return res.status(400).json({
      status: 'error',
      message: 'Données invalides',
      errors: errors.array()
    });
  }
  next();
};

module.exports = validateRequest;
