/**
 * Global Error Handler Middleware
 * Gère toutes les erreurs de l'application de manière centralisée
 */

function errorHandler(err, req, res, next) {
  // Log l'erreur (en production, utiliser un service comme Winston)
  console.error(`[ERROR] ${new Date().toISOString()} - ${req.method} ${req.path}`);
  console.error(err.stack);

  // Erreur de validation Joi/express-validator
  if (err.name === 'ValidationError' || err.type === 'validation') {
    return res.status(400).json({
      status: 'error',
      message: err.message || 'Données invalides',
      errors: err.errors || undefined
    });
  }

  // Erreur JWT
  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({
      status: 'error',
      message: 'Token invalide'
    });
  }

  // Token expiré
  if (err.name === 'TokenExpiredError') {
    return res.status(401).json({
      status: 'error',
      message: 'Session expirée, veuillez vous reconnecter'
    });
  }

  // Erreur Multer (upload)
  if (err.name === 'MulterError') {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        status: 'error',
        message: 'Fichier trop volumineux (max 5MB)'
      });
    }
    return res.status(400).json({
      status: 'error',
      message: `Erreur upload: ${err.message}`
    });
  }

  // Erreur MySQL - Duplicate entry
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({
      status: 'error',
      message: 'Cette donnée existe déjà'
    });
  }

  // Erreur MySQL - Foreign key constraint
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(400).json({
      status: 'error',
      message: 'Référence invalide (donnée liée inexistante)'
    });
  }

  // Erreur par défaut
  const statusCode = err.status || err.statusCode || 500;
  const message = statusCode === 500 
    ? 'Erreur serveur interne' 
    : err.message;

  res.status(statusCode).json({
    status: 'error',
    message,
    // Stack trace uniquement en développement
    ...(process.env.NODE_ENV === 'development' && { 
      stack: err.stack,
      details: err.message 
    })
  });
}

module.exports = errorHandler;
