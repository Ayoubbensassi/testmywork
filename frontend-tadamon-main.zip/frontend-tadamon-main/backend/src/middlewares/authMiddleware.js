const { verifyToken } = require('../utils/generateToken');
const User = require('../models/User');

async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        status: 'error',
        message: 'Token manquant. Veuillez vous connecter.'
      });
    }

    const token = authHeader.split(' ')[1];
    
    // Handle demo tokens - allow them to access the API with appropriate role
    // ONLY in development mode for testing purposes
    if (process.env.ENABLE_DEMO_TOKENS === 'true' && token.startsWith('demo-token-')) {
      const role = token.replace('demo-token-', '');
      req.user = {
        id: 0,
        email: `demo.${role}@lkhedma.ma`,
        role: role // 'admin', 'worker', or 'establishment'
      };
      return next();
    }
    
    const decoded = verifyToken(token);
    
    if (!decoded) {
      return res.status(401).json({
        status: 'error',
        message: 'Token invalide ou expiré.'
      });
    }

    const user = await User.findById(decoded.id);
    
    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'Utilisateur non trouvé.'
      });
    }

    if (!user.is_active) {
      return res.status(403).json({
        status: 'error',
        message: 'Compte désactivé. Contactez l\'administrateur.'
      });
    }

    req.user = {
      id: user.id,
      email: user.email,
      role: user.role
    };

    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Erreur d\'authentification'
    });
  }
}

// Optional authentication - doesn't fail if no token, just sets req.user if valid
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      req.user = null;
      return next();
    }

    const token = authHeader.split(' ')[1];
    
    // Handle demo tokens - ONLY in development mode
    if (process.env.ENABLE_DEMO_TOKENS === 'true' && token.startsWith('demo-token-')) {
      const role = token.replace('demo-token-', '');
      req.user = {
        id: 0,
        email: `demo.${role}@lkhedma.ma`,
        role: role
      };
      return next();
    }
    
    const decoded = verifyToken(token);
    
    if (!decoded) {
      req.user = null;
      return next();
    }

    const user = await User.findById(decoded.id);
    
    if (user && user.is_active) {
      req.user = {
        id: user.id,
        email: user.email,
        role: user.role
      };
    } else {
      req.user = null;
    }

    next();
  } catch (error) {
    req.user = null;
    next();
  }
}

module.exports = { authenticate, optionalAuth };
