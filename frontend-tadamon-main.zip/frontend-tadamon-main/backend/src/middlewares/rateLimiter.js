const rateLimit = require('express-rate-limit');

// Limiteur général pour toutes les requêtes API
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // 500 requêtes par fenêtre (augmenté pour le développement)
  message: {
    status: 'error',
    message: 'Trop de requêtes, veuillez réessayer dans 15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Limiteur strict pour l'authentification (protection brute-force)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // 50 tentatives (augmenté pour le développement)
  message: {
    status: 'error',
    message: 'Trop de tentatives de connexion, veuillez réessayer dans 15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true // Ne compte pas les requêtes réussies
});

// Limiteur pour la création de compte (anti-spam)
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 heure
  max: 20, // 20 inscriptions par heure par IP (augmenté pour le développement)
  message: {
    status: 'error',
    message: 'Trop de créations de compte, veuillez réessayer plus tard'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Limiteur pour les uploads (protection ressources serveur)
const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 heure
  max: 20, // 20 uploads par heure
  message: {
    status: 'error',
    message: 'Trop de fichiers uploadés, veuillez réessayer plus tard'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Limiteur pour les candidatures (anti-spam)
const applicationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 heure
  max: 10, // 10 candidatures par heure
  message: {
    status: 'error',
    message: 'Trop de candidatures envoyées, veuillez réessayer plus tard'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Limiteur pour les admins (plus permissif pour le dashboard)
const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // 500 requêtes par fenêtre (dashboard refresh toutes les 30s)
  message: {
    status: 'error',
    message: 'Trop de requêtes admin, veuillez réessayer dans quelques minutes'
  },
  standardHeaders: true,
  legacyHeaders: false
});

module.exports = {
  generalLimiter,
  authLimiter,
  registerLimiter,
  uploadLimiter,
  applicationLimiter,
  adminLimiter
};
