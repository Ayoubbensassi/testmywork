const express = require('express');
const router = express.Router();
const availabilityController = require('../controllers/availabilityController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');

/**
 * @swagger
 * /availabilities:
 *   post:
 *     summary: Définir une disponibilité (travailleur)
 *     tags: [Availabilities]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - date
 *             properties:
 *               date:
 *                 type: string
 *                 format: date
 *               start_time:
 *                 type: string
 *               end_time:
 *                 type: string
 *               is_available:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Disponibilité enregistrée
 */
router.post('/', authenticate, authorize('worker'), availabilityController.setAvailability);

/**
 * @swagger
 * /availabilities/bulk:
 *   post:
 *     summary: Définir plusieurs disponibilités en une fois (travailleur)
 *     tags: [Availabilities]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               availabilities:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     date:
 *                       type: string
 *                       format: date
 *                     is_available:
 *                       type: boolean
 *     responses:
 *       200:
 *         description: Disponibilités enregistrées
 */
router.post('/bulk', authenticate, authorize('worker'), availabilityController.bulkSetAvailabilities);

/**
 * @swagger
 * /availabilities/my:
 *   get:
 *     summary: Obtenir mes disponibilités (travailleur)
 *     tags: [Availabilities]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: year
 *         schema:
 *           type: integer
 *       - in: query
 *         name: month
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Liste des disponibilités
 */
router.get('/my', authenticate, authorize('worker'), availabilityController.getMyAvailabilities);

/**
 * @swagger
 * /availabilities/{date}:
 *   delete:
 *     summary: Supprimer une disponibilité (travailleur)
 *     tags: [Availabilities]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *     responses:
 *       200:
 *         description: Disponibilité supprimée
 */
router.delete('/:date', authenticate, authorize('worker'), availabilityController.deleteAvailability);

/**
 * @swagger
 * /availabilities/worker/{workerId}:
 *   get:
 *     summary: Obtenir les disponibilités d'un travailleur (établissement)
 *     tags: [Availabilities]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workerId
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Disponibilités du travailleur
 */
router.get('/worker/:workerId', authenticate, availabilityController.getWorkerAvailabilities);

/**
 * @swagger
 * /availabilities/search:
 *   get:
 *     summary: Rechercher des travailleurs disponibles (établissement)
 *     tags: [Availabilities]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Travailleurs disponibles
 */
router.get('/search', authenticate, authorize('establishment'), availabilityController.findAvailableWorkers);

module.exports = router;
