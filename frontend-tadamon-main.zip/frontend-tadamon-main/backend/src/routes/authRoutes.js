const express = require('express');
const router = express.Router();
const passport = require('../config/passport');
const jwt = require('jsonwebtoken');
const authController = require('../controllers/authController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authLimiter, registerLimiter } = require('../middlewares/rateLimiter');
const User = require('../models/User');

/**
 * @swagger
 * /auth/register:
 *   post:
 *     summary: Inscription d'un nouvel utilisateur
 *     description: |
 *       Crée un nouveau compte utilisateur sur la plateforme TADAMON.
 *       
 *       **Processus d'inscription:**
 *       1. Création du compte avec email/mot de passe
 *       2. Envoi d'un email de vérification
 *       3. Redirection vers l'onboarding pour compléter le profil
 *       
 *       **Règles du mot de passe:**
 *       - Minimum 6 caractères
 *       - Recommandé: majuscules, minuscules, chiffres
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UserRegistration'
 *           examples:
 *             worker:
 *               summary: Inscription travailleur
 *               value:
 *                 email: travailleur@example.com
 *                 password: MotDePasse123!
 *                 role: worker
 *             establishment:
 *               summary: Inscription établissement
 *               value:
 *                 email: etablissement@example.com
 *                 password: MotDePasse123!
 *                 role: establishment
 *     responses:
 *       201:
 *         description: Compte créé avec succès
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *       400:
 *         description: Données invalides ou email déjà utilisé
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             examples:
 *               email_exists:
 *                 summary: Email déjà utilisé
 *                 value:
 *                   status: error
 *                   message: Cet email est déjà utilisé
 *               invalid_password:
 *                 summary: Mot de passe trop court
 *                 value:
 *                   status: error
 *                   message: Le mot de passe doit contenir au moins 6 caractères
 *       429:
 *         $ref: '#/components/responses/RateLimitError'
 */
router.post('/register', registerLimiter, authController.register);

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Connexion d'un utilisateur
 *     description: |
 *       Authentifie un utilisateur et retourne un token JWT.
 *       
 *       **Durée du token:** 7 jours
 *       
 *       **Protection anti-brute-force:** 5 tentatives max par 15 minutes
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginCredentials'
 *           example:
 *             email: user@example.com
 *             password: MotDePasse123!
 *     responses:
 *       200:
 *         description: Connexion réussie
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *             example:
 *               status: success
 *               data:
 *                 token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 *                 user:
 *                   id: 1
 *                   email: user@example.com
 *                   role: worker
 *                   is_verified: true
 *       401:
 *         description: Identifiants invalides
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *             example:
 *               status: error
 *               message: Email ou mot de passe incorrect
 *       429:
 *         $ref: '#/components/responses/RateLimitError'
 */
router.post('/login', authLimiter, authController.login);

/**
 * @swagger
 * /auth/verify-email/{token}:
 *   get:
 *     summary: Vérifier l'adresse email
 *     description: |
 *       Vérifie l'adresse email d'un utilisateur via le lien envoyé par email.
 *       Le token est valide pendant 24 heures.
 *     tags: [Auth]
 *     parameters:
 *       - in: path
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Token de vérification reçu par email
 *         example: abc123def456...
 *     responses:
 *       200:
 *         description: Email vérifié avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Email vérifié avec succès
 *       400:
 *         description: Token invalide ou expiré
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
router.get('/verify-email/:token', authController.verifyEmail);

/**
 * @swagger
 * /auth/resend-verification:
 *   post:
 *     summary: Renvoyer l'email de vérification
 *     description: Renvoie un nouvel email de vérification à l'utilisateur
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *                 example: user@example.com
 *     responses:
 *       200:
 *         description: Email de vérification envoyé
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Email de vérification envoyé
 *       400:
 *         description: Email déjà vérifié ou compte inexistant
 *       429:
 *         $ref: '#/components/responses/RateLimitError'
 */
router.post('/resend-verification', authLimiter, authController.resendVerification);

/**
 * @swagger
 * /auth/forgot-password:
 *   post:
 *     summary: Demander une réinitialisation de mot de passe
 *     description: |
 *       Envoie un email avec un lien de réinitialisation de mot de passe.
 *       Le lien est valide pendant 1 heure.
 *     tags: [Auth]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *             properties:
 *               email:
 *                 type: string
 *                 format: email
 *                 example: user@example.com
 *     responses:
 *       200:
 *         description: Email de réinitialisation envoyé (si le compte existe)
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Si un compte existe avec cet email, vous recevrez un lien de réinitialisation
 *       429:
 *         $ref: '#/components/responses/RateLimitError'
 */
router.post('/forgot-password', authLimiter, authController.forgotPassword);

/**
 * @swagger
 * /auth/reset-password/{token}:
 *   post:
 *     summary: Réinitialiser le mot de passe
 *     description: Réinitialise le mot de passe avec le token reçu par email
 *     tags: [Auth]
 *     parameters:
 *       - in: path
 *         name: token
 *         required: true
 *         schema:
 *           type: string
 *         description: Token de réinitialisation reçu par email
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - password
 *             properties:
 *               password:
 *                 type: string
 *                 format: password
 *                 minLength: 6
 *                 example: NouveauMotDePasse123!
 *                 description: Nouveau mot de passe (min 6 caractères)
 *     responses:
 *       200:
 *         description: Mot de passe réinitialisé avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Mot de passe réinitialisé avec succès
 *       400:
 *         description: Token invalide ou expiré
 */
router.post('/reset-password/:token', authController.resetPassword);

/**
 * @swagger
 * /auth/google:
 *   get:
 *     summary: Connexion via Google OAuth
 *     description: |
 *       Redirige vers la page de connexion Google.
 *       Après authentification, l'utilisateur est redirigé vers le frontend avec un token.
 *       
 *       **Note:** Cette route redirige vers Google, elle ne retourne pas de JSON.
 *     tags: [Auth]
 *     parameters:
 *       - in: query
 *         name: role
 *         schema:
 *           type: string
 *           enum: [worker, establishment]
 *           default: worker
 *         description: Rôle pour les nouveaux comptes
 *     responses:
 *       302:
 *         description: Redirection vers Google OAuth
 */
router.get('/google', (req, res, next) => {
  const role = req.query.role || 'worker';
  const state = Buffer.from(JSON.stringify({ role })).toString('base64');
  
  passport.authenticate('google', {
    scope: ['profile', 'email'],
    state: state
  })(req, res, next);
});

/**
 * @swagger
 * /auth/google/callback:
 *   get:
 *     summary: Callback Google OAuth
 *     description: |
 *       Endpoint de callback appelé par Google après authentification.
 *       Redirige vers le frontend avec le token JWT.
 *       
 *       **Note:** Cette route est appelée automatiquement par Google.
 *     tags: [Auth]
 *     responses:
 *       302:
 *         description: Redirection vers le frontend avec token
 */
router.get('/google/callback', 
  passport.authenticate('google', { session: false, failureRedirect: `${process.env.FRONTEND_URL}/#/login?error=google_failed` }),
  async (req, res) => {
    try {
      const user = req.user;
      
      let role = 'worker';
      if (req.query.state) {
        try {
          const state = JSON.parse(Buffer.from(req.query.state, 'base64').toString());
          role = state.role || 'worker';
        } catch (e) {}
      }
      
      if (user.isNewUser) {
        const bcrypt = require('bcrypt');
        const randomPassword = require('crypto').randomBytes(32).toString('hex');
        const hashedPassword = await bcrypt.hash(randomPassword, 10);
        
        const newUserId = await User.create({
          email: user.email,
          password: hashedPassword,
          role: role,
          is_verified: true
        });
        
        const newUser = await User.findById(newUserId);
        const token = jwt.sign(
          { id: newUser.id, email: newUser.email, role: newUser.role },
          process.env.JWT_SECRET,
          { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );
        
        const redirectUrl = role === 'worker' ? 'onboarding/worker' : 'onboarding/establishment';
        res.redirect(`${process.env.FRONTEND_URL}/#/${redirectUrl}?token=${token}`);
      } else {
        const token = jwt.sign(
          { id: user.id, email: user.email, role: user.role },
          process.env.JWT_SECRET,
          { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );
        
        const redirectUrl = user.role === 'worker' ? 'worker/dashboard' : 
                           user.role === 'establishment' ? 'establishment/dashboard' : 
                           user.role === 'admin' ? 'admin/dashboard' : '';
        res.redirect(`${process.env.FRONTEND_URL}/#/${redirectUrl}?token=${token}`);
      }
    } catch (error) {
      console.error('Google OAuth callback error:', error);
      res.redirect(`${process.env.FRONTEND_URL}/#/login?error=google_failed`);
    }
  }
);

/**
 * @swagger
 * /auth/google/status:
 *   get:
 *     summary: Vérifier si Google OAuth est configuré
 *     description: Indique si l'authentification Google est disponible sur ce serveur
 *     tags: [Auth]
 *     responses:
 *       200:
 *         description: Statut de configuration Google OAuth
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     configured:
 *                       type: boolean
 *                       example: true
 *                       description: true si Google OAuth est configuré
 */
router.get('/google/status', (req, res) => {
  res.json({
    status: 'success',
    data: {
      configured: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET)
    }
  });
});

/**
 * @swagger
 * /auth/me:
 *   get:
 *     summary: Obtenir les informations de l'utilisateur connecté
 *     description: |
 *       Récupère les informations complètes de l'utilisateur authentifié.
 *       Inclut le profil associé (worker ou establishment) si existant.
 *     tags: [Auth]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Informations utilisateur
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     user:
 *                       allOf:
 *                         - $ref: '#/components/schemas/User'
 *                         - type: object
 *                           properties:
 *                             profile:
 *                               oneOf:
 *                                 - $ref: '#/components/schemas/WorkerProfile'
 *                                 - $ref: '#/components/schemas/EstablishmentProfile'
 *                               description: Profil associé (selon le rôle)
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.get('/me', authenticate, authController.getMe);

module.exports = router;
