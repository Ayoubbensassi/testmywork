const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');
const { authenticate } = require('../middlewares/authMiddleware');

/**
 * @swagger
 * /reviews:
 *   post:
 *     summary: Créer un avis après mission
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - mission_id
 *               - rating
 *             properties:
 *               mission_id:
 *                 type: integer
 *               rating:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 5
 *               comment:
 *                 type: string
 *     responses:
 *       201:
 *         description: Avis créé avec succès
 */
router.post('/', authenticate, reviewController.createReview);

/**
 * @swagger
 * /reviews/worker/{workerId}:
 *   get:
 *     summary: Obtenir les avis d'un travailleur
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workerId
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Liste des avis
 */
router.get('/worker/:workerId', authenticate, reviewController.getWorkerReviews);

/**
 * @swagger
 * /reviews/establishment/{establishmentId}:
 *   get:
 *     summary: Obtenir les avis d'un établissement
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: establishmentId
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Liste des avis
 */
router.get('/establishment/:establishmentId', authenticate, reviewController.getEstablishmentReviews);

/**
 * @swagger
 * /reviews/my:
 *   get:
 *     summary: Obtenir mes avis
 *     tags: [Reviews]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Mes avis
 */
router.get('/my', authenticate, reviewController.getMyReviews);

module.exports = router;
