const express = require('express');
const router = express.Router();
const diplomaController = require('../controllers/diplomaController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');
const upload = require('../config/multer');

/**
 * @swagger
 * /diplomas:
 *   post:
 *     summary: Ajouter un diplôme (travailleur)
 *     tags: [Diplomas]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - title
 *               - institution
 *             properties:
 *               title:
 *                 type: string
 *               institution:
 *                 type: string
 *               obtained_date:
 *                 type: string
 *                 format: date
 *               diploma:
 *                 type: string
 *                 format: binary
 *     responses:
 *       201:
 *         description: Diplôme ajouté
 */
router.post('/', authenticate, authorize('worker'), upload.single('diploma'), diplomaController.addDiploma);

/**
 * @swagger
 * /diplomas/my:
 *   get:
 *     summary: Obtenir mes diplômes (travailleur)
 *     tags: [Diplomas]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des diplômes
 */
router.get('/my', authenticate, authorize('worker'), diplomaController.getMyDiplomas);

/**
 * @swagger
 * /diplomas/{id}:
 *   put:
 *     summary: Mettre à jour un diplôme (travailleur)
 *     tags: [Diplomas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Diplôme mis à jour
 */
router.put('/:id', authenticate, authorize('worker'), diplomaController.updateDiploma);

/**
 * @swagger
 * /diplomas/{id}:
 *   delete:
 *     summary: Supprimer un diplôme (travailleur)
 *     tags: [Diplomas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Diplôme supprimé
 */
router.delete('/:id', authenticate, authorize('worker'), diplomaController.deleteDiploma);

/**
 * @swagger
 * /diplomas/worker/{workerId}:
 *   get:
 *     summary: Obtenir les diplômes d'un travailleur
 *     tags: [Diplomas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workerId
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Liste des diplômes
 */
router.get('/worker/:workerId', authenticate, diplomaController.getWorkerDiplomas);

/**
 * @swagger
 * /diplomas/{id}/verify:
 *   patch:
 *     summary: Vérifier un diplôme (admin)
 *     tags: [Diplomas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Diplôme vérifié
 */
router.patch('/:id/verify', authenticate, authorize('admin'), diplomaController.verifyDiploma);

module.exports = router;
