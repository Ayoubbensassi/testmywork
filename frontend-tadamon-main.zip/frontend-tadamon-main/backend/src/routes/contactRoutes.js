const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contactController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');

/**
 * @swagger
 * /contact:
 *   post:
 *     summary: Envoyer un message de contact
 *     description: |
 *       Permet aux visiteurs d'envoyer un message via le formulaire de contact.
 *       Le message sera traité par l'équipe TADAMON.
 *       
 *       **Note:** Cette route est publique et ne nécessite pas d'authentification.
 *     tags: [Stats]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *               - subject
 *               - message
 *             properties:
 *               name:
 *                 type: string
 *                 example: Mohammed Alami
 *                 description: Nom complet
 *                 minLength: 2
 *                 maxLength: 100
 *               email:
 *                 type: string
 *                 format: email
 *                 example: mohammed@example.com
 *                 description: Adresse email de contact
 *               phone:
 *                 type: string
 *                 example: '+212612345678'
 *                 description: Numéro de téléphone (optionnel)
 *               subject:
 *                 type: string
 *                 example: Question sur l'inscription
 *                 description: Sujet du message
 *                 minLength: 5
 *                 maxLength: 200
 *               message:
 *                 type: string
 *                 example: Bonjour, j'aimerais avoir plus d'informations sur...
 *                 description: Contenu du message
 *                 minLength: 20
 *                 maxLength: 2000
 *     responses:
 *       201:
 *         description: Message envoyé avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Votre message a été envoyé avec succès. Nous vous répondrons dans les plus brefs délais.
 *       400:
 *         description: Données invalides
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         $ref: '#/components/responses/RateLimitError'
 */
router.post('/', contactController.submitContactForm);

/**
 * @swagger
 * /contact:
 *   get:
 *     summary: Obtenir les messages de contact (Admin)
 *     description: |
 *       Récupère tous les messages de contact reçus.
 *       **Réservé aux administrateurs.**
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Numéro de page
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Nombre de messages par page
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [new, read, replied, archived]
 *         description: Filtrer par statut
 *     responses:
 *       200:
 *         description: Liste des messages de contact
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     messages:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: integer
 *                             example: 1
 *                           name:
 *                             type: string
 *                             example: Mohammed Alami
 *                           email:
 *                             type: string
 *                             example: mohammed@example.com
 *                           subject:
 *                             type: string
 *                             example: Question sur l'inscription
 *                           message:
 *                             type: string
 *                           status:
 *                             type: string
 *                             enum: [new, read, replied, archived]
 *                           created_at:
 *                             type: string
 *                             format: date-time
 *                     pagination:
 *                       $ref: '#/components/schemas/Pagination'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         $ref: '#/components/responses/ForbiddenError'
 */
router.get('/', authenticate, authorize('admin'), contactController.getContactMessages);

/**
 * @swagger
 * /contact/{id}/status:
 *   patch:
 *     summary: Mettre à jour le statut d'un message (Admin)
 *     description: |
 *       Met à jour le statut d'un message de contact.
 *       **Réservé aux administrateurs.**
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID du message
 *         example: 1
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - status
 *             properties:
 *               status:
 *                 type: string
 *                 enum: [new, read, replied, archived]
 *                 example: replied
 *                 description: Nouveau statut du message
 *     responses:
 *       200:
 *         description: Statut mis à jour
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Statut du message mis à jour
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         $ref: '#/components/responses/ForbiddenError'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 */
router.patch('/:id/status', authenticate, authorize('admin'), contactController.updateMessageStatus);

module.exports = router;
