const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');

// All routes require admin role
router.use(authenticate, authorize('admin'));

/**
 * @swagger
 * /admin/dashboard:
 *   get:
 *     summary: Obtenir les statistiques du tableau de bord admin
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Statistiques du dashboard
 */
router.get('/dashboard', adminController.getDashboardStats);

/**
 * @swagger
 * /admin/workers/pending:
 *   get:
 *     summary: Obtenir les travailleurs en attente de validation
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des travailleurs en attente
 */
router.get('/workers/pending', adminController.getPendingWorkers);

/**
 * @swagger
 * /admin/workers/{id}/approve:
 *   patch:
 *     summary: Approuver un travailleur
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Travailleur approuvé
 */
router.patch('/workers/:id/approve', adminController.approveWorker);

/**
 * @swagger
 * /admin/workers/{id}/reject:
 *   patch:
 *     summary: Rejeter un travailleur
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reason:
 *                 type: string
 *     responses:
 *       200:
 *         description: Travailleur rejeté
 */
router.patch('/workers/:id/reject', adminController.rejectWorker);

/**
 * @swagger
 * /admin/workers/labeled:
 *   get:
 *     summary: Obtenir les travailleurs labellisés
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des travailleurs labellisés
 */
router.get('/workers/labeled', adminController.getLabeledWorkers);

/**
 * @swagger
 * /admin/workers/{id}/label:
 *   patch:
 *     summary: Accorder le Label Réseau à un travailleur
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Label accordé
 */
router.patch('/workers/:id/label', adminController.grantLabel);

/**
 * @swagger
 * /admin/workers/{id}/unlabel:
 *   patch:
 *     summary: Retirer le Label Réseau d'un travailleur
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Label retiré
 */
router.patch('/workers/:id/unlabel', adminController.revokeLabel);

/**
 * @swagger
 * /admin/diplomas/pending:
 *   get:
 *     summary: Obtenir les diplômes en attente de vérification
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des diplômes en attente
 */
router.get('/diplomas/pending', adminController.getPendingDiplomas);

/**
 * @swagger
 * /admin/diplomas/{id}/verify:
 *   patch:
 *     summary: Vérifier un diplôme
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Diplôme vérifié
 */
router.patch('/diplomas/:id/verify', adminController.verifyDiploma);

/**
 * @swagger
 * /admin/establishments/pending:
 *   get:
 *     summary: Obtenir les établissements en attente de validation
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des établissements en attente
 */
router.get('/establishments/pending', adminController.getPendingEstablishments);

/**
 * @swagger
 * /admin/establishments/{id}/approve:
 *   patch:
 *     summary: Approuver un établissement
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Établissement approuvé
 */
router.patch('/establishments/:id/approve', adminController.approveEstablishment);

/**
 * @swagger
 * /admin/establishments/{id}/reject:
 *   patch:
 *     summary: Rejeter un établissement
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Établissement rejeté
 */
router.patch('/establishments/:id/reject', adminController.rejectEstablishment);

/**
 * @swagger
 * /admin/users:
 *   get:
 *     summary: Obtenir la liste de tous les utilisateurs
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des utilisateurs
 */
router.get('/users', adminController.getAllUsers);

/**
 * @swagger
 * /admin/applications:
 *   get:
 *     summary: Obtenir toutes les candidatures (mises en relation)
 *     tags: [Admin]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending, accepted, rejected]
 *     responses:
 *       200:
 *         description: Liste des candidatures
 */
router.get('/applications', adminController.getAllApplications);

module.exports = router;
