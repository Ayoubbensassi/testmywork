const express = require('express');
const router = express.Router();
const messageController = require('../controllers/messageController');
const { authenticate } = require('../middlewares/authMiddleware');

/**
 * @swagger
 * /messages/conversations:
 *   get:
 *     summary: Obtenir mes conversations
 *     description: |
 *       Récupère la liste de toutes les conversations de l'utilisateur connecté.
 *       Chaque conversation inclut le dernier message et le nombre de messages non lus.
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Numéro de page
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Nombre de conversations par page
 *     responses:
 *       200:
 *         description: Liste des conversations
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     conversations:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Conversation'
 *                     total_unread:
 *                       type: integer
 *                       example: 5
 *                       description: Nombre total de messages non lus
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.get('/conversations', authenticate, messageController.getMyConversations);

/**
 * @swagger
 * /messages/conversations/{conversationId}:
 *   get:
 *     summary: Obtenir les messages d'une conversation
 *     description: |
 *       Récupère tous les messages d'une conversation spécifique.
 *       Les messages sont triés du plus ancien au plus récent.
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: conversationId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID de la conversation (ID de l'autre utilisateur)
 *         example: 5
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Numéro de page
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 50
 *         description: Nombre de messages par page
 *     responses:
 *       200:
 *         description: Messages de la conversation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     messages:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Message'
 *                     participant:
 *                       type: object
 *                       description: Informations sur l'autre participant
 *                     pagination:
 *                       $ref: '#/components/schemas/Pagination'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 */
router.get('/conversations/:conversationId', authenticate, messageController.getConversationMessages);

/**
 * @swagger
 * /messages/send:
 *   post:
 *     summary: Envoyer un message
 *     description: |
 *       Envoie un message à un autre utilisateur.
 *       Le message est également diffusé en temps réel via WebSocket si le destinataire est connecté.
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - recipient_id
 *               - content
 *             properties:
 *               recipient_id:
 *                 type: integer
 *                 example: 5
 *                 description: ID du destinataire
 *               content:
 *                 type: string
 *                 example: Bonjour, je suis intéressé par votre profil.
 *                 description: Contenu du message (max 2000 caractères)
 *                 maxLength: 2000
 *     responses:
 *       201:
 *         description: Message envoyé avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Message envoyé avec succès
 *                 data:
 *                   type: object
 *                   properties:
 *                     message:
 *                       $ref: '#/components/schemas/Message'
 *       400:
 *         description: Contenu invalide ou destinataire introuvable
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.post('/send', authenticate, messageController.sendMessage);

/**
 * @swagger
 * /messages/{messageId}/read:
 *   patch:
 *     summary: Marquer un message comme lu
 *     description: Marque un message spécifique comme lu
 *     tags: [Messages]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: messageId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID du message
 *         example: 123
 *     responses:
 *       200:
 *         description: Message marqué comme lu
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Message marqué comme lu
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: Ce message ne vous appartient pas
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 */
router.patch('/:messageId/read', authenticate, messageController.markAsRead);

module.exports = router;
