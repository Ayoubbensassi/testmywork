const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const cvController = require('../controllers/cvController');
const { authenticate } = require('../middlewares/authMiddleware');

// Configure multer for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/temp/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'cv-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = ['.pdf', '.doc', '.docx'];
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (allowedTypes.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Format de fichier non supporté. Utilisez PDF, DOC ou DOCX.'), false);
  }
};

const upload = multer({ 
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB max
  }
});

/**
 * @swagger
 * /api/cv/analyze:
 *   post:
 *     summary: Analyze a CV using AI
 *     tags: [CV]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               cv:
 *                 type: string
 *                 format: binary
 *                 description: CV file (PDF, DOC, DOCX - max 5MB)
 *     responses:
 *       200:
 *         description: CV analysis result
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     analysis:
 *                       type: object
 *                       properties:
 *                         score:
 *                           type: number
 *                           example: 75
 *                         strengths:
 *                           type: array
 *                           items:
 *                             type: string
 *                         improvements:
 *                           type: array
 *                           items:
 *                             type: string
 *                         keywords:
 *                           type: array
 *                           items:
 *                             type: string
 *                         suggestions:
 *                           type: array
 *                           items:
 *                             type: string
 *                         summary:
 *                           type: string
 *       400:
 *         description: No file provided or invalid format
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Server error
 */
router.post('/analyze', authenticate, upload.single('cv'), cvController.analyzeCV);

module.exports = router;
