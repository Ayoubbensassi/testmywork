const express = require('express');
const router = express.Router();
const applicationController = require('../controllers/applicationController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');
const { applicationLimiter } = require('../middlewares/rateLimiter');

/**
 * @swagger
 * /applications:
 *   post:
 *     summary: Postuler à une mission (travailleur)
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - mission_id
 *             properties:
 *               mission_id:
 *                 type: integer
 *               cover_letter:
 *                 type: string
 *               proposed_rate:
 *                 type: number
 *     responses:
 *       201:
 *         description: Candidature envoyée
 */
router.post('/', authenticate, authorize('worker'), applicationLimiter, applicationController.applyToMission);

/**
 * @swagger
 * /applications/my:
 *   get:
 *     summary: Obtenir mes candidatures (travailleur)
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des candidatures
 */
router.get('/my', authenticate, authorize('worker'), applicationController.getMyApplications);

/**
 * @swagger
 * /applications/received:
 *   get:
 *     summary: Obtenir les candidatures reçues (établissement)
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des candidatures reçues
 */
router.get('/received', authenticate, authorize('establishment'), applicationController.getReceivedApplications);

/**
 * @swagger
 * /applications/mission/{missionId}:
 *   get:
 *     summary: Obtenir les candidatures pour une mission
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: missionId
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Candidatures pour la mission
 */
router.get('/mission/:missionId', authenticate, authorize('establishment'), applicationController.getMissionApplications);

/**
 * @swagger
 * /applications/{id}/accept:
 *   patch:
 *     summary: Accepter une candidature (établissement)
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Candidature acceptée
 */
router.patch('/:id/accept', authenticate, authorize('establishment'), applicationController.acceptApplication);

/**
 * @swagger
 * /applications/{id}/reject:
 *   patch:
 *     summary: Refuser une candidature (établissement)
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Candidature refusée
 */
router.patch('/:id/reject', authenticate, authorize('establishment'), applicationController.rejectApplication);

/**
 * @swagger
 * /applications/{id}:
 *   delete:
 *     summary: Retirer une candidature (travailleur)
 *     tags: [Applications]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Candidature retirée
 */
router.delete('/:id', authenticate, authorize('worker'), applicationController.withdrawApplication);

module.exports = router;

module.exports = router;
