const express = require('express');
const router = express.Router();
const regionController = require('../controllers/regionController');

/**
 * @swagger
 * /regions:
 *   get:
 *     summary: Obtenir toutes les régions du Maroc
 *     description: |
 *       Récupère la liste complète des 12 régions du Maroc.
 *       Utilisé pour les filtres de recherche et les formulaires.
 *     tags: [Regions]
 *     responses:
 *       200:
 *         description: Liste des régions
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     regions:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Region'
 *             example:
 *               status: success
 *               data:
 *                 regions:
 *                   - id: 1
 *                     name: Casablanca-Settat
 *                   - id: 2
 *                     name: Rabat-Salé-Kénitra
 *                   - id: 3
 *                     name: Marrakech-Safi
 */
router.get('/regions', regionController.getAllRegions);

/**
 * @swagger
 * /regions/{regionId}/cities:
 *   get:
 *     summary: Obtenir les villes d'une région
 *     description: Récupère toutes les villes appartenant à une région spécifique
 *     tags: [Regions]
 *     parameters:
 *       - in: path
 *         name: regionId
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID de la région
 *         example: 1
 *     responses:
 *       200:
 *         description: Liste des villes de la région
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     cities:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/City'
 *             example:
 *               status: success
 *               data:
 *                 cities:
 *                   - id: 1
 *                     name: Casablanca
 *                     region_id: 1
 *                   - id: 2
 *                     name: Mohammedia
 *                     region_id: 1
 *       404:
 *         description: Région non trouvée
 */
router.get('/regions/:regionId/cities', regionController.getCitiesByRegion);

/**
 * @swagger
 * /cities:
 *   get:
 *     summary: Obtenir toutes les villes
 *     description: |
 *       Récupère la liste complète de toutes les villes du Maroc.
 *       Chaque ville inclut sa région parente.
 *     tags: [Regions]
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Recherche par nom de ville
 *         example: Casa
 *     responses:
 *       200:
 *         description: Liste des villes
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     cities:
 *                       type: array
 *                       items:
 *                         allOf:
 *                           - $ref: '#/components/schemas/City'
 *                           - type: object
 *                             properties:
 *                               region_name:
 *                                 type: string
 *                                 example: Casablanca-Settat
 */
router.get('/cities', regionController.getAllCities);

/**
 * @swagger
 * /specialties:
 *   get:
 *     summary: Obtenir toutes les spécialités
 *     description: |
 *       Récupère la liste des spécialités du travail social disponibles sur la plateforme.
 *       Utilisé pour les profils travailleurs et les filtres de recherche.
 *     tags: [Regions]
 *     responses:
 *       200:
 *         description: Liste des spécialités
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     specialties:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: integer
 *                             example: 1
 *                           name:
 *                             type: string
 *                             example: Éducateur spécialisé
 *                           description:
 *                             type: string
 *                             example: Accompagnement éducatif de personnes en difficulté
 *             example:
 *               status: success
 *               data:
 *                 specialties:
 *                   - id: 1
 *                     name: Éducateur spécialisé
 *                   - id: 2
 *                     name: Assistant social
 *                   - id: 3
 *                     name: Moniteur éducateur
 *                   - id: 4
 *                     name: Aide médico-psychologique
 */
router.get('/specialties', regionController.getAllSpecialties);

module.exports = router;
