const express = require('express');
const router = express.Router();
const workerController = require('../controllers/workerController');
const { authenticate, optionalAuth } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');
const upload = require('../config/multer');

/**
 * @swagger
 * /workers:
 *   get:
 *     summary: Liste tous les travailleurs approuvés (public)
 *     tags: [Workers]
 *     responses:
 *       200:
 *         description: Liste des travailleurs
 */
router.get('/', optionalAuth, workerController.getAllWorkers);

/**
 * @swagger
 * /workers/profile:
 *   post:
 *     summary: Créer un profil travailleur
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - first_name
 *               - last_name
 *               - cin
 *             properties:
 *               first_name:
 *                 type: string
 *               last_name:
 *                 type: string
 *               cin:
 *                 type: string
 *               phone:
 *                 type: string
 *               bio:
 *                 type: string
 *               daily_rate:
 *                 type: number
 *     responses:
 *       201:
 *         description: Profil créé avec succès
 */
router.post('/profile', authenticate, authorize('worker'), workerController.createProfile);

/**
 * @swagger
 * /workers/profile:
 *   get:
 *     summary: Obtenir mon profil travailleur
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Profil travailleur
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                 data:
 *                   type: object
 *                   properties:
 *                     profile:
 *                       $ref: '#/components/schemas/WorkerProfile'
 */
router.get('/profile', authenticate, authorize('worker'), workerController.getMyProfile);

/**
 * @swagger
 * /workers/profile:
 *   put:
 *     summary: Mettre à jour mon profil travailleur
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Profil mis à jour
 */
router.put('/profile', authenticate, authorize('worker'), workerController.updateMyProfile);

/**
 * @swagger
 * /workers/profile/documents:
 *   post:
 *     summary: Uploader des documents (CIN, CV, photo de profil)
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               cin_front:
 *                 type: string
 *                 format: binary
 *               cin_back:
 *                 type: string
 *                 format: binary
 *               cv:
 *                 type: string
 *                 format: binary
 *               profile_picture:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: Documents uploadés avec succès
 */
router.post('/profile/documents', 
  authenticate, 
  authorize('worker'),
  upload.fields([
    { name: 'cin_front', maxCount: 1 },
    { name: 'cin_back', maxCount: 1 },
    { name: 'cv', maxCount: 1 },
    { name: 'profile_picture', maxCount: 1 }
  ]),
  workerController.uploadDocuments
);

/**
 * @swagger
 * /workers/specialties:
 *   post:
 *     summary: Ajouter une spécialité au profil
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - specialty_id
 *             properties:
 *               specialty_id:
 *                 type: integer
 *               years_experience:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Spécialité ajoutée
 */
router.post('/specialties', authenticate, authorize('worker'), workerController.addSpecialty);

/**
 * @swagger
 * /workers/specialties/{specialtyId}:
 *   delete:
 *     summary: Retirer une spécialité
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: specialtyId
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Spécialité retirée
 */
router.delete('/specialties/:specialtyId', authenticate, authorize('worker'), workerController.removeSpecialty);

/**
 * @swagger
 * /workers/profile/{id}:
 *   get:
 *     summary: Obtenir un profil travailleur public
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Profil public
 */
router.get('/profile/:id', authenticate, workerController.getPublicProfile);

/**
 * @swagger
 * /workers/search:
 *   get:
 *     summary: Rechercher des travailleurs (établissements et admins)
 *     tags: [Workers]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: region_id
 *         schema:
 *           type: integer
 *       - in: query
 *         name: city_id
 *         schema:
 *           type: integer
 *       - in: query
 *         name: specialty_id
 *         schema:
 *           type: integer
 *       - in: query
 *         name: is_labeled
 *         schema:
 *           type: boolean
 *       - in: query
 *         name: min_experience
 *         schema:
 *           type: integer
 *       - in: query
 *         name: min_rating
 *         schema:
 *           type: number
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Résultats de recherche
 */
router.get('/search', authenticate, authorize('establishment', 'admin'), workerController.searchWorkers);

module.exports = router;
