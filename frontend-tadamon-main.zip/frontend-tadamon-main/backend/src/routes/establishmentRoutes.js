const express = require('express');
const router = express.Router();
const establishmentController = require('../controllers/establishmentController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');
const upload = require('../config/multer');

/**
 * @swagger
 * /establishments/profile:
 *   post:
 *     summary: Créer un profil établissement
 *     description: |
 *       Crée le profil d'un établissement après inscription.
 *       Le profil sera en statut "pending" jusqu'à validation par un admin.
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - ice
 *               - type
 *             properties:
 *               name:
 *                 type: string
 *                 example: Centre Social Al Amal
 *                 description: Nom de l'établissement
 *               ice:
 *                 type: string
 *                 example: '001234567000089'
 *                 description: Identifiant Commun de l'Entreprise (15 chiffres)
 *               type:
 *                 type: string
 *                 enum: [association, fondation, cooperative, entreprise, public]
 *                 example: association
 *                 description: Type d'établissement
 *               description:
 *                 type: string
 *                 example: Centre d'accueil pour personnes en situation de handicap
 *                 description: Description de l'établissement
 *               phone:
 *                 type: string
 *                 example: '+212522123456'
 *               address:
 *                 type: string
 *                 example: 123 Rue Mohammed V, Casablanca
 *               website:
 *                 type: string
 *                 example: https://alamal.ma
 *               region_id:
 *                 type: integer
 *                 example: 1
 *               city_id:
 *                 type: integer
 *                 example: 1
 *     responses:
 *       201:
 *         description: Profil créé avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Profil établissement créé avec succès
 *                 data:
 *                   type: object
 *                   properties:
 *                     profile:
 *                       $ref: '#/components/schemas/EstablishmentProfile'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         $ref: '#/components/responses/ForbiddenError'
 */
router.post('/profile', authenticate, authorize('establishment'), establishmentController.createProfile);

/**
 * @swagger
 * /establishments/profile:
 *   get:
 *     summary: Obtenir mon profil établissement
 *     description: Récupère le profil complet de l'établissement connecté
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Profil établissement
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     profile:
 *                       $ref: '#/components/schemas/EstablishmentProfile'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       404:
 *         description: Profil non trouvé
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
router.get('/profile', authenticate, authorize('establishment'), establishmentController.getMyProfile);

/**
 * @swagger
 * /establishments/profile:
 *   put:
 *     summary: Mettre à jour mon profil établissement
 *     description: Met à jour les informations du profil établissement
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Centre Social Al Amal
 *               description:
 *                 type: string
 *                 example: Description mise à jour...
 *               phone:
 *                 type: string
 *                 example: '+212522123456'
 *               address:
 *                 type: string
 *                 example: Nouvelle adresse
 *               website:
 *                 type: string
 *                 example: https://alamal.ma
 *               region_id:
 *                 type: integer
 *               city_id:
 *                 type: integer
 *     responses:
 *       200:
 *         description: Profil mis à jour
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Profil mis à jour avec succès
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.put('/profile', authenticate, authorize('establishment'), establishmentController.updateMyProfile);

/**
 * @swagger
 * /establishments/profile/logo:
 *   post:
 *     summary: Uploader le logo de l'établissement
 *     description: Upload ou remplace le logo de l'établissement (JPEG, PNG, max 5MB)
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - logo
 *             properties:
 *               logo:
 *                 type: string
 *                 format: binary
 *                 description: Fichier image (JPEG, PNG)
 *     responses:
 *       200:
 *         description: Logo uploadé avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Logo uploadé avec succès
 *                 data:
 *                   type: object
 *                   properties:
 *                     logo_url:
 *                       type: string
 *                       example: /uploads/logos/logo_123.png
 *       400:
 *         description: Fichier invalide
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.post('/profile/logo',
  authenticate,
  authorize('establishment'),
  upload.single('logo'),
  establishmentController.uploadLogo
);

/**
 * @swagger
 * /establishments/profile/documents:
 *   post:
 *     summary: Uploader les documents de vérification
 *     description: |
 *       Upload les documents requis pour la vérification de l'établissement:
 *       - Certificat ICE
 *       - Document d'immatriculation
 *       - Autorisation d'exercice
 *       
 *       Formats acceptés: JPEG, PNG, PDF (max 5MB par fichier)
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               ice_document:
 *                 type: string
 *                 format: binary
 *                 description: Certificat ICE
 *               registration_document:
 *                 type: string
 *                 format: binary
 *                 description: Document d'immatriculation
 *               authorization_document:
 *                 type: string
 *                 format: binary
 *                 description: Autorisation d'exercice
 *               logo:
 *                 type: string
 *                 format: binary
 *                 description: Logo de l'établissement
 *     responses:
 *       200:
 *         description: Documents uploadés avec succès
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: Documents uploadés avec succès
 *                 data:
 *                   type: object
 *                   properties:
 *                     ice_document:
 *                       type: string
 *                       example: /uploads/documents/ice_123.pdf
 *                     registration_document:
 *                       type: string
 *                       example: /uploads/documents/reg_123.pdf
 *                     authorization_document:
 *                       type: string
 *                       example: /uploads/documents/auth_123.pdf
 *       400:
 *         description: Fichier invalide ou trop volumineux
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.post('/profile/documents',
  authenticate,
  authorize('establishment'),
  upload.fields([
    { name: 'ice_document', maxCount: 1 },
    { name: 'registration_document', maxCount: 1 },
    { name: 'authorization_document', maxCount: 1 },
    { name: 'logo', maxCount: 1 }
  ]),
  establishmentController.uploadDocuments
);

/**
 * @swagger
 * /establishments/profile/{id}:
 *   get:
 *     summary: Obtenir le profil public d'un établissement
 *     description: Récupère les informations publiques d'un établissement par son ID
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID de l'établissement
 *         example: 1
 *     responses:
 *       200:
 *         description: Profil public de l'établissement
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     profile:
 *                       $ref: '#/components/schemas/EstablishmentProfile'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 */
router.get('/profile/:id', authenticate, establishmentController.getPublicProfile);

/**
 * @swagger
 * /establishments:
 *   get:
 *     summary: Lister tous les établissements
 *     description: |
 *       Récupère la liste de tous les établissements approuvés.
 *       Supporte la pagination et les filtres.
 *     tags: [Establishments]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Numéro de page
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Nombre d'éléments par page
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *           enum: [association, fondation, cooperative, entreprise, public]
 *         description: Filtrer par type d'établissement
 *       - in: query
 *         name: region_id
 *         schema:
 *           type: integer
 *         description: Filtrer par région
 *       - in: query
 *         name: city_id
 *         schema:
 *           type: integer
 *         description: Filtrer par ville
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Recherche textuelle (nom, description)
 *     responses:
 *       200:
 *         description: Liste des établissements
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     establishments:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/EstablishmentProfile'
 *                     pagination:
 *                       $ref: '#/components/schemas/Pagination'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 */
router.get('/', authenticate, establishmentController.getAllEstablishments);

module.exports = router;
