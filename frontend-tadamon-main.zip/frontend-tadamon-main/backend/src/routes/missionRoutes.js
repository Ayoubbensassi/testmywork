const express = require('express');
const router = express.Router();
const missionController = require('../controllers/missionController');
const { authenticate, optionalAuth } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');

const { body } = require('express-validator');
const validateRequest = require('../middlewares/validateRequest');

// Validation rules for mission creation/update
const missionValidation = [
    body('title').notEmpty().withMessage('Le titre est requis').trim(),
    body('description').notEmpty().withMessage('La description est requise'),
    body('mission_type').isIn(['ponctuelle', 'courte_duree', 'longue_duree', 'remplacement'])
        .withMessage('Type de mission invalide'),
    body('start_date').isISO8601().withMessage('Date de début invalide'),
    body('region_id').isInt().withMessage('Région invalide'),
    body('city_id').isInt().withMessage('Ville invalide'),
    validateRequest
];

/**
 * @swagger
 * /missions:
 *   get:
 *     summary: Lister toutes les missions disponibles
 *     tags: [Missions]
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [open, in_progress, completed]
 *         description: Filtrer par statut
 *       - in: query
 *         name: region_id
 *         schema:
 *           type: integer
 *         description: Filtrer par région
 *       - in: query
 *         name: city_id
 *         schema:
 *           type: integer
 *         description: Filtrer par ville
 *       - in: query
 *         name: mission_type
 *         schema:
 *           type: string
 *           enum: [ponctuelle, courte_duree, longue_duree, remplacement]
 *         description: Filtrer par type de mission
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Numéro de page
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Nombre d'éléments par page
 *     responses:
 *       200:
 *         description: Liste des missions
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     missions:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/Mission'
 *                     pagination:
 *                       type: object
 *                       properties:
 *                         page:
 *                           type: integer
 *                         limit:
 *                           type: integer
 *                         total:
 *                           type: integer
 */
router.get('/', optionalAuth, missionController.getAllMissions);

/**
 * @swagger
 * /missions/search:
 *   get:
 *     summary: Rechercher des missions
 *     tags: [Missions]
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Recherche textuelle (titre, description)
 *       - in: query
 *         name: region_id
 *         schema:
 *           type: integer
 *       - in: query
 *         name: city_id
 *         schema:
 *           type: integer
 *       - in: query
 *         name: mission_type
 *         schema:
 *           type: string
 *           enum: [ponctuelle, courte_duree, longue_duree, remplacement]
 *     responses:
 *       200:
 *         description: Résultats de recherche
 */
router.get('/search', optionalAuth, missionController.searchMissions);

/**
 * @swagger
 * /missions:
 *   post:
 *     summary: Créer une nouvelle mission
 *     tags: [Missions]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - title
 *               - description
 *               - mission_type
 *               - start_date
 *               - region_id
 *               - city_id
 *             properties:
 *               title:
 *                 type: string
 *                 example: Éducateur spécialisé - Remplacement
 *               description:
 *                 type: string
 *                 example: Remplacement congé maternité...
 *               mission_type:
 *                 type: string
 *                 enum: [ponctuelle, courte_duree, longue_duree, remplacement]
 *               start_date:
 *                 type: string
 *                 format: date
 *               end_date:
 *                 type: string
 *                 format: date
 *               salary_min:
 *                 type: number
 *               salary_max:
 *                 type: number
 *               region_id:
 *                 type: integer
 *               city_id:
 *                 type: integer
 *               is_urgent:
 *                 type: boolean
 *     responses:
 *       201:
 *         description: Mission créée avec succès
 *       400:
 *         description: Données invalides
 *       401:
 *         description: Non authentifié
 *       403:
 *         description: Accès refusé (établissement requis)
 */
router.post('/', authenticate, authorize('establishment'), missionValidation, missionController.createMission);

/**
 * @swagger
 * /missions/my:
 *   get:
 *     summary: Obtenir mes missions (établissement)
 *     tags: [Missions]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des missions de l'établissement
 */
router.get('/my', authenticate, authorize('establishment'), missionController.getMyMissions);

/**
 * @swagger
 * /missions/{id}:
 *   get:
 *     summary: Obtenir les détails d'une mission
 *     tags: [Missions]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Détails de la mission
 *       404:
 *         description: Mission non trouvée
 */
router.get('/:id', optionalAuth, missionController.getMissionById);

/**
 * @swagger
 * /missions/{id}:
 *   put:
 *     summary: Mettre à jour une mission
 *     tags: [Missions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Mission mise à jour
 *       403:
 *         description: Accès refusé
 */
router.put('/:id', authenticate, authorize('establishment'), missionValidation, missionController.updateMission);

/**
 * @swagger
 * /missions/{id}:
 *   delete:
 *     summary: Supprimer une mission
 *     tags: [Missions]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Mission supprimée
 *       403:
 *         description: Accès refusé
 */
router.delete('/:id', authenticate, authorize('establishment'), missionController.deleteMission);

module.exports = router;
