const express = require('express');
const router = express.Router();
const statsController = require('../controllers/statsController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');

/**
 * @swagger
 * /stats/public:
 *   get:
 *     summary: Statistiques publiques de la plateforme
 *     description: |
 *       Récupère les statistiques générales affichées sur la page d'accueil.
 *       Ces données sont publiques et ne nécessitent pas d'authentification.
 *     tags: [Stats]
 *     responses:
 *       200:
 *         description: Statistiques publiques
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     total_workers:
 *                       type: integer
 *                       example: 1250
 *                       description: Nombre total de travailleurs inscrits
 *                     total_establishments:
 *                       type: integer
 *                       example: 350
 *                       description: Nombre total d'établissements
 *                     total_missions:
 *                       type: integer
 *                       example: 2500
 *                       description: Nombre total de missions publiées
 *                     completed_missions:
 *                       type: integer
 *                       example: 1800
 *                       description: Missions complétées avec succès
 *                     active_missions:
 *                       type: integer
 *                       example: 125
 *                       description: Missions actuellement ouvertes
 *                     regions_covered:
 *                       type: integer
 *                       example: 12
 *                       description: Nombre de régions couvertes
 */
router.get('/public', statsController.getPublicStats);

/**
 * @swagger
 * /stats/worker:
 *   get:
 *     summary: Statistiques du tableau de bord travailleur
 *     description: |
 *       Récupère les statistiques personnalisées pour le dashboard d'un travailleur.
 *       Inclut les candidatures, missions, revenus et évaluations.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Statistiques du travailleur
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     applications:
 *                       type: object
 *                       properties:
 *                         total:
 *                           type: integer
 *                           example: 25
 *                         pending:
 *                           type: integer
 *                           example: 5
 *                         accepted:
 *                           type: integer
 *                           example: 15
 *                         rejected:
 *                           type: integer
 *                           example: 5
 *                     missions:
 *                       type: object
 *                       properties:
 *                         completed:
 *                           type: integer
 *                           example: 12
 *                         in_progress:
 *                           type: integer
 *                           example: 2
 *                     reviews:
 *                       type: object
 *                       properties:
 *                         average_rating:
 *                           type: number
 *                           example: 4.5
 *                         total_reviews:
 *                           type: integer
 *                           example: 10
 *                     profile_views:
 *                       type: integer
 *                       example: 150
 *                       description: Nombre de vues du profil ce mois
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: Réservé aux travailleurs
 */
router.get('/worker', authenticate, authorize('worker'), statsController.getWorkerStats);

/**
 * @swagger
 * /stats/establishment:
 *   get:
 *     summary: Statistiques du tableau de bord établissement
 *     description: |
 *       Récupère les statistiques personnalisées pour le dashboard d'un établissement.
 *       Inclut les missions publiées, candidatures reçues et recrutements.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Statistiques de l'établissement
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 data:
 *                   type: object
 *                   properties:
 *                     missions:
 *                       type: object
 *                       properties:
 *                         total:
 *                           type: integer
 *                           example: 30
 *                         open:
 *                           type: integer
 *                           example: 5
 *                         in_progress:
 *                           type: integer
 *                           example: 3
 *                         completed:
 *                           type: integer
 *                           example: 20
 *                     applications:
 *                       type: object
 *                       properties:
 *                         total_received:
 *                           type: integer
 *                           example: 150
 *                         pending:
 *                           type: integer
 *                           example: 25
 *                         this_month:
 *                           type: integer
 *                           example: 15
 *                     workers_hired:
 *                       type: integer
 *                       example: 18
 *                       description: Nombre de travailleurs recrutés
 *                     reviews:
 *                       type: object
 *                       properties:
 *                         average_rating:
 *                           type: number
 *                           example: 4.2
 *                         total_reviews:
 *                           type: integer
 *                           example: 15
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: Réservé aux établissements
 */
router.get('/establishment', authenticate, authorize('establishment'), statsController.getEstablishmentStats);

module.exports = router;
