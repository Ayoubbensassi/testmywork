const express = require('express');
const router = express.Router();
const experienceController = require('../controllers/experienceController');
const { authenticate } = require('../middlewares/authMiddleware');
const { authorize } = require('../middlewares/roleMiddleware');

// Worker routes
router.post('/', authenticate, authorize('worker'), experienceController.addExperience);
router.get('/my', authenticate, authorize('worker'), experienceController.getMyExperiences);
router.put('/:id', authenticate, authorize('worker'), experienceController.updateExperience);
router.delete('/:id', authenticate, authorize('worker'), experienceController.deleteExperience);

// Public route
router.get('/worker/:workerId', authenticate, experienceController.getWorkerExperiences);

module.exports = router;
