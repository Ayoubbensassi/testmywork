const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');
const { authenticate } = require('../middlewares/authMiddleware');

// Get chat contacts
router.get('/contacts', authenticate, chatController.getContacts);

// Get messages with a specific user
router.get('/messages/:recipientId', authenticate, chatController.getMessages);

// Send a message
router.post('/messages', authenticate, chatController.sendMessage);

// Mark messages as read
router.patch('/messages/:senderId/read', authenticate, chatController.markAsRead);

// Get unread message count
router.get('/unread-count', authenticate, chatController.getUnreadCount);

module.exports = router;