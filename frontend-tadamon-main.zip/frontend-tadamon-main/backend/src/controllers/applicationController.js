const Application = require('../models/Application');
const Mission = require('../models/Mission');
const WorkerProfile = require('../models/WorkerProfile');
const EstablishmentProfile = require('../models/EstablishmentProfile');

exports.applyToMission = async (req, res) => {
  try {
    const workerProfile = await WorkerProfile.findByUserId(req.user.id);
    if (!workerProfile) {
      return res.status(404).json({ status: 'error', message: 'Profil travailleur non trouvé' });
    }

    if (workerProfile.status !== 'approved') {
      return res.status(403).json({ status: 'error', message: 'Votre profil doit être approuvé pour postuler' });
    }

    const { mission_id, cover_letter, proposed_rate } = req.body;

    if (!mission_id) {
      return res.status(400).json({ status: 'error', message: 'ID de mission requis' });
    }

    const mission = await Mission.findById(mission_id);
    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    if (mission.status !== 'open') {
      return res.status(400).json({ status: 'error', message: 'Cette mission n\'accepte plus de candidatures' });
    }

    const alreadyApplied = await Application.checkExists(mission_id, workerProfile.id);
    if (alreadyApplied) {
      return res.status(409).json({ status: 'error', message: 'Vous avez déjà postulé à cette mission' });
    }

    const applicationId = await Application.create(mission_id, workerProfile.id, {
      cover_letter, proposed_rate
    });

    res.status(201).json({
      status: 'success',
      message: 'Candidature envoyée avec succès',
      data: { applicationId }
    });
  } catch (error) {
    console.error('Apply to mission error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la candidature' });
  }
};

exports.getMyApplications = async (req, res) => {
  try {
    const workerProfile = await WorkerProfile.findByUserId(req.user.id);
    if (!workerProfile) {
      return res.status(404).json({ status: 'error', message: 'Profil travailleur non trouvé' });
    }

    const { status, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const applications = await Application.findByWorker(workerProfile.id, {
      status, limit: parseInt(limit), offset
    });

    res.json({ status: 'success', data: { applications } });
  } catch (error) {
    console.error('Get my applications error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des candidatures' });
  }
};

exports.getMissionApplications = async (req, res) => {
  try {
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!estabProfile) {
      return res.status(404).json({ status: 'error', message: 'Profil établissement non trouvé' });
    }

    const mission = await Mission.findById(req.params.missionId);
    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    if (mission.establishment_id !== estabProfile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    const { status } = req.query;
    const applications = await Application.findByMission(mission.id, { status });

    res.json({ status: 'success', data: { applications } });
  } catch (error) {
    console.error('Get mission applications error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des candidatures' });
  }
};

// Get all applications received by establishment (across all missions)
exports.getReceivedApplications = async (req, res) => {
  try {
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!estabProfile) {
      return res.status(404).json({ status: 'error', message: 'Profil établissement non trouvé' });
    }

    const { status } = req.query;
    const applications = await Application.findByEstablishment(estabProfile.id, { status });

    res.json({ status: 'success', data: { applications } });
  } catch (error) {
    console.error('Get received applications error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des candidatures' });
  }
};

exports.acceptApplication = async (req, res) => {
  try {
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);
    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ status: 'error', message: 'Candidature non trouvée' });
    }

    if (application.establishment_id !== estabProfile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    await Application.updateStatus(application.id, 'accepted', req.user.id);
    await Mission.selectWorker(application.mission_id, application.worker_id);

    res.json({ status: 'success', message: 'Candidature acceptée' });
  } catch (error) {
    console.error('Accept application error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'acceptation' });
  }
};

exports.rejectApplication = async (req, res) => {
  try {
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);
    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ status: 'error', message: 'Candidature non trouvée' });
    }

    if (application.establishment_id !== estabProfile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    const { reason } = req.body;
    await Application.updateStatus(application.id, 'rejected', req.user.id, reason);

    res.json({ status: 'success', message: 'Candidature refusée' });
  } catch (error) {
    console.error('Reject application error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors du refus' });
  }
};

exports.withdrawApplication = async (req, res) => {
  try {
    const workerProfile = await WorkerProfile.findByUserId(req.user.id);
    const application = await Application.findById(req.params.id);

    if (!application) {
      return res.status(404).json({ status: 'error', message: 'Candidature non trouvée' });
    }

    if (application.worker_id !== workerProfile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    if (application.status !== 'pending') {
      return res.status(400).json({ status: 'error', message: 'Impossible de retirer cette candidature' });
    }

    await Application.withdraw(application.id);

    res.json({ status: 'success', message: 'Candidature retirée' });
  } catch (error) {
    console.error('Withdraw application error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors du retrait' });
  }
};
