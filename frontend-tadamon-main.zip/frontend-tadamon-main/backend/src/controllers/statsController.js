const db = require('../config/database');

// Get public statistics for homepage
exports.getPublicStats = async (req, res) => {
  try {
    // Get workers count (only validated/active workers)
    const [workersResult] = await db.execute(
      `SELECT COUNT(*) as count FROM worker_profiles WHERE status = 'approved'`
    );

    // Get establishments count (only active establishments)
    const [establishmentsResult] = await db.execute(
      `SELECT COUNT(*) as count FROM establishment_profiles WHERE is_verified = TRUE`
    );

    // Get missions count (completed + active missions)
    const [missionsResult] = await db.execute(
      `SELECT COUNT(*) as count FROM missions WHERE status IN ('open', 'in_progress', 'completed')`
    );

    res.json({
      success: true,
      data: {
        workers: parseInt(workersResult[0].count) || 0,
        establishments: parseInt(establishmentsResult[0].count) || 0,
        missions: parseInt(missionsResult[0].count) || 0,
        specialties_distribution: await getSpecialtyDistribution()
      }
    });
  } catch (error) {
    console.error('Error fetching public stats:', error);
    res.status(500).json({
      success: false,
      message: 'Erreur lors de la récupération des statistiques'
    });
  }
};

// Get worker-specific statistics for dashboard
exports.getWorkerStats = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get worker profile
    const [profileResult] = await db.execute(
      `SELECT id, total_missions, average_rating FROM worker_profiles WHERE user_id = ?`,
      [userId]
    );
    
    if (!profileResult.length) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }
    
    const workerId = profileResult[0].id;
    
    // Get applications stats
    const [applicationsResult] = await db.execute(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
      FROM applications WHERE worker_id = ?
    `, [workerId]);
    
    // Get missions in progress (accepted applications with ongoing missions)
    const [inProgressResult] = await db.execute(`
      SELECT COUNT(*) as count 
      FROM applications a
      JOIN missions m ON a.mission_id = m.id
      WHERE a.worker_id = ? AND a.status = 'accepted' AND m.status = 'in_progress'
    `, [workerId]);
    
    // Get reviews count
    const [reviewsResult] = await db.execute(
      `SELECT COUNT(*) as count FROM reviews WHERE reviewee_id = ?`,
      [userId]
    );
    
    // Get this month's activity
    const [monthlyResult] = await db.execute(`
      SELECT COUNT(*) as applications_this_month
      FROM applications 
      WHERE worker_id = ? AND MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())
    `, [workerId]);
    
    res.json({
      status: 'success',
      data: {
        total_missions: profileResult[0].total_missions || 0,
        average_rating: parseFloat(profileResult[0].average_rating) || 0,
        applications: {
          total: applicationsResult[0].total || 0,
          pending: applicationsResult[0].pending || 0,
          accepted: applicationsResult[0].accepted || 0,
          rejected: applicationsResult[0].rejected || 0
        },
        missions_in_progress: inProgressResult[0].count || 0,
        reviews_count: reviewsResult[0].count || 0,
        applications_this_month: monthlyResult[0].applications_this_month || 0
      }
    });
  } catch (error) {
    console.error('Error fetching worker stats:', error);
    res.status(500).json({
      status: 'error',
      message: 'Erreur lors de la récupération des statistiques'
    });
  }
};

// Get establishment-specific statistics for dashboard
exports.getEstablishmentStats = async (req, res) => {
  try {
    const userId = req.user.id;
    
    // Get establishment profile
    const [profileResult] = await db.execute(
      `SELECT id, average_rating FROM establishment_profiles WHERE user_id = ?`,
      [userId]
    );
    
    if (!profileResult.length) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }
    
    const establishmentId = profileResult[0].id;
    
    // Get missions stats
    const [missionsResult] = await db.execute(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
      FROM missions WHERE establishment_id = ?
    `, [establishmentId]);
    
    // Get applications received
    const [applicationsResult] = await db.execute(`
      SELECT COUNT(*) as count 
      FROM applications a
      JOIN missions m ON a.mission_id = m.id
      WHERE m.establishment_id = ? AND a.status = 'pending'
    `, [establishmentId]);
    
    // Get reviews count
    const [reviewsResult] = await db.execute(
      `SELECT COUNT(*) as count FROM reviews WHERE reviewee_id = ?`,
      [userId]
    );
    
    res.json({
      status: 'success',
      data: {
        average_rating: parseFloat(profileResult[0].average_rating) || 0,
        missions: {
          total: missionsResult[0].total || 0,
          open: missionsResult[0].open || 0,
          in_progress: missionsResult[0].in_progress || 0,
          completed: missionsResult[0].completed || 0
        },
        pending_applications: applicationsResult[0].count || 0,
        reviews_count: reviewsResult[0].count || 0
      }
    });
  } catch (error) {
    console.error('Error fetching establishment stats:', error);
    res.status(500).json({
      status: 'error',
      message: 'Erreur lors de la récupération des statistiques'
    });
  }
};

async function getSpecialtyDistribution() {
  try {
    const [rows] = await db.execute(`
      SELECT s.name, COUNT(DISTINCT ws.worker_id) as count 
      FROM specialties s 
      LEFT JOIN worker_specialties ws ON s.id = ws.specialty_id 
      LEFT JOIN worker_profiles wp ON ws.worker_id = wp.id 
      WHERE wp.status = 'approved' OR wp.status IS NULL 
      GROUP BY s.id 
      ORDER BY count DESC
    `);

    // Map to simple object { "Handicap": 12, "Santé": 5 }
    const dist = {};
    rows.forEach(row => {
      dist[row.name] = row.count;
    });
    return dist;
  } catch (err) {
    console.warn('Failed to fetch specialty distribution:', err);
    return {}; // fallback to empty
  }
}
