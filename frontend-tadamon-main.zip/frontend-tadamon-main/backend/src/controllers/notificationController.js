const Notification = require('../models/Notification');

// Get my notifications
exports.getMyNotifications = async (req, res) => {
  try {
    const { page = 1, limit = 20, unread_only } = req.query;
    const offset = (page - 1) * limit;

    const notifications = await Notification.findByUser(req.user.id, {
      limit: parseInt(limit),
      offset,
      unread_only: unread_only === 'true'
    });

    const unreadCount = await Notification.countUnread(req.user.id);

    res.json({
      status: 'success',
      data: { notifications, unreadCount }
    });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Mark notification as read
exports.markAsRead = async (req, res) => {
  try {
    const notification = await Notification.findById(req.params.id);
    
    if (!notification || notification.user_id !== req.user.id) {
      return res.status(404).json({ status: 'error', message: 'Notification non trouvée' });
    }

    await Notification.markAsRead(notification.id);

    res.json({ status: 'success', message: 'Notification marquée comme lue' });
  } catch (error) {
    console.error('Mark as read error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur' });
  }
};

// Mark all as read
exports.markAllAsRead = async (req, res) => {
  try {
    await Notification.markAllAsRead(req.user.id);

    res.json({ status: 'success', message: 'Toutes les notifications marquées comme lues' });
  } catch (error) {
    console.error('Mark all as read error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur' });
  }
};

// Delete notification
exports.deleteNotification = async (req, res) => {
  try {
    const notification = await Notification.findById(req.params.id);
    
    if (!notification || notification.user_id !== req.user.id) {
      return res.status(404).json({ status: 'error', message: 'Notification non trouvée' });
    }

    await Notification.delete(notification.id);

    res.json({ status: 'success', message: 'Notification supprimée' });
  } catch (error) {
    console.error('Delete notification error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la suppression' });
  }
};

// Delete all read notifications
exports.deleteAllRead = async (req, res) => {
  try {
    await Notification.deleteAllRead(req.user.id);

    res.json({ status: 'success', message: 'Notifications lues supprimées' });
  } catch (error) {
    console.error('Delete all read error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la suppression' });
  }
};
