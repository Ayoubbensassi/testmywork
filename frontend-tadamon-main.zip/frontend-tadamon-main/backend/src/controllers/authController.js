const User = require('../models/User');
const { hashPassword, comparePassword } = require('../utils/hashPassword');
const { generateToken } = require('../utils/generateToken');
const { isValidEmail, isValidPassword } = require('../utils/validators');
const { sendVerificationEmail, sendPasswordResetEmail, sendWelcomeEmail } = require('../services/emailService');

exports.register = async (req, res) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password || !role) {
      return res.status(400).json({ status: 'error', message: 'Email, mot de passe et role requis' });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ status: 'error', message: 'Format email invalide' });
    }
    if (!isValidPassword(password)) {
      return res.status(400).json({ status: 'error', message: 'Mot de passe: 8 chars, 1 majuscule, 1 chiffre' });
    }
    if (!['worker', 'establishment'].includes(role)) {
      return res.status(400).json({ status: 'error', message: 'Role invalide' });
    }
    const emailExists = await User.emailExists(email);
    if (emailExists) {
      return res.status(409).json({ status: 'error', message: 'Email deja utilise' });
    }
    const hashedPassword = await hashPassword(password);
    const { userId, verificationToken } = await User.create(email, hashedPassword, role);
    sendVerificationEmail(email, verificationToken, email.split('@')[0]).catch(console.error);
    const token = generateToken({ id: userId, email, role });
    res.status(201).json({
      status: 'success',
      message: 'Compte cree. Verifiez votre email.',
      data: { userId, email, role, token, requiresVerification: true }
    });
  } catch (error) {
    next(error);
  }
};

exports.verifyEmail = async (req, res) => {
  try {
    const { token } = req.params;
    if (!token) return res.status(400).json({ status: 'error', message: 'Token requis' });
    const user = await User.findByVerificationToken(token);
    if (!user) return res.status(400).json({ status: 'error', message: 'Token invalide ou expire' });
    await User.verifyEmail(user.id);
    sendWelcomeEmail(user.email, user.email.split('@')[0], user.role);
    res.json({ status: 'success', message: 'Email verifie!' });
  } catch (error) {
    next(error);
  }
};


exports.resendVerification = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ status: 'error', message: 'Email requis' });
    const user = await User.findByEmail(email);
    if (!user) return res.json({ status: 'success', message: 'Si email existe, lien envoye.' });
    if (user.is_verified) return res.status(400).json({ status: 'error', message: 'Email deja verifie' });
    const verificationToken = await User.resendVerification(user.id);
    await sendVerificationEmail(email, verificationToken, email.split('@')[0]);
    res.json({ status: 'success', message: 'Nouveau lien envoye.' });
  } catch (error) {
    next(error);
  }
};

exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ status: 'error', message: 'Email requis' });
    const user = await User.findByEmail(email);
    if (!user) return res.json({ status: 'success', message: 'Si email existe, lien envoye.' });
    const resetToken = await User.setPasswordResetToken(user.id);
    await sendPasswordResetEmail(email, resetToken, email.split('@')[0]);
    res.json({ status: 'success', message: 'Lien reinitialisation envoye.' });
  } catch (error) {
    next(error);
  }
};

exports.resetPassword = async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;
    if (!token || !password) return res.status(400).json({ status: 'error', message: 'Token et mot de passe requis' });
    if (!isValidPassword(password)) return res.status(400).json({ status: 'error', message: 'Mot de passe invalide' });
    const user = await User.findByResetToken(token);
    if (!user) return res.status(400).json({ status: 'error', message: 'Token invalide ou expire' });
    const hashedPassword = await hashPassword(password);
    await User.updatePassword(user.id, hashedPassword);
    res.json({ status: 'success', message: 'Mot de passe reinitialise!' });
  } catch (error) {
    next(error);
  }
};


exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ status: 'error', message: 'Email et mot de passe requis' });
    const user = await User.findByEmail(email);
    if (!user) return res.status(401).json({ status: 'error', message: 'Email ou mot de passe incorrect' });
    if (!user.is_active) return res.status(403).json({ status: 'error', message: 'Compte desactive' });
    const isPasswordValid = await comparePassword(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ status: 'error', message: 'Email ou mot de passe incorrect' });
    await User.updateLastLogin(user.id);
    const token = generateToken({ id: user.id, email: user.email, role: user.role });
    res.json({
      status: 'success',
      message: 'Connexion reussie',
      data: { token, user: { id: user.id, email: user.email, role: user.role, is_verified: user.is_verified } }
    });
  } catch (error) {
    next(error);
  }
};

exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ status: 'error', message: 'Utilisateur non trouve' });
    res.json({ status: 'success', data: { user } });
  } catch (error) {
    next(error);
  }
};

exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) return res.status(400).json({ status: 'error', message: 'Mots de passe requis' });
    if (!isValidPassword(newPassword)) return res.status(400).json({ status: 'error', message: 'Nouveau mot de passe invalide' });
    const user = await User.findByEmail(req.user.email);
    const isValid = await comparePassword(currentPassword, user.password);
    if (!isValid) return res.status(401).json({ status: 'error', message: 'Mot de passe actuel incorrect' });
    const hashedPassword = await hashPassword(newPassword);
    await User.updatePassword(req.user.id, hashedPassword);
    res.json({ status: 'success', message: 'Mot de passe modifie!' });
  } catch (error) {
    next(error);
  }
};
