const Availability = require('../models/Availability');
const WorkerProfile = require('../models/WorkerProfile');

// Set availability for a single date
exports.setAvailability = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { date, start_time, end_time, is_available, note } = req.body;

    if (!date) {
      return res.status(400).json({ status: 'error', message: 'La date est requise' });
    }

    await Availability.create(profile.id, { date, start_time, end_time, is_available, note });

    res.json({ status: 'success', message: 'Disponibilité enregistrée' });
  } catch (error) {
    console.error('Set availability error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'enregistrement' });
  }
};

// Bulk set availabilities (calendar view)
exports.bulkSetAvailabilities = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { availabilities } = req.body;

    if (!availabilities || !Array.isArray(availabilities)) {
      return res.status(400).json({ status: 'error', message: 'Format invalide' });
    }

    await Availability.bulkCreate(profile.id, availabilities);

    res.json({ status: 'success', message: `${availabilities.length} disponibilités enregistrées` });
  } catch (error) {
    console.error('Bulk set availabilities error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'enregistrement' });
  }
};

// Get my availabilities for a month
exports.getMyAvailabilities = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { year, month } = req.query;
    const currentDate = new Date();
    const y = parseInt(year) || currentDate.getFullYear();
    const m = parseInt(month) || currentDate.getMonth() + 1;

    const availabilities = await Availability.findByWorkerAndMonth(profile.id, y, m);

    res.json({ status: 'success', data: { availabilities, year: y, month: m } });
  } catch (error) {
    console.error('Get availabilities error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Get worker's public availabilities (for establishments)
exports.getWorkerAvailabilities = async (req, res) => {
  try {
    const { workerId } = req.params;
    const { start_date, end_date } = req.query;

    if (!start_date || !end_date) {
      return res.status(400).json({ status: 'error', message: 'Dates de début et fin requises' });
    }

    const availabilities = await Availability.findByWorkerAndRange(workerId, start_date, end_date);

    // Only return available dates (hide unavailable for privacy)
    const publicAvailabilities = availabilities
      .filter(a => a.is_available)
      .map(a => ({ date: a.date, start_time: a.start_time, end_time: a.end_time }));

    res.json({ status: 'success', data: { availabilities: publicAvailabilities } });
  } catch (error) {
    console.error('Get worker availabilities error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Find available workers for mission dates
exports.findAvailableWorkers = async (req, res) => {
  try {
    const { start_date, end_date, region_id, is_labeled } = req.query;

    if (!start_date || !end_date) {
      return res.status(400).json({ status: 'error', message: 'Dates requises' });
    }

    const workers = await Availability.findAvailableWorkers(start_date, end_date, {
      region_id, is_labeled: is_labeled === 'true'
    });

    res.json({ status: 'success', data: { workers, count: workers.length } });
  } catch (error) {
    console.error('Find available workers error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la recherche' });
  }
};

// Delete availability
exports.deleteAvailability = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { date } = req.params;
    await Availability.delete(profile.id, date);

    res.json({ status: 'success', message: 'Disponibilité supprimée' });
  } catch (error) {
    console.error('Delete availability error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la suppression' });
  }
};
