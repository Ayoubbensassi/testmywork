const Region = require('../models/Region');
const pool = require('../config/database');

exports.getAllRegions = async (req, res) => {
  try {
    const regions = await Region.findAll();
    res.json({ status: 'success', data: { regions } });
  } catch (error) {
    console.error('Get regions error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des régions' });
  }
};

exports.getCitiesByRegion = async (req, res) => {
  try {
    const { regionId } = req.params;
    const cities = await Region.getCitiesByRegion(regionId);
    res.json({ status: 'success', data: { cities } });
  } catch (error) {
    console.error('Get cities error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des villes' });
  }
};

exports.getAllCities = async (req, res) => {
  try {
    const cities = await Region.getAllCities();
    res.json({ status: 'success', data: { cities } });
  } catch (error) {
    console.error('Get all cities error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des villes' });
  }
};

exports.getAllSpecialties = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM specialties ORDER BY name');
    res.json({ status: 'success', data: { specialties: rows } });
  } catch (error) {
    console.error('Get specialties error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des spécialités' });
  }
};
