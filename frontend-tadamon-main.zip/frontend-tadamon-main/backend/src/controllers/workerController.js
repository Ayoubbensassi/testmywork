const WorkerProfile = require('../models/WorkerProfile');
const { isValidCIN, isValidPhone } = require('../utils/validators');

exports.createProfile = async (req, res) => {
  try {
    const userId = req.user.id;

    const existing = await WorkerProfile.findByUserId(userId);
    if (existing) {
      return res.status(409).json({ status: 'error', message: 'Un profil existe déjà pour cet utilisateur' });
    }

    const { cin, phone, first_name, last_name, region_id, city_id } = req.body;

    if (!first_name || !last_name || !cin || !region_id || !city_id) {
      return res.status(400).json({ status: 'error', message: 'Prénom, nom, CIN, région et ville sont requis' });
    }

    if (!isValidCIN(cin)) {
      return res.status(400).json({ status: 'error', message: 'Format CIN invalide (ex: A123456)' });
    }

    const cinExists = await WorkerProfile.cinExists(cin);
    if (cinExists) {
      return res.status(409).json({ status: 'error', message: 'Ce numéro CIN est déjà utilisé' });
    }

    if (phone && !isValidPhone(phone)) {
      return res.status(400).json({ status: 'error', message: 'Format téléphone invalide (ex: 0612345678)' });
    }

    const profileId = await WorkerProfile.create(userId, req.body);

    res.status(201).json({
      status: 'success',
      message: 'Profil créé avec succès. En attente de validation.',
      data: { profileId }
    });
  } catch (error) {
    next(error);
  }
};

exports.getMyProfile = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const specialties = await WorkerProfile.getSpecialties(profile.id);
    profile.specialties = specialties;

    res.json({ status: 'success', data: { profile } });
  } catch (error) {
    next(error);
  }
};

exports.updateMyProfile = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    delete req.body.cin; // Cannot modify CIN
    delete req.body.is_labeled; // Cannot self-label
    await WorkerProfile.update(profile.id, req.body);

    res.json({ status: 'success', message: 'Profil mis à jour avec succès' });
  } catch (error) {
    next(error);
  }
};

exports.uploadDocuments = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const updates = {};
    if (req.files.cin_front) updates.cin_document_front = req.files.cin_front[0].path;
    if (req.files.cin_back) updates.cin_document_back = req.files.cin_back[0].path;
    if (req.files.cv) updates.cv_document = req.files.cv[0].path;
    if (req.files.profile_picture) updates.profile_picture = req.files.profile_picture[0].path;

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ status: 'error', message: 'Aucun fichier uploadé' });
    }

    await WorkerProfile.update(profile.id, updates);

    res.json({ status: 'success', message: 'Documents uploadés avec succès', data: updates });
  } catch (error) {
    next(error);
  }
};

exports.getPublicProfile = async (req, res) => {
  try {
    const profile = await WorkerProfile.findById(req.params.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const specialties = await WorkerProfile.getSpecialties(profile.id);

    const publicProfile = {
      id: profile.id,
      first_name: profile.first_name,
      last_name: profile.last_name,
      city_name: profile.city_name,
      region_name: profile.region_name,
      bio: profile.bio,
      years_experience: profile.years_experience,
      average_rating: profile.average_rating,
      total_missions: profile.total_missions,
      profile_picture: profile.profile_picture,
      daily_rate: profile.daily_rate,
      is_labeled: profile.is_labeled, // Show "Label Réseau" badge
      specialties
    };

    res.json({ status: 'success', data: { profile: publicProfile } });
  } catch (error) {
    next(error);
  }
};

exports.getAllWorkers = async (req, res) => {
  try {
    const { region_id, city_id, status = 'approved', page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const workers = await WorkerProfile.findAll({
      region_id, city_id, status, limit: parseInt(limit), offset
    });

    const total = await WorkerProfile.count({ status });

    res.json({
      status: 'success',
      data: { workers, pagination: { page: parseInt(page), limit: parseInt(limit), total } }
    });
  } catch (error) {
    next(error);
  }
};

// Advanced search for establishments
exports.searchWorkers = async (req, res) => {
  try {
    const {
      region_id, city_id, specialty_id, is_labeled,
      min_experience, min_rating, search,
      page = 1, limit = 20
    } = req.query;

    const offset = (page - 1) * limit;

    const workers = await WorkerProfile.search({
      region_id, city_id, specialty_id, is_labeled,
      min_experience, min_rating, search,
      limit: parseInt(limit), offset
    });

    // Get specialties for each worker
    for (const worker of workers) {
      worker.specialties = await WorkerProfile.getSpecialties(worker.id);
    }

    res.json({
      status: 'success',
      data: {
        workers,
        count: workers.length,
        filters: { region_id, city_id, specialty_id, is_labeled, min_experience, min_rating }
      }
    });
  } catch (error) {
    next(error);
  }
};

// Add specialty to profile
exports.addSpecialty = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { specialty_id, years_experience, proficiency_level } = req.body;

    if (!specialty_id) {
      return res.status(400).json({ status: 'error', message: 'Spécialité requise' });
    }

    await WorkerProfile.addSpecialty(profile.id, specialty_id, years_experience || 0, proficiency_level || 'intermediate');

    res.json({ status: 'success', message: 'Spécialité ajoutée' });
  } catch (error) {
    next(error);
  }
};

// Remove specialty from profile
exports.removeSpecialty = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { specialtyId } = req.params;
    await WorkerProfile.removeSpecialty(profile.id, specialtyId);

    res.json({ status: 'success', message: 'Spécialité supprimée' });
  } catch (error) {
    next(error);
  }
};
