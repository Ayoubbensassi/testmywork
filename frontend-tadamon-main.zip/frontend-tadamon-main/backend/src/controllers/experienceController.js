const Experience = require('../models/Experience');
const WorkerProfile = require('../models/WorkerProfile');

// Add experience
exports.addExperience = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { job_title, employer, start_date, end_date, is_current, description } = req.body;

    if (!job_title || !employer || !start_date) {
      return res.status(400).json({ status: 'error', message: 'Titre, employeur et date de début requis' });
    }

    const experienceId = await Experience.create(profile.id, {
      job_title, employer, start_date, end_date, is_current, description
    });

    // Update total years of experience
    await updateYearsExperience(profile.id);

    res.status(201).json({
      status: 'success',
      message: 'Expérience ajoutée avec succès',
      data: { experienceId }
    });
  } catch (error) {
    console.error('Add experience error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'ajout' });
  }
};

// Get my experiences
exports.getMyExperiences = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const experiences = await Experience.findByWorker(profile.id);

    res.json({ status: 'success', data: { experiences } });
  } catch (error) {
    console.error('Get experiences error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Get worker's experiences (public)
exports.getWorkerExperiences = async (req, res) => {
  try {
    const { workerId } = req.params;
    const experiences = await Experience.findByWorker(workerId);

    res.json({ status: 'success', data: { experiences } });
  } catch (error) {
    console.error('Get worker experiences error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Update experience
exports.updateExperience = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const experience = await Experience.findById(req.params.id);
    if (!experience || experience.worker_id !== profile.id) {
      return res.status(404).json({ status: 'error', message: 'Expérience non trouvée' });
    }

    const { job_title, employer, start_date, end_date, is_current, description } = req.body;
    await Experience.update(experience.id, { job_title, employer, start_date, end_date, is_current, description });

    // Update total years of experience
    await updateYearsExperience(profile.id);

    res.json({ status: 'success', message: 'Expérience mise à jour' });
  } catch (error) {
    console.error('Update experience error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la mise à jour' });
  }
};

// Delete experience
exports.deleteExperience = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const experience = await Experience.findById(req.params.id);
    if (!experience || experience.worker_id !== profile.id) {
      return res.status(404).json({ status: 'error', message: 'Expérience non trouvée' });
    }

    await Experience.delete(experience.id);

    // Update total years of experience
    await updateYearsExperience(profile.id);

    res.json({ status: 'success', message: 'Expérience supprimée' });
  } catch (error) {
    console.error('Delete experience error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la suppression' });
  }
};

// Helper: Calculate and update total years of experience
async function updateYearsExperience(workerId) {
  const experiences = await Experience.findByWorker(workerId);
  
  let totalMonths = 0;
  const now = new Date();

  for (const exp of experiences) {
    const start = new Date(exp.start_date);
    const end = exp.is_current ? now : (exp.end_date ? new Date(exp.end_date) : now);
    const months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
    totalMonths += Math.max(0, months);
  }

  const years = Math.round(totalMonths / 12);
  await WorkerProfile.update(workerId, { years_experience: years });
}
