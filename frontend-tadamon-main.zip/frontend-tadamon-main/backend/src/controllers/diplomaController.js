const Diploma = require('../models/Diploma');
const WorkerProfile = require('../models/WorkerProfile');

// Add diploma
exports.addDiploma = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { title, institution, obtained_date } = req.body;

    if (!title || !institution) {
      return res.status(400).json({ status: 'error', message: 'Titre et institution requis' });
    }

    const file_path = req.file ? req.file.path : null;

    const diplomaId = await Diploma.create(profile.id, {
      title, institution, obtained_date, file_path
    });

    res.status(201).json({
      status: 'success',
      message: 'Diplôme ajouté avec succès',
      data: { diplomaId }
    });
  } catch (error) {
    console.error('Add diploma error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'ajout du diplôme' });
  }
};

// Get my diplomas
exports.getMyDiplomas = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const diplomas = await Diploma.findByWorker(profile.id);

    res.json({ status: 'success', data: { diplomas } });
  } catch (error) {
    console.error('Get diplomas error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Get worker's diplomas (public - only verified ones)
exports.getWorkerDiplomas = async (req, res) => {
  try {
    const { workerId } = req.params;
    const diplomas = await Diploma.findByWorker(workerId);

    // Only show verified diplomas to public
    const publicDiplomas = diplomas
      .filter(d => d.is_verified)
      .map(d => ({
        id: d.id,
        title: d.title,
        institution: d.institution,
        obtained_date: d.obtained_date,
        is_verified: d.is_verified
      }));

    res.json({ status: 'success', data: { diplomas: publicDiplomas } });
  } catch (error) {
    console.error('Get worker diplomas error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Update diploma
exports.updateDiploma = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const diploma = await Diploma.findById(req.params.id);
    if (!diploma || diploma.worker_id !== profile.id) {
      return res.status(404).json({ status: 'error', message: 'Diplôme non trouvé' });
    }

    // Cannot update verified diploma
    if (diploma.is_verified) {
      return res.status(403).json({ status: 'error', message: 'Impossible de modifier un diplôme vérifié' });
    }

    const { title, institution, obtained_date } = req.body;
    await Diploma.update(diploma.id, { title, institution, obtained_date });

    res.json({ status: 'success', message: 'Diplôme mis à jour' });
  } catch (error) {
    console.error('Update diploma error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la mise à jour' });
  }
};

// Delete diploma
exports.deleteDiploma = async (req, res) => {
  try {
    const profile = await WorkerProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const diploma = await Diploma.findById(req.params.id);
    if (!diploma || diploma.worker_id !== profile.id) {
      return res.status(404).json({ status: 'error', message: 'Diplôme non trouvé' });
    }

    await Diploma.delete(diploma.id);

    res.json({ status: 'success', message: 'Diplôme supprimé' });
  } catch (error) {
    console.error('Delete diploma error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la suppression' });
  }
};

// Admin: Verify diploma
exports.verifyDiploma = async (req, res) => {
  try {
    const diploma = await Diploma.findById(req.params.id);
    if (!diploma) {
      return res.status(404).json({ status: 'error', message: 'Diplôme non trouvé' });
    }

    await Diploma.verify(diploma.id, req.user.id);

    // Check if worker should get labeled (all diplomas verified)
    const workerDiplomas = await Diploma.findByWorker(diploma.worker_id);
    const allVerified = workerDiplomas.every(d => d.is_verified || d.id === diploma.id);
    
    if (allVerified && workerDiplomas.length > 0) {
      await WorkerProfile.update(diploma.worker_id, { is_labeled: true });
    }

    res.json({ status: 'success', message: 'Diplôme vérifié avec succès' });
  } catch (error) {
    console.error('Verify diploma error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la vérification' });
  }
};
