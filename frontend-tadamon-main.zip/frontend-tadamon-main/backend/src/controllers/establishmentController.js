const EstablishmentProfile = require('../models/EstablishmentProfile');
const { isValidICE, isValidPhone } = require('../utils/validators');

exports.createProfile = async (req, res) => {
  try {
    const userId = req.user.id;

    const existing = await EstablishmentProfile.findByUserId(userId);
    if (existing) {
      return res.status(409).json({ status: 'error', message: 'Un profil existe déjà pour cet utilisateur' });
    }

    const { name, legal_name, ice, type, region_id, city_id } = req.body;

    if (!name || !legal_name || !ice || !type || !region_id || !city_id) {
      return res.status(400).json({ status: 'error', message: 'Nom, raison sociale, ICE, type, région et ville sont requis' });
    }

    if (!isValidICE(ice)) {
      return res.status(400).json({ status: 'error', message: 'Format ICE invalide (15 chiffres)' });
    }

    const iceExists = await EstablishmentProfile.iceExists(ice);
    if (iceExists) {
      return res.status(409).json({ status: 'error', message: 'Ce numéro ICE est déjà utilisé' });
    }

    if (req.body.phone && !isValidPhone(req.body.phone)) {
      return res.status(400).json({ status: 'error', message: 'Format téléphone invalide' });
    }

    const profileId = await EstablishmentProfile.create(userId, req.body);

    res.status(201).json({
      status: 'success',
      message: 'Profil créé avec succès. En attente de vérification.',
      data: { profileId }
    });
  } catch (error) {
    console.error('Create establishment profile error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la création du profil' });
  }
};

exports.getMyProfile = async (req, res) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }
    res.json({ status: 'success', data: { profile } });
  } catch (error) {
    console.error('Get establishment profile error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération du profil' });
  }
};

exports.updateMyProfile = async (req, res) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    delete req.body.ice; // Cannot modify ICE
    await EstablishmentProfile.update(profile.id, req.body);

    res.json({ status: 'success', message: 'Profil mis à jour avec succès' });
  } catch (error) {
    console.error('Update establishment profile error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la mise à jour du profil' });
  }
};

exports.uploadLogo = async (req, res) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    if (!req.file) {
      return res.status(400).json({ status: 'error', message: 'Aucun fichier uploadé' });
    }

    const logoPath = `/uploads/${req.file.filename}`;
    await EstablishmentProfile.update(profile.id, { logo: logoPath });

    res.json({ status: 'success', message: 'Logo uploadé avec succès', data: { logo: logoPath } });
  } catch (error) {
    console.error('Upload logo error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'upload du logo' });
  }
};

exports.uploadDocuments = async (req, res) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const updates = {};
    
    if (req.files) {
      if (req.files.ice_document && req.files.ice_document[0]) {
        updates.ice_document = `/uploads/${req.files.ice_document[0].filename}`;
      }
      if (req.files.registration_document && req.files.registration_document[0]) {
        updates.registration_document = `/uploads/${req.files.registration_document[0].filename}`;
      }
      if (req.files.authorization_document && req.files.authorization_document[0]) {
        updates.authorization_document = `/uploads/${req.files.authorization_document[0].filename}`;
      }
      if (req.files.logo && req.files.logo[0]) {
        updates.logo = `/uploads/${req.files.logo[0].filename}`;
      }
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ status: 'error', message: 'Aucun fichier uploadé' });
    }

    await EstablishmentProfile.update(profile.id, updates);

    res.json({ 
      status: 'success', 
      message: 'Documents uploadés avec succès', 
      data: updates 
    });
  } catch (error) {
    console.error('Upload establishment documents error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'upload des documents' });
  }
};

exports.getPublicProfile = async (req, res) => {
  try {
    const profile = await EstablishmentProfile.findById(req.params.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const publicProfile = {
      id: profile.id,
      name: profile.name,
      type: profile.type,
      city_name: profile.city_name,
      region_name: profile.region_name,
      description: profile.description,
      logo: profile.logo,
      is_verified: profile.is_verified,
      average_rating: profile.average_rating,
      total_missions: profile.total_missions
    };

    res.json({ status: 'success', data: { profile: publicProfile } });
  } catch (error) {
    console.error('Get public profile error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération du profil' });
  }
};

exports.getAllEstablishments = async (req, res) => {
  try {
    const { region_id, type, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const establishments = await EstablishmentProfile.findAll({
      region_id, type, is_verified: true, limit: parseInt(limit), offset
    });

    const total = await EstablishmentProfile.count({ is_verified: true });

    res.json({
      status: 'success',
      data: { establishments, pagination: { page: parseInt(page), limit: parseInt(limit), total } }
    });
  } catch (error) {
    console.error('Get all establishments error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des établissements' });
  }
};
