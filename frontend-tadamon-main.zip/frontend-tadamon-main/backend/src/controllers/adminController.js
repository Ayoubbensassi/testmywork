const User = require('../models/User');
const WorkerProfile = require('../models/WorkerProfile');
const EstablishmentProfile = require('../models/EstablishmentProfile');
const Mission = require('../models/Mission');
const Warning = require('../models/Warning');
const Diploma = require('../models/Diploma');
const Notification = require('../models/Notification');
const pool = require('../config/database');

exports.getDashboardStats = async (req, res) => {
  try {
    const [usersCount] = await pool.query('SELECT COUNT(*) as total FROM users');
    const [workersCount] = await pool.query('SELECT COUNT(*) as total FROM worker_profiles');
    const [estabCount] = await pool.query('SELECT COUNT(*) as total FROM establishment_profiles');
    const [missionsCount] = await pool.query('SELECT COUNT(*) as total FROM missions');
    const [pendingWorkers] = await pool.query("SELECT COUNT(*) as total FROM worker_profiles WHERE status = 'pending'");
    const [pendingEstabs] = await pool.query('SELECT COUNT(*) as total FROM establishment_profiles WHERE is_verified = FALSE');
    const [labeledWorkers] = await pool.query('SELECT COUNT(*) as total FROM worker_profiles WHERE is_labeled = TRUE');
    const [pendingDiplomas] = await pool.query('SELECT COUNT(*) as total FROM diplomas WHERE is_verified = FALSE');

    res.json({
      status: 'success',
      data: {
        stats: {
          total_users: usersCount[0].total,
          total_workers: workersCount[0].total,
          total_establishments: estabCount[0].total,
          total_missions: missionsCount[0].total,
          pending_workers: pendingWorkers[0].total,
          pending_establishments: pendingEstabs[0].total,
          labeled_workers: labeledWorkers[0].total,
          pending_diplomas: pendingDiplomas[0].total
        }
      }
    });
  } catch (error) {
    console.error('Get dashboard stats error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des statistiques' });
  }
};

exports.getPendingWorkers = async (req, res) => {
  try {
    const workers = await WorkerProfile.findAll({ status: 'pending' });
    res.json({ status: 'success', data: { workers } });
  } catch (error) {
    console.error('Get pending workers error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

exports.approveWorker = async (req, res) => {
  try {
    const worker = await WorkerProfile.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    await WorkerProfile.approve(worker.id, req.user.id);
    
    // Send notification
    await Notification.notifyProfileApproved(worker.user_id);

    res.json({ status: 'success', message: 'Profil approuvé avec succès' });
  } catch (error) {
    console.error('Approve worker error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'approbation' });
  }
};

exports.rejectWorker = async (req, res) => {
  try {
    const worker = await WorkerProfile.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    const { reason } = req.body;
    if (!reason) {
      return res.status(400).json({ status: 'error', message: 'Raison du rejet requise' });
    }

    await WorkerProfile.reject(worker.id, req.user.id, reason);
    res.json({ status: 'success', message: 'Profil rejeté' });
  } catch (error) {
    console.error('Reject worker error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors du rejet' });
  }
};

// Grant "Label Réseau" to a worker
exports.grantLabel = async (req, res) => {
  try {
    const worker = await WorkerProfile.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    if (worker.status !== 'approved') {
      return res.status(400).json({ status: 'error', message: 'Le profil doit être approuvé avant labellisation' });
    }

    await WorkerProfile.grantLabel(worker.id, req.user.id);

    // Notify worker
    await Notification.create(
      worker.user_id,
      'label',
      'Label Réseau obtenu!',
      'Félicitations! Vous avez obtenu le Label Réseau, gage de qualité et de confiance.',
      '/profile'
    );

    res.json({ status: 'success', message: 'Label Réseau accordé avec succès' });
  } catch (error) {
    console.error('Grant label error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la labellisation' });
  }
};

// Revoke "Label Réseau"
exports.revokeLabel = async (req, res) => {
  try {
    const worker = await WorkerProfile.findById(req.params.id);
    if (!worker) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    await WorkerProfile.revokeLabel(worker.id);

    res.json({ status: 'success', message: 'Label Réseau retiré' });
  } catch (error) {
    console.error('Revoke label error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors du retrait du label' });
  }
};

// Get pending diplomas for verification
exports.getPendingDiplomas = async (req, res) => {
  try {
    const [diplomas] = await pool.query(`
      SELECT d.*, wp.first_name, wp.last_name, wp.user_id
      FROM diplomas d
      JOIN worker_profiles wp ON d.worker_id = wp.id
      WHERE d.is_verified = FALSE
      ORDER BY d.created_at ASC
    `);

    res.json({ status: 'success', data: { diplomas } });
  } catch (error) {
    console.error('Get pending diplomas error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Verify a diploma
exports.verifyDiploma = async (req, res) => {
  try {
    const diploma = await Diploma.findById(req.params.id);
    if (!diploma) {
      return res.status(404).json({ status: 'error', message: 'Diplôme non trouvé' });
    }

    await Diploma.verify(diploma.id, req.user.id);

    // Check if all diplomas are verified -> auto-label
    const workerDiplomas = await Diploma.findByWorker(diploma.worker_id);
    const allVerified = workerDiplomas.every(d => d.is_verified || d.id === diploma.id);
    
    if (allVerified && workerDiplomas.length > 0) {
      const worker = await WorkerProfile.findById(diploma.worker_id);
      if (worker && worker.status === 'approved' && !worker.is_labeled) {
        await WorkerProfile.grantLabel(diploma.worker_id, req.user.id);
        
        await Notification.create(
          worker.user_id,
          'label',
          'Label Réseau obtenu!',
          'Tous vos diplômes ont été vérifiés. Vous avez obtenu le Label Réseau!',
          '/profile'
        );
      }
    }

    res.json({ status: 'success', message: 'Diplôme vérifié avec succès' });
  } catch (error) {
    console.error('Verify diploma error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la vérification' });
  }
};

// Get labeled workers
exports.getLabeledWorkers = async (req, res) => {
  try {
    const [workers] = await pool.query(`
      SELECT wp.*, r.name_fr as region_name, c.name_fr as city_name
      FROM worker_profiles wp
      LEFT JOIN regions r ON wp.region_id = r.id
      LEFT JOIN cities c ON wp.city_id = c.id
      WHERE wp.is_labeled = TRUE
      ORDER BY wp.labeled_at DESC
    `);

    res.json({ status: 'success', data: { workers } });
  } catch (error) {
    console.error('Get labeled workers error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

exports.getPendingEstablishments = async (req, res) => {
  try {
    const establishments = await EstablishmentProfile.findAll({ is_verified: false });
    res.json({ status: 'success', data: { establishments } });
  } catch (error) {
    console.error('Get pending establishments error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

exports.approveEstablishment = async (req, res) => {
  try {
    const estab = await EstablishmentProfile.findById(req.params.id);
    if (!estab) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    await EstablishmentProfile.verify(estab.id, req.user.id);
    res.json({ status: 'success', message: 'Établissement vérifié avec succès' });
  } catch (error) {
    console.error('Approve establishment error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la vérification' });
  }
};

exports.rejectEstablishment = async (req, res) => {
  try {
    const estab = await EstablishmentProfile.findById(req.params.id);
    if (!estab) {
      return res.status(404).json({ status: 'error', message: 'Profil non trouvé' });
    }

    await EstablishmentProfile.unverify(estab.id);
    res.json({ status: 'success', message: 'Vérification retirée' });
  } catch (error) {
    console.error('Reject establishment error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors du rejet' });
  }
};

exports.getAllWarnings = async (req, res) => {
  try {
    const [warnings] = await pool.query(`
      SELECT w.*, u.email as user_email, r.title as rule_title
      FROM warnings w
      LEFT JOIN users u ON w.user_id = u.id
      LEFT JOIN rules r ON w.rule_id = r.id
      ORDER BY w.created_at DESC
    `);
    res.json({ status: 'success', data: { warnings } });
  } catch (error) {
    console.error('Get warnings error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

exports.issueWarning = async (req, res) => {
  try {
    const { user_id, rule_id, reason } = req.body;

    if (!user_id || !reason) {
      return res.status(400).json({ status: 'error', message: 'Utilisateur et raison requis' });
    }

    const warningId = await Warning.create(user_id, rule_id, reason, req.user.id);
    await User.incrementWarnings(user_id);

    res.status(201).json({ status: 'success', message: 'Avertissement émis', data: { warningId } });
  } catch (error) {
    console.error('Issue warning error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'émission' });
  }
};

exports.deactivateUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ status: 'error', message: 'Utilisateur non trouvé' });
    }

    await User.deactivate(user.id);
    res.json({ status: 'success', message: 'Compte désactivé' });
  } catch (error) {
    console.error('Deactivate user error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la désactivation' });
  }
};

exports.reactivateUser = async (req, res) => {
  try {
    await pool.query('UPDATE users SET is_active = TRUE WHERE id = ?', [req.params.id]);
    res.json({ status: 'success', message: 'Compte réactivé' });
  } catch (error) {
    console.error('Reactivate user error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la réactivation' });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const { role, is_active, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let query = 'SELECT id, email, role, is_active, is_verified, warnings_count, created_at, last_login FROM users WHERE 1=1';
    const values = [];

    if (role) {
      query += ' AND role = ?';
      values.push(role);
    }

    if (is_active !== undefined) {
      query += ' AND is_active = ?';
      values.push(is_active === 'true');
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    values.push(parseInt(limit), offset);

    const [users] = await pool.query(query, values);
    const [countResult] = await pool.query('SELECT COUNT(*) as total FROM users');

    res.json({
      status: 'success',
      data: { users, pagination: { page: parseInt(page), limit: parseInt(limit), total: countResult[0].total } }
    });
  } catch (error) {
    console.error('Get all users error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération' });
  }
};

// Get all applications (matchings) for admin overview
exports.getAllApplications = async (req, res) => {
  try {
    const { status, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT a.*, 
             m.title as mission_title, m.status as mission_status, m.start_date, m.end_date,
             wp.first_name as worker_first_name, wp.last_name as worker_last_name, wp.is_labeled,
             ep.name as establishment_name
      FROM applications a
      JOIN missions m ON a.mission_id = m.id
      JOIN worker_profiles wp ON a.worker_id = wp.id
      JOIN establishment_profiles ep ON m.establishment_id = ep.id
      WHERE 1=1
    `;
    const values = [];

    if (status) {
      query += ' AND a.status = ?';
      values.push(status);
    }

    query += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
    values.push(parseInt(limit), offset);

    const [applications] = await pool.query(query, values);
    
    // Get counts by status
    const [counts] = await pool.query(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
      FROM applications
    `);

    res.json({
      status: 'success',
      data: { 
        applications, 
        stats: counts[0],
        pagination: { page: parseInt(page), limit: parseInt(limit) } 
      }
    });
  } catch (error) {
    console.error('Get all applications error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des candidatures' });
  }
};
