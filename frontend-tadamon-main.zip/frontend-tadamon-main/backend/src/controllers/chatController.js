const db = require('../config/database');

const chatController = {
  /**
   * Get chat contacts - ONLY users with accepted applications
   * Workers see establishments that accepted them
   * Establishments see workers they accepted
   */
  getContacts: async (req, res) => {
    try {
      const userId = req.user.id;
      const userRole = req.user.role;
      
      let query;
      
      if (userRole === 'worker') {
        // Worker sees establishments that accepted their applications
        query = `
          SELECT DISTINCT
            u.id as user_id,
            ep.name as first_name,
            '' as last_name,
            u.email,
            u.role,
            ep.logo as profile_picture,
            m.id as mission_id,
            m.title as mission_title,
            a.id as application_id,
            (
              SELECT msg.content 
              FROM messages msg
              JOIN conversations c ON msg.conversation_id = c.id
              WHERE (c.participant1_id = ? AND c.participant2_id = u.id)
                 OR (c.participant1_id = u.id AND c.participant2_id = ?)
              ORDER BY msg.created_at DESC 
              LIMIT 1
            ) as last_message,
            (
              SELECT COUNT(*) 
              FROM messages msg
              JOIN conversations c ON msg.conversation_id = c.id
              WHERE ((c.participant1_id = ? AND c.participant2_id = u.id)
                 OR (c.participant1_id = u.id AND c.participant2_id = ?))
              AND msg.sender_id = u.id
              AND msg.is_read = FALSE
            ) as unread_count
          FROM applications a
          JOIN missions m ON a.mission_id = m.id
          JOIN establishment_profiles ep ON m.establishment_id = ep.id
          JOIN users u ON ep.user_id = u.id
          JOIN worker_profiles wp ON a.worker_id = wp.id
          WHERE wp.user_id = ?
            AND a.status = 'accepted'
          ORDER BY a.updated_at DESC
        `;
      } else if (userRole === 'establishment') {
        // Establishment sees workers they accepted
        query = `
          SELECT DISTINCT
            u.id as user_id,
            wp.first_name,
            wp.last_name,
            u.email,
            u.role,
            wp.profile_picture,
            m.id as mission_id,
            m.title as mission_title,
            a.id as application_id,
            (
              SELECT msg.content 
              FROM messages msg
              JOIN conversations c ON msg.conversation_id = c.id
              WHERE (c.participant1_id = ? AND c.participant2_id = u.id)
                 OR (c.participant1_id = u.id AND c.participant2_id = ?)
              ORDER BY msg.created_at DESC 
              LIMIT 1
            ) as last_message,
            (
              SELECT COUNT(*) 
              FROM messages msg
              JOIN conversations c ON msg.conversation_id = c.id
              WHERE ((c.participant1_id = ? AND c.participant2_id = u.id)
                 OR (c.participant1_id = u.id AND c.participant2_id = ?))
              AND msg.sender_id = u.id
              AND msg.is_read = FALSE
            ) as unread_count
          FROM applications a
          JOIN missions m ON a.mission_id = m.id
          JOIN establishment_profiles ep ON m.establishment_id = ep.id
          JOIN worker_profiles wp ON a.worker_id = wp.id
          JOIN users u ON wp.user_id = u.id
          WHERE ep.user_id = ?
            AND a.status = 'accepted'
          ORDER BY a.updated_at DESC
        `;
      } else {
        return res.json({ status: 'success', data: { contacts: [] } });
      }

      const params = [userId, userId, userId, userId, userId];
      const [contacts] = await db.query(query, params);

      res.json({ 
        status: 'success', 
        data: { contacts } 
      });
    } catch (error) {
      console.error('Get contacts error:', error);
      res.status(500).json({ 
        status: 'error', 
        message: 'Erreur lors de la récupération des contacts' 
      });
    }
  },

  /**
   * Get messages with a specific user
   * Only allowed if there's an accepted application between them
   */
  getMessages: async (req, res) => {
    try {
      const userId = req.user.id;
      const recipientId = parseInt(req.params.recipientId);
      
      // Verify there's an accepted application between these users
      const hasAccess = await chatController.verifyAccess(userId, recipientId, req.user.role);
      if (!hasAccess) {
        return res.status(403).json({ 
          status: 'error', 
          message: 'Vous ne pouvez pas envoyer de messages à cet utilisateur' 
        });
      }

      // Get or create conversation
      let [conversations] = await db.query(
        `SELECT id FROM conversations 
         WHERE (participant1_id = ? AND participant2_id = ?)
            OR (participant1_id = ? AND participant2_id = ?)`,
        [userId, recipientId, recipientId, userId]
      );

      let conversationId;
      if (conversations.length === 0) {
        // Create new conversation
        const [result] = await db.query(
          `INSERT INTO conversations (participant1_id, participant2_id, last_message_at) 
           VALUES (?, ?, NOW())`,
          [userId, recipientId]
        );
        conversationId = result.insertId;
      } else {
        conversationId = conversations[0].id;
      }

      // Get messages
      const [messages] = await db.query(
        `SELECT m.*, 
                CASE WHEN m.sender_id = ? THEN 'sent' ELSE 'received' END as direction
         FROM messages m
         WHERE m.conversation_id = ?
         ORDER BY m.created_at ASC
         LIMIT 100`,
        [userId, conversationId]
      );

      // Mark messages as read
      await db.query(
        `UPDATE messages 
         SET is_read = TRUE, read_at = NOW() 
         WHERE conversation_id = ? AND sender_id = ? AND is_read = FALSE`,
        [conversationId, recipientId]
      );

      res.json({ 
        status: 'success', 
        data: { messages, conversationId } 
      });
    } catch (error) {
      console.error('Get messages error:', error);
      res.status(500).json({ 
        status: 'error', 
        message: 'Erreur lors de la récupération des messages' 
      });
    }
  },

  /**
   * Send a message
   * Only allowed if there's an accepted application between users
   */
  sendMessage: async (req, res) => {
    try {
      const userId = req.user.id;
      const { recipient_id, content } = req.body;

      if (!content || !content.trim()) {
        return res.status(400).json({ 
          status: 'error', 
          message: 'Le message ne peut pas être vide' 
        });
      }

      // Verify access
      const hasAccess = await chatController.verifyAccess(userId, recipient_id, req.user.role);
      if (!hasAccess) {
        return res.status(403).json({ 
          status: 'error', 
          message: 'Vous ne pouvez pas envoyer de messages à cet utilisateur' 
        });
      }

      // Get or create conversation
      let [conversations] = await db.query(
        `SELECT id FROM conversations 
         WHERE (participant1_id = ? AND participant2_id = ?)
            OR (participant1_id = ? AND participant2_id = ?)`,
        [userId, recipient_id, recipient_id, userId]
      );

      let conversationId;
      if (conversations.length === 0) {
        const [result] = await db.query(
          `INSERT INTO conversations (participant1_id, participant2_id, last_message_at) 
           VALUES (?, ?, NOW())`,
          [userId, recipient_id]
        );
        conversationId = result.insertId;
      } else {
        conversationId = conversations[0].id;
      }

      // Insert message
      const [result] = await db.query(
        `INSERT INTO messages (conversation_id, sender_id, content) VALUES (?, ?, ?)`,
        [conversationId, userId, content.trim()]
      );

      // Update conversation last_message_at
      await db.query(
        `UPDATE conversations SET last_message_at = NOW() WHERE id = ?`,
        [conversationId]
      );

      const message = {
        id: result.insertId,
        conversation_id: conversationId,
        sender_id: userId,
        content: content.trim(),
        is_read: false,
        created_at: new Date().toISOString()
      };

      res.json({ 
        status: 'success', 
        data: { message } 
      });
    } catch (error) {
      console.error('Send message error:', error);
      res.status(500).json({ 
        status: 'error', 
        message: 'Erreur lors de l\'envoi du message' 
      });
    }
  },

  /**
   * Mark messages as read
   */
  markAsRead: async (req, res) => {
    try {
      const userId = req.user.id;
      const senderId = parseInt(req.params.senderId);

      // Get conversation
      const [conversations] = await db.query(
        `SELECT id FROM conversations 
         WHERE (participant1_id = ? AND participant2_id = ?)
            OR (participant1_id = ? AND participant2_id = ?)`,
        [userId, senderId, senderId, userId]
      );

      if (conversations.length > 0) {
        await db.query(
          `UPDATE messages 
           SET is_read = TRUE, read_at = NOW() 
           WHERE conversation_id = ? AND sender_id = ? AND is_read = FALSE`,
          [conversations[0].id, senderId]
        );
      }

      res.json({ status: 'success' });
    } catch (error) {
      console.error('Mark as read error:', error);
      res.status(500).json({ 
        status: 'error', 
        message: 'Erreur lors du marquage des messages' 
      });
    }
  },

  /**
   * Get unread message count
   */
  getUnreadCount: async (req, res) => {
    try {
      const userId = req.user.id;

      const [result] = await db.query(
        `SELECT COUNT(*) as count
         FROM messages m
         JOIN conversations c ON m.conversation_id = c.id
         WHERE (c.participant1_id = ? OR c.participant2_id = ?)
           AND m.sender_id != ?
           AND m.is_read = FALSE`,
        [userId, userId, userId]
      );

      res.json({ 
        status: 'success', 
        data: { unread_count: result[0].count } 
      });
    } catch (error) {
      console.error('Get unread count error:', error);
      res.status(500).json({ 
        status: 'error', 
        message: 'Erreur lors de la récupération du nombre de messages non lus' 
      });
    }
  },

  /**
   * Verify that two users can chat (accepted application exists)
   */
  verifyAccess: async (userId, otherUserId, userRole) => {
    try {
      let query;
      
      if (userRole === 'worker') {
        // Check if worker has accepted application with this establishment
        query = `
          SELECT a.id FROM applications a
          JOIN missions m ON a.mission_id = m.id
          JOIN establishment_profiles ep ON m.establishment_id = ep.id
          JOIN worker_profiles wp ON a.worker_id = wp.id
          WHERE wp.user_id = ?
            AND ep.user_id = ?
            AND a.status = 'accepted'
          LIMIT 1
        `;
      } else if (userRole === 'establishment') {
        // Check if establishment accepted this worker
        query = `
          SELECT a.id FROM applications a
          JOIN missions m ON a.mission_id = m.id
          JOIN establishment_profiles ep ON m.establishment_id = ep.id
          JOIN worker_profiles wp ON a.worker_id = wp.id
          WHERE ep.user_id = ?
            AND wp.user_id = ?
            AND a.status = 'accepted'
          LIMIT 1
        `;
      } else {
        return false;
      }

      const [result] = await db.query(query, [userId, otherUserId]);
      return result.length > 0;
    } catch (error) {
      console.error('Verify access error:', error);
      return false;
    }
  }
};

module.exports = chatController;
