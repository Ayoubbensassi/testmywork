const pool = require('../config/database');
const nodemailer = require('nodemailer');

// Create contact messages table if not exists
const initContactTable = async () => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        user_type ENUM('worker', 'establishment', 'other') NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('new', 'read', 'replied', 'closed') DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `);
  } catch (error) {
    console.error('Error creating contact_messages table:', error);
  }
};

initContactTable();

exports.submitContactForm = async (req, res) => {
  try {
    const { name, email, userType, subject, message } = req.body;

    // Validation
    if (!name || !email || !userType || !subject || !message) {
      return res.status(400).json({
        status: 'error',
        message: 'Tous les champs sont requis'
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        status: 'error',
        message: 'Email invalide'
      });
    }

    // Save to database
    const [result] = await pool.query(
      `INSERT INTO contact_messages (name, email, user_type, subject, message) VALUES (?, ?, ?, ?, ?)`,
      [name, email, userType, subject, message]
    );

    // Try to send email notification (optional - won't fail if email not configured)
    try {
      if (process.env.SMTP_HOST && process.env.SMTP_USER) {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: process.env.SMTP_PORT || 587,
          secure: false,
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
          }
        });

        await transporter.sendMail({
          from: process.env.SMTP_FROM || 'noreply@lkhedma.ma',
          to: process.env.CONTACT_EMAIL || 'contact@lkhedma.ma',
          subject: `[Contact LKHEDMA] ${subject}`,
          html: `
            <h2>Nouveau message de contact</h2>
            <p><strong>Nom:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Type:</strong> ${userType}</p>
            <p><strong>Sujet:</strong> ${subject}</p>
            <p><strong>Message:</strong></p>
            <p>${message.replace(/\n/g, '<br>')}</p>
          `
        });
      }
    } catch (emailError) {
      console.log('Email notification skipped (SMTP not configured)');
    }

    res.status(201).json({
      status: 'success',
      message: 'Message envoyé avec succès',
      data: { id: result.insertId }
    });
  } catch (error) {
    console.error('Contact form error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Erreur lors de l\'envoi du message'
    });
  }
};

// Admin: Get all contact messages
exports.getContactMessages = async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    let query = 'SELECT * FROM contact_messages WHERE 1=1';
    const values = [];

    if (status) {
      query += ' AND status = ?';
      values.push(status);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    values.push(parseInt(limit), offset);

    const [messages] = await pool.query(query, values);
    const [countResult] = await pool.query('SELECT COUNT(*) as total FROM contact_messages');

    res.json({
      status: 'success',
      data: {
        messages,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: countResult[0].total
        }
      }
    });
  } catch (error) {
    console.error('Get contact messages error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Erreur lors de la récupération des messages'
    });
  }
};

// Admin: Update message status
exports.updateMessageStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['new', 'read', 'replied', 'closed'].includes(status)) {
      return res.status(400).json({
        status: 'error',
        message: 'Statut invalide'
      });
    }

    await pool.query('UPDATE contact_messages SET status = ? WHERE id = ?', [status, id]);

    res.json({
      status: 'success',
      message: 'Statut mis à jour'
    });
  } catch (error) {
    console.error('Update message status error:', error);
    res.status(500).json({
      status: 'error',
      message: 'Erreur lors de la mise à jour'
    });
  }
};
