const path = require('path');
const fs = require('fs');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const pdfParse = require('pdf-parse');

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Extract text from PDF
const extractTextFromPDF = async (filePath) => {
  try {
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdfParse(dataBuffer);
    return data.text;
  } catch (error) {
    console.error('PDF extraction error:', error);
    return null;
  }
};

// Analyze CV with Gemini AI
const analyzeWithGemini = async (cvText) => {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    const prompt = `Tu es un expert en recrutement dans le secteur social et médico-social en France. 
Analyse ce CV et fournis une évaluation détaillée.

CV à analyser:
${cvText}

Réponds UNIQUEMENT en JSON valide avec cette structure exacte (sans markdown, sans backticks):
{
  "score": <nombre entre 0 et 100>,
  "strengths": ["point fort 1", "point fort 2", "point fort 3"],
  "improvements": ["amélioration 1", "amélioration 2", "amélioration 3"],
  "keywords": ["mot-clé 1", "mot-clé 2", "mot-clé 3", "mot-clé 4", "mot-clé 5"],
  "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3", "suggestion 4"],
  "summary": "Résumé en 2-3 phrases de l'analyse globale du CV"
}

Critères d'évaluation:
- Pertinence pour le secteur social/médico-social
- Clarté et structure du CV
- Expériences professionnelles
- Formations et diplômes (DEES, DEASS, CAFERUIS, etc.)
- Compétences techniques et relationnelles
- Mots-clés du secteur social`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    let text = response.text();
    
    // Clean up response - remove markdown code blocks if present
    text = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    
    const analysis = JSON.parse(text);
    return analysis;
  } catch (error) {
    console.error('Gemini analysis error:', error);
    return null;
  }
};

// Fallback analysis without AI
const fallbackAnalysis = (text) => {
  const lowerText = text.toLowerCase();
  let score = 50;
  const strengths = [];
  const improvements = [];
  const keywords = [];
  const suggestions = [];

  // Social work keywords
  const socialKeywords = [
    'travail social', 'accompagnement', 'médiation', 'écoute active', 'insertion',
    'handicap', 'personnes âgées', 'enfance', 'protection', 'aide sociale',
    'éducateur', 'assistant social', 'animateur', 'coordinateur', 'intervenant',
    'DEES', 'DEASS', 'CAFERUIS', 'diplôme d\'état'
  ];

  socialKeywords.forEach(keyword => {
    if (lowerText.includes(keyword.toLowerCase())) {
      keywords.push(keyword);
      score += 3;
    }
  });

  // Check contact info
  if (/[\w.-]+@[\w.-]+\.\w+/.test(text)) {
    strengths.push('Email de contact présent');
    score += 5;
  } else {
    improvements.push('Ajouter une adresse email');
  }

  if (/0[67]\d{8}|0[1-5]\d{8}|\+33/.test(text)) {
    strengths.push('Numéro de téléphone présent');
    score += 5;
  } else {
    improvements.push('Ajouter un numéro de téléphone');
  }

  // Check experience
  if (/expérience|depuis\s*\d{4}|\d+\s*ans?/i.test(text)) {
    strengths.push('Expérience professionnelle mentionnée');
    score += 10;
  } else {
    improvements.push('Détailler votre expérience professionnelle');
  }

  // Check education
  if (/diplôme|formation|bac\+|licence|master|DEES|DEASS/i.test(text)) {
    strengths.push('Formation académique mentionnée');
    score += 10;
  } else {
    improvements.push('Ajouter vos diplômes et formations');
  }

  suggestions.push('Personnalisez votre CV pour chaque candidature');
  suggestions.push('Mettez en avant vos compétences relationnelles');
  suggestions.push('Quantifiez vos réalisations');
  suggestions.push('Ajoutez des références professionnelles');

  return {
    score: Math.min(100, Math.max(0, score)),
    strengths: strengths.length > 0 ? strengths : ['CV fourni pour analyse'],
    improvements: improvements.length > 0 ? improvements : ['Continuez à enrichir votre CV'],
    keywords: keywords.length > 0 ? keywords.slice(0, 8) : ['travail social'],
    suggestions,
    summary: 'Analyse basique effectuée. Pour une analyse plus détaillée, configurez l\'API Gemini.'
  };
};

exports.analyzeCV = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'Aucun fichier fourni' 
      });
    }

    const file = req.file;
    let textContent = '';
    let analysis = null;

    // Extract text from PDF
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext === '.pdf') {
      textContent = await extractTextFromPDF(file.path);
    }

    // If we have text content and Gemini API key, use AI analysis
    if (textContent && process.env.GEMINI_API_KEY) {
      analysis = await analyzeWithGemini(textContent);
    }

    // Fallback to basic analysis
    if (!analysis) {
      analysis = textContent 
        ? fallbackAnalysis(textContent)
        : {
            score: 60,
            strengths: ['Document CV fourni', `Format ${ext} accepté`],
            improvements: ['Utilisez un format PDF pour une meilleure analyse', 'Assurez-vous que le texte est sélectionnable'],
            keywords: ['CV', 'Candidature'],
            suggestions: [
              'Personnalisez votre CV pour chaque mission',
              'Mettez en avant vos compétences en travail social',
              'Incluez des références professionnelles',
              'Quantifiez vos réalisations'
            ],
            summary: 'Analyse limitée - le contenu du fichier n\'a pas pu être extrait.'
          };
    }

    // Clean up uploaded file
    if (fs.existsSync(file.path)) {
      fs.unlinkSync(file.path);
    }

    res.json({
      status: 'success',
      data: { analysis }
    });

  } catch (error) {
    console.error('CV Analysis error:', error);
    
    // Clean up file on error
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }

    res.status(500).json({ 
      status: 'error', 
      message: 'Erreur lors de l\'analyse du CV' 
    });
  }
};
