const Mission = require('../models/Mission');
const EstablishmentProfile = require('../models/EstablishmentProfile');
const { paginate } = require('../utils/pagination');

exports.createMission = async (req, res, next) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil établissement non trouvé' });
    }

    // Validation is handled by middleware now

    const missionId = await Mission.create(profile.id, req.body);

    // Add specialties if provided
    if (req.body.specialties && Array.isArray(req.body.specialties)) {
      for (const spec of req.body.specialties) {
        await Mission.addSpecialty(missionId, spec.id, spec.is_required);
      }
    }

    res.status(201).json({ status: 'success', message: 'Mission créée avec succès', data: { missionId } });
  } catch (error) {
    next(error);
  }
};

exports.getAllMissions = async (req, res, next) => {
  try {
    const { region_id, city_id, mission_type, is_urgent, search, page = 1, limit = 20 } = req.query;
    const { limit: lim, offset } = paginate(page, limit);

    const missions = await Mission.findAll({
      status: 'open', region_id, city_id, mission_type,
      is_urgent: is_urgent === 'true' ? true : undefined,
      search, limit: lim, offset
    });

    const total = await Mission.count({ status: 'open' });

    res.json({
      status: 'success',
      data: { missions, pagination: { page: parseInt(page), limit: lim, total } }
    });
  } catch (error) {
    next(error);
  }
};

exports.searchMissions = async (req, res, next) => {
  try {
    const { region_id, city_id, mission_type, search, page = 1, limit = 20 } = req.query;
    const { limit: lim, offset } = paginate(page, limit);

    const missions = await Mission.findAll({
      status: 'open', region_id, city_id, mission_type, search, limit: lim, offset
    });

    res.json({ status: 'success', data: { missions } });
  } catch (error) {
    next(error);
  }
};

exports.getMyMissions = async (req, res, next) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!profile) {
      return res.status(404).json({ status: 'error', message: 'Profil établissement non trouvé' });
    }

    const { status, page = 1, limit = 20 } = req.query;
    const { limit: lim, offset } = paginate(page, limit);

    const missions = await Mission.findByEstablishment(profile.id, { status, limit: lim, offset });

    res.json({ status: 'success', data: { missions } });
  } catch (error) {
    next(error);
  }
};

exports.getMissionById = async (req, res, next) => {
  try {
    const mission = await Mission.findById(req.params.id);
    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    const specialties = await Mission.getSpecialties(mission.id);
    mission.specialties = specialties;

    res.json({ status: 'success', data: { mission } });
  } catch (error) {
    next(error);
  }
};

exports.updateMission = async (req, res, next) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    const mission = await Mission.findById(req.params.id);

    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    if (mission.establishment_id !== profile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    await Mission.update(mission.id, req.body);

    res.json({ status: 'success', message: 'Mission mise à jour avec succès' });
  } catch (error) {
    next(error);
  }
};

exports.deleteMission = async (req, res, next) => {
  try {
    const profile = await EstablishmentProfile.findByUserId(req.user.id);
    const mission = await Mission.findById(req.params.id);

    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    if (mission.establishment_id !== profile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    await Mission.delete(mission.id);

    res.json({ status: 'success', message: 'Mission supprimée avec succès' });
  } catch (error) {
    next(error);
  }
};
