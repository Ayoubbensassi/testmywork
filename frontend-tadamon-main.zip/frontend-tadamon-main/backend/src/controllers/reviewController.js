const Review = require('../models/Review');
const Mission = require('../models/Mission');
const WorkerProfile = require('../models/WorkerProfile');
const EstablishmentProfile = require('../models/EstablishmentProfile');

exports.createReview = async (req, res) => {
  try {
    const { mission_id, rating, comment, is_public } = req.body;

    if (!mission_id || !rating) {
      return res.status(400).json({ status: 'error', message: 'Mission et note sont requis' });
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({ status: 'error', message: 'La note doit être entre 1 et 5' });
    }

    const mission = await Mission.findById(mission_id);
    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    if (mission.status !== 'completed') {
      return res.status(400).json({ status: 'error', message: 'La mission doit être terminée pour laisser un avis' });
    }

    // Check if already reviewed
    const alreadyReviewed = await Review.checkExists(mission_id, req.user.id);
    if (alreadyReviewed) {
      return res.status(409).json({ status: 'error', message: 'Vous avez déjà laissé un avis pour cette mission' });
    }

    // Determine reviewee_id based on who is reviewing
    let reviewee_id;
    const workerProfile = await WorkerProfile.findByUserId(req.user.id);
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);

    if (workerProfile && mission.selected_worker_id === workerProfile.id) {
      // Worker reviewing establishment
      const estab = await EstablishmentProfile.findById(mission.establishment_id);
      reviewee_id = estab.user_id;
    } else if (estabProfile && mission.establishment_id === estabProfile.id) {
      // Establishment reviewing worker
      const worker = await WorkerProfile.findById(mission.selected_worker_id);
      reviewee_id = worker.user_id;
    } else {
      return res.status(403).json({ status: 'error', message: 'Vous n\'êtes pas autorisé à évaluer cette mission' });
    }

    const reviewId = await Review.create({
      mission_id,
      reviewer_id: req.user.id,
      reviewee_id,
      rating,
      comment,
      is_public
    });

    // Update average rating for the reviewee
    if (workerProfile) {
      await EstablishmentProfile.updateRating(mission.establishment_id);
    } else {
      await WorkerProfile.updateRating(mission.selected_worker_id);
    }

    res.status(201).json({ status: 'success', message: 'Avis créé avec succès', data: { reviewId } });
  } catch (error) {
    console.error('Create review error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la création de l\'avis' });
  }
};

exports.getWorkerReviews = async (req, res) => {
  try {
    const worker = await WorkerProfile.findById(req.params.workerId);
    if (!worker) {
      return res.status(404).json({ status: 'error', message: 'Travailleur non trouvé' });
    }

    const reviews = await Review.findByReviewee(worker.user_id);
    const stats = await Review.getAverageRating(worker.user_id);

    res.json({
      status: 'success',
      data: { reviews, average_rating: stats.average, total_reviews: stats.count }
    });
  } catch (error) {
    console.error('Get worker reviews error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des avis' });
  }
};

exports.getEstablishmentReviews = async (req, res) => {
  try {
    const estab = await EstablishmentProfile.findById(req.params.establishmentId);
    if (!estab) {
      return res.status(404).json({ status: 'error', message: 'Établissement non trouvé' });
    }

    const reviews = await Review.findByReviewee(estab.user_id);
    const stats = await Review.getAverageRating(estab.user_id);

    res.json({
      status: 'success',
      data: { reviews, average_rating: stats.average, total_reviews: stats.count }
    });
  } catch (error) {
    console.error('Get establishment reviews error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des avis' });
  }
};

exports.getMyReviews = async (req, res) => {
  try {
    const reviews = await Review.findByReviewee(req.user.id);
    const stats = await Review.getAverageRating(req.user.id);

    res.json({
      status: 'success',
      data: { reviews, average_rating: stats.average, total_reviews: stats.count }
    });
  } catch (error) {
    console.error('Get my reviews error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des avis' });
  }
};
