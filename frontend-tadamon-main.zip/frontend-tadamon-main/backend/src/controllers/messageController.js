const Message = require('../models/Message');
const Mission = require('../models/Mission');
const WorkerProfile = require('../models/WorkerProfile');
const EstablishmentProfile = require('../models/EstablishmentProfile');

exports.getMyConversations = async (req, res) => {
  try {
    const conversations = await Message.getConversationsByUser(req.user.id);
    res.json({ status: 'success', data: { conversations } });
  } catch (error) {
    console.error('Get conversations error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des conversations' });
  }
};

exports.getConversationMessages = async (req, res) => {
  try {
    const conversation = await Message.findConversationById(req.params.conversationId);
    if (!conversation) {
      return res.status(404).json({ status: 'error', message: 'Conversation non trouvée' });
    }

    // Check authorization
    if (conversation.participant1_id !== req.user.id && conversation.participant2_id !== req.user.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    const { limit = 50, offset = 0 } = req.query;
    const messages = await Message.getMessages(conversation.id, req.user.id, parseInt(limit), parseInt(offset));

    // Mark messages as read
    await Message.markAllAsRead(conversation.id, req.user.id);

    res.json({ status: 'success', data: { conversation, messages } });
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des messages' });
  }
};

exports.sendMessage = async (req, res) => {
  try {
    const { conversation_id, content, mission_id, receiver_id } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ status: 'error', message: 'Le message ne peut pas être vide' });
    }

    let conversationId = conversation_id;

    // If no conversation_id, create a new conversation
    if (!conversationId && receiver_id) {
      // Can create conversation with or without mission_id
      conversationId = await Message.createConversation(mission_id || null, req.user.id, receiver_id);
    }

    if (!conversationId) {
      return res.status(400).json({ status: 'error', message: 'Conversation ID ou Receiver ID requis' });
    }

    // Verify user is part of conversation
    const conversation = await Message.findConversationById(conversationId);
    if (!conversation) {
      return res.status(404).json({ status: 'error', message: 'Conversation non trouvée' });
    }

    if (conversation.participant1_id !== req.user.id && conversation.participant2_id !== req.user.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    const messageId = await Message.sendMessage(conversationId, req.user.id, content.trim());

    res.status(201).json({
      status: 'success',
      message: 'Message envoyé',
      data: { messageId, conversationId }
    });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de l\'envoi du message' });
  }
};

exports.markAsRead = async (req, res) => {
  try {
    await Message.markAsRead(req.params.messageId);
    res.json({ status: 'success', message: 'Message marqué comme lu' });
  } catch (error) {
    console.error('Mark as read error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors du marquage' });
  }
};
