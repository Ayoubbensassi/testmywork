const Payment = require('../models/Payment');
const Mission = require('../models/Mission');
const EstablishmentProfile = require('../models/EstablishmentProfile');
const WorkerProfile = require('../models/WorkerProfile');

const COMMISSION_RATE = 15; // 15%

exports.createPayment = async (req, res) => {
  try {
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);
    if (!estabProfile) {
      return res.status(404).json({ status: 'error', message: 'Profil établissement non trouvé' });
    }

    const { mission_id, gross_amount } = req.body;

    if (!mission_id || !gross_amount) {
      return res.status(400).json({ status: 'error', message: 'Mission et montant sont requis' });
    }

    const mission = await Mission.findById(mission_id);
    if (!mission) {
      return res.status(404).json({ status: 'error', message: 'Mission non trouvée' });
    }

    if (mission.establishment_id !== estabProfile.id) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    if (!mission.selected_worker_id) {
      return res.status(400).json({ status: 'error', message: 'Aucun travailleur sélectionné pour cette mission' });
    }

    // Check if payment already exists
    const existingPayment = await Payment.findByMission(mission_id);
    if (existingPayment) {
      return res.status(409).json({ status: 'error', message: 'Un paiement existe déjà pour cette mission' });
    }

    const commission_amount = (gross_amount * COMMISSION_RATE) / 100;
    const net_amount = gross_amount - commission_amount;

    const paymentId = await Payment.create({
      mission_id,
      establishment_id: estabProfile.id,
      worker_id: mission.selected_worker_id,
      gross_amount,
      commission_rate: COMMISSION_RATE,
      commission_amount,
      net_amount
    });

    res.status(201).json({
      status: 'success',
      message: 'Paiement créé avec succès',
      data: { paymentId, gross_amount, commission_amount, net_amount }
    });
  } catch (error) {
    console.error('Create payment error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la création du paiement' });
  }
};

exports.getMyPayments = async (req, res) => {
  try {
    const workerProfile = await WorkerProfile.findByUserId(req.user.id);
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);

    let payments = [];
    if (workerProfile) {
      payments = await Payment.findByWorker(workerProfile.id, req.query);
    } else if (estabProfile) {
      payments = await Payment.findByEstablishment(estabProfile.id, req.query);
    }

    res.json({ status: 'success', data: { payments } });
  } catch (error) {
    console.error('Get my payments error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération des paiements' });
  }
};

exports.getPaymentById = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id);
    if (!payment) {
      return res.status(404).json({ status: 'error', message: 'Paiement non trouvé' });
    }

    // Check authorization
    const workerProfile = await WorkerProfile.findByUserId(req.user.id);
    const estabProfile = await EstablishmentProfile.findByUserId(req.user.id);

    const isWorker = workerProfile && payment.worker_id === workerProfile.id;
    const isEstab = estabProfile && payment.establishment_id === estabProfile.id;
    const isAdmin = req.user.role === 'admin';

    if (!isWorker && !isEstab && !isAdmin) {
      return res.status(403).json({ status: 'error', message: 'Accès refusé' });
    }

    res.json({ status: 'success', data: { payment } });
  } catch (error) {
    console.error('Get payment error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la récupération du paiement' });
  }
};

exports.releasePayment = async (req, res) => {
  try {
    const payment = await Payment.findById(req.params.id);
    if (!payment) {
      return res.status(404).json({ status: 'error', message: 'Paiement non trouvé' });
    }

    if (payment.payment_status !== 'paid') {
      return res.status(400).json({ status: 'error', message: 'Le paiement doit être payé avant d\'être libéré' });
    }

    await Payment.release(payment.id);

    res.json({ status: 'success', message: 'Paiement libéré avec succès' });
  } catch (error) {
    console.error('Release payment error:', error);
    res.status(500).json({ status: 'error', message: 'Erreur lors de la libération du paiement' });
  }
};
