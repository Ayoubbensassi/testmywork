function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPassword(password) {
  if (password.length < 8) return false;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  return hasUpperCase && hasNumber;
}

function isValidCIN(cin) {
  // Moroccan CIN: 1-2 letters followed by 5-7 digits
  // Examples: A123456, AB123456, BE1234567
  const cinRegex = /^[A-Z]{1,2}[0-9]{5,7}$/;
  return cinRegex.test(cin);
}

function isValidICE(ice) {
  const iceRegex = /^[0-9]{15}$/;
  return iceRegex.test(ice);
}

function isValidPhone(phone) {
  const phoneRegex = /^(0[567])[0-9]{8}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
}

module.exports = { isValidEmail, isValidPassword, isValidCIN, isValidICE, isValidPhone };
