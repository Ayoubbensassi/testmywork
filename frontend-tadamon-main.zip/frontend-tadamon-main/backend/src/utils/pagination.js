function paginate(page = 1, limit = 10) {
  const offset = (page - 1) * limit;
  return { limit: parseInt(limit), offset };
}

function paginateResponse(data, page, limit, total) {
  return {
    data,
    pagination: {
      page: parseInt(page),
      limit: parseInt(limit),
      total,
      totalPages: Math.ceil(total / limit)
    }
  };
}

module.exports = { paginate, paginateResponse };
