const pool = require('../config/database');

class Experience {
  static async create(workerId, data) {
    const { job_title, employer, start_date, end_date, is_current, description } = data;

    const [result] = await pool.query(
      `INSERT INTO experiences (worker_id, job_title, employer, start_date, end_date, is_current, description)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [workerId, job_title, employer, start_date, end_date, is_current || false, description]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM experiences WHERE id = ?', [id]);
    return rows[0];
  }

  static async findByWorker(workerId) {
    const [rows] = await pool.query(
      'SELECT * FROM experiences WHERE worker_id = ? ORDER BY start_date DESC',
      [workerId]
    );
    return rows;
  }

  static async update(id, data) {
    const fields = [];
    const values = [];

    Object.keys(data).forEach(key => {
      if (data[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(data[key]);
      }
    });

    if (fields.length === 0) return;

    values.push(id);
    await pool.query(`UPDATE experiences SET ${fields.join(', ')} WHERE id = ?`, values);
  }

  static async delete(id) {
    await pool.query('DELETE FROM experiences WHERE id = ?', [id]);
  }
}

module.exports = Experience;
