const pool = require('../config/database');

class EstablishmentProfile {
  static async create(userId, data) {
    const {
      name, legal_name, ice, type, phone, email,
      region_id, city_id, address, description,
      contact_person_name, contact_person_phone
    } = data;

    const [result] = await pool.query(
      `INSERT INTO establishment_profiles 
      (user_id, name, legal_name, ice, type, phone, email,
       region_id, city_id, address, description,
       contact_person_name, contact_person_phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, name, legal_name, ice, type, phone, email,
       region_id, city_id, address, description,
       contact_person_name, contact_person_phone]
    );

    return result.insertId;
  }

  static async findByUserId(userId) {
    const [rows] = await pool.query(
      `SELECT ep.*, r.name_fr as region_name, c.name_fr as city_name
       FROM establishment_profiles ep
       LEFT JOIN regions r ON ep.region_id = r.id
       LEFT JOIN cities c ON ep.city_id = c.id
       WHERE ep.user_id = ?`,
      [userId]
    );
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await pool.query(
      `SELECT ep.*, r.name_fr as region_name, c.name_fr as city_name
       FROM establishment_profiles ep
       LEFT JOIN regions r ON ep.region_id = r.id
       LEFT JOIN cities c ON ep.city_id = c.id
       WHERE ep.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async update(id, data) {
    const fields = [];
    const values = [];

    Object.keys(data).forEach(key => {
      if (data[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(data[key]);
      }
    });

    if (fields.length === 0) return;

    values.push(id);
    await pool.query(`UPDATE establishment_profiles SET ${fields.join(', ')} WHERE id = ?`, values);
  }

  static async verify(id, adminId) {
    await pool.query(
      `UPDATE establishment_profiles SET is_verified = TRUE, verified_by = ?, verified_at = NOW() WHERE id = ?`,
      [adminId, id]
    );
  }

  static async unverify(id) {
    await pool.query(
      `UPDATE establishment_profiles SET is_verified = FALSE, verified_by = NULL, verified_at = NULL WHERE id = ?`,
      [id]
    );
  }

  static async findAll(filters = {}) {
    let query = `
      SELECT ep.*, r.name_fr as region_name, c.name_fr as city_name
      FROM establishment_profiles ep
      LEFT JOIN regions r ON ep.region_id = r.id
      LEFT JOIN cities c ON ep.city_id = c.id
      WHERE 1=1
    `;
    const values = [];

    if (filters.is_verified !== undefined) {
      query += ' AND ep.is_verified = ?';
      values.push(filters.is_verified);
    }

    if (filters.region_id) {
      query += ' AND ep.region_id = ?';
      values.push(filters.region_id);
    }

    if (filters.type) {
      query += ' AND ep.type = ?';
      values.push(filters.type);
    }

    query += ' ORDER BY ep.created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(filters.limit, filters.offset || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async iceExists(ice, excludeUserId = null) {
    let query = 'SELECT id FROM establishment_profiles WHERE ice = ?';
    const values = [ice];

    if (excludeUserId) {
      query += ' AND user_id != ?';
      values.push(excludeUserId);
    }

    const [rows] = await pool.query(query, values);
    return rows.length > 0;
  }

  static async count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM establishment_profiles WHERE 1=1';
    const values = [];

    if (filters.is_verified !== undefined) {
      query += ' AND is_verified = ?';
      values.push(filters.is_verified);
    }

    const [rows] = await pool.query(query, values);
    return rows[0].total;
  }

  // Update rating after new review
  static async updateRating(establishmentId) {
    await pool.query(`
      UPDATE establishment_profiles ep
      SET average_rating = (
        SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE reviewee_id = (
          SELECT user_id FROM establishment_profiles WHERE id = ?
        )
      )
      WHERE id = ?
    `, [establishmentId, establishmentId]);
  }

  // Increment mission count
  static async incrementMissions(establishmentId) {
    await pool.query(
      'UPDATE establishment_profiles SET total_missions = total_missions + 1 WHERE id = ?',
      [establishmentId]
    );
  }
}


module.exports = EstablishmentProfile;
