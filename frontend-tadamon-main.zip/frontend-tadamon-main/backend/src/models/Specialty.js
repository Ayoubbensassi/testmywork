const pool = require('../config/database');

class Specialty {
  static async findAll() {
    const [rows] = await pool.query('SELECT * FROM specialties ORDER BY category, name');
    return rows;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM specialties WHERE id = ?', [id]);
    return rows[0];
  }

  static async findByCategory(category) {
    const [rows] = await pool.query(
      'SELECT * FROM specialties WHERE category = ? ORDER BY name',
      [category]
    );
    return rows;
  }
}

module.exports = Specialty;
