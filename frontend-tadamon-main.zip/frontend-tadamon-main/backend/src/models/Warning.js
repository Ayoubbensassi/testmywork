const pool = require('../config/database');

class Warning {
  static async create(userId, ruleId, reason, issuedBy) {
    const [result] = await pool.query(
      `INSERT INTO warnings (user_id, rule_id, reason, issued_by) VALUES (?, ?, ?, ?)`,
      [userId, ruleId, reason, issuedBy]
    );
    return result.insertId;
  }

  static async findByUser(userId) {
    const [rows] = await pool.query(
      `SELECT w.*, r.title as rule_title, r.severity
       FROM warnings w
       LEFT JOIN rules r ON w.rule_id = r.id
       WHERE w.user_id = ?
       ORDER BY w.created_at DESC`,
      [userId]
    );
    return rows;
  }

  static async acknowledge(id) {
    await pool.query(
      `UPDATE warnings SET status = 'acknowledged', acknowledged_at = NOW() WHERE id = ?`,
      [id]
    );
  }

  static async getActiveCount(userId) {
    const [rows] = await pool.query(
      `SELECT COUNT(*) as count FROM warnings WHERE user_id = ? AND status = 'active'`,
      [userId]
    );
    return rows[0].count;
  }

  static async getAllRules() {
    const [rows] = await pool.query('SELECT * FROM rules ORDER BY severity DESC');
    return rows;
  }
}

module.exports = Warning;
