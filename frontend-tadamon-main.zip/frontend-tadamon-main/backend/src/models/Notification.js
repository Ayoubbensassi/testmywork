const pool = require('../config/database');

class Notification {
  static async create(userId, type, title, message, link = null) {
    const [result] = await pool.query(
      `INSERT INTO notifications (user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?)`,
      [userId, type, title, message, link]
    );
    return result.insertId;
  }

  static async findByUser(userId, filters = {}) {
    let query = 'SELECT * FROM notifications WHERE user_id = ?';
    const values = [userId];

    if (filters.is_read !== undefined) {
      query += ' AND is_read = ?';
      values.push(filters.is_read);
    }

    query += ' ORDER BY created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(filters.limit, filters.offset || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async markAsRead(id) {
    await pool.query(
      `UPDATE notifications SET is_read = TRUE, read_at = NOW() WHERE id = ?`,
      [id]
    );
  }

  static async markAllAsRead(userId) {
    await pool.query(
      `UPDATE notifications SET is_read = TRUE, read_at = NOW() WHERE user_id = ? AND is_read = FALSE`,
      [userId]
    );
  }

  static async countUnread(userId) {
    const [rows] = await pool.query(
      `SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = FALSE`,
      [userId]
    );
    return rows[0].count;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM notifications WHERE id = ?', [id]);
    return rows[0];
  }

  static async delete(id) {
    await pool.query('DELETE FROM notifications WHERE id = ?', [id]);
  }

  static async deleteAllRead(userId) {
    await pool.query('DELETE FROM notifications WHERE user_id = ? AND is_read = TRUE', [userId]);
  }

  // Helper to send notification for common events
  static async notifyApplicationReceived(establishmentUserId, workerName, missionTitle) {
    return this.create(
      establishmentUserId,
      'application',
      'Nouvelle candidature',
      `${workerName} a postulé à votre mission "${missionTitle}"`,
      '/applications'
    );
  }

  static async notifyApplicationAccepted(workerUserId, missionTitle) {
    return this.create(
      workerUserId,
      'application',
      'Candidature acceptée',
      `Votre candidature pour "${missionTitle}" a été acceptée!`,
      '/my-applications'
    );
  }

  static async notifyApplicationRejected(workerUserId, missionTitle) {
    return this.create(
      workerUserId,
      'application',
      'Candidature refusée',
      `Votre candidature pour "${missionTitle}" n'a pas été retenue`,
      '/my-applications'
    );
  }

  static async notifyProfileApproved(userId) {
    return this.create(
      userId,
      'profile',
      'Profil approuvé',
      'Votre profil a été validé. Vous pouvez maintenant postuler aux missions!',
      '/profile'
    );
  }

  static async notifyNewMessage(userId, senderName) {
    return this.create(
      userId,
      'message',
      'Nouveau message',
      `Vous avez reçu un message de ${senderName}`,
      '/messages'
    );
  }
}

module.exports = Notification;
