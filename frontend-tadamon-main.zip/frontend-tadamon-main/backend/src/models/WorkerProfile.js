const pool = require('../config/database');

class WorkerProfile {
  static async create(userId, data) {
    const {
      first_name, last_name, cin, phone, birth_date,
      region_id, city_id, address, mobility_radius, bio, daily_rate
    } = data;

    const [result] = await pool.query(
      `INSERT INTO worker_profiles 
      (user_id, first_name, last_name, cin, phone, birth_date,
       region_id, city_id, address, mobility_radius, bio, daily_rate)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, first_name, last_name, cin, phone, birth_date,
       region_id, city_id, address, mobility_radius || 50, bio, daily_rate]
    );

    return result.insertId;
  }

  static async findByUserId(userId) {
    const [rows] = await pool.query(
      `SELECT wp.*, r.name_fr as region_name, c.name_fr as city_name, u.email
       FROM worker_profiles wp
       LEFT JOIN regions r ON wp.region_id = r.id
       LEFT JOIN cities c ON wp.city_id = c.id
       LEFT JOIN users u ON wp.user_id = u.id
       WHERE wp.user_id = ?`,
      [userId]
    );
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await pool.query(
      `SELECT wp.*, r.name_fr as region_name, c.name_fr as city_name, u.email
       FROM worker_profiles wp
       LEFT JOIN regions r ON wp.region_id = r.id
       LEFT JOIN cities c ON wp.city_id = c.id
       LEFT JOIN users u ON wp.user_id = u.id
       WHERE wp.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async update(id, data) {
    const fields = [];
    const values = [];

    Object.keys(data).forEach(key => {
      if (data[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(data[key]);
      }
    });

    if (fields.length === 0) return;

    values.push(id);
    await pool.query(`UPDATE worker_profiles SET ${fields.join(', ')} WHERE id = ?`, values);
  }

  static async approve(id, adminId) {
    await pool.query(
      `UPDATE worker_profiles SET status = 'approved', validated_by = ?, validated_at = NOW() WHERE id = ?`,
      [adminId, id]
    );
  }

  static async reject(id, adminId, reason) {
    await pool.query(
      `UPDATE worker_profiles SET status = 'rejected', validated_by = ?, validated_at = NOW(), rejection_reason = ? WHERE id = ?`,
      [adminId, reason, id]
    );
  }

  // Grant "Label Réseau" to a worker
  static async grantLabel(id, adminId) {
    await pool.query(
      `UPDATE worker_profiles SET is_labeled = TRUE, labeled_by = ?, labeled_at = NOW() WHERE id = ?`,
      [adminId, id]
    );
  }

  // Revoke "Label Réseau"
  static async revokeLabel(id) {
    await pool.query(
      `UPDATE worker_profiles SET is_labeled = FALSE, labeled_by = NULL, labeled_at = NULL WHERE id = ?`,
      [id]
    );
  }

  static async findAll(filters = {}) {
    let query = `
      SELECT wp.*, r.name_fr as region_name, c.name_fr as city_name
      FROM worker_profiles wp
      LEFT JOIN regions r ON wp.region_id = r.id
      LEFT JOIN cities c ON wp.city_id = c.id
      WHERE 1=1
    `;
    const values = [];

    if (filters.status) {
      query += ' AND wp.status = ?';
      values.push(filters.status);
    }

    if (filters.region_id) {
      query += ' AND wp.region_id = ?';
      values.push(filters.region_id);
    }

    if (filters.city_id) {
      query += ' AND wp.city_id = ?';
      values.push(filters.city_id);
    }

    query += ' ORDER BY wp.created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(filters.limit, filters.offset || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  // Advanced search for establishments
  static async search(filters = {}) {
    let query = `
      SELECT DISTINCT wp.*, r.name_fr as region_name, c.name_fr as city_name,
             (SELECT COUNT(*) FROM reviews WHERE reviewee_id = wp.user_id) as reviews_count
      FROM worker_profiles wp
      LEFT JOIN regions r ON wp.region_id = r.id
      LEFT JOIN cities c ON wp.city_id = c.id
      LEFT JOIN worker_specialties ws ON wp.id = ws.worker_id
      WHERE wp.status = 'approved'
    `;
    const values = [];

    // Filter by region
    if (filters.region_id) {
      query += ' AND wp.region_id = ?';
      values.push(filters.region_id);
    }

    // Filter by city
    if (filters.city_id) {
      query += ' AND wp.city_id = ?';
      values.push(filters.city_id);
    }

    // Filter by "Label Réseau" (labellisation)
    if (filters.is_labeled === true || filters.is_labeled === 'true') {
      query += ' AND wp.is_labeled = TRUE';
    }

    // Filter by minimum years of experience
    if (filters.min_experience) {
      query += ' AND wp.years_experience >= ?';
      values.push(parseInt(filters.min_experience));
    }

    // Filter by specialty
    if (filters.specialty_id) {
      query += ' AND ws.specialty_id = ?';
      values.push(filters.specialty_id);
    }

    // Filter by minimum rating
    if (filters.min_rating) {
      query += ' AND wp.average_rating >= ?';
      values.push(parseFloat(filters.min_rating));
    }

    // Search by name
    if (filters.search) {
      query += ' AND (wp.first_name LIKE ? OR wp.last_name LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      values.push(searchTerm, searchTerm);
    }

    // Order by: labeled first, then by rating
    query += ' ORDER BY wp.is_labeled DESC, wp.average_rating DESC, wp.total_missions DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(parseInt(filters.limit), parseInt(filters.offset) || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async cinExists(cin, excludeUserId = null) {
    let query = 'SELECT id FROM worker_profiles WHERE cin = ?';
    const values = [cin];

    if (excludeUserId) {
      query += ' AND user_id != ?';
      values.push(excludeUserId);
    }

    const [rows] = await pool.query(query, values);
    return rows.length > 0;
  }

  static async count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM worker_profiles WHERE 1=1';
    const values = [];

    if (filters.status) {
      query += ' AND status = ?';
      values.push(filters.status);
    }

    const [rows] = await pool.query(query, values);
    return rows[0].total;
  }

  static async getSpecialties(workerId) {
    const [rows] = await pool.query(
      `SELECT s.*, ws.years_experience, ws.proficiency_level
       FROM worker_specialties ws
       JOIN specialties s ON ws.specialty_id = s.id
       WHERE ws.worker_id = ?`,
      [workerId]
    );
    return rows;
  }

  static async addSpecialty(workerId, specialtyId, yearsExp, level) {
    await pool.query(
      `INSERT INTO worker_specialties (worker_id, specialty_id, years_experience, proficiency_level)
       VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE years_experience = ?, proficiency_level = ?`,
      [workerId, specialtyId, yearsExp, level, yearsExp, level]
    );
  }

  static async removeSpecialty(workerId, specialtyId) {
    await pool.query(
      'DELETE FROM worker_specialties WHERE worker_id = ? AND specialty_id = ?',
      [workerId, specialtyId]
    );
  }

  // Update rating after new review
  static async updateRating(workerId) {
    await pool.query(`
      UPDATE worker_profiles wp
      SET average_rating = (
        SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE reviewee_id = (
          SELECT user_id FROM worker_profiles WHERE id = ?
        )
      )
      WHERE id = ?
    `, [workerId, workerId]);
  }

  // Increment mission count
  static async incrementMissions(workerId) {
    await pool.query(
      'UPDATE worker_profiles SET total_missions = total_missions + 1 WHERE id = ?',
      [workerId]
    );
  }
}

module.exports = WorkerProfile;
