const pool = require('../config/database');

class Favorite {
  static async add(establishmentId, workerId) {
    await pool.query(
      `INSERT IGNORE INTO favorites (establishment_id, worker_id) VALUES (?, ?)`,
      [establishmentId, workerId]
    );
  }

  static async remove(establishmentId, workerId) {
    await pool.query(
      `DELETE FROM favorites WHERE establishment_id = ? AND worker_id = ?`,
      [establishmentId, workerId]
    );
  }

  static async check(establishmentId, workerId) {
    const [rows] = await pool.query(
      `SELECT * FROM favorites WHERE establishment_id = ? AND worker_id = ?`,
      [establishmentId, workerId]
    );
    return rows.length > 0;
  }

  static async getByEstablishment(establishmentId) {
    const [rows] = await pool.query(
      `SELECT f.*, wp.first_name, wp.last_name, wp.profile_picture, wp.average_rating
       FROM favorites f
       LEFT JOIN worker_profiles wp ON f.worker_id = wp.id
       WHERE f.establishment_id = ?
       ORDER BY f.created_at DESC`,
      [establishmentId]
    );
    return rows;
  }
}

module.exports = Favorite;
