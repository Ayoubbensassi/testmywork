const pool = require('../config/database');

class Review {
  static async create(data) {
    const { mission_id, reviewer_id, reviewee_id, rating, comment, is_public } = data;

    const [result] = await pool.query(
      `INSERT INTO reviews 
      (mission_id, reviewer_id, reviewee_id, rating, comment, is_public)
      VALUES (?, ?, ?, ?, ?, ?)`,
      [mission_id, reviewer_id, reviewee_id, rating, comment, is_public !== false]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM reviews WHERE id = ?', [id]);
    return rows[0];
  }

  static async findByMission(missionId) {
    const [rows] = await pool.query(
      'SELECT * FROM reviews WHERE mission_id = ?',
      [missionId]
    );
    return rows;
  }

  static async findByReviewee(revieweeId) {
    const [rows] = await pool.query(
      `SELECT r.*, m.title as mission_title
       FROM reviews r
       LEFT JOIN missions m ON r.mission_id = m.id
       WHERE r.reviewee_id = ?
       ORDER BY r.created_at DESC`,
      [revieweeId]
    );
    return rows;
  }

  static async checkExists(missionId, reviewerId) {
    const [rows] = await pool.query(
      'SELECT id FROM reviews WHERE mission_id = ? AND reviewer_id = ?',
      [missionId, reviewerId]
    );
    return rows.length > 0;
  }

  static async getAverageRating(revieweeId) {
    const [rows] = await pool.query(
      `SELECT AVG(rating) as average, COUNT(*) as count
       FROM reviews WHERE reviewee_id = ?`,
      [revieweeId]
    );
    return rows[0];
  }
}

module.exports = Review;
