const pool = require('../config/database');

class Mission {
  static async create(establishmentId, data) {
    const {
      title, description, mission_type, start_date, end_date,
      salary_min, salary_max, negotiable, region_id, city_id,
      required_experience, is_urgent
    } = data;

    const [result] = await pool.query(
      `INSERT INTO missions 
      (establishment_id, title, description, mission_type, start_date, end_date,
       salary_min, salary_max, negotiable, region_id, city_id,
       required_experience, is_urgent, status, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', NOW())`,
      [establishmentId, title, description, mission_type, start_date, end_date,
       salary_min, salary_max, negotiable !== false, region_id, city_id,
       required_experience || 0, is_urgent || false]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [rows] = await pool.query(
      `SELECT m.*, ep.name as establishment_name, ep.logo as establishment_logo,
              r.name_fr as region_name, c.name_fr as city_name
       FROM missions m
       LEFT JOIN establishment_profiles ep ON m.establishment_id = ep.id
       LEFT JOIN regions r ON m.region_id = r.id
       LEFT JOIN cities c ON m.city_id = c.id
       WHERE m.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async update(id, data) {
    const fields = [];
    const values = [];

    Object.keys(data).forEach(key => {
      if (data[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(data[key]);
      }
    });

    if (fields.length === 0) return;

    values.push(id);
    await pool.query(`UPDATE missions SET ${fields.join(', ')} WHERE id = ?`, values);
  }

  static async delete(id) {
    await pool.query('DELETE FROM missions WHERE id = ?', [id]);
  }

  static async publish(id) {
    await pool.query(
      `UPDATE missions SET status = 'open', published_at = NOW() WHERE id = ?`,
      [id]
    );
  }

  static async findByEstablishment(establishmentId, filters = {}) {
    let query = `
      SELECT m.*, r.name_fr as region_name, c.name_fr as city_name,
             (SELECT COUNT(*) FROM applications WHERE mission_id = m.id) as applications_count
      FROM missions m
      LEFT JOIN regions r ON m.region_id = r.id
      LEFT JOIN cities c ON m.city_id = c.id
      WHERE m.establishment_id = ?
    `;
    const values = [establishmentId];

    if (filters.status) {
      query += ' AND m.status = ?';
      values.push(filters.status);
    }

    query += ' ORDER BY m.created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(filters.limit, filters.offset || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async findAll(filters = {}) {
    let query = `
      SELECT m.*, ep.name as establishment_name, ep.logo as establishment_logo,
             r.name_fr as region_name, c.name_fr as city_name
      FROM missions m
      LEFT JOIN establishment_profiles ep ON m.establishment_id = ep.id
      LEFT JOIN regions r ON m.region_id = r.id
      LEFT JOIN cities c ON m.city_id = c.id
      WHERE 1=1
    `;
    const values = [];

    if (filters.status) {
      query += ' AND m.status = ?';
      values.push(filters.status);
    }

    if (filters.region_id) {
      query += ' AND m.region_id = ?';
      values.push(filters.region_id);
    }

    if (filters.city_id) {
      query += ' AND m.city_id = ?';
      values.push(filters.city_id);
    }

    if (filters.mission_type) {
      query += ' AND m.mission_type = ?';
      values.push(filters.mission_type);
    }

    if (filters.is_urgent !== undefined) {
      query += ' AND m.is_urgent = ?';
      values.push(filters.is_urgent);
    }

    if (filters.search) {
      query += ' AND (m.title LIKE ? OR m.description LIKE ?)';
      const searchTerm = `%${filters.search}%`;
      values.push(searchTerm, searchTerm);
    }

    query += ' ORDER BY m.is_urgent DESC, m.published_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(filters.limit, filters.offset || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM missions WHERE 1=1';
    const values = [];

    if (filters.status) {
      query += ' AND status = ?';
      values.push(filters.status);
    }

    if (filters.establishment_id) {
      query += ' AND establishment_id = ?';
      values.push(filters.establishment_id);
    }

    const [rows] = await pool.query(query, values);
    return rows[0].total;
  }

  static async selectWorker(missionId, workerId) {
    await pool.query(
      `UPDATE missions SET selected_worker_id = ?, status = 'in_progress' WHERE id = ?`,
      [workerId, missionId]
    );
  }

  static async complete(id) {
    await pool.query(`UPDATE missions SET status = 'completed' WHERE id = ?`, [id]);
  }

  static async getSpecialties(missionId) {
    const [rows] = await pool.query(
      `SELECT s.*, ms.is_required
       FROM mission_specialties ms
       JOIN specialties s ON ms.specialty_id = s.id
       WHERE ms.mission_id = ?`,
      [missionId]
    );
    return rows;
  }

  static async addSpecialty(missionId, specialtyId, isRequired = true) {
    await pool.query(
      `INSERT INTO mission_specialties (mission_id, specialty_id, is_required)
       VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE is_required = ?`,
      [missionId, specialtyId, isRequired, isRequired]
    );
  }

  static async removeSpecialty(missionId, specialtyId) {
    await pool.query(
      'DELETE FROM mission_specialties WHERE mission_id = ? AND specialty_id = ?',
      [missionId, specialtyId]
    );
  }
}

module.exports = Mission;
