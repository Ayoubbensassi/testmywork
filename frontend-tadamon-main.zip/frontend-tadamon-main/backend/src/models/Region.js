const pool = require('../config/database');

class Region {
  static async findAll() {
    const [rows] = await pool.query('SELECT * FROM regions ORDER BY code');
    return rows;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM regions WHERE id = ?', [id]);
    return rows[0];
  }

  static async getCitiesByRegion(regionId) {
    const [rows] = await pool.query(
      'SELECT * FROM cities WHERE region_id = ? ORDER BY name_fr',
      [regionId]
    );
    return rows;
  }

  static async getAllCities() {
    const [rows] = await pool.query(
      `SELECT c.*, r.name_fr as region_name 
       FROM cities c
       LEFT JOIN regions r ON c.region_id = r.id
       ORDER BY r.name_fr, c.name_fr`
    );
    return rows;
  }

  static async findCityById(id) {
    const [rows] = await pool.query('SELECT * FROM cities WHERE id = ?', [id]);
    return rows[0];
  }
}

module.exports = Region;
