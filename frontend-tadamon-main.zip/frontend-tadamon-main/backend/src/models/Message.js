const pool = require('../config/database');

class Message {
  static async createConversation(missionId, participant1Id, participant2Id) {
    // Check if conversation already exists between these two users
    let query, params;
    
    if (missionId) {
      // Conversation for a specific mission
      query = `SELECT id FROM conversations 
               WHERE mission_id = ? 
               AND ((participant1_id = ? AND participant2_id = ?) OR (participant1_id = ? AND participant2_id = ?))`;
      params = [missionId, participant1Id, participant2Id, participant2Id, participant1Id];
    } else {
      // Direct conversation (no mission)
      query = `SELECT id FROM conversations 
               WHERE mission_id IS NULL 
               AND ((participant1_id = ? AND participant2_id = ?) OR (participant1_id = ? AND participant2_id = ?))`;
      params = [participant1Id, participant2Id, participant2Id, participant1Id];
    }
    
    const [existing] = await pool.query(query, params);

    if (existing.length > 0) {
      return existing[0].id;
    }

    const [result] = await pool.query(
      `INSERT INTO conversations (mission_id, participant1_id, participant2_id, last_message_at) VALUES (?, ?, ?, NOW())`,
      [missionId || null, participant1Id, participant2Id]
    );

    return result.insertId;
  }

  static async findConversationById(id) {
    const [rows] = await pool.query(
      `SELECT c.*, m.title as mission_title
       FROM conversations c
       LEFT JOIN missions m ON c.mission_id = m.id
       WHERE c.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async getConversationsByUser(userId) {
    const [rows] = await pool.query(
      `SELECT c.id, c.mission_id, c.last_message_at, c.created_at,
              m.title as mission_title,
              CASE 
                WHEN c.participant1_id = ? THEN c.participant2_id 
                ELSE c.participant1_id 
              END as other_user_id,
              CASE 
                WHEN c.participant1_id = ? THEN COALESCE(
                  CONCAT(wp2.first_name, ' ', wp2.last_name),
                  ep2.name,
                  'Utilisateur'
                )
                ELSE COALESCE(
                  CONCAT(wp1.first_name, ' ', wp1.last_name),
                  ep1.name,
                  'Utilisateur'
                )
              END as other_user_name,
              CASE 
                WHEN c.participant1_id = ? THEN COALESCE(wp2.profile_picture, ep2.logo)
                ELSE COALESCE(wp1.profile_picture, ep1.logo)
              END as other_user_avatar,
              (SELECT content FROM messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message,
              (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND sender_id != ? AND is_read = FALSE) as unread_count
       FROM conversations c
       LEFT JOIN missions m ON c.mission_id = m.id
       LEFT JOIN worker_profiles wp1 ON c.participant1_id = wp1.user_id
       LEFT JOIN worker_profiles wp2 ON c.participant2_id = wp2.user_id
       LEFT JOIN establishment_profiles ep1 ON c.participant1_id = ep1.user_id
       LEFT JOIN establishment_profiles ep2 ON c.participant2_id = ep2.user_id
       WHERE c.participant1_id = ? OR c.participant2_id = ?
       ORDER BY c.last_message_at DESC`,
      [userId, userId, userId, userId, userId, userId]
    );
    return rows;
  }

  static async sendMessage(conversationId, senderId, content) {
    const [result] = await pool.query(
      `INSERT INTO messages (conversation_id, sender_id, content) VALUES (?, ?, ?)`,
      [conversationId, senderId, content]
    );

    await pool.query(
      `UPDATE conversations SET last_message_at = NOW() WHERE id = ?`,
      [conversationId]
    );

    return result.insertId;
  }

  static async getMessages(conversationId, userId, limit = 50, offset = 0) {
    const [rows] = await pool.query(
      `SELECT m.*, 
              (m.sender_id = ?) as is_mine
       FROM messages m 
       WHERE m.conversation_id = ? 
       ORDER BY m.created_at ASC 
       LIMIT ? OFFSET ?`,
      [userId, conversationId, limit, offset]
    );
    return rows;
  }

  static async markAsRead(messageId) {
    await pool.query(
      `UPDATE messages SET is_read = TRUE, read_at = NOW() WHERE id = ?`,
      [messageId]
    );
  }

  static async markAllAsRead(conversationId, userId) {
    await pool.query(
      `UPDATE messages SET is_read = TRUE, read_at = NOW() 
       WHERE conversation_id = ? AND sender_id != ? AND is_read = FALSE`,
      [conversationId, userId]
    );
  }

  static async getUnreadCount(userId) {
    const [rows] = await pool.query(
      `SELECT COUNT(*) as count 
       FROM messages m
       JOIN conversations c ON m.conversation_id = c.id
       WHERE (c.participant1_id = ? OR c.participant2_id = ?)
       AND m.sender_id != ?
       AND m.is_read = FALSE`,
      [userId, userId, userId]
    );
    return rows[0].count;
  }
}

module.exports = Message;
