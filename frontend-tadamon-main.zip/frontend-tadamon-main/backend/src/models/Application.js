const pool = require('../config/database');

class Application {
  static async create(missionId, workerId, data) {
    const { cover_letter, proposed_rate } = data;

    const [result] = await pool.query(
      `INSERT INTO applications (mission_id, worker_id, cover_letter, proposed_rate)
       VALUES (?, ?, ?, ?)`,
      [missionId, workerId, cover_letter, proposed_rate]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [rows] = await pool.query(
      `SELECT a.*, 
              wp.first_name, wp.last_name, wp.profile_picture, wp.average_rating,
              m.title as mission_title, m.establishment_id
       FROM applications a
       LEFT JOIN worker_profiles wp ON a.worker_id = wp.id
       LEFT JOIN missions m ON a.mission_id = m.id
       WHERE a.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async findByMission(missionId, filters = {}) {
    let query = `
      SELECT a.*, 
             wp.first_name, wp.last_name, wp.profile_picture, wp.average_rating,
             wp.years_experience, wp.daily_rate
      FROM applications a
      LEFT JOIN worker_profiles wp ON a.worker_id = wp.id
      WHERE a.mission_id = ?
    `;
    const values = [missionId];

    if (filters.status) {
      query += ' AND a.status = ?';
      values.push(filters.status);
    }

    query += ' ORDER BY a.created_at DESC';

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async findByWorker(workerId, filters = {}) {
    let query = `
      SELECT a.*, 
             m.title as mission_title, m.start_date, m.end_date, m.status as mission_status,
             ep.name as establishment_name
      FROM applications a
      LEFT JOIN missions m ON a.mission_id = m.id
      LEFT JOIN establishment_profiles ep ON m.establishment_id = ep.id
      WHERE a.worker_id = ?
    `;
    const values = [workerId];

    if (filters.status) {
      query += ' AND a.status = ?';
      values.push(filters.status);
    }

    query += ' ORDER BY a.created_at DESC';

    if (filters.limit) {
      query += ' LIMIT ? OFFSET ?';
      values.push(filters.limit, filters.offset || 0);
    }

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async findByEstablishment(establishmentId, filters = {}) {
    let query = `
      SELECT a.*, 
             m.title as mission_title, m.start_date, m.end_date,
             wp.first_name, wp.last_name, wp.profile_picture, wp.average_rating,
             wp.years_experience, wp.daily_rate, wp.is_labeled, wp.total_missions
      FROM applications a
      LEFT JOIN missions m ON a.mission_id = m.id
      LEFT JOIN worker_profiles wp ON a.worker_id = wp.id
      WHERE m.establishment_id = ?
    `;
    const values = [establishmentId];

    if (filters.status) {
      query += ' AND a.status = ?';
      values.push(filters.status);
    }

    query += ' ORDER BY a.created_at DESC';

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async updateStatus(id, status, reviewerId, reason = null) {
    await pool.query(
      `UPDATE applications SET status = ?, reviewed_at = NOW(), reviewed_by = ?
       WHERE id = ?`,
      [status, reviewerId, id]
    );
  }

  static async checkExists(missionId, workerId) {
    const [rows] = await pool.query(
      'SELECT id FROM applications WHERE mission_id = ? AND worker_id = ?',
      [missionId, workerId]
    );
    return rows.length > 0;
  }

  static async withdraw(id) {
    await pool.query(`UPDATE applications SET status = 'withdrawn' WHERE id = ?`, [id]);
  }

  static async count(filters = {}) {
    let query = 'SELECT COUNT(*) as total FROM applications WHERE 1=1';
    const values = [];

    if (filters.mission_id) {
      query += ' AND mission_id = ?';
      values.push(filters.mission_id);
    }

    if (filters.worker_id) {
      query += ' AND worker_id = ?';
      values.push(filters.worker_id);
    }

    if (filters.status) {
      query += ' AND status = ?';
      values.push(filters.status);
    }

    const [rows] = await pool.query(query, values);
    return rows[0].total;
  }
}

module.exports = Application;
