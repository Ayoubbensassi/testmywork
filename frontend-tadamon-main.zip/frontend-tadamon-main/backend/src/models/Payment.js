const pool = require('../config/database');

class Payment {
  static async create(data) {
    const {
      mission_id, establishment_id, worker_id,
      gross_amount, commission_rate, commission_amount, net_amount
    } = data;

    const [result] = await pool.query(
      `INSERT INTO payments 
      (mission_id, establishment_id, worker_id, gross_amount, commission_rate, commission_amount, net_amount)
      VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [mission_id, establishment_id, worker_id, gross_amount, commission_rate || 15, commission_amount, net_amount]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [rows] = await pool.query(
      `SELECT p.*, m.title as mission_title,
              ep.name as establishment_name,
              CONCAT(wp.first_name, ' ', wp.last_name) as worker_name
       FROM payments p
       LEFT JOIN missions m ON p.mission_id = m.id
       LEFT JOIN establishment_profiles ep ON p.establishment_id = ep.id
       LEFT JOIN worker_profiles wp ON p.worker_id = wp.id
       WHERE p.id = ?`,
      [id]
    );
    return rows[0];
  }

  static async findByMission(missionId) {
    const [rows] = await pool.query('SELECT * FROM payments WHERE mission_id = ?', [missionId]);
    return rows[0];
  }

  static async findByEstablishment(establishmentId, filters = {}) {
    let query = `
      SELECT p.*, m.title as mission_title,
             CONCAT(wp.first_name, ' ', wp.last_name) as worker_name
      FROM payments p
      LEFT JOIN missions m ON p.mission_id = m.id
      LEFT JOIN worker_profiles wp ON p.worker_id = wp.id
      WHERE p.establishment_id = ?
    `;
    const values = [establishmentId];

    if (filters.status) {
      query += ' AND p.payment_status = ?';
      values.push(filters.status);
    }

    query += ' ORDER BY p.created_at DESC';

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async findByWorker(workerId, filters = {}) {
    let query = `
      SELECT p.*, m.title as mission_title,
             ep.name as establishment_name
      FROM payments p
      LEFT JOIN missions m ON p.mission_id = m.id
      LEFT JOIN establishment_profiles ep ON p.establishment_id = ep.id
      WHERE p.worker_id = ?
    `;
    const values = [workerId];

    if (filters.status) {
      query += ' AND p.payment_status = ?';
      values.push(filters.status);
    }

    query += ' ORDER BY p.created_at DESC';

    const [rows] = await pool.query(query, values);
    return rows;
  }

  static async markAsPaid(id) {
    await pool.query(
      `UPDATE payments SET payment_status = 'paid', paid_at = NOW() WHERE id = ?`,
      [id]
    );
  }

  static async release(id) {
    await pool.query(
      `UPDATE payments SET payment_status = 'released', released_at = NOW() WHERE id = ?`,
      [id]
    );
  }

  static async getTotalByEstablishment(establishmentId) {
    const [rows] = await pool.query(
      `SELECT SUM(gross_amount) as total FROM payments WHERE establishment_id = ? AND payment_status != 'pending'`,
      [establishmentId]
    );
    return rows[0].total || 0;
  }

  static async getTotalByWorker(workerId) {
    const [rows] = await pool.query(
      `SELECT SUM(net_amount) as total FROM payments WHERE worker_id = ? AND payment_status = 'released'`,
      [workerId]
    );
    return rows[0].total || 0;
  }
}

module.exports = Payment;
