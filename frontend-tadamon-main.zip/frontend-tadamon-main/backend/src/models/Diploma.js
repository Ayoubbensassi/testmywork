const pool = require('../config/database');

class Diploma {
  static async create(workerId, data) {
    const { title, institution, obtained_date, file_path } = data;

    const [result] = await pool.query(
      `INSERT INTO diplomas (worker_id, title, institution, obtained_date, file_path)
       VALUES (?, ?, ?, ?, ?)`,
      [workerId, title, institution, obtained_date, file_path]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM diplomas WHERE id = ?', [id]);
    return rows[0];
  }

  static async findByWorker(workerId) {
    const [rows] = await pool.query(
      'SELECT * FROM diplomas WHERE worker_id = ? ORDER BY obtained_date DESC',
      [workerId]
    );
    return rows;
  }

  static async update(id, data) {
    const fields = [];
    const values = [];

    Object.keys(data).forEach(key => {
      if (data[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(data[key]);
      }
    });

    if (fields.length === 0) return;

    values.push(id);
    await pool.query(`UPDATE diplomas SET ${fields.join(', ')} WHERE id = ?`, values);
  }

  static async verify(id, adminId) {
    await pool.query(
      `UPDATE diplomas SET is_verified = TRUE, verified_by = ?, verified_at = NOW() WHERE id = ?`,
      [adminId, id]
    );
  }

  static async delete(id) {
    await pool.query('DELETE FROM diplomas WHERE id = ?', [id]);
  }
}

module.exports = Diploma;
