const pool = require('../config/database');

class Availability {
  // Create availability slot
  static async create(workerId, data) {
    const { date, start_time, end_time, is_available, note } = data;

    const [result] = await pool.query(
      `INSERT INTO availabilities (worker_id, date, start_time, end_time, is_available, note)
       VALUES (?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE start_time = ?, end_time = ?, is_available = ?, note = ?`,
      [workerId, date, start_time || '08:00', end_time || '18:00', is_available !== false, note,
       start_time || '08:00', end_time || '18:00', is_available !== false, note]
    );

    return result.insertId;
  }

  // Bulk create/update availabilities (for calendar)
  static async bulkCreate(workerId, availabilities) {
    const results = [];
    for (const avail of availabilities) {
      const id = await this.create(workerId, avail);
      results.push(id);
    }
    return results;
  }

  // Get worker's availabilities for a date range
  static async findByWorkerAndRange(workerId, startDate, endDate) {
    const [rows] = await pool.query(
      `SELECT * FROM availabilities 
       WHERE worker_id = ? AND date BETWEEN ? AND ?
       ORDER BY date ASC`,
      [workerId, startDate, endDate]
    );
    return rows;
  }

  // Get worker's availabilities for a month
  static async findByWorkerAndMonth(workerId, year, month) {
    const [rows] = await pool.query(
      `SELECT * FROM availabilities 
       WHERE worker_id = ? AND YEAR(date) = ? AND MONTH(date) = ?
       ORDER BY date ASC`,
      [workerId, year, month]
    );
    return rows;
  }

  // Check if worker is available on specific date
  static async isAvailable(workerId, date) {
    const [rows] = await pool.query(
      `SELECT * FROM availabilities 
       WHERE worker_id = ? AND date = ? AND is_available = TRUE`,
      [workerId, date]
    );
    return rows.length > 0;
  }

  // Find available workers for a date range
  static async findAvailableWorkers(startDate, endDate, filters = {}) {
    let query = `
      SELECT DISTINCT wp.*, r.name_fr as region_name, c.name_fr as city_name,
             u.email, wp.is_labeled
      FROM worker_profiles wp
      JOIN users u ON wp.user_id = u.id
      LEFT JOIN regions r ON wp.region_id = r.id
      LEFT JOIN cities c ON wp.city_id = c.id
      WHERE wp.status = 'approved'
      AND wp.id IN (
        SELECT worker_id FROM availabilities 
        WHERE date BETWEEN ? AND ? AND is_available = TRUE
        GROUP BY worker_id
        HAVING COUNT(DISTINCT date) >= DATEDIFF(?, ?) + 1
      )
    `;
    const values = [startDate, endDate, endDate, startDate];

    if (filters.region_id) {
      query += ' AND wp.region_id = ?';
      values.push(filters.region_id);
    }

    if (filters.is_labeled) {
      query += ' AND wp.is_labeled = TRUE';
    }

    query += ' ORDER BY wp.average_rating DESC';

    const [rows] = await pool.query(query, values);
    return rows;
  }

  // Delete availability
  static async delete(workerId, date) {
    await pool.query(
      'DELETE FROM availabilities WHERE worker_id = ? AND date = ?',
      [workerId, date]
    );
  }

  // Delete range
  static async deleteRange(workerId, startDate, endDate) {
    await pool.query(
      'DELETE FROM availabilities WHERE worker_id = ? AND date BETWEEN ? AND ?',
      [workerId, startDate, endDate]
    );
  }
}

module.exports = Availability;
