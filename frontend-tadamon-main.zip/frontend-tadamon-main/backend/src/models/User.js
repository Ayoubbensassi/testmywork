const pool = require('../config/database');
const crypto = require('crypto');

class User {
  static async create(email, hashedPassword, role) {
    const verificationToken = crypto.randomBytes(32).toString('hex');
    const [result] = await pool.query(
      'INSERT INTO users (email, password, role, verification_token) VALUES (?, ?, ?, ?)',
      [email, hashedPassword, role, verificationToken]
    );
    return { userId: result.insertId, verificationToken };
  }

  static async findByEmail(email) {
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await pool.query(
      'SELECT id, email, role, is_active, is_verified, created_at, last_login FROM users WHERE id = ?',
      [id]
    );
    return rows[0];
  }

  static async emailExists(email) {
    const [rows] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    return rows.length > 0;
  }

  static async updateLastLogin(id) {
    await pool.query('UPDATE users SET last_login = NOW() WHERE id = ?', [id]);
  }

  static async findByVerificationToken(token) {
    const [rows] = await pool.query('SELECT * FROM users WHERE verification_token = ?', [token]);
    return rows[0];
  }

  static async verifyEmail(id) {
    await pool.query('UPDATE users SET is_verified = TRUE, verification_token = NULL WHERE id = ?', [id]);
  }

  static async resendVerification(id) {
    const verificationToken = crypto.randomBytes(32).toString('hex');
    await pool.query('UPDATE users SET verification_token = ? WHERE id = ?', [verificationToken, id]);
    return verificationToken;
  }
}


User.setPasswordResetToken = async function(id) {
  const resetToken = crypto.randomBytes(32).toString('hex');
  const resetExpires = new Date(Date.now() + 3600000); // 1 hour
  await pool.query(
    'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?',
    [resetToken, resetExpires, id]
  );
  return resetToken;
};

User.findByResetToken = async function(token) {
  const [rows] = await pool.query(
    'SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > NOW()',
    [token]
  );
  return rows[0];
};

User.updatePassword = async function(id, hashedPassword) {
  await pool.query(
    'UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?',
    [hashedPassword, id]
  );
};

User.updateStatus = async function(id, isActive) {
  await pool.query('UPDATE users SET is_active = ? WHERE id = ?', [isActive, id]);
};

User.getAll = async function(filters = {}) {
  let query = 'SELECT id, email, role, is_active, is_verified, created_at, last_login FROM users WHERE 1=1';
  const params = [];
  if (filters.role) {
    query += ' AND role = ?';
    params.push(filters.role);
  }
  if (filters.is_active !== undefined) {
    query += ' AND is_active = ?';
    params.push(filters.is_active);
  }
  query += ' ORDER BY created_at DESC';
  if (filters.limit) {
    query += ' LIMIT ?';
    params.push(parseInt(filters.limit));
  }
  if (filters.offset) {
    query += ' OFFSET ?';
    params.push(parseInt(filters.offset));
  }
  const [rows] = await pool.query(query, params);
  return rows;
};

module.exports = User;
