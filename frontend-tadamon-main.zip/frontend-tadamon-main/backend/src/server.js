const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const hpp = require('hpp');
const http = require('http');
const { Server } = require('socket.io');
const passport = require('./config/passport');

// Charger les variables d'environnement (.env.local en priorité)
require('dotenv').config({ path: '.env.local' });
require('dotenv').config(); // Fallback sur .env

// Import routes
const authRoutes = require('./routes/authRoutes');
const workerRoutes = require('./routes/workerRoutes');
const establishmentRoutes = require('./routes/establishmentRoutes');
const missionRoutes = require('./routes/missionRoutes');
const applicationRoutes = require('./routes/applicationRoutes');
const reviewRoutes = require('./routes/reviewRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const messageRoutes = require('./routes/messageRoutes');
const chatRoutes = require('./routes/chat');
const adminRoutes = require('./routes/adminRoutes');
const regionRoutes = require('./routes/regionRoutes');
const availabilityRoutes = require('./routes/availabilityRoutes');
const diplomaRoutes = require('./routes/diplomaRoutes');
const experienceRoutes = require('./routes/experienceRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const statsRoutes = require('./routes/statsRoutes');
const contactRoutes = require('./routes/contactRoutes');
const cvRoutes = require('./routes/cvRoutes');

// Import middlewares
const errorHandler = require('./middlewares/errorHandler');
const { generalLimiter, adminLimiter } = require('./middlewares/rateLimiter');

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 5000;

// ===========================================
// SOCKET.IO SETUP
// ===========================================

const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Store connected users
const connectedUsers = new Map();

io.on('connection', (socket) => {
  console.log('🔌 User connected:', socket.id);

  // User joins with their userId
  socket.on('user:join', (userId) => {
    connectedUsers.set(userId, socket.id);
    socket.userId = userId;
    console.log(`👤 User ${userId} joined with socket ${socket.id}`);
    
    // Notify others that user is online
    socket.broadcast.emit('user:online', userId);
  });

  // Handle private messages
  socket.on('message:send', async (data) => {
    const { recipientId, content, senderId } = data;
    const recipientSocketId = connectedUsers.get(recipientId.toString());
    
    const messageData = {
      senderId,
      recipientId,
      content,
      timestamp: new Date().toISOString(),
      id: Date.now()
    };

    // Send to recipient if online
    if (recipientSocketId) {
      io.to(recipientSocketId).emit('message:receive', messageData);
    }

    // Send confirmation to sender
    socket.emit('message:sent', messageData);
  });

  // Handle typing indicator
  socket.on('typing:start', (data) => {
    const recipientSocketId = connectedUsers.get(data.recipientId.toString());
    if (recipientSocketId) {
      io.to(recipientSocketId).emit('typing:start', { senderId: data.senderId });
    }
  });

  socket.on('typing:stop', (data) => {
    const recipientSocketId = connectedUsers.get(data.recipientId.toString());
    if (recipientSocketId) {
      io.to(recipientSocketId).emit('typing:stop', { senderId: data.senderId });
    }
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    if (socket.userId) {
      connectedUsers.delete(socket.userId);
      socket.broadcast.emit('user:offline', socket.userId);
      console.log(`👤 User ${socket.userId} disconnected`);
    }
    console.log('🔌 User disconnected:', socket.id);
  });
});

// Make io accessible to routes
app.set('io', io);
app.set('connectedUsers', connectedUsers);

// ===========================================
// SECURITY MIDDLEWARES (Ordre important!)
// ===========================================

// 1. Helmet - Sécurise les headers HTTP
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }, // Permet le chargement des images uploadées
  contentSecurityPolicy: false // Désactivé pour le développement
}));

// 2. HPP - Protection contre HTTP Parameter Pollution
app.use(hpp());

// 3. Compression - Compresse les réponses (performance)
app.use(compression());

// 4. CORS - Configuration sécurisée
const allowedOrigins = [
  'http://localhost:5173', // Vite default port
  'http://localhost:3000', // React default port
  process.env.FRONTEND_URL
].filter(Boolean); // Remove undefined values

const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      // In development, allow all localhost origins
      if (process.env.NODE_ENV !== 'production' && origin.startsWith('http://localhost:')) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
};
app.use(cors(corsOptions));

// 6. Passport initialization (for Google OAuth)
app.use(passport.initialize());

// 5. Rate Limiting global (sauf admin qui a son propre limiter)
app.use('/api/admin', adminLimiter);
app.use('/api', generalLimiter);

// ===========================================
// PARSING MIDDLEWARES
// ===========================================

// Body parser avec limite de taille (protection DoS)
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// Logging (désactivé en production pour performance)
if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// ===========================================
// STATIC FILES
// ===========================================

// Fichiers uploadés avec headers de cache
app.use('/uploads', express.static(path.join(__dirname, '../uploads'), {
  maxAge: '1d', // Cache 1 jour
  etag: true
}));

// ===========================================
// SWAGGER API DOCUMENTATION
// ===========================================

const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./config/swagger');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {
  customCss: '.swagger-ui .topbar { display: none }',
  customSiteTitle: 'TADAMON API Documentation'
}));

// Swagger JSON endpoint
app.get('/api-docs.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

// ===========================================
// API ROOT ENDPOINT
// ===========================================

/**
 * @swagger
 * /api:
 *   get:
 *     summary: API root endpoint - Get API information
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: API information
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: TADAMON API - Plateforme Travailleurs Sociaux
 *                 version:
 *                   type: string
 *                   example: 1.0.0
 *                 documentation:
 *                   type: string
 *                   example: http://localhost:5000/api-docs
 *                 endpoints:
 *                   type: object
 */
app.get('/api', (req, res) => {
  res.json({
    status: 'success',
    message: 'TADAMON API - Plateforme Travailleurs Sociaux',
    version: '1.0.0',
    documentation: `${req.protocol}://${req.get('host')}/api-docs`,
    health: `${req.protocol}://${req.get('host')}/api/health`,
    endpoints: {
      auth: '/api/auth',
      workers: '/api/workers',
      establishments: '/api/establishments',
      missions: '/api/missions',
      applications: '/api/applications',
      reviews: '/api/reviews',
      admin: '/api/admin',
      regions: '/api/regions',
      availabilities: '/api/availabilities',
      diplomas: '/api/diplomas',
      experiences: '/api/experiences',
      notifications: '/api/notifications',
      messages: '/api/messages',
      stats: '/api/stats'
    }
  });
});

// ===========================================
// HEALTH CHECK
// ===========================================

/**
 * @swagger
 * /health:
 *   get:
 *     summary: Health check endpoint
 *     tags: [Health]
 *     responses:
 *       200:
 *         description: API is running
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: string
 *                   example: success
 *                 message:
 *                   type: string
 *                   example: LKHEDMA Social API is running!
 *                 timestamp:
 *                   type: string
 *                   format: date-time
 *                 environment:
 *                   type: string
 *                   example: development
 *                 version:
 *                   type: string
 *                   example: 1.0.0
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'success',
    message: 'LKHEDMA Social API is running!',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    version: '1.0.0'
  });
});

// ===========================================
// API ROUTES
// ===========================================

app.use('/api/auth', authRoutes);
app.use('/api/workers', workerRoutes);
app.use('/api/establishments', establishmentRoutes);
app.use('/api/missions', missionRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', regionRoutes);
app.use('/api/availabilities', availabilityRoutes);
app.use('/api/diplomas', diplomaRoutes);
app.use('/api/experiences', experienceRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/cv', cvRoutes);

// ===========================================
// ERROR HANDLING
// ===========================================

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    status: 'error',
    message: `Route ${req.originalUrl} not found`
  });
});

// Global error handler
app.use(errorHandler);

// ===========================================
// SERVER START
// ===========================================

server.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log(`🚀 LKHEDMA Social API`);
  console.log(`📍 Running on http://localhost:${PORT}`);
  console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔒 Security: Helmet, Rate Limiting, HPP enabled`);
  console.log(`💬 Socket.io: Real-time messaging enabled`);
  console.log('='.repeat(50));
});

module.exports = { app, io, server };
