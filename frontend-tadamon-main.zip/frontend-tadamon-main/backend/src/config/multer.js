const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadDirs = ['uploads/diplomas', 'uploads/cin', 'uploads/logos', 'uploads/cv', 'uploads/profile-pictures'];
uploadDirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    let folder = 'uploads/';
    if (file.fieldname === 'diploma') folder += 'diplomas/';
    else if (file.fieldname === 'cin_front' || file.fieldname === 'cin_back') folder += 'cin/';
    else if (file.fieldname === 'logo') folder += 'logos/';
    else if (file.fieldname === 'cv') folder += 'cv/';
    else if (file.fieldname === 'profile_picture') folder += 'profile-pictures/';
    cb(null, folder);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = ['.pdf', '.jpg', '.jpeg', '.png'];
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (allowedTypes.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('Type de fichier non autorisé. Acceptés : PDF, JPG, PNG'), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5242880
  }
});

module.exports = upload;
