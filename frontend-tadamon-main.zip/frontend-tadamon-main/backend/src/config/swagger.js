const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'TADAMON API',
      version: '1.0.0',
      description: `
# 🤝 TADAMON - Plateforme de Mise en Relation

API REST complète pour la plateforme de mise en relation entre **travailleurs sociaux indépendants** et **établissements** au Maroc.

---

## 🔐 Authentification

La plupart des endpoints nécessitent une authentification JWT.

### Obtenir un token
1. Créez un compte via \`POST /auth/register\`
2. Connectez-vous via \`POST /auth/login\`
3. Récupérez le token dans la réponse

### Utiliser le token
Incluez le token dans le header de chaque requête:
\`\`\`
Authorization: Bearer <votre_token>
\`\`\`

---

## 👥 Rôles Utilisateurs

| Rôle | Description | Permissions |
|------|-------------|-------------|
| **worker** | Travailleur social indépendant | Créer profil, postuler aux missions, gérer disponibilités |
| **establishment** | Établissement recruteur | Publier missions, gérer candidatures, recruter |
| **admin** | Administrateur plateforme | Valider profils, gérer labels, modération |

---

## 📊 Codes de Réponse

| Code | Signification |
|------|---------------|
| 200 | Succès |
| 201 | Ressource créée |
| 400 | Requête invalide |
| 401 | Non authentifié |
| 403 | Accès refusé |
| 404 | Ressource non trouvée |
| 429 | Trop de requêtes (rate limit) |
| 500 | Erreur serveur |

---

## 🚦 Rate Limiting

| Endpoint | Limite |
|----------|--------|
| Général | 100 req/15min |
| Auth (login) | 5 req/15min |
| Inscription | 5 req/heure |
| Upload | 20 req/heure |
| Candidatures | 10 req/heure |
| Admin | 500 req/15min |

---

## 📁 Upload de Fichiers

Formats acceptés: **JPEG, PNG, PDF**
Taille max: **5 MB**

Les fichiers sont accessibles via: \`/uploads/<chemin_fichier>\`
      `,
      contact: {
        name: 'TADAMON Support',
        email: 'support@tadamon.ma',
        url: 'https://tadamon.ma/contact'
      },
      license: {
        name: 'MIT',
        url: 'https://opensource.org/licenses/MIT'
      }
    },
    externalDocs: {
      description: 'Documentation complète',
      url: 'https://docs.tadamon.ma'
    },
    servers: [
      {
        url: 'http://localhost:5000/api',
        description: '🔧 Serveur de développement'
      },
      {
        url: 'https://api.tadamon.ma/api',
        description: '🚀 Serveur de production'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Token JWT obtenu via `/auth/login`\n\nFormat: `Bearer <token>`'
        }
      },
      schemas: {
        // ============ COMMON SCHEMAS ============
        Error: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              example: 'error',
              description: 'Statut de la réponse'
            },
            message: {
              type: 'string',
              example: 'Message d\'erreur descriptif',
              description: 'Description de l\'erreur'
            },
            code: {
              type: 'string',
              example: 'VALIDATION_ERROR',
              description: 'Code d\'erreur technique'
            }
          }
        },
        Success: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              example: 'success'
            },
            message: {
              type: 'string',
              example: 'Opération réussie'
            },
            data: {
              type: 'object',
              description: 'Données de la réponse'
            }
          }
        },
        Pagination: {
          type: 'object',
          properties: {
            page: {
              type: 'integer',
              example: 1,
              description: 'Page actuelle'
            },
            limit: {
              type: 'integer',
              example: 20,
              description: 'Éléments par page'
            },
            total: {
              type: 'integer',
              example: 150,
              description: 'Nombre total d\'éléments'
            },
            totalPages: {
              type: 'integer',
              example: 8,
              description: 'Nombre total de pages'
            }
          }
        },

        // ============ USER SCHEMAS ============
        User: {
          type: 'object',
          properties: {
            id: { 
              type: 'integer',
              example: 1,
              description: 'Identifiant unique'
            },
            email: { 
              type: 'string', 
              format: 'email',
              example: 'user@example.com',
              description: 'Adresse email'
            },
            role: { 
              type: 'string', 
              enum: ['worker', 'establishment', 'admin'],
              example: 'worker',
              description: 'Rôle de l\'utilisateur'
            },
            is_active: { 
              type: 'boolean',
              example: true,
              description: 'Compte actif'
            },
            is_verified: { 
              type: 'boolean',
              example: true,
              description: 'Email vérifié'
            },
            created_at: { 
              type: 'string', 
              format: 'date-time',
              example: '2025-01-12T10:30:00Z',
              description: 'Date de création'
            }
          }
        },
        UserRegistration: {
          type: 'object',
          required: ['email', 'password', 'role'],
          properties: {
            email: {
              type: 'string',
              format: 'email',
              example: 'nouveau@example.com',
              description: 'Adresse email unique'
            },
            password: {
              type: 'string',
              format: 'password',
              minLength: 6,
              example: 'MotDePasse123!',
              description: 'Mot de passe (min 6 caractères)'
            },
            role: {
              type: 'string',
              enum: ['worker', 'establishment'],
              example: 'worker',
              description: 'Type de compte'
            }
          }
        },
        LoginCredentials: {
          type: 'object',
          required: ['email', 'password'],
          properties: {
            email: {
              type: 'string',
              format: 'email',
              example: 'user@example.com'
            },
            password: {
              type: 'string',
              format: 'password',
              example: 'MotDePasse123!'
            }
          }
        },
        AuthResponse: {
          type: 'object',
          properties: {
            status: { type: 'string', example: 'success' },
            data: {
              type: 'object',
              properties: {
                token: {
                  type: 'string',
                  example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
                  description: 'Token JWT valide 7 jours'
                },
                user: { $ref: '#/components/schemas/User' }
              }
            }
          }
        },

        // ============ WORKER SCHEMAS ============
        WorkerProfile: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            user_id: { type: 'integer', example: 5 },
            first_name: { 
              type: 'string', 
              example: 'Mohammed',
              description: 'Prénom'
            },
            last_name: { 
              type: 'string', 
              example: 'Alami',
              description: 'Nom de famille'
            },
            cin: { 
              type: 'string', 
              example: 'AB123456',
              description: 'Numéro CIN'
            },
            phone: { 
              type: 'string', 
              example: '+212612345678',
              description: 'Téléphone'
            },
            bio: { 
              type: 'string', 
              example: 'Éducateur spécialisé avec 5 ans d\'expérience...',
              description: 'Biographie professionnelle'
            },
            daily_rate: { 
              type: 'number', 
              example: 500,
              description: 'Tarif journalier en MAD'
            },
            years_experience: { 
              type: 'integer', 
              example: 5,
              description: 'Années d\'expérience'
            },
            average_rating: { 
              type: 'number', 
              example: 4.5,
              description: 'Note moyenne (1-5)'
            },
            total_missions: { 
              type: 'integer', 
              example: 12,
              description: 'Nombre de missions complétées'
            },
            is_labeled: { 
              type: 'boolean', 
              example: true,
              description: 'Label Réseau TADAMON'
            },
            status: { 
              type: 'string', 
              enum: ['pending', 'approved', 'rejected', 'suspended'],
              example: 'approved',
              description: 'Statut de validation'
            },
            profile_picture: {
              type: 'string',
              example: '/uploads/profiles/photo_123.jpg',
              description: 'URL photo de profil'
            },
            region: { type: 'string', example: 'Casablanca-Settat' },
            city: { type: 'string', example: 'Casablanca' }
          }
        },
        WorkerProfileCreate: {
          type: 'object',
          required: ['first_name', 'last_name', 'cin'],
          properties: {
            first_name: { type: 'string', example: 'Mohammed' },
            last_name: { type: 'string', example: 'Alami' },
            cin: { type: 'string', example: 'AB123456' },
            phone: { type: 'string', example: '+212612345678' },
            bio: { type: 'string', example: 'Éducateur spécialisé...' },
            daily_rate: { type: 'number', example: 500 },
            years_experience: { type: 'integer', example: 5 },
            region_id: { type: 'integer', example: 1 },
            city_id: { type: 'integer', example: 1 }
          }
        },

        // ============ ESTABLISHMENT SCHEMAS ============
        EstablishmentProfile: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            user_id: { type: 'integer', example: 10 },
            name: { 
              type: 'string', 
              example: 'Centre Social Al Amal',
              description: 'Nom de l\'établissement'
            },
            ice: { 
              type: 'string', 
              example: '001234567000089',
              description: 'Identifiant Commun de l\'Entreprise'
            },
            type: { 
              type: 'string', 
              enum: ['association', 'fondation', 'cooperative', 'entreprise', 'public'],
              example: 'association',
              description: 'Type d\'établissement'
            },
            description: { 
              type: 'string', 
              example: 'Centre d\'accueil pour personnes en situation de handicap...',
              description: 'Description de l\'établissement'
            },
            phone: { type: 'string', example: '+212522123456' },
            address: { type: 'string', example: '123 Rue Mohammed V' },
            website: { type: 'string', example: 'https://alamal.ma' },
            logo: { 
              type: 'string', 
              example: '/uploads/logos/logo_123.png',
              description: 'URL du logo'
            },
            status: { 
              type: 'string', 
              enum: ['pending', 'approved', 'rejected', 'suspended'],
              example: 'approved'
            },
            average_rating: { type: 'number', example: 4.2 },
            total_missions: { type: 'integer', example: 25 }
          }
        },

        // ============ MISSION SCHEMAS ============
        Mission: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            title: { 
              type: 'string', 
              example: 'Éducateur spécialisé - Remplacement congé maternité',
              description: 'Titre de la mission'
            },
            description: { 
              type: 'string', 
              example: 'Nous recherchons un éducateur spécialisé pour un remplacement...',
              description: 'Description détaillée'
            },
            mission_type: { 
              type: 'string', 
              enum: ['ponctuelle', 'courte_duree', 'longue_duree', 'remplacement'],
              example: 'remplacement',
              description: 'Type de mission'
            },
            start_date: { 
              type: 'string', 
              format: 'date',
              example: '2025-02-01',
              description: 'Date de début'
            },
            end_date: { 
              type: 'string', 
              format: 'date',
              example: '2025-04-30',
              description: 'Date de fin'
            },
            salary_min: { 
              type: 'number', 
              example: 400,
              description: 'Salaire minimum journalier (MAD)'
            },
            salary_max: { 
              type: 'number', 
              example: 600,
              description: 'Salaire maximum journalier (MAD)'
            },
            status: { 
              type: 'string', 
              enum: ['draft', 'open', 'in_progress', 'completed', 'cancelled'],
              example: 'open',
              description: 'Statut de la mission'
            },
            is_urgent: { 
              type: 'boolean', 
              example: false,
              description: 'Mission urgente'
            },
            region_id: { type: 'integer', example: 1 },
            city_id: { type: 'integer', example: 1 },
            region: { type: 'string', example: 'Casablanca-Settat' },
            city: { type: 'string', example: 'Casablanca' },
            establishment: { $ref: '#/components/schemas/EstablishmentProfile' },
            applications_count: { type: 'integer', example: 5 }
          }
        },
        MissionCreate: {
          type: 'object',
          required: ['title', 'description', 'mission_type', 'start_date', 'region_id', 'city_id'],
          properties: {
            title: { type: 'string', example: 'Éducateur spécialisé - Remplacement' },
            description: { type: 'string', example: 'Description de la mission...' },
            mission_type: { 
              type: 'string', 
              enum: ['ponctuelle', 'courte_duree', 'longue_duree', 'remplacement']
            },
            start_date: { type: 'string', format: 'date' },
            end_date: { type: 'string', format: 'date' },
            salary_min: { type: 'number' },
            salary_max: { type: 'number' },
            region_id: { type: 'integer' },
            city_id: { type: 'integer' },
            is_urgent: { type: 'boolean', default: false }
          }
        },

        // ============ APPLICATION SCHEMAS ============
        Application: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            mission_id: { type: 'integer', example: 5 },
            worker_id: { type: 'integer', example: 3 },
            cover_letter: { 
              type: 'string', 
              example: 'Je suis très intéressé par cette mission...',
              description: 'Lettre de motivation'
            },
            proposed_rate: { 
              type: 'number', 
              example: 500,
              description: 'Tarif proposé (MAD/jour)'
            },
            status: { 
              type: 'string', 
              enum: ['pending', 'accepted', 'rejected', 'withdrawn'],
              example: 'pending',
              description: 'Statut de la candidature'
            },
            created_at: { type: 'string', format: 'date-time' },
            mission: { $ref: '#/components/schemas/Mission' },
            worker: { $ref: '#/components/schemas/WorkerProfile' }
          }
        },
        ApplicationCreate: {
          type: 'object',
          required: ['mission_id'],
          properties: {
            mission_id: { type: 'integer', example: 5 },
            cover_letter: { type: 'string', example: 'Je suis très intéressé...' },
            proposed_rate: { type: 'number', example: 500 }
          }
        },

        // ============ REVIEW SCHEMAS ============
        Review: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            mission_id: { type: 'integer', example: 5 },
            reviewer_id: { type: 'integer', example: 10 },
            reviewee_id: { type: 'integer', example: 3 },
            rating: { 
              type: 'integer', 
              minimum: 1, 
              maximum: 5,
              example: 5,
              description: 'Note de 1 à 5'
            },
            comment: { 
              type: 'string', 
              example: 'Excellent travail, très professionnel.',
              description: 'Commentaire'
            },
            created_at: { type: 'string', format: 'date-time' }
          }
        },

        // ============ DIPLOMA SCHEMAS ============
        Diploma: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            worker_id: { type: 'integer', example: 3 },
            title: { 
              type: 'string', 
              example: 'Diplôme d\'État d\'Éducateur Spécialisé',
              description: 'Intitulé du diplôme'
            },
            institution: { 
              type: 'string', 
              example: 'IRTS Casablanca',
              description: 'Établissement délivrant'
            },
            obtained_date: { 
              type: 'string', 
              format: 'date',
              example: '2020-06-15',
              description: 'Date d\'obtention'
            },
            document_url: { 
              type: 'string', 
              example: '/uploads/diplomas/diplome_123.pdf',
              description: 'URL du document'
            },
            is_verified: { 
              type: 'boolean', 
              example: true,
              description: 'Vérifié par admin'
            }
          }
        },

        // ============ AVAILABILITY SCHEMAS ============
        Availability: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            worker_id: { type: 'integer', example: 3 },
            date: { 
              type: 'string', 
              format: 'date',
              example: '2025-02-15',
              description: 'Date de disponibilité'
            },
            start_time: { 
              type: 'string', 
              example: '08:00',
              description: 'Heure de début'
            },
            end_time: { 
              type: 'string', 
              example: '18:00',
              description: 'Heure de fin'
            },
            is_available: { 
              type: 'boolean', 
              example: true,
              description: 'Disponible ce jour'
            }
          }
        },

        // ============ MESSAGE SCHEMAS ============
        Message: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            sender_id: { type: 'integer', example: 3 },
            recipient_id: { type: 'integer', example: 10 },
            content: { 
              type: 'string', 
              example: 'Bonjour, je suis intéressé par votre profil.',
              description: 'Contenu du message'
            },
            is_read: { type: 'boolean', example: false },
            created_at: { type: 'string', format: 'date-time' }
          }
        },
        Conversation: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            participant: { $ref: '#/components/schemas/User' },
            last_message: { $ref: '#/components/schemas/Message' },
            unread_count: { type: 'integer', example: 2 }
          }
        },

        // ============ REGION SCHEMAS ============
        Region: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Casablanca-Settat' },
            cities: {
              type: 'array',
              items: { $ref: '#/components/schemas/City' }
            }
          }
        },
        City: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Casablanca' },
            region_id: { type: 'integer', example: 1 }
          }
        },

        // ============ ADMIN SCHEMAS ============
        DashboardStats: {
          type: 'object',
          properties: {
            total_workers: { type: 'integer', example: 150 },
            pending_workers: { type: 'integer', example: 12 },
            approved_workers: { type: 'integer', example: 130 },
            labeled_workers: { type: 'integer', example: 45 },
            total_establishments: { type: 'integer', example: 50 },
            pending_establishments: { type: 'integer', example: 5 },
            total_missions: { type: 'integer', example: 200 },
            active_missions: { type: 'integer', example: 35 },
            total_applications: { type: 'integer', example: 500 },
            pending_applications: { type: 'integer', example: 80 }
          }
        },

        // ============ NOTIFICATION SCHEMAS ============
        Notification: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            user_id: { type: 'integer', example: 3 },
            type: { 
              type: 'string', 
              enum: ['application', 'message', 'mission', 'review', 'system'],
              example: 'application'
            },
            title: { type: 'string', example: 'Nouvelle candidature' },
            message: { type: 'string', example: 'Vous avez reçu une nouvelle candidature.' },
            is_read: { type: 'boolean', example: false },
            created_at: { type: 'string', format: 'date-time' }
          }
        }
      },
      responses: {
        UnauthorizedError: {
          description: 'Token manquant ou invalide',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' },
              example: {
                status: 'error',
                message: 'Token invalide ou expiré'
              }
            }
          }
        },
        ForbiddenError: {
          description: 'Accès refusé - permissions insuffisantes',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' },
              example: {
                status: 'error',
                message: 'Vous n\'avez pas les permissions nécessaires'
              }
            }
          }
        },
        NotFoundError: {
          description: 'Ressource non trouvée',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' },
              example: {
                status: 'error',
                message: 'Ressource non trouvée'
              }
            }
          }
        },
        ValidationError: {
          description: 'Erreur de validation des données',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' },
              example: {
                status: 'error',
                message: 'Données invalides',
                errors: [
                  { field: 'email', message: 'Email invalide' }
                ]
              }
            }
          }
        },
        RateLimitError: {
          description: 'Trop de requêtes',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' },
              example: {
                status: 'error',
                message: 'Trop de requêtes, veuillez réessayer dans 15 minutes'
              }
            }
          }
        }
      }
    },
    tags: [
      { 
        name: 'Auth', 
        description: '🔐 Authentification et gestion des comptes utilisateurs'
      },
      { 
        name: 'Workers', 
        description: '👷 Gestion des profils travailleurs sociaux'
      },
      { 
        name: 'Establishments', 
        description: '🏢 Gestion des profils établissements'
      },
      { 
        name: 'Missions', 
        description: '📋 Publication et recherche de missions'
      },
      { 
        name: 'Applications', 
        description: '📝 Gestion des candidatures aux missions'
      },
      { 
        name: 'Reviews', 
        description: '⭐ Système d\'évaluation et avis'
      },
      { 
        name: 'Messages', 
        description: '💬 Messagerie entre utilisateurs'
      },
      { 
        name: 'Availabilities', 
        description: '📅 Gestion des disponibilités des travailleurs'
      },
      { 
        name: 'Diplomas', 
        description: '🎓 Gestion et vérification des diplômes'
      },
      { 
        name: 'Notifications', 
        description: '🔔 Notifications utilisateurs'
      },
      { 
        name: 'Regions', 
        description: '🗺️ Régions et villes du Maroc'
      },
      { 
        name: 'Stats', 
        description: '📊 Statistiques publiques de la plateforme'
      },
      { 
        name: 'Admin', 
        description: '👑 Administration et modération (admin uniquement)'
      },
      { 
        name: 'Health', 
        description: '💚 Vérification de l\'état de l\'API'
      }
    ]
  },
  apis: [
    './src/routes/*.js',
    './src/controllers/*.js',
    './src/server.js'
  ]
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = swaggerSpec;
