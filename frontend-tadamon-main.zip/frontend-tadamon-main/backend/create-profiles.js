// Create profiles for test accounts that don't have them
const mysql = require('mysql2/promise');
require('dotenv').config({ path: '.env.local' });
require('dotenv').config();

async function createProfiles() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
  });

  try {
    // Check worker@test.com
    const [workerUsers] = await pool.execute(
      "SELECT id FROM users WHERE email = 'worker@test.com' AND role = 'worker'"
    );
    
    if (workerUsers.length > 0) {
      const userId = workerUsers[0].id;
      const [existing] = await pool.execute(
        'SELECT id FROM worker_profiles WHERE user_id = ?', [userId]
      );
      
      if (existing.length === 0) {
        await pool.execute(
          `INSERT INTO worker_profiles (user_id, first_name, last_name, cin, phone, region_id, city_id, bio, daily_rate, years_experience, status)
           VALUES (?, 'Test', 'Worker', 'TW123456', '0600000001', 6, 1, 'Compte de test worker', 400, 3, 'approved')`,
          [userId]
        );
        console.log('✓ Created profile for worker@test.com');
      } else {
        console.log('- worker@test.com already has a profile');
      }
    }

    // Check establishment@test.com
    const [estUsers] = await pool.execute(
      "SELECT id FROM users WHERE email = 'establishment@test.com' AND role = 'establishment'"
    );
    
    if (estUsers.length > 0) {
      const userId = estUsers[0].id;
      const [existing] = await pool.execute(
        'SELECT id FROM establishment_profiles WHERE user_id = ?', [userId]
      );
      
      if (existing.length === 0) {
        await pool.execute(
          `INSERT INTO establishment_profiles (user_id, name, legal_name, ice, type, phone, email, region_id, city_id, description, is_verified)
           VALUES (?, 'Test Establishment', 'Test Establishment SARL', '002345678901234', 'association', '0522000001', 'establishment@test.com', 6, 1, 'Compte de test établissement', TRUE)`,
          [userId]
        );
        console.log('✓ Created profile for establishment@test.com');
      } else {
        console.log('- establishment@test.com already has a profile');
      }
    }

    console.log('\n✅ Done!');
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await pool.end();
  }
}

createProfiles();
