-- Add email verification columns to users table
-- Run this in phpMyAdmin or MySQL CLI

ALTER TABLE users 
ADD COLUMN verification_token VARCHAR(255) NULL,
ADD COLUMN verification_expires DATETIME NULL,
ADD COLUMN reset_token VARCHAR(255) NULL,
ADD COLUMN reset_expires DATETIME NULL;

-- Add index for faster token lookups
CREATE INDEX idx_verification_token ON users(verification_token);
CREATE INDEX idx_reset_token ON users(reset_token);
