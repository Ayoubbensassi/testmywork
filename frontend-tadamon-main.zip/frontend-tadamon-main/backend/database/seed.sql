-- =====================================================
-- LKHEDMA SOCIAL - SEED DATA
-- Données initiales pour le Maroc
-- =====================================================

-- Insert regions (12 régions du Maroc)
INSERT INTO regions (code, name_fr, name_ar) VALUES
('TTA', 'Tanger-Tétouan-Al Hoceïma', 'طنجة تطوان الحسيمة'),
('OR', 'Oriental', 'الشرق'),
('FMK', 'Fès-Meknès', 'فاس مكناس'),
('RSK', 'Rabat-Salé-Kénitra', 'الرباط سلا القنيطرة'),
('BMK', 'Béni Mellal-Khénifra', 'بني ملال خنيفرة'),
('CS', 'Casablanca-Settat', 'الدار البيضاء سطات'),
('MTH', 'Marrakech-Safi', 'مراكش آسفي'),
('DT', 'Drâa-Tafilalet', 'درعة تافيلالت'),
('SM', 'Souss-Massa', 'سوس ماسة'),
('GLO', 'Guelmim-Oued Noun', 'كلميم واد نون'),
('LSS', 'Laâyoune-Sakia El Hamra', 'العيون الساقية الحمراء'),
('DOS', 'Dakhla-Oued Ed-Dahab', 'الداخلة وادي الذهب');

-- Insert major cities
INSERT INTO cities (region_id, name_fr, name_ar, latitude, longitude) VALUES
-- Casablanca-Settat
(6, 'Casablanca', 'الدار البيضاء', 33.5731, -7.5898),
(6, 'Mohammedia', 'المحمدية', 33.6861, -7.3828),
(6, 'El Jadida', 'الجديدة', 33.2316, -8.5007),
(6, 'Settat', 'سطات', 33.0011, -7.6166),
-- Rabat-Salé-Kénitra
(4, 'Rabat', 'الرباط', 34.0209, -6.8416),
(4, 'Salé', 'سلا', 34.0531, -6.7985),
(4, 'Kénitra', 'القنيطرة', 34.2610, -6.5802),
(4, 'Témara', 'تمارة', 33.9287, -6.9122),
-- Marrakech-Safi
(7, 'Marrakech', 'مراكش', 31.6295, -7.9811),
(7, 'Safi', 'آسفي', 32.2994, -9.2372),
(7, 'Essaouira', 'الصويرة', 31.5085, -9.7595),
-- Fès-Meknès
(3, 'Fès', 'فاس', 34.0181, -5.0078),
(3, 'Meknès', 'مكناس', 33.8935, -5.5473),
-- Tanger-Tétouan-Al Hoceïma
(1, 'Tanger', 'طنجة', 35.7595, -5.8340),
(1, 'Tétouan', 'تطوان', 35.5889, -5.3626),
(1, 'Al Hoceïma', 'الحسيمة', 35.2517, -3.9372),
-- Souss-Massa
(9, 'Agadir', 'أكادير', 30.4278, -9.5981),
(9, 'Inezgane', 'إنزكان', 30.3558, -9.5370),
-- Oriental
(2, 'Oujda', 'وجدة', 34.6867, -1.9114),
(2, 'Nador', 'الناظور', 35.1681, -2.9287);

-- Insert specialties
INSERT INTO specialties (name, category, description) VALUES
-- Handicap
('Éducateur spécialisé', 'handicap', 'Accompagnement éducatif des personnes en situation de handicap'),
('Moniteur-éducateur', 'handicap', 'Animation et accompagnement au quotidien'),
('Aide médico-psychologique', 'handicap', 'Assistance dans les actes de la vie quotidienne'),
('Ergothérapeute', 'handicap', 'Rééducation par l\'activité'),
-- Enfance
('Éducateur de jeunes enfants', 'enfance', 'Accompagnement des enfants de 0 à 7 ans'),
('Assistant familial', 'enfance', 'Accueil d\'enfants à domicile'),
('Technicien de l\'intervention sociale et familiale', 'enfance', 'Soutien aux familles'),
-- Personnes âgées
('Aide-soignant', 'personnes_agees', 'Soins d\'hygiène et de confort'),
('Auxiliaire de vie sociale', 'personnes_agees', 'Aide à domicile'),
('Animateur en gérontologie', 'personnes_agees', 'Animation auprès des personnes âgées'),
-- Insertion
('Conseiller en insertion professionnelle', 'insertion', 'Accompagnement vers l\'emploi'),
('Médiateur social', 'insertion', 'Médiation et lien social'),
-- Santé mentale
('Infirmier psychiatrique', 'sante_mentale', 'Soins en psychiatrie'),
('Psychologue', 'sante_mentale', 'Accompagnement psychologique'),
-- Autre
('Chef de service', 'autre', 'Encadrement d\'équipe'),
('Directeur d\'établissement', 'autre', 'Direction et gestion');

-- Insert rules for warnings
INSERT INTO rules (title, description, severity) VALUES
('Non-respect des engagements', 'Annulation répétée de missions sans justification', 'high'),
('Comportement inapproprié', 'Attitude non professionnelle envers les usagers ou collègues', 'high'),
('Retards répétés', 'Retards fréquents aux missions', 'medium'),
('Documents non conformes', 'Fourniture de documents falsifiés ou non valides', 'high'),
('Non-respect de la confidentialité', 'Divulgation d\'informations confidentielles', 'high'),
('Absence de communication', 'Défaut de réponse aux messages importants', 'low');

-- Insert admin user (password: Admin123!)
-- Hash generated with bcrypt, 10 rounds
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('admin@lkhedma.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'admin', TRUE, TRUE);

-- Note: Password is 'Admin123!' - you can regenerate with: bcrypt.hashSync('Admin123!', 10)


-- =====================================================
-- TEST DATA - Users, Profiles, and Missions
-- =====================================================

-- Test establishment user (password: Test123!)
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('etablissement@test.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'establishment', TRUE, TRUE);

-- Test worker user (password: Test123!)
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('travailleur@test.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'worker', TRUE, TRUE);

-- Establishment profile (user_id = 2)
INSERT INTO establishment_profiles (user_id, name, legal_name, ice, type, phone, email, region_id, city_id, address, description, is_verified) VALUES
(2, 'Centre Social Espoir', 'Association Centre Social Espoir', '001234567890123', 'association', '0522123456', 'contact@espoir.ma', 6, 1, '123 Rue Mohammed V, Casablanca', 'Centre d''accompagnement social pour personnes en difficulté. Nous offrons des services d''insertion professionnelle et d''aide sociale.', TRUE);

-- Worker profile (user_id = 3)
INSERT INTO worker_profiles (user_id, first_name, last_name, cin, phone, region_id, city_id, bio, daily_rate, years_experience, status, is_labeled) VALUES
(3, 'Ahmed', 'Benali', 'AB123456', '0612345678', 6, 1, 'Éducateur spécialisé avec 8 ans d''expérience dans l''accompagnement des personnes en situation de handicap. Passionné par mon métier.', 450, 8, 'approved', TRUE);

-- Worker specialties
INSERT INTO worker_specialties (worker_id, specialty_id, years_experience, proficiency_level) VALUES
(1, 1, 8, 'expert'),
(1, 2, 5, 'intermediate');

-- Test missions
INSERT INTO missions (establishment_id, title, description, mission_type, start_date, end_date, salary_min, salary_max, region_id, city_id, required_experience, is_urgent, status, published_at) VALUES
(1, 'Éducateur spécialisé - Accompagnement handicap', 'Recherche éducateur spécialisé pour accompagnement d''enfants en situation de handicap au sein de notre centre. Mission de 3 mois renouvelable.', 'longue_duree', '2026-02-01', '2026-05-01', 400, 500, 6, 1, 2, TRUE, 'open', NOW()),
(1, 'Moniteur-éducateur - Animation', 'Mission d''animation et d''accompagnement au quotidien pour notre groupe de jeunes adultes.', 'ponctuelle', '2026-01-20', '2026-02-20', 350, 400, 6, 1, 1, FALSE, 'open', NOW()),
(1, 'Assistant social - Insertion professionnelle', 'Accompagnement des bénéficiaires dans leurs démarches d''insertion professionnelle.', 'longue_duree', '2026-02-15', '2026-08-15', 380, 450, 6, 1, 3, FALSE, 'open', NOW());

-- Mission specialties
INSERT INTO mission_specialties (mission_id, specialty_id, is_required) VALUES
(1, 1, TRUE),
(1, 3, FALSE),
(2, 2, TRUE),
(3, 11, TRUE);
