-- More cities for Morocco
-- Run this in phpMyAdmin

-- Casablanca-Settat (region_id = 6)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(6, 'Berrechid', 'برشيد'),
(6, 'Benslimane', 'بنسليمان'),
(6, 'Médiouna', 'مديونة');

-- Rabat-Salé-Kénitra (region_id = 4)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(4, 'Skhirat', 'الصخيرات'),
(4, 'Harhoura', 'الهرهورة'),
(4, 'Sidi Slimane', 'سيدي سليمان'),
(4, 'Sidi Kacem', 'سيدي قاسم');

-- Marrakech-Safi (region_id = 7)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(7, 'Beni Mellal', 'بني ملال'),
(7, 'Kelaa des Sraghna', 'قلعة السراغنة'),
(7, 'Youssoufia', 'اليوسفية');

-- Fès-Meknès (region_id = 3)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(3, 'Taza', 'تازة'),
(3, 'Sefrou', 'صفرو'),
(3, 'Ifrane', 'إفران'),
(3, 'Azrou', 'أزرو');

-- Tanger-Tétouan-Al Hoceïma (region_id = 1)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(1, 'Larache', 'العرائش'),
(1, 'Asilah', 'أصيلة'),
(1, 'Chefchaouen', 'شفشاون'),
(1, 'Fnideq', 'الفنيدق'),
(1, 'M''diq', 'المضيق');

-- Souss-Massa (region_id = 9)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(9, 'Taroudant', 'تارودانت'),
(9, 'Tiznit', 'تزنيت'),
(9, 'Ait Melloul', 'أيت ملول');

-- Oriental (region_id = 2)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(2, 'Berkane', 'بركان'),
(2, 'Taourirt', 'تاوريرت'),
(2, 'Jerada', 'جرادة');

-- Béni Mellal-Khénifra (region_id = 5)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(5, 'Beni Mellal', 'بني ملال'),
(5, 'Khouribga', 'خريبكة'),
(5, 'Fquih Ben Salah', 'الفقيه بن صالح'),
(5, 'Azilal', 'أزيلال');

-- Drâa-Tafilalet (region_id = 8)
INSERT IGNORE INTO cities (region_id, name_fr, name_ar) VALUES
(8, 'Errachidia', 'الراشيدية'),
(8, 'Ouarzazate', 'ورزازات'),
(8, 'Tinghir', 'تنغير'),
(8, 'Zagora', 'زاكورة');
