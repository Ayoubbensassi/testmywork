# قاعدة البيانات - LKHEDMA Social

## الملفات

| الملف | الوصف |
|-------|-------|
| `FINAL_DATABASE.sql` | **الملف الرسمي** - قم بتشغيله في phpMyAdmin |
| `schema.sql` | هيكل الجداول فقط (للمرجعية) |
| `seed.sql` | البيانات الأولية (للمرجعية) |
| `more_cities.sql` | مدن إضافية (اختياري) |

## التثبيت

### 1. إنشاء قاعدة البيانات
```sql
CREATE DATABASE lkhedma_social CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. تشغيل الملف
- افتح phpMyAdmin
- اختر قاعدة البيانات `lkhedma_social`
- اذهب إلى تبويب "Import"
- اختر ملف `FINAL_DATABASE.sql`
- اضغط "Go"

## حسابات الاختبار

| الحساب | البريد | كلمة المرور |
|--------|--------|-------------|
| Admin | admin@lkhedma.ma | Admin123! |
| Établissement | etablissement@test.ma | Test123! |
| Travailleur | travailleur@test.ma | Test123! |

## حسابات Demo (بدون قاعدة بيانات)

| الحساب | البريد | كلمة المرور |
|--------|--------|-------------|
| Demo Admin | demo.admin@lkhedma.ma | demo123 |
| Demo Établissement | demo.etablissement@lkhedma.ma | demo123 |
| Demo Travailleur | demo.travailleur@lkhedma.ma | demo123 |

## الجداول (22 جدول)

1. `users` - المستخدمون
2. `regions` - المناطق
3. `cities` - المدن
4. `specialties` - التخصصات
5. `worker_profiles` - ملفات العمال
6. `worker_specialties` - تخصصات العمال
7. `diplomas` - الشهادات
8. `experiences` - الخبرات
9. `availabilities` - التوفر
10. `establishment_profiles` - ملفات المؤسسات
11. `missions` - المهمات
12. `mission_specialties` - تخصصات المهمات
13. `applications` - الترشيحات
14. `reviews` - التقييمات
15. `payments` - المدفوعات
16. `conversations` - المحادثات
17. `messages` - الرسائل
18. `notifications` - الإشعارات
19. `favorites` - المفضلة
20. `rules` - قواعد الإشراف
21. `warnings` - التحذيرات
22. `contact_messages` - رسائل الاتصال
