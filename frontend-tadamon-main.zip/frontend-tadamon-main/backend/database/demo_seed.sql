-- =====================================================
-- LKHEDMA SOCIAL - DEMO SEED DATA
-- Password: Test1234
-- =====================================================

-- Admin
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('admin@lkhedma.ma', '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe', 'admin', TRUE, TRUE)
ON DUPLICATE KEY UPDATE password = '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe';

-- Establishment
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('etablissement@test.ma', '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe', 'establishment', TRUE, TRUE)
ON DUPLICATE KEY UPDATE password = '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe';

-- Worker
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('travailleur@test.ma', '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe', 'worker', TRUE, TRUE)
ON DUPLICATE KEY UPDATE password = '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe';

-- Demo Worker
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('demo.worker@example.com', '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe', 'worker', TRUE, TRUE)
ON DUPLICATE KEY UPDATE password = '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe';

-- Demo Establishment
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('demo.establishment@example.com', '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe', 'establishment', TRUE, TRUE)
ON DUPLICATE KEY UPDATE password = '$2b$10$gEWb3H5gqHfZ41isgpHCAuTRM20gpHNjlyj/n9ERrhKnEYDfawZxe';

-- =====================================================
-- LOGIN CREDENTIALS (Password: Test1234)
-- =====================================================
-- admin@lkhedma.ma              | admin
-- etablissement@test.ma         | establishment
-- travailleur@test.ma           | worker
-- demo.worker@example.com       | worker
-- demo.establishment@example.com| establishment
-- =====================================================

SELECT 'Done! Password: Test1234' as status;
