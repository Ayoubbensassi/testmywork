-- =====================================================
-- LKHEDMA SOCIAL - RESET DEMO DATA
-- Supprime les données de test et crée des comptes démo
-- =====================================================

-- Désactiver les contraintes de clés étrangères
SET FOREIGN_KEY_CHECKS = 0;

-- Supprimer toutes les données (DELETE au lieu de TRUNCATE)
DELETE FROM messages;
DELETE FROM conversations;
DELETE FROM notifications;
DELETE FROM warnings;
DELETE FROM reviews;
DELETE FROM payments;
DELETE FROM applications;
DELETE FROM mission_specialties;
DELETE FROM missions;
DELETE FROM availabilities;
DELETE FROM worker_specialties;
DELETE FROM experiences;
DELETE FROM diplomas;
DELETE FROM favorites;
DELETE FROM establishment_profiles;
DELETE FROM worker_profiles;
DELETE FROM users;

-- Réinitialiser les auto-increments
ALTER TABLE messages AUTO_INCREMENT = 1;
ALTER TABLE conversations AUTO_INCREMENT = 1;
ALTER TABLE notifications AUTO_INCREMENT = 1;
ALTER TABLE warnings AUTO_INCREMENT = 1;
ALTER TABLE reviews AUTO_INCREMENT = 1;
ALTER TABLE payments AUTO_INCREMENT = 1;
ALTER TABLE applications AUTO_INCREMENT = 1;
ALTER TABLE mission_specialties AUTO_INCREMENT = 1;
ALTER TABLE missions AUTO_INCREMENT = 1;
ALTER TABLE availabilities AUTO_INCREMENT = 1;
ALTER TABLE worker_specialties AUTO_INCREMENT = 1;
ALTER TABLE experiences AUTO_INCREMENT = 1;
ALTER TABLE diplomas AUTO_INCREMENT = 1;
ALTER TABLE favorites AUTO_INCREMENT = 1;
ALTER TABLE establishment_profiles AUTO_INCREMENT = 1;
ALTER TABLE worker_profiles AUTO_INCREMENT = 1;
ALTER TABLE users AUTO_INCREMENT = 1;

-- Réactiver les contraintes
SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- CRÉER LES COMPTES DÉMO
-- Mot de passe pour tous: Admin123!
-- =====================================================

-- Admin
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('admin@lkhedma.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'admin', TRUE, TRUE);

-- Worker demo
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('worker@demo.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'worker', TRUE, TRUE);

-- Establishment demo
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('etablissement@demo.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'establishment', TRUE, TRUE);

-- Créer le profil worker
INSERT INTO worker_profiles (user_id, first_name, last_name, cin, phone, region_id, city_id, bio, daily_rate, years_experience, status, is_labeled) VALUES
(2, 'Ahmed', 'Benali', 'AB123456', '0612345678', 6, 1, 'Éducateur spécialisé avec 5 ans d''expérience.', 500, 5, 'approved', TRUE);

-- Créer le profil establishment
INSERT INTO establishment_profiles (user_id, name, ice, type, phone, region_id, city_id, description, is_verified) VALUES
(3, 'Association Espoir', '001234567890123', 'association', '0522123456', 6, 1, 'Association d''aide aux personnes en situation de handicap.', TRUE);

-- Ajouter des spécialités au worker
INSERT INTO worker_specialties (worker_id, specialty_id, years_experience, proficiency_level) VALUES
(1, 1, 5, 'expert'),
(1, 2, 3, 'intermediate');

-- Ajouter une expérience
INSERT INTO experiences (worker_id, job_title, employer, start_date, end_date, is_current, description) VALUES
(1, 'Éducateur spécialisé', 'Centre Social Casablanca', '2020-01-01', NULL, TRUE, 'Accompagnement éducatif.');

-- Ajouter un diplôme
INSERT INTO diplomas (worker_id, title, institution, obtained_date, is_verified) VALUES
(1, 'DEES - Diplôme d''État d''Éducateur Spécialisé', 'IRTS Casablanca', '2019-06-15', TRUE);

-- Créer une mission exemple
INSERT INTO missions (establishment_id, title, description, mission_type, start_date, end_date, salary_min, salary_max, region_id, city_id, required_experience, status, published_at) VALUES
(1, 'Éducateur pour centre de jour', 'Recherche éducateur spécialisé pour accompagnement.', 'longue_duree', '2026-02-01', '2026-08-31', 400, 600, 6, 1, 2, 'open', NOW());

-- Ajouter spécialité requise à la mission
INSERT INTO mission_specialties (mission_id, specialty_id, is_required) VALUES
(1, 1, TRUE);

SELECT 'Base réinitialisée!' AS message;
