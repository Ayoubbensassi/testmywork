-- =====================================================
-- LKHEDMA SOCIAL - قاعدة البيانات النهائية
-- Plateforme de travailleurs sociaux - Maroc
-- VERSION FINALE - COMPATIBLE AVEC LE CODE
-- =====================================================
-- تشغيل هذا الملف في phpMyAdmin سيحذف البيانات القديمة
-- ويعيد إنشاء قاعدة البيانات بشكل صحيح
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET NAMES utf8mb4;

-- حذف الجداول القديمة بالترتيب الصحيح
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS warnings;
DROP TABLE IF EXISTS rules;
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS conversations;
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS mission_specialties;
DROP TABLE IF EXISTS missions;
DROP TABLE IF EXISTS availabilities;
DROP TABLE IF EXISTS worker_specialties;
DROP TABLE IF EXISTS experiences;
DROP TABLE IF EXISTS diplomas;
DROP TABLE IF EXISTS worker_profiles;
DROP TABLE IF EXISTS establishment_profiles;
DROP TABLE IF EXISTS specialties;
DROP TABLE IF EXISTS cities;
DROP TABLE IF EXISTS regions;
DROP TABLE IF EXISTS users;

-- =====================================================
-- 1. USERS - المستخدمون
-- =====================================================
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('worker', 'establishment', 'admin') NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  is_verified BOOLEAN DEFAULT FALSE,
  warnings_count INT DEFAULT 0,
  last_login DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role),
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. REGIONS - المناطق (12 جهة بالمغرب)
-- =====================================================
CREATE TABLE regions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(10) UNIQUE NOT NULL,
  name_fr VARCHAR(100) NOT NULL,
  name_ar VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 3. CITIES - المدن
-- =====================================================
CREATE TABLE cities (
  id INT PRIMARY KEY AUTO_INCREMENT,
  region_id INT NOT NULL,
  name_fr VARCHAR(100) NOT NULL,
  name_ar VARCHAR(100),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (region_id) REFERENCES regions(id) ON DELETE CASCADE,
  INDEX idx_region (region_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. SPECIALTIES - التخصصات
-- =====================================================
CREATE TABLE specialties (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  category ENUM('handicap', 'enfance', 'personnes_agees', 'insertion', 'sante_mentale', 'autre') NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. WORKER_PROFILES - ملفات العمال
-- =====================================================
CREATE TABLE worker_profiles (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT UNIQUE NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  cin VARCHAR(20) UNIQUE NOT NULL,
  phone VARCHAR(20),
  birth_date DATE,
  region_id INT,
  city_id INT,
  address TEXT,
  mobility_radius INT DEFAULT 50,
  bio TEXT,
  daily_rate DECIMAL(10, 2),
  years_experience INT DEFAULT 0,
  profile_picture VARCHAR(255),
  cin_document_front VARCHAR(255),
  cin_document_back VARCHAR(255),
  cv_document VARCHAR(255),
  status ENUM('pending', 'approved', 'rejected', 'suspended') DEFAULT 'pending',
  rejection_reason TEXT,
  validated_by INT,
  validated_at DATETIME,
  is_labeled BOOLEAN DEFAULT FALSE,
  labeled_by INT,
  labeled_at DATETIME,
  average_rating DECIMAL(3, 2) DEFAULT 0,
  total_missions INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (region_id) REFERENCES regions(id),
  FOREIGN KEY (city_id) REFERENCES cities(id),
  FOREIGN KEY (validated_by) REFERENCES users(id),
  FOREIGN KEY (labeled_by) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_region (region_id),
  INDEX idx_labeled (is_labeled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. WORKER_SPECIALTIES - تخصصات العمال
-- =====================================================
CREATE TABLE worker_specialties (
  id INT PRIMARY KEY AUTO_INCREMENT,
  worker_id INT NOT NULL,
  specialty_id INT NOT NULL,
  years_experience INT DEFAULT 0,
  proficiency_level ENUM('beginner', 'intermediate', 'expert') DEFAULT 'intermediate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_worker_specialty (worker_id, specialty_id),
  FOREIGN KEY (worker_id) REFERENCES worker_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (specialty_id) REFERENCES specialties(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. DIPLOMAS - الشهادات
-- =====================================================
CREATE TABLE diplomas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  worker_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  institution VARCHAR(255) NOT NULL,
  obtained_date DATE,
  file_path VARCHAR(255),
  is_verified BOOLEAN DEFAULT FALSE,
  verified_by INT,
  verified_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (worker_id) REFERENCES worker_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (verified_by) REFERENCES users(id),
  INDEX idx_worker (worker_id),
  INDEX idx_verified (is_verified)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 8. EXPERIENCES - الخبرات
-- =====================================================
CREATE TABLE experiences (
  id INT PRIMARY KEY AUTO_INCREMENT,
  worker_id INT NOT NULL,
  job_title VARCHAR(255) NOT NULL,
  employer VARCHAR(255) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  is_current BOOLEAN DEFAULT FALSE,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (worker_id) REFERENCES worker_profiles(id) ON DELETE CASCADE,
  INDEX idx_worker (worker_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9. AVAILABILITIES - التوفر
-- =====================================================
CREATE TABLE availabilities (
  id INT PRIMARY KEY AUTO_INCREMENT,
  worker_id INT NOT NULL,
  date DATE NOT NULL,
  start_time TIME DEFAULT '08:00:00',
  end_time TIME DEFAULT '18:00:00',
  is_available BOOLEAN DEFAULT TRUE,
  note VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_worker_date (worker_id, date),
  FOREIGN KEY (worker_id) REFERENCES worker_profiles(id) ON DELETE CASCADE,
  INDEX idx_availability (worker_id, date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 10. ESTABLISHMENT_PROFILES - ملفات المؤسسات
-- =====================================================
CREATE TABLE establishment_profiles (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  legal_name VARCHAR(255),
  ice VARCHAR(20) UNIQUE,
  type ENUM('association', 'entreprise', 'public', 'autre') NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(255),
  region_id INT,
  city_id INT,
  address TEXT,
  website VARCHAR(255),
  description TEXT,
  logo VARCHAR(255),
  contact_person_name VARCHAR(100),
  contact_person_phone VARCHAR(20),
  is_verified BOOLEAN DEFAULT FALSE,
  verified_by INT,
  verified_at DATETIME,
  average_rating DECIMAL(3, 2) DEFAULT 0,
  total_missions INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (region_id) REFERENCES regions(id),
  FOREIGN KEY (city_id) REFERENCES cities(id),
  FOREIGN KEY (verified_by) REFERENCES users(id),
  INDEX idx_verified (is_verified),
  INDEX idx_region (region_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 11. MISSIONS - المهمات
-- =====================================================
CREATE TABLE missions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  establishment_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  mission_type ENUM('ponctuelle', 'courte_duree', 'longue_duree', 'remplacement') NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  salary_min DECIMAL(10, 2),
  salary_max DECIMAL(10, 2),
  negotiable BOOLEAN DEFAULT TRUE,
  region_id INT,
  city_id INT,
  required_experience INT DEFAULT 0,
  is_urgent BOOLEAN DEFAULT FALSE,
  status ENUM('draft', 'open', 'in_progress', 'completed', 'cancelled') DEFAULT 'draft',
  selected_worker_id INT,
  published_at DATETIME,
  views_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (establishment_id) REFERENCES establishment_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (region_id) REFERENCES regions(id),
  FOREIGN KEY (city_id) REFERENCES cities(id),
  FOREIGN KEY (selected_worker_id) REFERENCES worker_profiles(id),
  INDEX idx_status (status),
  INDEX idx_region (region_id),
  INDEX idx_dates (start_date, end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 12. MISSION_SPECIALTIES - تخصصات المهمات
-- =====================================================
CREATE TABLE mission_specialties (
  id INT PRIMARY KEY AUTO_INCREMENT,
  mission_id INT NOT NULL,
  specialty_id INT NOT NULL,
  is_required BOOLEAN DEFAULT TRUE,
  UNIQUE KEY unique_mission_specialty (mission_id, specialty_id),
  FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE,
  FOREIGN KEY (specialty_id) REFERENCES specialties(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 13. APPLICATIONS - الترشيحات
-- =====================================================
CREATE TABLE applications (
  id INT PRIMARY KEY AUTO_INCREMENT,
  mission_id INT NOT NULL,
  worker_id INT NOT NULL,
  cover_letter TEXT,
  proposed_rate DECIMAL(10, 2),
  status ENUM('pending', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending',
  reviewed_by INT,
  reviewed_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_application (mission_id, worker_id),
  FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES worker_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (reviewed_by) REFERENCES users(id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 14. REVIEWS - التقييمات
-- =====================================================
CREATE TABLE reviews (
  id INT PRIMARY KEY AUTO_INCREMENT,
  mission_id INT NOT NULL,
  reviewer_id INT NOT NULL,
  reviewee_id INT NOT NULL,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  is_public BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_review (mission_id, reviewer_id, reviewee_id),
  FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE,
  FOREIGN KEY (reviewer_id) REFERENCES users(id),
  FOREIGN KEY (reviewee_id) REFERENCES users(id),
  INDEX idx_reviewee (reviewee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 15. PAYMENTS - المدفوعات
-- =====================================================
CREATE TABLE payments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  mission_id INT NOT NULL,
  payer_id INT NOT NULL,
  payee_id INT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  platform_fee DECIMAL(10, 2) DEFAULT 0,
  status ENUM('pending', 'held', 'released', 'refunded', 'cancelled') DEFAULT 'pending',
  payment_method VARCHAR(50),
  transaction_id VARCHAR(255),
  released_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (mission_id) REFERENCES missions(id),
  FOREIGN KEY (payer_id) REFERENCES users(id),
  FOREIGN KEY (payee_id) REFERENCES users(id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 16. CONVERSATIONS - المحادثات
-- =====================================================
CREATE TABLE conversations (
  id INT PRIMARY KEY AUTO_INCREMENT,
  mission_id INT,
  participant1_id INT NOT NULL,
  participant2_id INT NOT NULL,
  last_message_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE SET NULL,
  FOREIGN KEY (participant1_id) REFERENCES users(id),
  FOREIGN KEY (participant2_id) REFERENCES users(id),
  INDEX idx_participants (participant1_id, participant2_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 17. MESSAGES - الرسائل
-- =====================================================
CREATE TABLE messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  conversation_id INT NOT NULL,
  sender_id INT NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  read_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_id) REFERENCES users(id),
  INDEX idx_conversation (conversation_id),
  INDEX idx_unread (sender_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 18. NOTIFICATIONS - الإشعارات
-- =====================================================
CREATE TABLE notifications (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(255),
  is_read BOOLEAN DEFAULT FALSE,
  read_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_unread (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 19. FAVORITES - المفضلة
-- =====================================================
CREATE TABLE favorites (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  worker_id INT,
  mission_id INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (worker_id) REFERENCES worker_profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 20. RULES - قواعد الإشراف
-- =====================================================
CREATE TABLE rules (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  severity ENUM('low', 'medium', 'high') DEFAULT 'medium',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 21. WARNINGS - التحذيرات
-- =====================================================
CREATE TABLE warnings (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  rule_id INT,
  reason TEXT NOT NULL,
  issued_by INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (rule_id) REFERENCES rules(id),
  FOREIGN KEY (issued_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 22. CONTACT_MESSAGES - رسائل الاتصال
-- =====================================================
CREATE TABLE contact_messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  user_type ENUM('worker', 'establishment', 'other') NOT NULL,
  subject VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  status ENUM('new', 'read', 'replied', 'closed') DEFAULT 'new',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;


-- =====================================================
-- البيانات الأولية - SEED DATA
-- =====================================================

-- المناطق الـ 12 بالمغرب
INSERT INTO regions (code, name_fr, name_ar) VALUES
('TTA', 'Tanger-Tétouan-Al Hoceïma', 'طنجة تطوان الحسيمة'),
('OR', 'Oriental', 'الشرق'),
('FMK', 'Fès-Meknès', 'فاس مكناس'),
('RSK', 'Rabat-Salé-Kénitra', 'الرباط سلا القنيطرة'),
('BMK', 'Béni Mellal-Khénifra', 'بني ملال خنيفرة'),
('CS', 'Casablanca-Settat', 'الدار البيضاء سطات'),
('MTH', 'Marrakech-Safi', 'مراكش آسفي'),
('DT', 'Drâa-Tafilalet', 'درعة تافيلالت'),
('SM', 'Souss-Massa', 'سوس ماسة'),
('GLO', 'Guelmim-Oued Noun', 'كلميم واد نون'),
('LSS', 'Laâyoune-Sakia El Hamra', 'العيون الساقية الحمراء'),
('DOS', 'Dakhla-Oued Ed-Dahab', 'الداخلة وادي الذهب');

-- المدن الرئيسية
INSERT INTO cities (region_id, name_fr, name_ar, latitude, longitude) VALUES
-- Casablanca-Settat (6)
(6, 'Casablanca', 'الدار البيضاء', 33.5731, -7.5898),
(6, 'Mohammedia', 'المحمدية', 33.6861, -7.3828),
(6, 'El Jadida', 'الجديدة', 33.2316, -8.5007),
(6, 'Settat', 'سطات', 33.0011, -7.6166),
(6, 'Berrechid', 'برشيد', 33.2654, -7.5876),
-- Rabat-Salé-Kénitra (4)
(4, 'Rabat', 'الرباط', 34.0209, -6.8416),
(4, 'Salé', 'سلا', 34.0531, -6.7985),
(4, 'Kénitra', 'القنيطرة', 34.2610, -6.5802),
(4, 'Témara', 'تمارة', 33.9287, -6.9122),
-- Marrakech-Safi (7)
(7, 'Marrakech', 'مراكش', 31.6295, -7.9811),
(7, 'Safi', 'آسفي', 32.2994, -9.2372),
(7, 'Essaouira', 'الصويرة', 31.5085, -9.7595),
-- Fès-Meknès (3)
(3, 'Fès', 'فاس', 34.0181, -5.0078),
(3, 'Meknès', 'مكناس', 33.8935, -5.5473),
(3, 'Taza', 'تازة', 34.2100, -4.0100),
(3, 'Ifrane', 'إفران', 33.5333, -5.1167),
-- Tanger-Tétouan-Al Hoceïma (1)
(1, 'Tanger', 'طنجة', 35.7595, -5.8340),
(1, 'Tétouan', 'تطوان', 35.5889, -5.3626),
(1, 'Al Hoceïma', 'الحسيمة', 35.2517, -3.9372),
(1, 'Chefchaouen', 'شفشاون', 35.1688, -5.2636),
-- Souss-Massa (9)
(9, 'Agadir', 'أكادير', 30.4278, -9.5981),
(9, 'Inezgane', 'إنزكان', 30.3558, -9.5370),
(9, 'Taroudant', 'تارودانت', 30.4727, -8.8748),
-- Oriental (2)
(2, 'Oujda', 'وجدة', 34.6867, -1.9114),
(2, 'Nador', 'الناظور', 35.1681, -2.9287),
(2, 'Berkane', 'بركان', 34.9200, -2.3200),
-- Béni Mellal-Khénifra (5)
(5, 'Béni Mellal', 'بني ملال', 32.3373, -6.3498),
(5, 'Khouribga', 'خريبكة', 32.8811, -6.9063),
-- Drâa-Tafilalet (8)
(8, 'Errachidia', 'الراشيدية', 31.9314, -4.4277),
(8, 'Ouarzazate', 'ورزازات', 30.9189, -6.8936);

-- التخصصات
INSERT INTO specialties (name, category, description) VALUES
-- Handicap
('Éducateur spécialisé', 'handicap', 'Accompagnement éducatif des personnes en situation de handicap'),
('Moniteur-éducateur', 'handicap', 'Animation et accompagnement au quotidien'),
('Aide médico-psychologique', 'handicap', 'Assistance dans les actes de la vie quotidienne'),
('Ergothérapeute', 'handicap', 'Rééducation par l\'activité'),
-- Enfance
('Éducateur de jeunes enfants', 'enfance', 'Accompagnement des enfants de 0 à 7 ans'),
('Assistant familial', 'enfance', 'Accueil d\'enfants à domicile'),
('Technicien intervention sociale', 'enfance', 'Soutien aux familles'),
-- Personnes âgées
('Aide-soignant', 'personnes_agees', 'Soins d\'hygiène et de confort'),
('Auxiliaire de vie sociale', 'personnes_agees', 'Aide à domicile'),
('Animateur en gérontologie', 'personnes_agees', 'Animation auprès des personnes âgées'),
-- Insertion
('Conseiller insertion professionnelle', 'insertion', 'Accompagnement vers l\'emploi'),
('Médiateur social', 'insertion', 'Médiation et lien social'),
-- Santé mentale
('Infirmier psychiatrique', 'sante_mentale', 'Soins en psychiatrie'),
('Psychologue', 'sante_mentale', 'Accompagnement psychologique'),
-- Autre
('Chef de service', 'autre', 'Encadrement d\'équipe'),
('Directeur d\'établissement', 'autre', 'Direction et gestion');

-- قواعد الإشراف
INSERT INTO rules (title, description, severity) VALUES
('Non-respect des engagements', 'Annulation répétée de missions sans justification', 'high'),
('Comportement inapproprié', 'Attitude non professionnelle', 'high'),
('Retards répétés', 'Retards fréquents aux missions', 'medium'),
('Documents non conformes', 'Fourniture de documents falsifiés', 'high'),
('Non-respect confidentialité', 'Divulgation d\'informations confidentielles', 'high'),
('Absence de communication', 'Défaut de réponse aux messages', 'low');

-- =====================================================
-- حسابات الاختبار
-- كلمة المرور: Admin123! أو Test123!
-- =====================================================

-- Admin (admin@lkhedma.ma / Admin123!)
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('admin@lkhedma.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'admin', TRUE, TRUE);

-- Establishment Test (etablissement@test.ma / Test123!)
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('etablissement@test.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'establishment', TRUE, TRUE);

-- Worker Test (travailleur@test.ma / Test123!)
INSERT INTO users (email, password, role, is_active, is_verified) VALUES
('travailleur@test.ma', '$2b$10$8K1p/a0dL1LXMIgoEDFrwOfMQHLaV6PVN1.Ij.vI5/Kg7/OqKqIuy', 'worker', TRUE, TRUE);

-- ملف المؤسسة (user_id = 2)
INSERT INTO establishment_profiles (user_id, name, legal_name, ice, type, phone, email, region_id, city_id, address, description, is_verified) VALUES
(2, 'Centre Social Espoir', 'Association Centre Social Espoir', '001234567890123', 'association', '0522123456', 'contact@espoir.ma', 6, 1, '123 Rue Mohammed V, Casablanca', 'Centre d\'accompagnement social pour personnes en difficulté.', TRUE);

-- ملف العامل (user_id = 3)
INSERT INTO worker_profiles (user_id, first_name, last_name, cin, phone, region_id, city_id, bio, daily_rate, years_experience, status, is_labeled) VALUES
(3, 'Ahmed', 'Benali', 'AB123456', '0612345678', 6, 1, 'Éducateur spécialisé avec 8 ans d\'expérience.', 450, 8, 'approved', TRUE);

-- تخصصات العامل
INSERT INTO worker_specialties (worker_id, specialty_id, years_experience, proficiency_level) VALUES
(1, 1, 8, 'expert'),
(1, 2, 5, 'intermediate');

-- مهمات اختبارية
INSERT INTO missions (establishment_id, title, description, mission_type, start_date, end_date, salary_min, salary_max, region_id, city_id, required_experience, is_urgent, status, published_at) VALUES
(1, 'Éducateur spécialisé - Accompagnement handicap', 'Recherche éducateur spécialisé pour accompagnement d\'enfants en situation de handicap.', 'longue_duree', '2026-02-01', '2026-05-01', 400, 500, 6, 1, 2, TRUE, 'open', NOW()),
(1, 'Moniteur-éducateur - Animation', 'Mission d\'animation et d\'accompagnement au quotidien.', 'ponctuelle', '2026-01-20', '2026-02-20', 350, 400, 6, 1, 1, FALSE, 'open', NOW()),
(1, 'Assistant social - Insertion', 'Accompagnement des bénéficiaires dans leurs démarches.', 'longue_duree', '2026-02-15', '2026-08-15', 380, 450, 6, 1, 3, FALSE, 'open', NOW());

-- تخصصات المهمات
INSERT INTO mission_specialties (mission_id, specialty_id, is_required) VALUES
(1, 1, TRUE),
(1, 3, FALSE),
(2, 2, TRUE),
(3, 11, TRUE);

-- =====================================================
-- نهاية الملف
-- =====================================================
