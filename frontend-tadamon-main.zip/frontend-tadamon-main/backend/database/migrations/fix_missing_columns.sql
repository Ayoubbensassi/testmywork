-- =====================================================
-- FIX MISSING COLUMNS
-- Run this if you get errors about missing columns
-- =====================================================

-- Add missing columns to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS verification_token VARCHAR(255),
ADD COLUMN IF NOT EXISTS verification_expires DATETIME,
ADD COLUMN IF NOT EXISTS reset_token VARCHAR(255),
ADD COLUMN IF NOT EXISTS reset_expires DATETIME;

-- Add missing columns to worker_profiles table
ALTER TABLE worker_profiles 
ADD COLUMN IF NOT EXISTS is_labeled BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS labeled_by INT,
ADD COLUMN IF NOT EXISTS labeled_at DATETIME,
ADD COLUMN IF NOT EXISTS average_rating DECIMAL(3, 2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_missions INT DEFAULT 0;

-- Add missing columns to establishment_profiles table
ALTER TABLE establishment_profiles 
ADD COLUMN IF NOT EXISTS average_rating DECIMAL(3, 2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_missions INT DEFAULT 0;

-- Now create the indexes (ignore errors if they already exist)
CREATE INDEX idx_worker_labeled ON worker_profiles(is_labeled);

-- Verify
SELECT 'Migration completed!' as status;
