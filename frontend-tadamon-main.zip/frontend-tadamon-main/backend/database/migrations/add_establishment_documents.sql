-- Migration: Add document fields to establishment_profiles
-- Run this to add verification document support for establishments

ALTER TABLE establishment_profiles
ADD COLUMN ice_document VARCHAR(255) AFTER logo,
ADD COLUMN registration_document VARCHAR(255) AFTER ice_document,
ADD COLUMN authorization_document VARCHAR(255) AFTER registration_document,
ADD COLUMN rejection_reason TEXT AFTER is_verified;

-- ice_document: ICE certificate / Certificat d'inscription au registre de commerce
-- registration_document: Business registration / Registre de commerce
-- authorization_document: Operating authorization / Autorisation d'exercice
