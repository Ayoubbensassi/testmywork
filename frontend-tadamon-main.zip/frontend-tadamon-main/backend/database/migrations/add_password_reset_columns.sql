-- Migration: Add password reset and email verification columns to users table
-- Run this if you already have the database created

ALTER TABLE users 
ADD COLUMN IF NOT EXISTS verification_token VARCHAR(255) AFTER is_verified,
ADD COLUMN IF NOT EXISTS verification_expires DATETIME AFTER verification_token,
ADD COLUMN IF NOT EXISTS reset_token VARCHAR(255) AFTER verification_expires,
ADD COLUMN IF NOT EXISTS reset_expires DATETIME AFTER reset_token;

-- Verify the changes
DESCRIBE users;
