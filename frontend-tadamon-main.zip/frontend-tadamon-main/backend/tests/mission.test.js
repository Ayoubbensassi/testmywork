const missionController = require('../src/controllers/missionController');
const Mission = require('../src/models/Mission');
const EstablishmentProfile = require('../src/models/EstablishmentProfile');

// Mock dependencies
jest.mock('../src/models/Mission');
jest.mock('../src/models/EstablishmentProfile');
jest.mock('../src/config/database', () => ({
    query: jest.fn(),
    getConnection: jest.fn().mockResolvedValue({ release: jest.fn() })
}));

describe('MissionController', () => {
    let req, res, next;

    beforeEach(() => {
        req = {
            user: { id: 1 },
            body: {},
            query: {},
            params: {}
        };
        res = {
            json: jest.fn(),
            status: jest.fn().mockReturnThis()
        };
        next = jest.fn();
        jest.clearAllMocks();
    });

    describe('createMission', () => {
        it('should create a mission successfully', async () => {
            // Mock profile found
            EstablishmentProfile.findByUserId.mockResolvedValue({ id: 100 });
            // Mock mission created
            Mission.create.mockResolvedValue(555);

            req.body = {
                title: 'Mission Test',
                description: 'Desc',
                mission_type: 'ponctuelle',
                start_date: '2025-01-01',
                region_id: 1,
                city_id: 1
            };

            await missionController.createMission(req, res, next);

            expect(EstablishmentProfile.findByUserId).toHaveBeenCalledWith(1);
            expect(Mission.create).toHaveBeenCalledWith(100, req.body);
            expect(res.status).toHaveBeenCalledWith(201);
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                status: 'success',
                data: { missionId: 555 }
            }));
        });

        it('should return 404 if establishment profile not found', async () => {
            EstablishmentProfile.findByUserId.mockResolvedValue(null);

            await missionController.createMission(req, res, next);

            expect(res.status).toHaveBeenCalledWith(404);
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                status: 'error',
                message: 'Profil établissement non trouvé'
            }));
        });

        it('should call next(error) if database fails', async () => {
            EstablishmentProfile.findByUserId.mockRejectedValue(new Error('DB Error'));

            await missionController.createMission(req, res, next);

            expect(next).toHaveBeenCalledWith(expect.any(Error));
        });
    });

    describe('getAllMissions', () => {
        it('should return missions with pagination', async () => {
            const mockMissions = [{ id: 1, title: 'Mission 1' }];
            Mission.findAll.mockResolvedValue(mockMissions);
            Mission.count.mockResolvedValue(1);

            await missionController.getAllMissions(req, res, next);

            expect(Mission.findAll).toHaveBeenCalledWith(expect.objectContaining({
                limit: 20,
                offset: 0
            }));
            expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
                status: 'success',
                data: expect.objectContaining({
                    missions: mockMissions,
                    pagination: expect.any(Object)
                })
            }));
        });
    });
});
