module.exports = {
    testEnvironment: 'node',
    verbose: true,
    silent: false,
    testMatch: ['**/tests/**/*.test.js']
};
