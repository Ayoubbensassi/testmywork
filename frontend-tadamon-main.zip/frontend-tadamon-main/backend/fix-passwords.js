// Run this script to fix test account passwords
// Usage: node fix-passwords.js

const bcrypt = require('bcrypt');
const mysql = require('mysql2/promise');
require('dotenv').config({ path: '.env.local' });
require('dotenv').config();

async function fixPasswords() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
  });

  try {
    // Generate proper hashes
    const adminHash = await bcrypt.hash('Admin123!', 10);
    const testHash = await bcrypt.hash('Test123!', 10);

    // Update admin
    await pool.execute(
      'UPDATE users SET password = ? WHERE email = ?',
      [adminHash, 'admin@lkhedma.ma']
    );
    console.log('✓ Updated admin@lkhedma.ma with password: Admin123!');

    // Update establishment
    await pool.execute(
      'UPDATE users SET password = ? WHERE email = ?',
      [testHash, 'etablissement@test.ma']
    );
    console.log('✓ Updated etablissement@test.ma with password: Test123!');

    // Update worker
    await pool.execute(
      'UPDATE users SET password = ? WHERE email = ?',
      [testHash, 'travailleur@test.ma']
    );
    console.log('✓ Updated travailleur@test.ma with password: Test123!');

    console.log('\n✅ All passwords fixed! You can now login.');
  } catch (error) {
    console.error('Error:', error.message);
  } finally {
    await pool.end();
  }
}

fixPasswords();
