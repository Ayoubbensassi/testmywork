Développement Full-Stack - Projet 2025
Réseau de travailleurs sociaux indépendants 

1-	Contexte :
Ce projet consiste à concevoir et développer une plateforme numérique innovante dédiée à la création d’un réseau sélectif de travailleurs sociaux indépendants, et qui a pour mission de connecter des établissements en quête de renforts avec des professionnels hautement qualifiés (techniciens, ingénieurs, chefs de projet, …).
Plus qu’une simple mise en relation, cette solution vise à garantir une qualité de service supérieure grâce à un système de labellisation rigoureux basé sur les diplômes et l’expérience. 
L’objectif final est de proposer des renforts sur mesure, limitant la multiplication des intervenants, en vue de créer un lien avec le public accueilli, lien nécessaire à un accompagnement de qualité.

2-	Objectifs pédagogiques :
Ce projet permet de valider les compétences suivantes :
•	Front-end (React) : Gestion de formulaires, tableaux de bord différenciés, et gestion d'état. 
•	Back-end (Node.js/Express) : Architecture REST, authentification JWT, et gestion des rôles (Admin, Travailleur, Établissement).
•	Base de données (SQL) : Modélisation de relations et requêtes de filtrage avancées.

3-	Parcours Utilisateurs (User Stories) :
A. Le Travailleur Social (Indépendant)
•	Créer un profil enrichi : diplômes (upload de PDF), expériences, spécialités (technicien spécialisé, ingénieur, chef de projet, etc.).
•	Indiquer ses disponibilités via un calendrier.
•	Postuler à des missions proposées par des établissements.
B. L'Établissement (Client)
•	Publier des offres de mission précisant le besoin (type de public, durée, urgence).
•	Rechercher des professionnels via des filtres (compétences, labels, proximité).
•	Valider une prestation et noter/commenter l'intervention.
C. L'Administrateur (Le Réseau)
•	Modérer et "labelliser" les nouveaux inscrits (vérification des diplômes).
•	Avoir une vue d'ensemble sur les mises en relation en cours.
4-	Spécifications fonctionnelles:
Elles décrivent les actions que les utilisateurs peuvent effectuer sur la plateforme.
A. Gestion des comptes et profils
•	Authentification sécurisée : Inscription et connexion via email/mot de passe avec gestion des rôles (Professionnel, Établissement, Administrateur).
•	Profil Travailleur enrichi : Saisie des expériences, téléchargement de diplômes (PDF), sélection de domaines d'intervention (handicap, protection de l'enfance, etc.).
•	Validation : Un administrateur doit pouvoir approuver un profil après vérification des pièces justificatives.
B. Mise en relation (Matching)
•	Dépôt d'offres : Les établissements publient des missions (titre, dates, descriptif, compétences requises).
•	Moteur de recherche : Filtrage des professionnels par spécialités, années d'expérience et statut "Label Réseau".
•	Candidature : Les travailleurs peuvent postuler aux missions. L'établissement reçoit une notification (ou email) et peut accepter/refuser.
C. Suivi et Qualité
•	Tableau de bord : Vue d'ensemble des missions en cours, à venir et terminées pour chaque utilisateur.
•	Évaluation : Système de feedback après mission pour garantir le maintien des standards de qualité du réseau.

5-	Spécifications non fonctionnelles :
Elles définissent les exigences techniques et de performance du système.
A. Sécurité et Conformité
•	RGPD : Les données des travailleurs sociaux (données personnelles et diplômes) doivent être chiffrées et stockées de manière sécurisée.
•	Hachage des mots de passe : Utilisation d'algorithmes robustes (type bcrypt).
•	Protection des routes : Utilisation de JWT (JSON Web Tokens) pour sécuriser les appels API selon le rôle de l'utilisateur.
B. Performance et Disponibilité
•	Réactivité de l’interface : L’application doit garantir une expérience utilisateur fluide (SPA - Single Page Application). Le temps de réponse de l’API pour les requêtes de recherche et de filtrage doit être inférieur à 500ms, avec une mise en cache côté client (ex: React Query ou SWR) pour limiter les appels redondants
•	Scalabilité : Le code doit être modularisé (Architecture MVC ou Clean Architecture) pour permettre l'ajout futur de fonctionnalités (ex: messagerie temps réel).
C. Utilisabilité (UX/UI)
•	Responsive Design : L'application doit être parfaitement utilisable sur tablette et ordinateur (outils privilégiés des cadres en établissement).
•	Accessibilité : Respect des contrastes et des standards de navigation pour un confort de lecture optimal.

Bon courage !

¬¬¬¬¬
 

