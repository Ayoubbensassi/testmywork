import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { applicationsAPI } from '../src/api';
import { showSuccess, showError } from '../components/common/Toast';

// Query key factory
export const applicationKeys = {
  all: ['applications'] as const,
  my: () => [...applicationKeys.all, 'my'] as const,
  received: () => [...applicationKeys.all, 'received'] as const,
  mission: (missionId: number) => [...applicationKeys.all, 'mission', missionId] as const,
};

// Get my applications (worker)
export const useMyApplications = () => {
  return useQuery({
    queryKey: applicationKeys.my(),
    queryFn: () => applicationsAPI.getMyApplications(),
    select: (data) => data.applications || data.data?.applications || [],
  });
};

// Get received applications (establishment)
export const useReceivedApplications = () => {
  return useQuery({
    queryKey: applicationKeys.received(),
    queryFn: () => applicationsAPI.getReceivedApplications(),
    select: (data) => data.applications || data.data?.applications || [],
  });
};

// Get applications for a mission
export const useMissionApplications = (missionId: number | null) => {
  return useQuery({
    queryKey: applicationKeys.mission(missionId!),
    queryFn: () => applicationsAPI.getMissionApplications(missionId!),
    enabled: !!missionId,
    select: (data) => data.applications || data.data?.applications || [],
  });
};

// Apply to mission mutation
export const useApplyToMission = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: any) => applicationsAPI.apply(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: applicationKeys.my() });
      showSuccess('Candidature envoyée!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de la candidature');
    },
  });
};

// Accept application mutation
export const useAcceptApplication = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (id: number) => applicationsAPI.accept(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: applicationKeys.received() });
      queryClient.invalidateQueries({ queryKey: applicationKeys.all });
      showSuccess('Candidature acceptée!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de l\'acceptation');
    },
  });
};

// Reject application mutation
export const useRejectApplication = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (id: number) => applicationsAPI.reject(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: applicationKeys.received() });
      queryClient.invalidateQueries({ queryKey: applicationKeys.all });
      showSuccess('Candidature refusée');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors du rejet');
    },
  });
};

// Withdraw application mutation
export const useWithdrawApplication = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (id: number) => applicationsAPI.withdraw(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: applicationKeys.my() });
      showSuccess('Candidature retirée');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors du retrait');
    },
  });
};

