import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { missionsAPI } from '../src/api';
import { showSuccess, showError } from '../components/common/Toast';

// Query key factory
export const missionKeys = {
  all: ['missions'] as const,
  lists: () => [...missionKeys.all, 'list'] as const,
  list: (filters?: any) => [...missionKeys.lists(), filters] as const,
  details: () => [...missionKeys.all, 'detail'] as const,
  detail: (id: number) => [...missionKeys.details(), id] as const,
  my: () => [...missionKeys.all, 'my'] as const,
};

// Get all missions
export const useMissions = (params?: any) => {
  return useQuery({
    queryKey: missionKeys.list(params),
    queryFn: () => missionsAPI.getAll(params),
    select: (data) => data.missions || data.data?.missions || [],
  });
};

// Get mission by ID
export const useMission = (id: number | null) => {
  return useQuery({
    queryKey: missionKeys.detail(id!),
    queryFn: () => missionsAPI.getById(id!),
    enabled: !!id,
    select: (data) => data.mission || data.data?.mission,
  });
};

// Get my missions (establishment)
export const useMyMissions = () => {
  return useQuery({
    queryKey: missionKeys.my(),
    queryFn: () => missionsAPI.getMyMissions(),
    select: (data) => data.missions || data.data?.missions || [],
  });
};

// Search missions
export const useSearchMissions = (params?: any) => {
  return useQuery({
    queryKey: [...missionKeys.all, 'search', params],
    queryFn: () => missionsAPI.search(params),
    enabled: !!params && (!!params.q || !!params.region_id || !!params.mission_type),
    select: (data) => data.missions || data.data?.missions || [],
  });
};

// Create mission mutation
export const useCreateMission = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: any) => missionsAPI.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: missionKeys.my() });
      queryClient.invalidateQueries({ queryKey: missionKeys.lists() });
      showSuccess('Mission créée avec succès!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de la création');
    },
  });
};

// Update mission mutation
export const useUpdateMission = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => missionsAPI.update(id, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: missionKeys.detail(variables.id) });
      queryClient.invalidateQueries({ queryKey: missionKeys.my() });
      showSuccess('Mission mise à jour!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de la mise à jour');
    },
  });
};

// Delete mission mutation
export const useDeleteMission = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (id: number) => missionsAPI.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: missionKeys.my() });
      queryClient.invalidateQueries({ queryKey: missionKeys.lists() });
      showSuccess('Mission supprimée!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de la suppression');
    },
  });
};

