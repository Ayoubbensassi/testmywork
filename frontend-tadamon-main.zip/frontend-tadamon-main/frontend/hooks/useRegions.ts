import { useQuery } from '@tanstack/react-query';
import { regionsAPI } from '../src/api';

// Query key factory
export const regionKeys = {
  all: ['regions'] as const,
  regions: () => [...regionKeys.all, 'list'] as const,
  cities: (regionId: number) => [...regionKeys.all, 'cities', regionId] as const,
  allCities: () => [...regionKeys.all, 'cities', 'all'] as const,
  specialties: () => [...regionKeys.all, 'specialties'] as const,
};

// Get all regions
export const useRegions = () => {
  return useQuery({
    queryKey: regionKeys.regions(),
    queryFn: () => regionsAPI.getAll(),
    select: (data) => data.regions || data.data?.regions || [],
    staleTime: 30 * 60 * 1000, // 30 minutes - regions don't change often
  });
};

// Get cities by region
export const useCitiesByRegion = (regionId: number | null) => {
  return useQuery({
    queryKey: regionKeys.cities(regionId!),
    queryFn: () => regionsAPI.getCities(regionId!),
    enabled: !!regionId,
    select: (data) => data.cities || data.data?.cities || [],
    staleTime: 30 * 60 * 1000,
  });
};

// Get all cities
export const useAllCities = () => {
  return useQuery({
    queryKey: regionKeys.allCities(),
    queryFn: () => regionsAPI.getAllCities(),
    select: (data) => data.cities || data.data?.cities || [],
    staleTime: 30 * 60 * 1000,
  });
};

// Get specialties
export const useSpecialties = () => {
  return useQuery({
    queryKey: regionKeys.specialties(),
    queryFn: () => regionsAPI.getSpecialties(),
    select: (data) => data.specialties || data.data?.specialties || [],
    staleTime: 30 * 60 * 1000,
  });
};

