import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { workerAPI } from '../src/api';
import { showSuccess, showError } from '../components/common/Toast';

// Query key factory
export const workerKeys = {
  all: ['workers'] as const,
  profile: () => [...workerKeys.all, 'profile'] as const,
  public: (id: number) => [...workerKeys.all, 'public', id] as const,
  search: (filters?: any) => [...workerKeys.all, 'search', filters] as const,
};

// Get worker profile
export const useWorkerProfile = () => {
  return useQuery({
    queryKey: workerKeys.profile(),
    queryFn: () => workerAPI.getMyProfile(),
    select: (data) => data.profile || data.data?.profile,
  });
};

// Get public worker profile
export const usePublicWorkerProfile = (id: number | null) => {
  return useQuery({
    queryKey: workerKeys.public(id!),
    queryFn: () => workerAPI.getPublicProfile(id!),
    enabled: !!id,
    select: (data) => data.data?.profile || data.profile,
  });
};

// Search workers
export const useSearchWorkers = (filters?: any) => {
  return useQuery({
    queryKey: workerKeys.search(filters),
    queryFn: () => workerAPI.searchWorkers(filters),
    enabled: !!filters,
    select: (data) => data.data?.workers || data.workers || [],
  });
};

// Create worker profile mutation
export const useCreateWorkerProfile = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: any) => workerAPI.createProfile(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: workerKeys.profile() });
      showSuccess('Profil créé avec succès!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de la création');
    },
  });
};

// Update worker profile mutation
export const useUpdateWorkerProfile = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: (data: any) => workerAPI.updateProfile(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: workerKeys.profile() });
      showSuccess('Profil mis à jour!');
    },
    onError: (error: any) => {
      showError(error.response?.data?.message || 'Erreur lors de la mise à jour');
    },
  });
};

