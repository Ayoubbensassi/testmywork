
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const API_BASE_URL = 'http://localhost:5000/api';

const Signup: React.FC = () => {
    const { signup, error: authError, clearError } = useAuth();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const [role, setRole] = useState<'worker' | 'institution' | null>(null);
    const [step, setStep] = useState(0); // 0: Role, 1: Form
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [googleEnabled, setGoogleEnabled] = useState(false);
    const [localError, setLocalError] = useState<string | null>(null);
    
    // Combine auth error and local error
    const error = localError || authError;

    // Check if Google OAuth is configured
    useEffect(() => {
        fetch(`${API_BASE_URL}/auth/google/status`)
            .then(res => res.json())
            .then(data => setGoogleEnabled(data.data?.configured || false))
            .catch(() => setGoogleEnabled(false));

        // Handle token from Google OAuth callback
        const token = searchParams.get('token');
        if (token) {
            localStorage.setItem('token', token);
            window.location.href = '/#/';
        }
    }, [searchParams]);

    const handleRoleSelect = (selectedRole: 'worker' | 'institution') => {
        setRole(selectedRole);
        setStep(1);
        clearError();
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setLocalError(null);
        clearError();
        
        const actualRole = role === 'worker' ? 'worker' : 'establishment';
        const success = await signup({
            email,
            password,
            role: actualRole,
        });
        
        setIsLoading(false);
        if (success) {
            // Redirect to onboarding based on role
            navigate(actualRole === 'worker' ? '/onboarding/worker' : '/onboarding/establishment');
        } else {
            // Capture the auth error locally so it persists
            setLocalError(authError || "Échec de l'inscription. Veuillez réessayer.");
        }
    };

    const handleGoogleLogin = (selectedRole?: 'worker' | 'institution') => {
        if (googleEnabled) {
            const actualRole = selectedRole === 'institution' ? 'establishment' : 'worker';
            window.location.href = `${API_BASE_URL}/auth/google?role=${actualRole}`;
        } else {
            alert('🚧 Connexion Google\n\nGoogle OAuth n\'est pas configuré sur ce serveur.\n\nPour l\'activer, ajoutez GOOGLE_CLIENT_ID et GOOGLE_CLIENT_SECRET dans le fichier .env.local du backend.');
        }
    };

    return (
        <div className="h-screen w-full flex flex-col lg:flex-row bg-white overflow-hidden relative">
            {/* Back Button */}
            <Link
                to="/"
                className="absolute top-6 left-6 z-50 w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors border border-slate-200"
                title="Retour à l'accueil"
            >
                <span className="material-symbols-outlined">arrow_back</span>
            </Link>

            {/* LEFT COLUMN: FORM */}
            <div className="w-full lg:w-1/2 h-full flex flex-col justify-center items-center p-6 lg:p-8 relative bg-white z-10">
                <div className="w-full max-w-[460px]">
                    <div className="text-center mb-6">
                        <h2 className="text-3xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#2563EB] to-[#db2777] uppercase tracking-tighter mb-6">
                            TADAMON
                        </h2>

                        {/* Navigation Toggle - Matching Design */}
                        <div className="bg-slate-100 p-1.5 rounded-full inline-flex w-full max-w-[320px] relative">
                            {/* Active Tab Background (Right for Inscription) */}
                            <div className="absolute top-1.5 bottom-1.5 right-1.5 w-[calc(50%-6px)] bg-white rounded-full shadow-sm z-0 transition-all duration-300"></div>

                            <Link
                                to="/login"
                                className="relative z-10 w-1/2 py-2.5 text-sm font-bold text-slate-500 hover:text-slate-700 transition-colors text-center"
                            >
                                Connexion
                            </Link>
                            <span className="relative z-10 w-1/2 py-2.5 text-sm font-bold text-[#2563EB] cursor-default text-center">
                                Inscription
                            </span>
                        </div>
                    </div>

                    <AnimatePresence mode="wait">
                        {step === 0 ? (
                            <motion.div
                                key="step0"
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 10 }}
                                transition={{ duration: 0.4 }}
                                className="space-y-6"
                            >
                                <div className="text-center mb-6">
                                    <h3 className="text-2xl font-bold text-slate-900 mb-2">Choisissez votre profil</h3>
                                    <p className="text-slate-500 text-sm">Sélectionnez le type de compte pour commencer</p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <button
                                        onClick={() => handleRoleSelect('worker')}
                                        className="group p-6 rounded-[2rem] border-2 border-slate-100 bg-white hover:border-blue-500 hover:bg-blue-50/10 transition-all flex flex-col items-center text-center gap-4 relative overflow-hidden"
                                    >
                                        <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform z-10 mb-1">
                                            <span className="material-symbols-outlined text-3xl">person</span>
                                        </div>
                                        <div className="z-10">
                                            <div className="font-bold text-slate-900 group-hover:text-blue-700 text-base mb-1">Travailleur social</div>
                                            <div className="text-[11px] text-slate-500 font-medium leading-tight">Candidats chercheurs d'emploi</div>
                                        </div>
                                    </button>

                                    <button
                                        onClick={() => handleRoleSelect('institution')}
                                        className="group p-6 rounded-[2rem] border-2 border-slate-100 bg-white hover:border-purple-500 hover:bg-purple-50/10 transition-all flex flex-col items-center text-center gap-4 relative overflow-hidden"
                                    >
                                        <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 group-hover:scale-110 transition-transform z-10 mb-1">
                                            <span className="material-symbols-outlined text-3xl">domain</span>
                                        </div>
                                        <div className="z-10">
                                            <div className="font-bold text-slate-900 group-hover:text-purple-700 text-base mb-1">Établissement</div>
                                            <div className="text-[11px] text-slate-500 font-medium leading-tight">Employeurs et organismes</div>
                                        </div>
                                    </button>
                                </div>

                                <div className="relative py-4">
                                    <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                                    <div className="relative flex justify-center text-[10px] uppercase"><span className="bg-white px-3 text-slate-400 font-bold tracking-widest">ou</span></div>
                                </div>

                                <button
                                    type="button"
                                    onClick={() => handleGoogleLogin()}
                                    className="w-full py-3.5 border border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-700 font-bold rounded-2xl transition-all flex items-center justify-center gap-3"
                                >
                                    <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5" alt="Google" />
                                    Continuer avec Google
                                </button>
                            </motion.div>
                        ) : (
                            <motion.form
                                key="step1"
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                transition={{ duration: 0.4 }}
                                onSubmit={handleSubmit}
                                className="space-y-4"
                            >
                                <div className="flex items-center mb-6">
                                    <button
                                        type="button"
                                        onClick={() => { setStep(0); setLocalError(null); clearError(); }}
                                        className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors mr-3"
                                    >
                                        <span className="material-symbols-outlined text-xl">arrow_back</span>
                                    </button>
                                    <div>
                                        <h3 className="text-lg font-bold text-slate-900 leading-tight">
                                            Compte {role === 'worker' ? 'Expert' : 'Structure'}
                                        </h3>
                                        <p className="text-xs text-slate-500">Finalisez votre inscription</p>
                                    </div>
                                </div>

                                {error && (
                                    <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3">
                                        <span className="material-symbols-outlined text-red-500 text-xl flex-shrink-0">error</span>
                                        <div className="flex-1">
                                            <p className="text-red-700 text-sm font-semibold mb-1">Échec de l'inscription</p>
                                            <p className="text-red-600 text-sm">{error}</p>
                                        </div>
                                    </div>
                                )}

                                <div className="space-y-1.5">
                                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Email professionnel</label>
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">mail</span>
                                        <input
                                            type="email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none"
                                            placeholder="email@exemple.com"
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="space-y-1.5">
                                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Mot de passe</label>
                                    <div className="relative group">
                                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">lock</span>
                                        <input
                                            type="password"
                                            value={password}
                                            onChange={(e) => setPassword(e.target.value)}
                                            className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none"
                                            placeholder="••••••••"
                                            required
                                        />
                                    </div>
                                </div>

                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full py-3.5 bg-gradient-to-r from-[#2563EB] to-[#3B82F6] hover:from-[#1d4ed8] hover:to-[#2563eb] text-white font-bold rounded-2xl transition-all mt-4 flex items-center justify-center gap-2 shadow-lg shadow-blue-500/30 transform active:scale-[0.98]"
                                >
                                    {isLoading ? (
                                        <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                    ) : (
                                        'Créer mon compte'
                                    )}
                                </button>
                            </motion.form>
                        )}
                    </AnimatePresence>

                    <div className="mt-6 text-center">
                        <p className="text-slate-400 text-[11px] font-medium">
                            Rejoignez plus de 10 000 professionnels sur TADAMON.
                        </p>
                    </div>
                </div>
            </div>

            {/* RIGHT COLUMN: VISUALS */}
            <div className="hidden lg:flex w-1/2 h-full bg-slate-900 relative flex-col justify-end pb-20 overflow-hidden">

                {/* Background Image with Slow Zoom */}
                <div className="absolute inset-0 z-0">
                    <motion.div
                        animate={{ scale: [1, 1.05] }}
                        transition={{ duration: 20, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
                        className="w-full h-full"
                    >
                        <img
                            src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=1500"
                            alt="Team Meeting"
                            className="w-full h-full object-cover opacity-50"
                        />
                    </motion.div>
                    <div className="absolute inset-0 bg-gradient-to-tl from-[#0F172A] via-[#1E3A8A]/60 to-[#0F172A]/80"></div>
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-soft-light"></div>
                </div>

                {/* Content anchored at bottom */}
                <div className="relative z-20 text-center px-12 max-w-2xl mx-auto mt-auto mb-16">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
                    >
                        <h3 className="text-4xl md:text-5xl font-bold font-display text-white mb-6 leading-tight drop-shadow-xl">
                            Votre avenir commence <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-white to-emerald-400">
                                aujourd'hui
                            </span>
                        </h3>

                        <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-white/10 border border-white/10 backdrop-blur-md mt-6 hover:bg-white/20 transition-colors">
                            <div className="flex -space-x-2">
                                {[1, 2, 3, 4].map(i => (
                                    <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-900 bg-slate-700 overflow-hidden">
                                        <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="" className="w-full h-full object-cover" />
                                    </div>
                                ))}
                            </div>
                            <span className="text-white text-xs font-bold">+500 inscrits cette semaine</span>
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};

export default Signup;
