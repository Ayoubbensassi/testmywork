import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import { contactAPI } from '../src/api';

const Contact: React.FC = () => {
  const { openLoginModal } = useAuth();
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    userType: '' as 'worker' | 'establishment' | 'other' | '',
    subject: '',
    message: ''
  });

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.userType || !formData.subject || !formData.message) {
      setSubmitError('Veuillez remplir tous les champs');
      return;
    }
    
    setIsSubmitting(true);
    setSubmitError(null);
    
    try {
      await contactAPI.submit({
        name: formData.name,
        email: formData.email,
        userType: formData.userType as 'worker' | 'establishment' | 'other',
        subject: formData.subject,
        message: formData.message
      });
      setSubmitSuccess(true);
      setFormData({ name: '', email: '', userType: '', subject: '', message: '' });
    } catch (err: any) {
      setSubmitError(err.message || 'Erreur lors de l\'envoi du message');
    } finally {
      setIsSubmitting(false);
    }
  };

  const faqs = [
    { question: "Comment créer un compte ?", answer: "Cliquez sur 'Inscription', choisissez votre profil (travailleur ou établissement), et suivez les étapes de validation. La validation prend moins de 24h." },
    { question: "Qu'est-ce que le Label Réseau ?", answer: "C'est notre certification qualité, attribuée après vérification rigoureuse de vos diplômes et expériences professionnelles." },
    { question: "Combien coûte le service ?", answer: "L'inscription est gratuite. Une commission de 10% s'applique uniquement sur les missions réalisées et payées." },
    { question: "Puis-je modifier mon profil après inscription ?", answer: "Oui, vous pouvez mettre à jour vos disponibilités, tarifs et documents à tout moment depuis votre espace personnel." }
  ];

  return (
    <div className="bg-slate-50 min-h-screen font-sans">
      {/* Premium Hero Section */}
      <section className="relative pt-40 pb-48 lg:pt-48 lg:pb-64 overflow-hidden">
         {/* Background with image */}
         <div className="absolute inset-0">
           <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=2069')` }} />
           <div className="absolute inset-0 bg-gradient-to-br from-slate-950/95 via-slate-900/90 to-slate-950/95" />
           <div className="absolute inset-0 bg-gradient-to-tr from-blue-950/40 via-transparent to-indigo-950/30" />
         </div>
         
         {/* Animated orbs */}
         <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-cyan-500 rounded-full blur-[150px]" />
         <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.08, 0.15, 0.08] }} transition={{ duration: 10, repeat: Infinity, delay: 2 }} className="absolute bottom-1/4 right-1/4 w-[350px] h-[350px] bg-indigo-500 rounded-full blur-[150px]" />
         
         {/* Grid pattern */}
         <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px]" />
         
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
               className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/[0.03] border border-white/10 backdrop-blur-xl mb-8">
               <span className="relative flex h-2 w-2"><span className="animate-ping absolute h-full w-full rounded-full bg-emerald-400 opacity-75"></span><span className="relative rounded-full h-2 w-2 bg-emerald-400"></span></span>
               <span className="text-white/70 text-sm font-medium">Réponse sous 24h garantie</span>
            </motion.div>
            
            <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
               className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight tracking-tight">
               Parlons de votre <span className="italic text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">projet</span>
            </motion.h1>
            
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.2 }}
               className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-10">
               Une question ? Un besoin spécifique ? Notre équipe d'experts est là pour vous accompagner.
            </motion.p>

            {/* Trust badges */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="flex flex-wrap justify-center gap-4">
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
                <span className="material-symbols-outlined text-amber-400 text-lg">star</span>
                <span className="text-white/60 text-sm">Support 5 étoiles</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
                <span className="material-symbols-outlined text-emerald-400 text-lg">verified</span>
                <span className="text-white/60 text-sm">Équipe certifiée</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10">
                <span className="material-symbols-outlined text-blue-400 text-lg">schedule</span>
                <span className="text-white/60 text-sm">Lun-Ven 9h-18h</span>
              </div>
            </motion.div>
         </div>
         
         {/* Wave divider */}
         <div className="absolute bottom-0 left-0 w-full overflow-hidden z-20">
           <svg className="relative block w-full h-[60px] md:h-[80px]" viewBox="0 0 1440 120" preserveAspectRatio="none">
             <path d="M0,64 C360,100 720,120 1080,80 C1260,60 1380,40 1440,64 L1440,120 L0,120 Z" fill="#f8fafc" />
           </svg>
         </div>
      </section>

      <section className="relative z-20 -mt-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                  { title: "Email", desc: "Notre équipe répond sous 24h", val: "contact@tadamon.ma", icon: "mail", action: "mailto:contact@tadamon.ma", color: "text-blue-600", bg: "bg-blue-50" },
                  { title: "Téléphone", desc: "Du Lundi au Vendredi, 9h-18h", val: "+212 5 22 00 00 00", icon: "call", action: "tel:+212522000000", color: "text-indigo-600", bg: "bg-indigo-50" },
                  { title: "Bureau", desc: "Siège social", val: "Casablanca, Maroc", icon: "location_on", action: "#", color: "text-purple-600", bg: "bg-purple-50" }
              ].map((card, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 + (i * 0.1) }}
                     className="bg-white rounded-[2.5rem] p-8 text-center shadow-[0_20px_40px_-5px_rgba(0,0,0,0.1)] border border-slate-100 hover:-translate-y-2 transition-transform duration-500 group relative overflow-hidden">
                      <div className="relative z-10">
                          <div className={`w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-6 transition-all duration-300 shadow-sm group-hover:scale-110 ${card.bg} ${card.color} group-hover:bg-slate-900 group-hover:text-white`}>
                              <span className="material-symbols-outlined text-3xl">{card.icon}</span>
                          </div>
                          <h3 className="text-xl font-bold text-slate-900 mb-2 font-display">{card.title}</h3>
                          <p className="text-slate-500 text-xs font-bold uppercase tracking-wide mb-4">{card.desc}</p>
                          <a href={card.action} className={`text-base font-bold hover:underline transition-colors ${card.color}`}>{card.val}</a>
                      </div>
                  </motion.div>
              ))}
          </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.4 }} className="lg:col-span-7">
                  <div className="bg-white rounded-[2.5rem] p-8 md:p-12 shadow-sm border border-slate-100 relative overflow-hidden group">
                      <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>
                      <div className="relative z-10">
                          <div className="flex items-center gap-4 mb-10">
                              <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 shadow-sm border border-blue-100">
                                <span className="material-symbols-outlined text-2xl">chat_bubble_outline</span>
                              </div>
                              <h2 className="text-3xl font-bold font-display text-slate-900">Envoyez-nous un message</h2>
                          </div>

                          {submitSuccess ? (
                            <div className="text-center py-12">
                              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                <span className="material-symbols-outlined text-4xl text-green-600">check_circle</span>
                              </div>
                              <h3 className="text-2xl font-bold text-slate-900 mb-2">Message envoyé !</h3>
                              <p className="text-slate-500 mb-6">Nous vous répondrons dans les plus brefs délais.</p>
                              <button onClick={() => setSubmitSuccess(false)} className="px-6 py-3 bg-blue-50 text-blue-600 font-bold rounded-xl hover:bg-blue-100 transition-colors cursor-pointer">
                                Envoyer un autre message
                              </button>
                            </div>
                          ) : (
                          <form onSubmit={handleSubmit} className="space-y-8">
                              {submitError && (
                                <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm font-medium">{submitError}</div>
                              )}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                  <div className="space-y-2 group/input">
                                      <label className="text-xs font-bold text-slate-900 uppercase tracking-wide ml-1">Nom complet</label>
                                      <input type="text" name="name" value={formData.name} onChange={handleInputChange} placeholder="Votre nom" 
                                        className="w-full bg-slate-50 border-transparent focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-2xl px-5 py-4 text-sm font-medium transition-all outline-none placeholder:text-slate-400" />
                                  </div>
                                  <div className="space-y-2 group/input">
                                      <label className="text-xs font-bold text-slate-900 uppercase tracking-wide ml-1">Email professionnel</label>
                                      <input type="email" name="email" value={formData.email} onChange={handleInputChange} placeholder="nom@entreprise.com" 
                                        className="w-full bg-slate-50 border-transparent focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-2xl px-5 py-4 text-sm font-medium transition-all outline-none placeholder:text-slate-400" />
                                  </div>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                  <div className="space-y-2 group/input">
                                      <label className="text-xs font-bold text-slate-900 uppercase tracking-wide ml-1">Vous êtes</label>
                                      <div className="relative">
                                          <select name="userType" value={formData.userType} onChange={handleInputChange}
                                            className="w-full bg-slate-50 border-transparent focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-2xl px-5 py-4 text-sm font-medium transition-all text-slate-600 appearance-none cursor-pointer outline-none">
                                              <option value="">Sélectionnez...</option>
                                              <option value="worker">Travailleur Social</option>
                                              <option value="establishment">Établissement</option>
                                              <option value="other">Autre</option>
                                          </select>
                                          <span className="material-symbols-outlined absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none text-xl">expand_more</span>
                                      </div>
                                  </div>
                                  <div className="space-y-2 group/input">
                                      <label className="text-xs font-bold text-slate-900 uppercase tracking-wide ml-1">Sujet</label>
                                      <input type="text" name="subject" value={formData.subject} onChange={handleInputChange} placeholder="Sujet de votre message" 
                                        className="w-full bg-slate-50 border-transparent focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-2xl px-5 py-4 text-sm font-medium transition-all outline-none placeholder:text-slate-400" />
                                  </div>
                              </div>
                              <div className="space-y-2 group/input">
                                  <label className="text-xs font-bold text-slate-900 uppercase tracking-wide ml-1">Message</label>
                                  <textarea name="message" value={formData.message} onChange={handleInputChange} rows={5} placeholder="Décrivez votre demande..." 
                                    className="w-full bg-slate-50 border-transparent focus:bg-white focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-2xl px-5 py-4 text-sm font-medium transition-all resize-none outline-none placeholder:text-slate-400"></textarea>
                              </div>
                              <button type="submit" disabled={isSubmitting}
                                className="w-full py-5 bg-[#2563EB] hover:bg-blue-700 text-white font-bold rounded-2xl shadow-xl shadow-blue-500/30 transition-all hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer">
                                  {isSubmitting ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <><span>Envoyer le message</span><span className="material-symbols-outlined">send</span></>}
                              </button>
                          </form>
                          )}
                      </div>
                  </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.5 }} className="lg:col-span-5 lg:pt-8">
                  <h2 className="text-3xl font-bold font-display text-slate-900 mb-4">Questions fréquentes</h2>
                  <p className="text-slate-500 mb-10 font-medium leading-relaxed">Trouvez rapidement des réponses aux questions les plus courantes.</p>
                  <div className="space-y-4">
                      {faqs.map((faq, idx) => (
                          <div key={idx} className={`bg-white border rounded-[1.5rem] transition-all duration-300 overflow-hidden ${openFaq === idx ? 'border-blue-200 shadow-lg ring-1 ring-blue-50' : 'border-slate-100 hover:border-blue-100 hover:bg-slate-50'}`}>
                              <button onClick={() => toggleFaq(idx)} className="w-full flex items-start gap-4 p-6 text-left group cursor-pointer">
                                  <div className={`w-6 h-6 rounded-full mt-0.5 shrink-0 transition-all flex items-center justify-center ${openFaq === idx ? 'bg-blue-600 text-white rotate-90' : 'bg-slate-100 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500'}`}>
                                      <span className="material-symbols-outlined text-sm font-bold">{openFaq === idx ? 'remove' : 'add'}</span>
                                  </div>
                                  <div className="flex-1">
                                      <span className={`text-base font-bold transition-colors ${openFaq === idx ? 'text-slate-900' : 'text-slate-700'}`}>{faq.question}</span>
                                      <div className={`grid transition-[grid-template-rows] duration-300 ease-out ${openFaq === idx ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}>
                                          <div className="overflow-hidden">
                                              <p className="pt-3 text-sm text-slate-500 leading-relaxed font-medium">{faq.answer}</p>
                                          </div>
                                      </div>
                                  </div>
                              </button>
                          </div>
                      ))}
                  </div>
                  <div className="mt-12 pt-8 border-t border-slate-100">
                      <p className="text-sm text-slate-500 mb-2 font-medium">Vous ne trouvez pas votre réponse ?</p>
                      <Link to="/process" className="inline-flex items-center gap-1 text-blue-600 font-bold text-sm hover:underline group cursor-pointer">
                          En savoir plus sur TADAMON
                          <span className="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                      </Link>
                  </div>
              </motion.div>
          </div>
      </section>

      <section className="py-32 bg-[#0B1120] relative overflow-hidden text-center">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1E293B] to-[#020617]"></div>
          <div className="max-w-4xl mx-auto px-4 relative z-10">
              <h2 className="text-4xl md:text-6xl font-bold font-display text-white mb-6 tracking-tight">Prêt à commencer ?</h2>
              <p className="text-slate-400 text-lg md:text-xl mb-12 max-w-2xl mx-auto font-medium">
                  Rejoignez notre réseau grandissant de professionnels qualifiés et d'établissements de confiance.
              </p>
              <button onClick={() => navigate('/signup')} className="px-10 py-5 bg-white text-slate-900 font-bold rounded-2xl hover:bg-blue-50 transition-all hover:scale-105 shadow-[0_0_40px_rgba(255,255,255,0.1)] flex items-center gap-3 mx-auto group cursor-pointer">
                  Créer un compte
                  <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">arrow_forward</span>
              </button>
          </div>
      </section>
    </div>
  );
};

export default Contact;
