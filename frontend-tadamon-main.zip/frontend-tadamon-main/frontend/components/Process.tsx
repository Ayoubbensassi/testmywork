
import React from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../AuthContext';

const Process: React.FC = () => {
  const { openLoginModal } = useAuth();

  const fadeInUp = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  const stagger = {
    visible: { transition: { staggerChildren: 0.1 } }
  };

  return (
    <div className="bg-slate-50 min-h-screen font-sans overflow-x-hidden">
      
      {/* 1. PREMIUM HERO SECTION */}
      <section className="relative pt-40 pb-32 overflow-hidden">
         {/* Background with image */}
         <div className="absolute inset-0">
           <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=2069')` }} />
           <div className="absolute inset-0 bg-gradient-to-br from-slate-950/95 via-slate-900/90 to-slate-950/95" />
           <div className="absolute inset-0 bg-gradient-to-tr from-blue-950/40 via-transparent to-indigo-950/30" />
         </div>
         
         {/* Animated orbs */}
         <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-cyan-500 rounded-full blur-[150px]" />
         <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.08, 0.15, 0.08] }} transition={{ duration: 10, repeat: Infinity, delay: 2 }} className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-500 rounded-full blur-[150px]" />
         
         {/* Grid pattern */}
         <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px]" />

         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div 
               initial="hidden" 
               whileInView="visible" 
               viewport={{ once: true }}
               className="text-center max-w-4xl mx-auto mb-20"
            >
                <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-300 text-[11px] font-bold uppercase tracking-[0.2em] mb-8 backdrop-blur-md">
                   <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                   Processus Certifié
                </motion.div>
                
                <motion.h1 variants={fadeInUp} className="text-4xl md:text-6xl lg:text-7xl font-bold font-display text-white mb-8 leading-[1.1] tracking-tight">
                   Le réseau de confiance du <br/>
                   <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-400 to-teal-400">secteur social</span>
                </motion.h1>
                
                <motion.p variants={fadeInUp} className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed font-medium">
                   TADAMON connecte les travailleurs sociaux qualifiés avec les établissements qui 
                   ont besoin de renforts. Chaque profil vérifié, chaque diplôme authentifié.
                </motion.p>
            </motion.div>

            {/* Premium Stats Card */}
            <motion.div 
               initial={{ opacity: 0, y: 40 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.8, delay: 0.2 }}
               className="relative"
            >
               <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-3xl blur-2xl -z-10 transform scale-95 translate-y-4"></div>
               <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-12 divide-y md:divide-y-0 md:divide-x divide-white/10">
                     {[
                        { val: "1,500+", label: "Professionnels", icon: "group" },
                        { val: "350+", label: "Établissements", icon: "domain" },
                        { val: "4,200+", label: "Missions", icon: "handshake" }
                     ].map((stat, i) => (
                        <div key={i} className="flex flex-col items-center justify-center text-center group/stat">
                           <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-4 text-blue-400 group-hover/stat:scale-110 group-hover/stat:bg-blue-500 group-hover/stat:text-white transition-all duration-300">
                              <span className="material-symbols-outlined text-2xl">{stat.icon}</span>
                           </div>
                           <span className="text-4xl md:text-5xl font-bold text-white mb-2 font-display tracking-tight">{stat.val}</span>
                           <span className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">{stat.label}</span>
                        </div>
                     ))}
                  </div>
               </div>
            </motion.div>
         </div>

         {/* Decorative Bottom Wave */}
         <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none z-20">
            <svg className="relative block w-full h-[80px] md:h-[120px]" preserveAspectRatio="none" viewBox="0 0 1200 120">
               <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z" className="fill-slate-50"></path>
            </svg>
         </div>
      </section>

      {/* 2. VISION SECTION */}
      <section className="py-32 bg-slate-50 relative overflow-hidden">
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
               
               {/* Left Text */}
               <motion.div 
                  initial="hidden" 
                  whileInView="visible" 
                  viewport={{ once: true }}
                  variants={stagger}
                  className="order-2 lg:order-1 relative z-10"
               >
                  <motion.div variants={fadeInUp} className="inline-block px-4 py-1.5 bg-blue-100 text-blue-700 rounded-full text-[10px] font-bold uppercase tracking-widest mb-8">
                     Notre Vision
                  </motion.div>
                  <motion.h2 variants={fadeInUp} className="text-3xl md:text-5xl lg:text-6xl font-bold font-display text-slate-900 mb-8 leading-[1.15]">
                     Le secteur social mérite une solution à la <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">hauteur de ses enjeux</span>.
                  </motion.h2>
                  <motion.div variants={fadeInUp} className="space-y-6 text-slate-600 text-lg leading-relaxed font-medium">
                     <p>
                        Nous avons créé TADAMON avec une conviction : la qualité ne doit pas être une option. 
                        Chaque professionnel de notre réseau est vérifié, chaque diplôme authentifié, chaque expérience confirmée.
                     </p>
                     <p>
                        Notre objectif est simple : créer un lien durable entre les professionnels et les établissements, 
                        un lien nécessaire à un accompagnement de qualité.
                     </p>
                  </motion.div>
                  
                  <motion.div variants={fadeInUp} className="mt-10 flex flex-wrap gap-4">
                     <div className="flex items-center gap-3 bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
                        <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                           <span className="material-symbols-outlined">security</span>
                        </div>
                        <div className="text-sm font-bold text-slate-900">100% Sécurisé</div>
                     </div>
                     <div className="flex items-center gap-3 bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
                        <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                           <span className="material-symbols-outlined">verified</span>
                        </div>
                        <div className="text-sm font-bold text-slate-900">Profils Vérifiés</div>
                     </div>
                  </motion.div>
               </motion.div>

               {/* Right Illustration */}
               <motion.div 
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1 }}
                  className="relative order-1 lg:order-2"
               >
                  {/* Decorative Blobs behind image */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[140%] bg-white rounded-full opacity-60 blur-3xl -z-10"></div>
                  <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-400/20 rounded-full blur-2xl animate-float"></div>
                  <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-teal-400/20 rounded-full blur-2xl animate-float animation-delay-2000"></div>
                  
                  {/* Image Container */}
                  <div className="relative mx-auto w-full max-w-md perspective-1000">
                      <motion.div 
                        whileHover={{ rotateY: 5, rotateX: 5 }}
                        className="bg-gradient-to-b from-white to-slate-50 p-3 rounded-[3rem] shadow-[0_40px_80px_-20px_rgba(0,0,0,0.1)] border border-white relative z-10"
                      >
                         <div className="rounded-[2.5rem] overflow-hidden aspect-[4/5] relative bg-slate-100">
                            <img 
                               src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800" 
                               alt="Professional woman" 
                               className="w-full h-full object-cover object-top mix-blend-multiply opacity-90 transition-transform duration-700 hover:scale-110" 
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
                         </div>
                         
                         {/* Floating Badge 1 */}
                         <motion.div 
                           initial={{ y: 20, opacity: 0 }}
                           whileInView={{ y: 0, opacity: 1 }}
                           transition={{ delay: 0.5 }}
                           className="absolute top-10 right-[-20px] bg-white/90 backdrop-blur-md p-3 rounded-2xl shadow-lg border border-white flex items-center gap-3"
                        >
                             <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-600 shadow-inner">
                                 <span className="material-symbols-outlined filled">star</span>
                             </div>
                             <div className="pr-2">
                                 <div className="text-xs font-bold text-slate-900">Top Expert</div>
                                 <div className="text-[10px] text-slate-500 font-medium">5.0/5 Rating</div>
                             </div>
                         </motion.div>

                         {/* Floating Badge 2 */}
                         <motion.div 
                           initial={{ y: 20, opacity: 0 }}
                           whileInView={{ y: 0, opacity: 1 }}
                           transition={{ delay: 0.7 }}
                           className="absolute bottom-10 left-[-20px] bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-white flex items-center gap-4 max-w-[240px]"
                         >
                             <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-green-500/30">
                                 <span className="material-symbols-outlined">verified_user</span>
                             </div>
                             <div>
                                 <div className="text-sm font-bold text-slate-900">Identité Vérifiée</div>
                                 <div className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">Authentification biométrique & diplômes validés</div>
                             </div>
                         </motion.div>
                      </motion.div>
                  </div>
               </motion.div>

            </div>
         </div>
      </section>

      {/* 3. LABEL RESEAU SECTION */}
      <section className="py-32 bg-[#0B1120] text-white relative overflow-hidden">
         {/* Premium Background Effects */}
         <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-soft-light"></div>
         <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none translate-x-1/2 -translate-y-1/2 mix-blend-screen"></div>
         <div className="absolute bottom-0 left-0 w-[800px] h-[800px] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none -translate-x-1/2 translate-y-1/2 mix-blend-screen"></div>
         
         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
               
               {/* Left Card Visual */}
               <motion.div 
                  initial={{ opacity: 0, scale: 0.9, rotateY: -10 }}
                  whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1 }}
                  className="relative flex justify-center perspective-1000"
               >
                  {/* The Card */}
                  <div className="relative w-[340px] bg-gradient-to-br from-slate-800 to-slate-900 rounded-[2.5rem] p-8 pb-10 shadow-[0_30px_60px_-10px_rgba(0,0,0,0.5)] border border-white/10 flex flex-col items-center text-center overflow-hidden group hover:scale-[1.02] transition-transform duration-500">
                     
                     {/* Glossy Overlay */}
                     <div className="absolute inset-0 bg-gradient-to-tr from-white/10 via-transparent to-transparent opacity-50 pointer-events-none"></div>
                     
                     {/* Card Header */}
                     <div className="w-full flex justify-between items-start mb-10 z-10">
                        <span className="text-[10px] font-black tracking-[0.3em] uppercase opacity-50 text-white">TADAMON</span>
                        <div className="px-2 py-1 bg-green-500/20 border border-green-500/30 rounded-lg">
                           <span className="text-[10px] font-bold text-green-400 uppercase tracking-wider flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                              Active
                           </span>
                        </div>
                     </div>
                     
                     {/* Central Gold Medal */}
                     <div className="relative mb-10 z-10 group-hover:scale-110 transition-transform duration-500">
                        <div className="absolute inset-0 bg-yellow-500/30 blur-2xl rounded-full"></div>
                        <div className="w-28 h-28 bg-gradient-to-br from-[#FCD34D] via-[#F59E0B] to-[#B45309] rounded-full flex items-center justify-center shadow-lg border-[6px] border-[#1E293B] relative z-10">
                           <span className="material-symbols-outlined text-6xl text-white drop-shadow-md">military_tech</span>
                        </div>
                        {/* Shimmer on medal */}
                        <div className="absolute inset-0 rounded-full overflow-hidden z-20 pointer-events-none">
                             <div className="absolute top-0 -left-[100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12 animate-[shimmer_2s_infinite]"></div>
                        </div>
                     </div>
                     
                     <div className="z-10">
                        <h3 className="text-3xl font-bold font-display text-white mb-2 tracking-tight">Label Réseau</h3>
                        <div className="h-0.5 w-12 bg-blue-500 mx-auto mb-2"></div>
                        <p className="text-blue-200 text-sm mb-10 font-medium tracking-wide">CERTIFIÉ EXCELLENCE</p>
                     </div>
                     
                     {/* Checklist */}
                     <div className="w-full space-y-3 z-10 text-left">
                        {['Diplômes vérifiés', 'Expérience confirmée', 'Évaluations positives'].map((item, i) => (
                           <motion.div 
                              key={i} 
                              initial={{ x: -20, opacity: 0 }}
                              whileInView={{ x: 0, opacity: 1 }}
                              transition={{ delay: 0.5 + i * 0.1 }}
                              className="flex items-center gap-3 bg-white/5 p-3 rounded-xl border border-white/5 hover:bg-white/10 transition-colors"
                           >
                              <div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center shrink-0 shadow-lg shadow-green-900/50">
                                 <span className="material-symbols-outlined text-[14px] font-bold text-white">check</span>
                              </div>
                              <span className="text-xs font-bold text-slate-300">{item}</span>
                           </motion.div>
                        ))}
                     </div>
                  </div>
               </motion.div>

               {/* Right Content */}
               <motion.div 
                  initial="hidden" 
                  whileInView="visible" 
                  viewport={{ once: true }}
                  variants={stagger}
               >
                  <motion.div variants={fadeInUp} className="inline-block px-4 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-[10px] font-bold uppercase tracking-widest mb-8 text-blue-300">
                     Excellence Certifiée
                  </motion.div>
                  <motion.h2 variants={fadeInUp} className="text-3xl md:text-5xl lg:text-6xl font-bold font-display text-white mb-8 leading-tight">
                     Le Label <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-yellow-500">Réseau</span>
                  </motion.h2>
                  <motion.p variants={fadeInUp} className="text-slate-400 text-lg leading-relaxed mb-12 font-medium max-w-lg">
                     Notre label distingue les professionnels qui incarnent l'excellence. 
                     Il représente des heures de vérification, des diplômes authentifiés, 
                     et un engagement constant envers la qualité.
                  </motion.p>

                  <div className="space-y-8">
                     {[
                        { icon: 'visibility', title: 'Visibilité prioritaire', desc: 'Mise en avant auprès des meilleurs établissements.' },
                        { icon: 'gpp_good', title: 'Badge de confiance', desc: 'Un sceau de qualité visible sur votre profil.' },
                        { icon: 'diamond', title: 'Accès aux missions premium', desc: 'Accédez aux offres exclusives du réseau.' }
                     ].map((feat, i) => (
                        <motion.div 
                           key={i} 
                           variants={fadeInUp}
                           className="flex gap-6 group"
                        >
                           <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center shrink-0 border border-slate-700 group-hover:border-blue-500/50 group-hover:bg-blue-500/10 transition-all duration-300 relative overflow-hidden">
                              <span className="material-symbols-outlined text-blue-400 text-2xl relative z-10">{feat.icon}</span>
                              <div className="absolute inset-0 bg-blue-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                           </div>
                           <div>
                              <h4 className="font-bold text-white mb-2 text-lg group-hover:text-blue-300 transition-colors">{feat.title}</h4>
                              <p className="text-sm text-slate-400 font-medium leading-relaxed max-w-sm">{feat.desc}</p>
                           </div>
                        </motion.div>
                     ))}
                  </div>
               </motion.div>

            </div>
         </div>
      </section>
      
      <style>{`
         @keyframes shimmer {
            100% { transform: translateX(200%) skewX(12deg); }
         }
      `}</style>
    </div>
  );
};

export default Process;
