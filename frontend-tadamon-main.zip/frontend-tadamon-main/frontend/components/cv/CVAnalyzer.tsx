import React, { useState, useRef } from 'react';
import { UploadSimple, FileText, Sparkle, CheckCircle, XCircle, Spinner, WarningCircle } from '@phosphor-icons/react';
import { cvAPI } from '../../services/api';

interface AnalysisResult {
  score: number;
  strengths: string[];
  improvements: string[];
  keywords: string[];
  suggestions: string[];
  summary?: string;
}

interface WorkerProfileData {
  first_name?: string;
  last_name?: string;
  bio?: string;
  phone?: string;
  city_name?: string;
  region_name?: string;
  years_experience?: number;
  daily_rate?: number;
  specialties?: any[];
  diplomas?: { title: string; institution: string }[];
}

interface CVAnalyzerProps {
  workerProfile?: WorkerProfileData;
}

const CVAnalyzer: React.FC<CVAnalyzerProps> = ({ workerProfile }) => {
  const [file, setFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // Validate file size (5MB max)
      if (selectedFile.size > 5 * 1024 * 1024) {
        setError('Le fichier est trop volumineux. Maximum 5MB.');
        return;
      }
      setFile(selectedFile);
      setResult(null);
      setError(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      const ext = droppedFile.name.toLowerCase();
      if (ext.endsWith('.pdf') || ext.endsWith('.doc') || ext.endsWith('.docx')) {
        if (droppedFile.size > 5 * 1024 * 1024) {
          setError('Le fichier est trop volumineux. Maximum 5MB.');
          return;
        }
        setFile(droppedFile);
        setResult(null);
        setError(null);
      } else {
        setError('Format non supporté. Utilisez PDF, DOC ou DOCX.');
      }
    }
  };

  const analyzeCV = async () => {
    if (!file) return;
    
    setAnalyzing(true);
    setError(null);
    
    try {
      const response = await cvAPI.analyzeCV(file);
      
      if (response.status === 'success' && response.data?.analysis) {
        setResult(response.data.analysis);
      } else {
        throw new Error('Réponse invalide du serveur');
      }
    } catch (err: any) {
      console.error('CV Analysis error:', err);
      setError(err.message || 'Erreur lors de l\'analyse du CV. Veuillez réessayer.');
    } finally {
      setAnalyzing(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return '#10b981';
    if (score >= 60) return '#f59e0b';
    return '#ef4444';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Bon';
    if (score >= 40) return 'À améliorer';
    return 'Insuffisant';
  };

  return (
    <div className="cv-analyzer">
      <div className="analyzer-header">
        <Sparkle size={24} weight="fill" className="sparkle-icon" />
        <div>
          <h2>Analyseur de CV</h2>
          <p>Optimisez votre CV avec l'aide de l'IA pour le secteur social</p>
        </div>
      </div>

      {/* Profile Summary if available */}
      {workerProfile && (
        <div className="profile-summary">
          <h4>Votre profil actuel</h4>
          <div className="profile-tags">
            {workerProfile.years_experience && (
              <span className="profile-tag">{workerProfile.years_experience} ans d'expérience</span>
            )}
            {workerProfile.city_name && (
              <span className="profile-tag">{workerProfile.city_name}</span>
            )}
            {workerProfile.specialties?.slice(0, 3).map((s: any, i: number) => (
              <span key={i} className="profile-tag specialty">{s.name || s}</span>
            ))}
          </div>
        </div>
      )}

      {error && (
        <div className="error-message">
          <WarningCircle size={18} />
          <span>{error}</span>
        </div>
      )}

      <div
        className={`upload-zone ${file ? 'has-file' : ''}`}
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={handleFileSelect}
          hidden
        />
        
        {file ? (
          <div className="file-info">
            <FileText size={40} weight="duotone" />
            <span className="file-name">{file.name}</span>
            <span className="file-size">{(file.size / 1024).toFixed(1)} KB</span>
          </div>
        ) : (
          <>
            <UploadSimple size={40} />
            <p>Glissez votre CV ici ou cliquez pour sélectionner</p>
            <span>PDF, DOC, DOCX (max 5MB)</span>
          </>
        )}
      </div>

      {file && !result && (
        <button className="analyze-btn" onClick={analyzeCV} disabled={analyzing}>
          {analyzing ? (
            <>
              <Spinner size={20} className="spinning" />
              Analyse en cours...
            </>
          ) : (
            <>
              <Sparkle size={20} weight="fill" />
              Analyser mon CV
            </>
          )}
        </button>
      )}

      {result && (
        <div className="analysis-result">
          <div className="score-section">
            <div className="score-circle" style={{ '--score-color': getScoreColor(result.score) } as any}>
              <svg viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" className="score-bg" />
                <circle
                  cx="50" cy="50" r="45"
                  className="score-fill"
                  strokeDasharray={`${result.score * 2.83} 283`}
                />
              </svg>
              <div className="score-value">
                <span className="score-number">{result.score}</span>
                <span className="score-label">/ 100</span>
              </div>
            </div>
            <p className="score-text">{getScoreLabel(result.score)}</p>
            {result.summary && (
              <p className="score-summary">{result.summary}</p>
            )}
          </div>

          <div className="analysis-sections">
            <div className="analysis-card strengths">
              <h3><CheckCircle size={20} weight="fill" /> Points forts</h3>
              <ul>
                {result.strengths.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>

            <div className="analysis-card improvements">
              <h3><XCircle size={20} weight="fill" /> À améliorer</h3>
              <ul>
                {result.improvements.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>

            <div className="analysis-card keywords">
              <h3>Mots-clés détectés</h3>
              <div className="keywords-list">
                {result.keywords.map((keyword, i) => (
                  <span key={i} className="keyword-tag">{keyword}</span>
                ))}
              </div>
            </div>

            <div className="analysis-card suggestions">
              <h3><Sparkle size={20} weight="fill" /> Suggestions</h3>
              <ul>
                {result.suggestions.map((item, i) => (
                  <li key={i}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          <button className="reset-btn" onClick={() => { setFile(null); setResult(null); }}>
            Analyser un autre CV
          </button>
        </div>
      )}

      <style>{`
        .cv-analyzer { padding: 24px; }
        .analyzer-header {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 24px;
        }
        .sparkle-icon { color: #8b5cf6; }
        .analyzer-header h2 { 
          font-size: 20px; 
          font-weight: 600; 
          margin: 0 0 4px; 
          color: #F8FAFC;
        }
        .analyzer-header p { 
          font-size: 14px; 
          color: #94A3B8; 
          margin: 0; 
        }
        
        .profile-summary {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 20px;
        }
        .profile-summary h4 {
          font-size: 13px;
          color: #A78BFA;
          margin: 0 0 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .profile-tags {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .profile-tag {
          background: rgba(139, 92, 246, 0.15);
          color: #C4B5FD;
          padding: 4px 12px;
          border-radius: 16px;
          font-size: 12px;
        }
        .profile-tag.specialty {
          background: rgba(16, 185, 129, 0.15);
          color: #6EE7B7;
        }
        
        .error-message {
          display: flex;
          align-items: center;
          gap: 10px;
          background: rgba(239, 68, 68, 0.1);
          border: 1px solid rgba(239, 68, 68, 0.3);
          color: #FCA5A5;
          padding: 12px 16px;
          border-radius: 10px;
          margin-bottom: 16px;
          font-size: 14px;
        }
        
        .upload-zone {
          border: 2px dashed rgba(139, 92, 246, 0.4);
          border-radius: 16px;
          padding: 60px 40px;
          text-align: center;
          cursor: pointer;
          transition: all 0.3s;
          background: rgba(139, 92, 246, 0.05);
        }
        .upload-zone:hover { 
          border-color: #8B5CF6; 
          background: rgba(139, 92, 246, 0.1); 
        }
        .upload-zone.has-file { 
          border-style: solid; 
          border-color: #10b981; 
          background: rgba(16, 185, 129, 0.1); 
        }
        .upload-zone svg { color: #A78BFA; }
        .upload-zone p { 
          margin: 16px 0 8px; 
          font-weight: 500; 
          color: #CBD5E1;
        }
        .upload-zone span { 
          font-size: 13px; 
          color: #64748B; 
        }
        .file-info { 
          display: flex; 
          flex-direction: column; 
          align-items: center; 
          gap: 8px; 
        }
        .file-info svg { color: #10B981; }
        .file-name { 
          font-weight: 500; 
          color: #F8FAFC; 
        }
        .file-size { 
          font-size: 13px; 
          color: #94A3B8; 
        }
        .analyze-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          width: 100%;
          padding: 16px;
          margin-top: 24px;
          background: linear-gradient(135deg, #8b5cf6, #7C3AED);
          color: white;
          border: none;
          border-radius: 14px;
          font-size: 15px;
          font-weight: 600;
          cursor: pointer;
          transition: transform 0.2s, box-shadow 0.2s;
        }
        .analyze-btn:hover:not(:disabled) { 
          transform: translateY(-2px); 
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4); 
        }
        .analyze-btn:disabled { 
          opacity: 0.7; 
          cursor: not-allowed; 
        }
        .spinning { animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        
        .analysis-result { margin-top: 32px; }
        .score-section { 
          text-align: center; 
          margin-bottom: 32px;
          padding: 24px;
          background: rgba(18, 18, 26, 0.6);
          border-radius: 20px;
          border: 1px solid rgba(139, 92, 246, 0.15);
        }
        .score-circle {
          width: 160px;
          height: 160px;
          margin: 0 auto;
          position: relative;
        }
        .score-circle svg { transform: rotate(-90deg); }
        .score-bg { 
          fill: none; 
          stroke: rgba(139, 92, 246, 0.2); 
          stroke-width: 10; 
        }
        .score-fill { 
          fill: none; 
          stroke: var(--score-color); 
          stroke-width: 10; 
          stroke-linecap: round; 
          transition: stroke-dasharray 1s ease; 
        }
        .score-value {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          text-align: center;
        }
        .score-number { 
          font-size: 42px; 
          font-weight: 700; 
          color: var(--score-color); 
        }
        .score-label { 
          font-size: 16px; 
          color: #64748B; 
          display: block; 
        }
        .score-text { 
          margin-top: 16px; 
          color: var(--score-color); 
          font-size: 18px;
          font-weight: 600;
        }
        .score-summary {
          margin-top: 12px;
          color: #94A3B8;
          font-size: 14px;
          line-height: 1.5;
        }
        
        .analysis-sections { 
          display: grid; 
          grid-template-columns: repeat(2, 1fr); 
          gap: 20px; 
        }
        .analysis-card {
          background: rgba(18, 18, 26, 0.8);
          border: 1px solid rgba(139, 92, 246, 0.15);
          border-radius: 16px;
          padding: 20px;
        }
        .analysis-card h3 {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 15px;
          font-weight: 600;
          margin: 0 0 16px;
          color: #F8FAFC;
        }
        .analysis-card.strengths h3 { color: #10b981; }
        .analysis-card.improvements h3 { color: #f59e0b; }
        .analysis-card.suggestions h3 { color: #8b5cf6; }
        .analysis-card ul { 
          margin: 0; 
          padding-left: 20px; 
        }
        .analysis-card li { 
          font-size: 14px; 
          color: #CBD5E1; 
          margin-bottom: 10px; 
          line-height: 1.5; 
        }
        .keywords-list { 
          display: flex; 
          flex-wrap: wrap; 
          gap: 10px; 
        }
        .keyword-tag {
          background: rgba(139, 92, 246, 0.2);
          color: #A78BFA;
          padding: 6px 14px;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 500;
          border: 1px solid rgba(139, 92, 246, 0.3);
        }
        .reset-btn {
          display: block;
          width: 100%;
          padding: 14px;
          margin-top: 24px;
          background: transparent;
          border: 1px solid rgba(139, 92, 246, 0.3);
          border-radius: 12px;
          color: #A78BFA;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
        }
        .reset-btn:hover { 
          border-color: #8B5CF6; 
          background: rgba(139, 92, 246, 0.1);
          color: #C4B5FD; 
        }
        
        /* Light mode */
        [data-theme="light"] .analyzer-header h2 { color: #1e293b; }
        [data-theme="light"] .analyzer-header p { color: #64748b; }
        [data-theme="light"] .profile-summary { 
          background: rgba(139, 92, 246, 0.05);
          border-color: rgba(139, 92, 246, 0.15);
        }
        [data-theme="light"] .profile-summary h4 { color: #7C3AED; }
        [data-theme="light"] .profile-tag { 
          background: rgba(139, 92, 246, 0.1);
          color: #7C3AED;
        }
        [data-theme="light"] .profile-tag.specialty {
          background: rgba(16, 185, 129, 0.1);
          color: #059669;
        }
        [data-theme="light"] .error-message {
          background: rgba(239, 68, 68, 0.05);
          color: #DC2626;
        }
        [data-theme="light"] .upload-zone { 
          border-color: #e2e8f0;
          background: #f8fafc;
        }
        [data-theme="light"] .upload-zone:hover { 
          background: rgba(139, 92, 246, 0.05);
          border-color: #8B5CF6;
        }
        [data-theme="light"] .upload-zone p { color: #1e293b; }
        [data-theme="light"] .upload-zone span { color: #64748b; }
        [data-theme="light"] .file-name { color: #1e293b; }
        [data-theme="light"] .score-section {
          background: #f8fafc;
          border-color: #e2e8f0;
        }
        [data-theme="light"] .score-bg { stroke: #e2e8f0; }
        [data-theme="light"] .score-summary { color: #64748b; }
        [data-theme="light"] .analysis-card { 
          background: #f8fafc;
          border-color: #e2e8f0;
        }
        [data-theme="light"] .analysis-card h3 { color: #1e293b; }
        [data-theme="light"] .analysis-card li { color: #475569; }
        [data-theme="light"] .keyword-tag { 
          background: rgba(139, 92, 246, 0.1);
          border-color: rgba(139, 92, 246, 0.2);
        }
        [data-theme="light"] .reset-btn {
          border-color: #e2e8f0;
          color: #64748b;
        }
        [data-theme="light"] .reset-btn:hover {
          border-color: #8B5CF6;
          color: #8B5CF6;
        }
        
        @media (max-width: 768px) {
          .analysis-sections { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
};

export default CVAnalyzer;
