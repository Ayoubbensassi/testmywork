import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../AuthContext';

interface NavbarProps {
  isScrolled: boolean;
}

const Navbar = ({ isScrolled }: NavbarProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  
  const menuItems = [
    { name: 'Accueil', path: '/', icon: 'home' },
    { name: 'Missions', path: '/missions', icon: 'work' },
    { name: 'Comment ça marche', path: '/process', icon: 'info' },
    { name: 'Tarifs', path: '/pricing', icon: 'payments' },
    { name: 'Contact', path: '/contact', icon: 'mail' }
  ];

  const isActive = (path: string) => {
    if (path === '/' && location.pathname !== '/') return false;
    return location.pathname.startsWith(path);
  };

  const getDashboardPath = () => {
    if (!user) return '/';
    if (user.role === 'worker') return '/worker/dashboard';
    if (user.role === 'establishment') return '/establishment/dashboard';
    if (user.role === 'admin') return '/admin/dashboard';
    return '/';
  };

  return (
    <>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className={`fixed w-full z-50 top-0 transition-all duration-500 ${
          isScrolled 
            ? 'bg-white/95 backdrop-blur-xl shadow-[0_4px_30px_rgba(0,0,0,0.08)] border-b border-slate-200/50' 
            : 'bg-slate-900/90 backdrop-blur-xl border-b border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`flex justify-between items-center transition-all duration-300 ${isScrolled ? 'py-3' : 'py-5'}`}>
            
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group relative z-10">
              <div className={`relative w-11 h-11 rounded-2xl flex items-center justify-center transition-all duration-300 group-hover:scale-105 ${
                isScrolled 
                  ? 'bg-gradient-to-br from-blue-600 to-indigo-600 shadow-lg shadow-blue-500/25' 
                  : 'bg-white/10 backdrop-blur-md border border-white/20'
              }`}>
                <span className={`material-symbols-outlined text-2xl font-bold ${isScrolled ? 'text-white' : 'text-white'}`}>diversity_1</span>
                {/* Glow effect */}
                <div className="absolute inset-0 rounded-2xl bg-blue-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10"></div>
              </div>
              <div className="flex flex-col">
                <span className={`text-[1.3rem] font-bold tracking-tight leading-none font-display transition-colors duration-300 ${
                  isScrolled ? 'text-slate-900' : 'text-white'
                }`}>TADAMON</span>
                <span className={`text-[9px] font-black tracking-[0.3em] uppercase mt-0.5 transition-colors duration-300 ${
                  isScrolled ? 'text-blue-600' : 'text-blue-300'
                }`}>Social</span>
              </div>
            </Link>

            {/* Desktop Nav Links */}
            <div className="hidden lg:flex items-center">
              <div className={`flex items-center gap-1 p-1.5 rounded-2xl transition-all duration-300 ${
                isScrolled ? 'bg-slate-100/80' : 'bg-white/5 backdrop-blur-md border border-white/10'
              }`}>
                {menuItems.map((item) => (
                  <Link 
                    key={item.name} 
                    to={item.path} 
                    className={`relative px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
                      isActive(item.path) 
                        ? isScrolled 
                          ? 'bg-white text-blue-600 shadow-sm' 
                          : 'bg-white/15 text-white'
                        : isScrolled 
                          ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50' 
                          : 'text-white/70 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>

            {/* Desktop Actions */}
            <div className="hidden lg:flex items-center gap-3">
              {user ? (
                <div className="flex items-center gap-3">
                  {/* Dashboard Button */}
                  <button 
                    onClick={() => navigate(getDashboardPath())}
                    className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 flex items-center gap-2 ${
                      isScrolled 
                        ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' 
                        : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'
                    }`}
                  >
                    <span className="material-symbols-outlined text-lg">dashboard</span>
                    Dashboard
                  </button>

                  {/* Profile Dropdown */}
                  <div className="relative">
                    <button 
                      onClick={() => setIsProfileOpen(!isProfileOpen)}
                      className={`flex items-center gap-3 p-2 pr-4 rounded-2xl transition-all duration-300 ${
                        isScrolled 
                          ? 'bg-slate-100 hover:bg-slate-200' 
                          : 'bg-white/10 hover:bg-white/20 border border-white/10'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                        isScrolled 
                          ? 'bg-gradient-to-br from-blue-600 to-indigo-600 text-white' 
                          : 'bg-white/20 text-white'
                      }`}>
                        {(user.firstName || user.email).charAt(0).toUpperCase()}
                      </div>
                      <div className="text-left hidden xl:block">
                        <div className={`text-sm font-bold leading-tight ${isScrolled ? 'text-slate-900' : 'text-white'}`}>
                          {user.firstName} {user.lastName}
                        </div>
                        <div className={`text-[10px] font-medium ${isScrolled ? 'text-slate-500' : 'text-white/60'}`}>
                          {user.role === 'worker' ? 'Expert Social' : user.role === 'establishment' ? 'Établissement' : 'Admin'}
                        </div>
                      </div>
                      <span className={`material-symbols-outlined text-lg transition-transform duration-300 ${isProfileOpen ? 'rotate-180' : ''} ${
                        isScrolled ? 'text-slate-400' : 'text-white/60'
                      }`}>expand_more</span>
                    </button>

                    {/* Dropdown Menu */}
                    <AnimatePresence>
                      {isProfileOpen && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          transition={{ duration: 0.2 }}
                          className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden"
                        >
                          <div className="p-3 border-b border-slate-100">
                            <div className="text-sm font-bold text-slate-900">{user.firstName} {user.lastName}</div>
                            <div className="text-xs text-slate-500">{user.email}</div>
                          </div>
                          <div className="p-2">
                            <button 
                              onClick={() => { navigate(getDashboardPath()); setIsProfileOpen(false); }}
                              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                            >
                              <span className="material-symbols-outlined text-lg text-slate-400">dashboard</span>
                              Mon Dashboard
                            </button>
                            <button 
                              onClick={() => { logout(); setIsProfileOpen(false); }}
                              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                            >
                              <span className="material-symbols-outlined text-lg">logout</span>
                              Se déconnecter
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              ) : (
                <>
                  <Link 
                    to="/login"
                    className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
                      isScrolled 
                        ? 'text-slate-700 hover:text-blue-600 hover:bg-slate-100' 
                        : 'text-white/90 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    Connexion
                  </Link>
                  <Link 
                    to="/signup"
                    className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all duration-300 flex items-center gap-2 ${
                      isScrolled 
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:-translate-y-0.5' 
                        : 'bg-white text-slate-900 hover:bg-blue-50 shadow-lg'
                    }`}
                  >
                    <span>Inscription</span>
                    <span className="material-symbols-outlined text-lg">arrow_forward</span>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`lg:hidden p-2.5 rounded-xl transition-all duration-300 ${
                isScrolled 
                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' 
                  : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'
              }`}
            >
              <span className="material-symbols-outlined text-2xl">{isMenuOpen ? 'close' : 'menu'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="lg:hidden bg-white border-t border-slate-100 overflow-hidden"
            >
              <div className="max-w-7xl mx-auto px-4 py-4 space-y-2">
                {menuItems.map((item) => (
                  <Link 
                    key={item.name} 
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                      isActive(item.path) 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className={`material-symbols-outlined text-xl ${isActive(item.path) ? 'text-blue-600' : 'text-slate-400'}`}>{item.icon}</span>
                    {item.name}
                  </Link>
                ))}
                
                <div className="pt-4 border-t border-slate-100 space-y-2">
                  {user ? (
                    <>
                      <div className="flex items-center gap-3 px-4 py-3">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold">
                          {(user.firstName || user.email).charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900">{user.firstName} {user.lastName}</div>
                          <div className="text-xs text-slate-500">{user.role === 'worker' ? 'Expert Social' : 'Établissement'}</div>
                        </div>
                      </div>
                      <button 
                        onClick={() => { navigate(getDashboardPath()); setIsMenuOpen(false); }}
                        className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-xl text-slate-400">dashboard</span>
                        Mon Dashboard
                      </button>
                      <button 
                        onClick={() => { logout(); setIsMenuOpen(false); }}
                        className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-red-600 hover:bg-red-50 cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-xl">logout</span>
                        Se déconnecter
                      </button>
                    </>
                  ) : (
                    <>
                      <Link 
                        to="/login"
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200"
                      >
                        Connexion
                      </Link>
                      <Link 
                        to="/signup"
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-blue-600 to-indigo-600"
                      >
                        Inscription
                        <span className="material-symbols-outlined text-lg">arrow_forward</span>
                      </Link>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Overlay for profile dropdown */}
      {isProfileOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsProfileOpen(false)}
        />
      )}
    </>
  );
};

export default Navbar;
