import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const API_BASE_URL = 'http://localhost:5000/api';

const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(`${API_BASE_URL}/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await response.json();
      
      if (data.status === 'success') {
        setSuccess(true);
      } else {
        setError(data.message || 'Une erreur est survenue');
      }
    } catch (err) {
      setError('Erreur de connexion au serveur');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-white overflow-hidden relative">
      <Link to="/login" className="absolute top-6 left-6 z-50 w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors border border-slate-200">
        <span className="material-symbols-outlined">arrow_back</span>
      </Link>

      <div className="w-full lg:w-1/2 min-h-screen flex flex-col justify-center items-center p-6 lg:p-8 relative bg-white z-10">
        <div className="w-full max-w-[420px]">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#2563EB] to-[#db2777] uppercase tracking-tighter mb-6">TADAMON</h2>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Mot de passe oublié ?</h3>
            <p className="text-slate-500 text-sm">Entrez votre email pour recevoir un lien de réinitialisation</p>
          </div>

          {success ? (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="material-symbols-outlined text-4xl text-green-600">mark_email_read</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Email envoyé !</h3>
              <p className="text-slate-500 mb-6">Si un compte existe avec cet email, vous recevrez un lien de réinitialisation.</p>
              <Link to="/login" className="inline-block px-6 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors">
                Retour à la connexion
              </Link>
            </motion.div>
          ) : (
            <motion.form initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm font-medium">{error}</div>
              )}

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Adresse email</label>
                <div className="relative group">
                  <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">mail</span>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
                    className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none"
                    placeholder="votre@email.com" />
                </div>
              </div>

              <button type="submit" disabled={isLoading}
                className="w-full py-3.5 bg-gradient-to-r from-[#2563EB] to-[#3B82F6] hover:from-[#1d4ed8] hover:to-[#2563eb] text-white font-bold rounded-2xl transition-all shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2">
                {isLoading ? (
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                ) : (
                  <>Envoyer le lien<span className="material-symbols-outlined">send</span></>
                )}
              </button>

              <div className="text-center">
                <Link to="/login" className="text-blue-600 font-bold text-sm hover:underline">
                  ← Retour à la connexion
                </Link>
              </div>
            </motion.form>
          )}
        </div>
      </div>

      <div className="hidden lg:flex w-1/2 h-screen bg-slate-900 relative flex-col justify-center items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-slate-900 to-slate-900"></div>
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
        <div className="relative z-10 text-center px-12">
          <span className="material-symbols-outlined text-8xl text-blue-400 mb-6">lock_reset</span>
          <h3 className="text-3xl font-bold text-white mb-4">Récupérez votre accès</h3>
          <p className="text-blue-200/70">Un lien sécurisé vous sera envoyé par email pour créer un nouveau mot de passe.</p>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
