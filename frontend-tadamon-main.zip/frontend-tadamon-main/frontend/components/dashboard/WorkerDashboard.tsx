import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import {
  FileText, ChatCircle, CalendarBlank, Star, Briefcase, User,
  MapPin, Clock, CheckCircle, WarningCircle, CaretLeft, CaretRight,
  TrendUp, Medal, SignOut, Plus, UploadSimple, Eye, DownloadSimple, 
  PaperPlaneTilt, X, Gear, Moon, Sun, CaretDown, House, ChartLineUp,
  Wallet, CreditCard, Receipt, Buildings, Phone, Envelope, Globe,
  ArrowUp, ArrowDown, DotsThreeVertical, Lightning, RocketLaunch,
  ShoppingCart, Bell, MagnifyingGlass, List, UserCircle, Sparkle
} from '@phosphor-icons/react';
import { workerAPI, missionAPI, applicationAPI, diplomaAPI, availabilityAPI, regionAPI, statsAPI, reviewAPI } from '../../services/api';
import { showSuccess, showError } from '../common/Toast';
import MessagingPanel from '../messaging/MessagingPanel';
import NotificationsDropdown from '../common/NotificationsDropdown';
import CVAnalyzer from '../cv/CVAnalyzer';
import '../../styles/dashboard-unified.css';
import '../../styles/TravailleurDashboard.css';
import '../../styles/dashboard-light-mode.css';

// Types
interface WorkerProfile {
  id: number;
  first_name: string;
  last_name: string;
  cin: string;
  phone: string;
  bio: string;
  daily_rate: number;
  years_experience: number;
  average_rating: number;
  total_missions: number;
  is_labeled: boolean;
  status: string;
  profile_picture: string;
  region_id: number;
  city_id: number;
  city_name?: string;
  region_name?: string;
  specialties: any[];
}

interface Mission {
  id: number;
  title: string;
  description: string;
  establishment_name: string;
  city_name: string;
  start_date: string;
  end_date: string;
  salary_min: number;
  salary_max: number;
  is_urgent: boolean;
  status: string;
}

interface Region {
  id: number;
  name_fr: string;
  code: string;
}

interface City {
  id: number;
  name_fr: string;
  region_id: number;
}

// ============================================
// VISION UI COMPONENTS
// ============================================

// Quick Actions & Overview Card
const QuickActionsCard = ({ 
  profile, 
  missionsCount, 
  applicationsCount,
  onNavigate 
}: { 
  profile: WorkerProfile | null;
  missionsCount: number;
  applicationsCount: number;
  onNavigate: (tab: string) => void;
}) => {
  const today = new Date();
  const hour = today.getHours();
  const greeting = hour < 12 ? 'Bonjour' : hour < 18 ? 'Bon après-midi' : 'Bonsoir';
  
  return (
    <div className="quick-actions-card">
      <div className="quick-header">
        <div className="quick-greeting">
          <h2>{greeting}, {formatName(profile?.first_name)} 👋</h2>
          <p>{today.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
        </div>
      </div>
      
      <div className="quick-summary">
        <div className="summary-item" onClick={() => onNavigate('missions')}>
          <div className="summary-icon blue">
            <Briefcase size={20} weight="fill" />
          </div>
          <div className="summary-info">
            <span className="summary-value">{missionsCount}</span>
            <span className="summary-label">Missions disponibles</span>
          </div>
          <CaretRight size={18} className="summary-arrow" />
        </div>
        
        <div className="summary-item" onClick={() => onNavigate('applications')}>
          <div className="summary-icon green">
            <FileText size={20} weight="fill" />
          </div>
          <div className="summary-info">
            <span className="summary-value">{applicationsCount}</span>
            <span className="summary-label">Candidatures en cours</span>
          </div>
          <CaretRight size={18} className="summary-arrow" />
        </div>
        
        <div className="summary-item" onClick={() => onNavigate('calendar')}>
          <div className="summary-icon orange">
            <CalendarBlank size={20} weight="fill" />
          </div>
          <div className="summary-info">
            <span className="summary-value">Gérer</span>
            <span className="summary-label">Mes disponibilités</span>
          </div>
          <CaretRight size={18} className="summary-arrow" />
        </div>
      </div>
      
      <div className="quick-actions-btns">
        <button className="quick-btn primary" onClick={() => onNavigate('missions')}>
          <MagnifyingGlass size={18} />
          Chercher une mission
        </button>
        <button className="quick-btn secondary" onClick={() => onNavigate('profile')}>
          <User size={18} />
          Mon profil
        </button>
      </div>
    </div>
  );
};

// Mini Statistics Card - Vision UI Style
const MiniStatCard = ({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendValue,
  gradient 
}: { 
  title: string; 
  value: string | number; 
  icon: any;
  trend?: 'up' | 'down';
  trendValue?: string;
  gradient: 'blue' | 'green' | 'orange' | 'purple' | 'pink';
}) => (
  <div className="mini-stat-card">
    <div className="mini-stat-content">
      <p className="mini-stat-title">{title}</p>
      <div className="mini-stat-value-row">
        <h3 className="mini-stat-value">{value}</h3>
        {trend && trendValue && (
          <span className={`mini-stat-trend ${trend}`}>
            {trend === 'up' ? <ArrowUp size={12} weight="bold" /> : <ArrowDown size={12} weight="bold" />}
            {trendValue}
          </span>
        )}
      </div>
    </div>
    <div className={`mini-stat-icon gradient-${gradient}`}>
      <Icon size={22} weight="fill" />
    </div>
  </div>
);

// Satisfaction Rate Card - Circular Progress
const SatisfactionCard = ({ rating }: { rating: number }) => {
  const numRating = Number(rating) || 0;
  const percentage = (numRating / 5) * 100;
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;
  
  return (
    <div className="satisfaction-card-compact">
      <div className="satisfaction-content">
        <div className="satisfaction-chart-small">
          <svg viewBox="0 0 100 100" className="circular-progress">
            <circle cx="50" cy="50" r="45" className="progress-bg" />
            <circle 
              cx="50" cy="50" r="45" 
              className="progress-fill"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
            />
          </svg>
          <div className="satisfaction-value">
            <span className="value">{numRating.toFixed(1)}</span>
            <span className="max">/5</span>
          </div>
        </div>
        <div className="satisfaction-info">
          <h3>Satisfaction</h3>
          <p>Avis établissements</p>
        </div>
      </div>
    </div>
  );
};

// Interactive Globe Card with Mission Points
const GlobeCard = ({ missions, isExpanded, onExpand, onClose }: { 
  missions: Mission[]; 
  isExpanded?: boolean;
  onExpand?: () => void;
  onClose?: () => void;
}) => {
  const [rotation, setRotation] = useState(0);
  const [hoveredMission, setHoveredMission] = useState<Mission | null>(null);
  
  // Morocco cities coordinates (simplified for visualization)
  const cityCoords: { [key: string]: { x: number; y: number } } = {
    'Casablanca': { x: 48, y: 52 },
    'Rabat': { x: 46, y: 48 },
    'Marrakech': { x: 44, y: 58 },
    'Fès': { x: 52, y: 46 },
    'Tanger': { x: 44, y: 40 },
    'Agadir': { x: 38, y: 62 },
    'Oujda': { x: 60, y: 46 },
    'Meknès': { x: 50, y: 48 },
    'Kenitra': { x: 44, y: 50 },
    'Tétouan': { x: 46, y: 42 },
  };
  
  // Auto-rotate globe
  useEffect(() => {
    const interval = setInterval(() => {
      setRotation(prev => (prev + 0.3) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, []);
  
  const getMissionCoords = (mission: Mission) => {
    const cityName = mission.city_name || 'Casablanca';
    return cityCoords[cityName] || { x: 50, y: 50 };
  };

  const handleCardClick = (e: React.MouseEvent) => {
    if (!isExpanded && onExpand) {
      onExpand();
    }
  };

  return (
    <div className={`globe-card ${isExpanded ? 'expanded' : ''}`} onClick={handleCardClick}>
      <div className="globe-header">
        <h3 className="card-title">Missions au Maroc</h3>
        <div className="globe-header-right">
          <span className="globe-count">{missions.length} actives</span>
          {isExpanded && onClose && (
            <button className="close-expanded-btn" onClick={(e) => { e.stopPropagation(); onClose(); }}>
              <X size={20} />
            </button>
          )}
        </div>
      </div>
      
      <div className="globe-container">
        {/* Globe SVG */}
        <svg viewBox="0 0 100 100" className="globe-svg">
          <defs>
            <linearGradient id="globeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#0075ff" stopOpacity="0.3" />
              <stop offset="50%" stopColor="#00e5ff" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#0075ff" stopOpacity="0.1" />
            </linearGradient>
            <linearGradient id="oceanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#001a33" />
              <stop offset="100%" stopColor="#003366" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="1.5" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          
          {/* Globe background */}
          <circle cx="50" cy="50" r="45" fill="url(#oceanGrad)" className="globe-sphere" />
          
          {/* Grid lines */}
          <g className="globe-grid" style={{ transform: `rotate(${rotation}deg)`, transformOrigin: '50px 50px' }}>
            {[20, 35, 50, 65, 80].map((y, i) => (
              <ellipse key={`lat-${i}`} cx="50" cy="50" rx={45 * Math.cos((y - 50) * Math.PI / 90)} ry="45" 
                fill="none" stroke="rgba(0, 229, 255, 0.1)" strokeWidth="0.3"
                transform={`translate(0, ${(y - 50) * 0.9})`} />
            ))}
            {[0, 30, 60, 90, 120, 150].map((angle, i) => (
              <ellipse key={`lon-${i}`} cx="50" cy="50" rx="10" ry="45" 
                fill="none" stroke="rgba(0, 229, 255, 0.1)" strokeWidth="0.3"
                transform={`rotate(${angle}, 50, 50)`} />
            ))}
          </g>
          
          {/* Morocco shape (simplified) */}
          <path 
            d="M42,38 L58,38 L62,45 L60,55 L55,65 L45,68 L38,60 L36,50 L38,42 Z" 
            fill="url(#globeGrad)" 
            stroke="rgba(0, 229, 255, 0.5)" 
            strokeWidth="0.5"
            className="morocco-shape"
          />
          
          {/* Mission points */}
          {missions.slice(0, isExpanded ? 10 : 6).map((mission, index) => {
            const coords = getMissionCoords(mission);
            return (
              <g key={mission.id} className="mission-point">
                <circle 
                  cx={coords.x} 
                  cy={coords.y} 
                  r={isExpanded ? "4" : "3"}
                  fill={mission.is_urgent ? '#ff6b6b' : '#00e5ff'}
                  filter="url(#glow)"
                  className="point-glow"
                  onMouseEnter={() => setHoveredMission(mission)}
                  onMouseLeave={() => setHoveredMission(null)}
                />
                <circle 
                  cx={coords.x} 
                  cy={coords.y} 
                  r={isExpanded ? "2" : "1.5"}
                  fill="white"
                />
                {/* Pulse animation */}
                <circle 
                  cx={coords.x} 
                  cy={coords.y} 
                  r={isExpanded ? "4" : "3"}
                  fill="none"
                  stroke={mission.is_urgent ? '#ff6b6b' : '#00e5ff'}
                  strokeWidth="0.5"
                  className="point-pulse"
                  style={{ animationDelay: `${index * 0.3}s` }}
                />
              </g>
            );
          })}
          
          {/* Outer glow ring */}
          <circle cx="50" cy="50" r="46" fill="none" stroke="rgba(0, 229, 255, 0.2)" strokeWidth="0.5" />
        </svg>
        
        {/* Hover tooltip */}
        {hoveredMission && (
          <div className="globe-tooltip">
            <span className="tooltip-city">{hoveredMission.city_name || 'Maroc'}</span>
            <span className="tooltip-title">{hoveredMission.title}</span>
            {hoveredMission.is_urgent && <span className="tooltip-urgent">Urgent</span>}
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div className="globe-legend">
        <div className="legend-item">
          <span className="legend-dot urgent"></span>
          <span>Urgent</span>
        </div>
        <div className="legend-item">
          <span className="legend-dot normal"></span>
          <span>Standard</span>
        </div>
      </div>
      
      {/* Expand hint */}
      {!isExpanded && (
        <div className="expand-hint">
          <span>Cliquer pour agrandir</span>
        </div>
      )}
      
      {/* Mission list in expanded mode */}
      {isExpanded && (
        <div className="globe-missions-list">
          <h4>Liste des missions</h4>
          <div className="missions-scroll">
            {missions.map((mission) => (
              <div key={mission.id} className="globe-mission-item">
                <div className={`mission-dot ${mission.is_urgent ? 'urgent' : ''}`}></div>
                <div className="mission-details">
                  <span className="mission-name">{mission.title}</span>
                  <span className="mission-location">{mission.city_name || 'Maroc'} • {mission.establishment_name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Referral Tracking Card
const ReferralCard = ({ profile }: { profile: WorkerProfile | null }) => (
  <div className="referral-card">
    <div className="referral-header">
      <div>
        <p className="referral-label">Missions complétées</p>
        <h3 className="referral-value">{profile?.total_missions || 0}</h3>
      </div>
      <div className="referral-icon">
        <RocketLaunch size={24} weight="fill" />
      </div>
    </div>
    <div className="referral-stats">
      <div className="referral-stat">
        <div className="stat-bar">
          <div className="stat-fill" style={{ width: `${Math.min((profile?.total_missions || 0) * 10, 100)}%` }}></div>
        </div>
        <div className="stat-info">
          <span className="stat-label">Progression</span>
          <span className="stat-value">{Math.min((profile?.total_missions || 0) * 10, 100)}%</span>
        </div>
      </div>
    </div>
  </div>
);

// Projects Table - Vision UI Style
const ProjectsTable = ({ 
  missions, 
  onApply 
}: { 
  missions: Mission[]; 
  onApply: (id: number) => void;
}) => (
  <div className="projects-card">
    <div className="projects-header">
      <div>
        <h3 className="card-title">Missions disponibles</h3>
        <p className="card-subtitle">{missions.length} missions trouvées</p>
      </div>
      <button className="icon-btn">
        <DotsThreeVertical size={20} />
      </button>
    </div>
    <div className="projects-table">
      <div className="table-header">
        <span className="col-mission">Mission</span>
        <span className="col-location">Lieu</span>
        <span className="col-salary">Salaire</span>
        <span className="col-date">Date</span>
        <span className="col-action">Action</span>
      </div>
      <div className="table-body">
        {missions.length === 0 ? (
          <div className="table-empty">
            <Briefcase size={32} />
            <p>Aucune mission disponible</p>
          </div>
        ) : (
          missions.slice(0, 5).map((mission) => (
            <div key={mission.id} className="table-row">
              <div className="col-mission">
                <div className="mission-icon">
                  <Buildings size={18} />
                </div>
                <div className="mission-info">
                  <h4>{mission.title}</h4>
                  <p>{mission.establishment_name}</p>
                </div>
                {mission.is_urgent && <span className="urgent-badge">Urgent</span>}
              </div>
              <div className="col-location">
                <MapPin size={14} />
                <span>{mission.city_name || 'Maroc'}</span>
              </div>
              <div className="col-salary">
                <span className="salary-value">{mission.salary_min} - {mission.salary_max} DH</span>
              </div>
              <div className="col-date">
                <Clock size={14} />
                <span>{new Date(mission.start_date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span>
              </div>
              <div className="col-action">
                <button className="apply-btn" onClick={() => onApply(mission.id)}>
                  Postuler
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  </div>
);

// Orders Overview / Activity Timeline - Vision UI Style
const ActivityTimeline = ({ applications }: { applications: any[] }) => (
  <div className="activity-card">
    <div className="activity-header">
      <h3 className="card-title">Activité récente</h3>
      <p className="card-subtitle">
        <Lightning size={14} weight="fill" className="text-green" />
        <span>{applications.filter(a => a.status === 'accepted').length} acceptées ce mois</span>
      </p>
    </div>
    <div className="activity-timeline">
      {applications.length === 0 ? (
        <div className="timeline-empty">
          <p>Aucune activité récente</p>
        </div>
      ) : (
        applications.slice(0, 5).map((app, index) => (
          <div key={app.id || index} className="timeline-item">
            <div className={`timeline-dot ${app.status}`}></div>
            <div className="timeline-content">
              <h4>{app.mission?.title || 'Candidature'}</h4>
              <p>{app.mission?.establishment_name}</p>
              <span className="timeline-date">
                {new Date(app.created_at).toLocaleDateString('fr-FR', { 
                  day: 'numeric', 
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </span>
            </div>
            <span className={`timeline-status ${app.status}`}>
              {app.status === 'pending' && 'En attente'}
              {app.status === 'accepted' && 'Acceptée'}
              {app.status === 'rejected' && 'Refusée'}
            </span>
          </div>
        ))
      )}
    </div>
  </div>
);

// Billing Information Card - Vision UI Style
const BillingCard = ({ profile, onEdit }: { profile: WorkerProfile | null; onEdit?: () => void }) => (
  <div className="billing-card">
    <div className="billing-header">
      <h3 className="card-title">Informations de facturation</h3>
      <button className="edit-btn" onClick={onEdit}>
        <Gear size={16} />
        Modifier
      </button>
    </div>
    <div className="billing-items">
      <div className="billing-item">
        <div className="billing-icon">
          <Wallet size={20} />
        </div>
        <div className="billing-info">
          <span className="billing-label">Tarif journalier</span>
          <span className="billing-value">{profile?.daily_rate || 0} DH/jour</span>
        </div>
      </div>
      <div className="billing-item">
        <div className="billing-icon">
          <CreditCard size={20} />
        </div>
        <div className="billing-info">
          <span className="billing-label">CIN</span>
          <span className="billing-value">{profile?.cin || 'Non renseigné'}</span>
        </div>
      </div>
      <div className="billing-item">
        <div className="billing-icon">
          <Phone size={20} />
        </div>
        <div className="billing-info">
          <span className="billing-label">Téléphone</span>
          <span className="billing-value">{profile?.phone || 'Non renseigné'}</span>
        </div>
      </div>
    </div>
  </div>
);

// Invoices / Diplomas Card - Vision UI Style
const DiplomasCard = ({ 
  diplomas, 
  onAdd 
}: { 
  diplomas: any[]; 
  onAdd: () => void;
}) => (
  <div className="invoices-card">
    <div className="invoices-header">
      <h3 className="card-title">Mes diplômes</h3>
      <button className="add-btn" onClick={onAdd}>
        <Plus size={16} />
        Ajouter
      </button>
    </div>
    <div className="invoices-list">
      {diplomas.length === 0 ? (
        <div className="invoices-empty">
          <FileText size={32} />
          <p>Aucun diplôme ajouté</p>
        </div>
      ) : (
        diplomas.slice(0, 4).map((diploma) => (
          <div key={diploma.id} className="invoice-item">
            <div className="invoice-info">
              <span className="invoice-date">
                {diploma.obtained_date ? new Date(diploma.obtained_date).getFullYear() : 'N/A'}
              </span>
              <h4 className="invoice-title">{diploma.title}</h4>
              <p className="invoice-institution">{diploma.institution}</p>
            </div>
            <div className="invoice-actions">
              <span className={`invoice-status ${diploma.is_verified ? 'verified' : 'pending'}`}>
                {diploma.is_verified ? (
                  <><CheckCircle size={14} /> Vérifié</>
                ) : (
                  <><Clock size={14} /> En attente</>
                )}
              </span>
              {diploma.file_path && (
                <button className="download-btn">
                  <DownloadSimple size={16} />
                </button>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  </div>
);

// Profile Card - Full Image with Blue Overlay & Animations
const ProfileCard = ({ profile, user }: { profile: WorkerProfile | null; user: any }) => (
  <div className="profile-card-vision">
    {/* Full Background Image */}
    <div className="profile-bg-image">
      {getProfilePictureUrl(profile?.profile_picture) ? (
        <img src={getProfilePictureUrl(profile?.profile_picture)!} alt="Profile" />
      ) : (
        <div className="profile-bg-placeholder">
          <span>{profile?.first_name?.charAt(0) || 'U'}</span>
        </div>
      )}
      <div className="profile-overlay"></div>
    </div>
    
    {/* Content Over Image */}
    <div className="profile-content">
      {profile?.is_labeled && (
        <div className="profile-badge animate-fade-in">
          <Medal size={14} weight="fill" />
          <span>Label Réseau</span>
        </div>
      )}
      
      <div className="profile-info-bottom">
        <h3 className="profile-name animate-slide-up">
          {formatName(profile?.first_name)} {formatName(profile?.last_name)}
        </h3>
        <p className="profile-role animate-slide-up delay-1">Travailleur Social</p>
        
        <div className="profile-stats animate-slide-up delay-2">
          <div className="profile-stat">
            <span className="stat-value">{profile?.total_missions || 0}</span>
            <span className="stat-label">Missions</span>
          </div>
          <div className="profile-stat">
            <span className="stat-value">{Number(profile?.average_rating || 0).toFixed(1)}</span>
            <span className="stat-label">Note</span>
          </div>
          <div className="profile-stat">
            <span className="stat-value">{profile?.years_experience || 0}</span>
            <span className="stat-label">Années</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Calendar Mini Widget
const CalendarWidget = () => {
  const today = new Date();
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).getDay();
  const monthNames = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
                      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
  
  return (
    <div className="calendar-widget">
      <div className="calendar-widget-header">
        <h3>{monthNames[today.getMonth()]} {today.getFullYear()}</h3>
        <div className="calendar-nav">
          <button><CaretLeft size={16} /></button>
          <button><CaretRight size={16} /></button>
        </div>
      </div>
      <div className="calendar-widget-days">
        {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => (
          <span key={i} className="day-name">{d}</span>
        ))}
        {Array.from({ length: (firstDay + 6) % 7 }, (_, i) => (
          <span key={`empty-${i}`} className="day-empty"></span>
        ))}
        {Array.from({ length: daysInMonth }, (_, i) => (
          <span 
            key={i + 1} 
            className={`day-number ${i + 1 === today.getDate() ? 'today' : ''}`}
          >
            {i + 1}
          </span>
        ))}
      </div>
    </div>
  );
};

// Sidebar Component - Vision UI Style
const Sidebar = ({ 
  activeTab, 
  setActiveTab, 
  onLogout 
}: { 
  activeTab: string; 
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Tableau de bord', icon: House },
    { id: 'missions', label: 'Missions', icon: Briefcase },
    { id: 'applications', label: 'Candidatures', icon: FileText },
    { id: 'cv-analyzer', label: 'Analyseur CV', icon: Sparkle },
    { id: 'calendar', label: 'Disponibilités', icon: CalendarBlank },
    { id: 'messages', label: 'Messages', icon: ChatCircle },
    { id: 'documents', label: 'Documents', icon: Receipt },
    { id: 'profile', label: 'Mon Profil', icon: UserCircle },
  ];

  return (
    <aside className="vision-sidebar">
      <Link to="/" className="sidebar-brand">
        <div className="brand-icon">
          <svg width="44" height="44" viewBox="0 0 48 48" fill="none">
            {/* Blue rounded square background */}
            <rect width="48" height="48" rx="12" fill="url(#blueGrad)"/>
            {/* People/social icon */}
            <g fill="white">
              {/* Top arc */}
              <path d="M14 20C14 15.5 18.5 12 24 12C29.5 12 34 15.5 34 20" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              {/* Left person */}
              <circle cx="16" cy="28" r="3"/>
              <path d="M12 36C12 33 13.8 31 16 31C18.2 31 20 33 20 36" fill="white"/>
              {/* Center person (larger) */}
              <circle cx="24" cy="26" r="4"/>
              <path d="M18 36C18 32 20.5 29 24 29C27.5 29 30 32 30 36" fill="white"/>
              {/* Right person */}
              <circle cx="32" cy="28" r="3"/>
              <path d="M28 36C28 33 29.8 31 32 31C34.2 31 36 33 36 36" fill="white"/>
            </g>
            <defs>
              <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#4F6AF6"/>
                <stop offset="100%" stopColor="#3B5BDB"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div className="brand-text-group">
          <span className="brand-text">TADAMON</span>
          <span className="brand-subtext">SOCIAL</span>
        </div>
      </Link>

      <div className="sidebar-divider"></div>

      <nav className="sidebar-nav">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => setActiveTab(item.id)}
          >
            <item.icon size={20} weight={activeTab === item.id ? 'fill' : 'regular'} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="sidebar-divider"></div>
        <button className="nav-item logout" onClick={onLogout}>
          <SignOut size={20} />
          <span>Déconnexion</span>
        </button>
      </div>
    </aside>
  );
};

// Top Navbar - Vision UI Style
const TopNavbar = ({ 
  user, 
  profile,
  activeTab,
  searchQuery,
  onSearchChange 
}: { 
  user: any; 
  profile: WorkerProfile | null;
  activeTab: string;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}) => {
  const { theme, toggleTheme } = useTheme();

  const getPageTitle = () => {
    const titles: { [key: string]: string } = {
      dashboard: 'Tableau de bord',
      missions: 'Missions',
      applications: 'Candidatures',
      calendar: 'Disponibilités',
      messages: 'Messages',
      documents: 'Documents',
      profile: 'Mon Profil',
    };
    return titles[activeTab] || 'Tableau de bord';
  };

  return (
    <header className="vision-navbar">
      <div className="navbar-left">
        <div className="breadcrumb">
          <span className="breadcrumb-item">Pages</span>
          <span className="breadcrumb-separator">/</span>
          <span className="breadcrumb-current">{getPageTitle()}</span>
        </div>
        <h1 className="page-title">{getPageTitle()}</h1>
      </div>
      <div className="navbar-right">
        <div className="search-box">
          <MagnifyingGlass size={18} />
          <input 
            type="text" 
            placeholder="Rechercher..." 
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
        <button className="navbar-btn" onClick={toggleTheme}>
          {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
        </button>
        <NotificationsDropdown />
        <div className="navbar-user">
          <div className="user-avatar">
            {getProfilePictureUrl(profile?.profile_picture) ? (
              <img 
                src={getProfilePictureUrl(profile?.profile_picture)!} 
                alt={`${profile?.first_name} ${profile?.last_name}`}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const parent = target.parentElement;
                  if (parent) {
                    parent.textContent = profile?.first_name?.charAt(0) || 'U';
                  }
                }}
              />
            ) : (
              profile?.first_name?.charAt(0) || 'U'
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

// Calendar Full Tab Component
// Note/Todo Item Type
interface TodoItem {
  id: string;
  text: string;
  completed: boolean;
  createdAt: string;
}

const CalendarTab = ({ profile }: { profile: any }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [availabilities, setAvailabilities] = useState<{ [key: string]: boolean }>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Notes & Todo State
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    const saved = localStorage.getItem('worker_todos');
    return saved ? JSON.parse(saved) : [];
  });
  const [newTodo, setNewTodo] = useState('');
  const [notes, setNotes] = useState(() => {
    return localStorage.getItem('worker_notes') || '';
  });

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  useEffect(() => {
    loadAvailabilities();
  }, [year, month]);

  // Save todos to localStorage
  useEffect(() => {
    localStorage.setItem('worker_todos', JSON.stringify(todos));
  }, [todos]);

  // Save notes to localStorage
  useEffect(() => {
    localStorage.setItem('worker_notes', notes);
  }, [notes]);

  const loadAvailabilities = async () => {
    setIsLoading(true);
    try {
      const res = await availabilityAPI.getMyAvailabilities(year, month + 1);
      const avails = res.data?.availabilities || res.availabilities || [];
      const availMap: { [key: string]: boolean } = {};
      avails.forEach((a: any) => {
        availMap[a.date] = a.is_available;
      });
      setAvailabilities(availMap);
    } catch (err) {
      console.log('No availabilities yet');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleDay = (dateStr: string) => {
    setAvailabilities(prev => ({
      ...prev,
      [dateStr]: !prev[dateStr]
    }));
  };

  const saveAvailabilities = async () => {
    setIsSaving(true);
    try {
      const availsToSave = Object.entries(availabilities).map(([date, is_available]) => ({
        date,
        is_available
      }));
      await availabilityAPI.bulkSetAvailabilities(availsToSave);
      showSuccess('Disponibilités enregistrées!');
    } catch (err) {
      showError('Erreur lors de l\'enregistrement');
    } finally {
      setIsSaving(false);
    }
  };

  // Todo functions
  const addTodo = () => {
    if (!newTodo.trim()) return;
    const todo: TodoItem = {
      id: Date.now().toString(),
      text: newTodo.trim(),
      completed: false,
      createdAt: new Date().toISOString()
    };
    setTodos(prev => [todo, ...prev]);
    setNewTodo('');
  };

  const toggleTodo = (id: string) => {
    setTodos(prev => prev.map(t => 
      t.id === id ? { ...t, completed: !t.completed } : t
    ));
  };

  const deleteTodo = (id: string) => {
    setTodos(prev => prev.filter(t => t.id !== id));
  };

  const getDaysInMonth = () => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1;
    
    const days = [];
    for (let i = 0; i < startingDay; i++) {
      days.push(null);
    }
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }
    return days;
  };

  const formatDateStr = (day: number) => {
    return `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  };

  const monthNames = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
                      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  const completedCount = todos.filter(t => t.completed).length;

  return (
    <div className="calendar-page">
      {/* Header */}
      <div className="calendar-page-header">
        <div className="calendar-title-section">
          <h2>Disponibilités & Notes</h2>
          <p>Gérez votre planning et vos tâches</p>
        </div>
        <button className="save-btn" onClick={saveAvailabilities} disabled={isSaving}>
          {isSaving ? 'Enregistrement...' : 'Enregistrer'}
        </button>
      </div>

      <div className="calendar-page-grid">
        {/* Calendar Section - Compact */}
        <div className="calendar-section">
          <div className="calendar-compact">
            <div className="calendar-nav-header">
              <button onClick={prevMonth}><CaretLeft size={18} /></button>
              <h3>{monthNames[month]} {year}</h3>
              <button onClick={nextMonth}><CaretRight size={18} /></button>
            </div>
            <div className="calendar-weekdays-compact">
              {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => (
                <span key={i}>{d}</span>
              ))}
            </div>
            <div className="calendar-days-compact">
              {getDaysInMonth().map((day, index) => {
                if (day === null) {
                  return <div key={`empty-${index}`} className="day-cell-compact empty"></div>;
                }
                const dateStr = formatDateStr(day);
                const isAvailable = availabilities[dateStr];
                const isToday = dateStr === todayStr;
                const isPast = new Date(dateStr) < new Date(todayStr);

                return (
                  <div
                    key={dateStr}
                    className={`day-cell-compact ${isAvailable ? 'available' : ''} ${isToday ? 'today' : ''} ${isPast ? 'past' : ''}`}
                    onClick={() => !isPast && toggleDay(dateStr)}
                  >
                    {day}
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Legend */}
          <div className="calendar-legend-compact">
            <div className="legend-row">
              <div className="legend-dot available"></div>
              <span>Disponible</span>
            </div>
            <div className="legend-row">
              <div className="legend-dot today"></div>
              <span>Aujourd'hui</span>
            </div>
          </div>
        </div>

        {/* Notes & Todo Section */}
        <div className="notes-section">
          {/* Todo List */}
          <div className="todo-card">
            <div className="todo-header">
              <h3>Liste de tâches</h3>
              <span className="todo-count">{completedCount}/{todos.length}</span>
            </div>
            
            <div className="todo-input-row">
              <input
                type="text"
                placeholder="Ajouter une tâche..."
                value={newTodo}
                onChange={(e) => setNewTodo(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addTodo()}
              />
              <button className="todo-add-btn" onClick={addTodo}>
                <Plus size={18} />
              </button>
            </div>

            <div className="todo-list">
              {todos.length === 0 ? (
                <div className="todo-empty">
                  <CheckCircle size={24} />
                  <p>Aucune tâche</p>
                </div>
              ) : (
                todos.map((todo) => (
                  <div key={todo.id} className={`todo-item ${todo.completed ? 'completed' : ''}`}>
                    <button 
                      className="todo-check" 
                      onClick={() => toggleTodo(todo.id)}
                    >
                      {todo.completed ? <CheckCircle size={18} weight="fill" /> : <div className="check-empty" />}
                    </button>
                    <span className="todo-text">{todo.text}</span>
                    <button className="todo-delete" onClick={() => deleteTodo(todo.id)}>
                      <X size={14} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Notes */}
          <div className="notes-card">
            <h3>Notes personnelles</h3>
            <textarea
              placeholder="Écrivez vos notes ici..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>
      </div>
    </div>
  );

};

// ============================================
// MAIN DASHBOARD COMPONENT
// ============================================

// Helper function to get full profile picture URL
const getProfilePictureUrl = (path: string | null | undefined): string | null => {
  if (!path) return null;
  if (path.startsWith('http://') || path.startsWith('https://')) return path;
  const apiUrl = (import.meta as any).env?.VITE_API_URL || 'http://localhost:5000/api';
  const backendUrl = apiUrl.replace('/api', '') || 'http://localhost:5000';
  // Ensure path doesn't start with / to avoid double slashes
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  return `${backendUrl}/${cleanPath}`;
};

// Helper function to format name (capitalize first letter, lowercase rest)
const formatName = (name: string | null | undefined): string => {
  if (!name) return '';
  return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
};

const TravailleurDashboard = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  
  // State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [applicationStatusFilter, setApplicationStatusFilter] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [profile, setProfile] = useState<WorkerProfile | null>(null);
  const [hasProfile, setHasProfile] = useState(false);
  const [missions, setMissions] = useState<Mission[]>([]);
  const [myApplications, setMyApplications] = useState<any[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [specialties, setSpecialties] = useState<any[]>([]);
  const [diplomas, setDiplomas] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showDiplomaModal, setShowDiplomaModal] = useState(false);
  const [isUploadingDiploma, setIsUploadingDiploma] = useState(false);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [profilePictureFile, setProfilePictureFile] = useState<File | null>(null);
  const [profilePicturePreview, setProfilePicturePreview] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [editProfileForm, setEditProfileForm] = useState({
    first_name: '',
    last_name: '',
    cin: '',
    phone: '',
    bio: '',
    daily_rate: '',
    region_id: '',
    city_id: '',
    years_experience: '',
    email: '',
  });
  const [diplomaForm, setDiplomaForm] = useState({
    title: '',
    institution: '',
    obtained_date: '',
    file: null as File | null,
  });
  
  // Profile form state
  const [profileForm, setProfileForm] = useState({
    first_name: '',
    last_name: '',
    cin: '',
    phone: '',
    bio: '',
    daily_rate: '',
    region_id: '',
    city_id: '',
  });
  
  // Stats state
  const [workerStats, setWorkerStats] = useState<any>(null);
  const [myReviews, setMyReviews] = useState<any[]>([]);

  // Load initial data
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      console.log('Loading regions and specialties...');
      const [regionsRes, specialtiesRes] = await Promise.all([
        regionAPI.getRegions(),
        regionAPI.getSpecialties(),
      ]);
      setRegions(regionsRes.data?.regions || []);
      setSpecialties(specialtiesRes.data?.specialties || []);
      console.log('Regions loaded:', regionsRes.data?.regions?.length || 0);

      try {
        console.log('Loading worker profile...');
        const profileRes = await workerAPI.getProfile();
        console.log('Profile response:', profileRes);
        
        if (profileRes.data?.profile) {
          setProfile(profileRes.data.profile);
          setHasProfile(true);
          console.log('Profile loaded successfully');
          
          // Load all dashboard data in parallel
          const [missionsRes, applicationsRes, diplomasRes, statsRes, reviewsRes] = await Promise.all([
            missionAPI.getMissions({ status: 'open', limit: 20 }),
            applicationAPI.getMyApplications(),
            diplomaAPI.getMyDiplomas(),
            statsAPI.getWorkerStats().catch(() => ({ data: null })),
            reviewAPI.getMyReviews().catch(() => ({ data: { reviews: [] } })),
          ]);
          
          setMissions(missionsRes.data?.missions || []);
          setMyApplications(applicationsRes.data?.applications || []);
          setDiplomas(diplomasRes.data?.diplomas || []);
          setWorkerStats(statsRes.data);
          setMyReviews(reviewsRes.data?.reviews || []);
          console.log('All data loaded');
        } else {
          console.log('No profile in response');
          setHasProfile(false);
        }
      } catch (err: any) {
        console.error('Error loading profile:', err.response?.status, err.response?.data || err.message);
        if (err.response?.status !== 404) {
          setError('Erreur lors du chargement du profil: ' + (err.response?.data?.message || err.message));
        }
        setHasProfile(false);
      }
    } catch (err: any) {
      console.error('Error loading data:', err);
      setError('Erreur lors du chargement des donnees: ' + (err.response?.data?.message || err.message));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegionChange = async (regionId: string) => {
    setProfileForm({ ...profileForm, region_id: regionId, city_id: '' });
    if (regionId) {
      try {
        const res = await regionAPI.getCitiesByRegion(parseInt(regionId));
        setCities(res.data?.cities || res.cities || []);
      } catch (err) {
        setCities([]);
      }
    } else {
      setCities([]);
    }
  };

  // Filter missions based on search query
  const filteredMissions = missions.filter(mission => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      mission.title?.toLowerCase().includes(query) ||
      mission.description?.toLowerCase().includes(query) ||
      mission.establishment_name?.toLowerCase().includes(query) ||
      mission.city_name?.toLowerCase().includes(query)
    );
  });

  // Filter applications based on search query
  const filteredApplications = myApplications.filter(app => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      app.mission_title?.toLowerCase().includes(query) ||
      app.establishment_name?.toLowerCase().includes(query)
    );
  });

  const handleCreateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      await workerAPI.createProfile({
        ...profileForm,
        daily_rate: parseFloat(profileForm.daily_rate) || 0,
        region_id: parseInt(profileForm.region_id),
        city_id: parseInt(profileForm.city_id),
      });
      await loadData();
      setActiveTab('dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Erreur lors de la création du profil');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyToMission = async (missionId: number) => {
    try {
      await applicationAPI.apply({
        mission_id: missionId,
        cover_letter: 'Je suis intéressé par cette mission.',
      });
      const res = await applicationAPI.getMyApplications();
      setMyApplications(res.data?.applications || []);
      showSuccess('Candidature envoyée!');
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors de la candidature');
    }
  };

  // Initialize edit profile form when profile loads
  const initEditProfileForm = () => {
    if (profile) {
      setEditProfileForm({
        first_name: profile.first_name || '',
        last_name: profile.last_name || '',
        cin: profile.cin || '',
        phone: profile.phone || '',
        bio: profile.bio || '',
        daily_rate: profile.daily_rate?.toString() || '',
        region_id: profile.region_id?.toString() || '',
        city_id: profile.city_id?.toString() || '',
        years_experience: profile.years_experience?.toString() || '',
        email: user?.email || '',
      });
      setProfilePicturePreview(getProfilePictureUrl(profile.profile_picture) || null);
    }
  };

  const handleEditRegionChange = async (regionId: string) => {
    setEditProfileForm({ ...editProfileForm, region_id: regionId, city_id: '' });
    if (regionId) {
      try {
        const res = await regionAPI.getCitiesByRegion(parseInt(regionId));
        setCities(res.data?.cities || res.cities || []);
      } catch (err) {
        setCities([]);
      }
    } else {
      setCities([]);
    }
  };

  const handleProfilePictureChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfilePictureFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicturePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async (e?: React.FormEvent | React.MouseEvent) => {
    if (e) e.preventDefault();
    setIsSavingProfile(true);
    
    try {
      // Update profile data
      await workerAPI.updateProfile({
        first_name: editProfileForm.first_name,
        last_name: editProfileForm.last_name,
        cin: editProfileForm.cin,
        phone: editProfileForm.phone,
        bio: editProfileForm.bio,
        daily_rate: parseFloat(editProfileForm.daily_rate) || 0,
        region_id: parseInt(editProfileForm.region_id) || undefined,
        city_id: parseInt(editProfileForm.city_id) || undefined,
        years_experience: parseInt(editProfileForm.years_experience) || 0,
      });

      // Upload profile picture if changed
      if (profilePictureFile) {
        const formData = new FormData();
        formData.append('profile_picture', profilePictureFile);
        await workerAPI.uploadDocuments(formData);
      }

      await loadData();
      setIsEditingProfile(false);
      setProfilePictureFile(null);
      showSuccess('Profil mis à jour avec succès!');
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors de la mise à jour');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showError('Les mots de passe ne correspondent pas');
      return;
    }
    
    if (passwordForm.newPassword.length < 8) {
      showError('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }

    try {
      // API call to change password would go here
      // await authAPI.changePassword(passwordForm);
      showSuccess('Mot de passe modifié avec succès!');
      setShowPasswordModal(false);
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors du changement de mot de passe');
    }
  };

  const handleUploadDiploma = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!diplomaForm.title || !diplomaForm.institution) {
      showError('Titre et institution requis');
      return;
    }

    setIsUploadingDiploma(true);
    try {
      const formData = new FormData();
      formData.append('title', diplomaForm.title);
      formData.append('institution', diplomaForm.institution);
      if (diplomaForm.obtained_date) formData.append('obtained_date', diplomaForm.obtained_date);
      if (diplomaForm.file) formData.append('diploma', diplomaForm.file);

      await diplomaAPI.addDiploma(formData);
      const res = await diplomaAPI.getMyDiplomas();
      setDiplomas(res.data?.diplomas || []);
      setDiplomaForm({ title: '', institution: '', obtained_date: '', file: null });
      setShowDiplomaModal(false);
      showSuccess('Diplôme ajouté!');
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur');
    } finally {
      setIsUploadingDiploma(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Loading state
  if (isLoading && !profile) {
    return (
      <div className="vision-loading">
        <div className="loading-spinner"></div>
        <p>Chargement...</p>
      </div>
    );
  }

  // Profile creation form
  if (!hasProfile) {
    return (
      <div className="vision-profile-creation">
        <div className="creation-card">
          <div className="creation-header">
            <h1>Créer votre profil</h1>
            <p>Complétez votre profil pour accéder aux missions</p>
          </div>

          {error && (
            <div className="error-alert">
              <WarningCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleCreateProfile} className="creation-form">
            <div className="form-row">
              <div className="form-group">
                <label>Prénom *</label>
                <input
                  type="text"
                  value={profileForm.first_name}
                  onChange={(e) => setProfileForm({ ...profileForm, first_name: e.target.value })}
                  placeholder="Votre prénom"
                  required
                />
              </div>
              <div className="form-group">
                <label>Nom *</label>
                <input
                  type="text"
                  value={profileForm.last_name}
                  onChange={(e) => setProfileForm({ ...profileForm, last_name: e.target.value })}
                  placeholder="Votre nom"
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>CIN *</label>
                <input
                  type="text"
                  value={profileForm.cin}
                  onChange={(e) => setProfileForm({ ...profileForm, cin: e.target.value.toUpperCase() })}
                  placeholder="Ex: AB123456"
                  required
                />
              </div>
              <div className="form-group">
                <label>Téléphone</label>
                <input
                  type="tel"
                  value={profileForm.phone}
                  onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                  placeholder="Ex: 0612345678"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Région *</label>
                <select value={profileForm.region_id} onChange={(e) => handleRegionChange(e.target.value)} required>
                  <option value="">Sélectionner</option>
                  {regions.map((r) => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Ville *</label>
                <select value={profileForm.city_id} onChange={(e) => setProfileForm({ ...profileForm, city_id: e.target.value })} required disabled={!profileForm.region_id}>
                  <option value="">Sélectionner</option>
                  {cities.map((c) => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                </select>
              </div>
            </div>

            <div className="form-group">
              <label>Tarif journalier (DH)</label>
              <input
                type="number"
                value={profileForm.daily_rate}
                onChange={(e) => setProfileForm({ ...profileForm, daily_rate: e.target.value })}
                placeholder="Ex: 500"
              />
            </div>

            <div className="form-group">
              <label>Bio</label>
              <textarea
                value={profileForm.bio}
                onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                placeholder="Décrivez votre expérience..."
                rows={4}
              />
            </div>

            <button type="submit" className="submit-btn" disabled={isLoading}>
              {isLoading ? 'Création...' : 'Créer mon profil'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Main Dashboard Render
  return (
    <div className="vision-dashboard">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />
      
      <main className="vision-main">
        <TopNavbar user={user} profile={profile} activeTab={activeTab} searchQuery={searchQuery} onSearchChange={setSearchQuery} />

        {/* Status Banner */}
        {profile?.status === 'pending' && (
          <div className="status-alert warning">
            <WarningCircle size={18} />
            <span>Votre profil est en attente de validation</span>
          </div>
        )}

        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="dashboard-content">
            {/* Row 1: Profile + Satisfaction + Quick Actions */}
            <div className="dashboard-row row-top-new">
              <ProfileCard profile={profile} user={user} />
              <SatisfactionCard rating={profile?.average_rating || 0} />
              <QuickActionsCard 
                profile={profile} 
                missionsCount={missions.length}
                applicationsCount={myApplications.length}
                onNavigate={setActiveTab}
              />
            </div>

            {/* Row 2: Mini Stats */}
            <div className="dashboard-row row-stats">
              <MiniStatCard 
                title="Missions en cours" 
                value={workerStats?.missions_in_progress || myApplications.filter(a => a.status === 'accepted').length}
                icon={Briefcase}
                gradient="blue"
              />
              <MiniStatCard 
                title="Missions terminées" 
                value={workerStats?.total_missions || profile?.total_missions || 0}
                icon={CheckCircle}
                gradient="green"
              />
              <MiniStatCard 
                title="Note moyenne" 
                value={Number(workerStats?.average_rating || profile?.average_rating || 0).toFixed(1)}
                icon={Star}
                gradient="orange"
              />
              <MiniStatCard 
                title="Avis reçus" 
                value={workerStats?.reviews_count || myReviews.length || 0}
                icon={ChatCircle}
                gradient="purple"
              />
            </div>

            {/* Row 3: Projects Table + Globe */}
            <div className="dashboard-row row-main-globe">
              <ProjectsTable missions={filteredMissions} onApply={handleApplyToMission} />
              <GlobeCard 
                missions={filteredMissions} 
                isExpanded={expandedCard === 'globe'}
                onExpand={() => setExpandedCard('globe')}
                onClose={() => setExpandedCard(null)}
              />
            </div>

            {/* Row 4: Billing + Activity + Diplomas */}
            <div className="dashboard-row row-bottom-new">
              <BillingCard profile={profile} onEdit={() => setActiveTab('profile')} />
              <ActivityTimeline applications={myApplications} />
              <DiplomasCard diplomas={diplomas} onAdd={() => setShowDiplomaModal(true)} />
            </div>
            
            {/* Expanded Card Backdrop */}
            {expandedCard && (
              <div className="expanded-backdrop" onClick={() => setExpandedCard(null)}></div>
            )}
          </div>
        )}

        {/* Missions Tab */}
        {activeTab === 'missions' && (
          <div className="tab-content-vision">
            <ProjectsTable missions={filteredMissions} onApply={handleApplyToMission} />
          </div>
        )}

        {/* Applications Tab */}
        {activeTab === 'applications' && (
          <div className="tab-content-vision">
            {/* Application Status Filter Tabs */}
            <div className="application-status-tabs" style={{ display: 'flex', gap: '8px', marginBottom: '24px', borderBottom: '2px solid #e5e7eb', paddingBottom: '8px' }}>
              <button 
                className={`status-tab-btn ${applicationStatusFilter === 'all' ? 'active' : ''}`}
                onClick={() => setApplicationStatusFilter('all')}
                style={{ 
                  padding: '8px 16px', 
                  border: 'none', 
                  background: applicationStatusFilter === 'all' ? '#3b82f6' : 'transparent',
                  color: applicationStatusFilter === 'all' ? 'white' : '#6b7280',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: applicationStatusFilter === 'all' ? '600' : '400',
                  transition: 'all 0.2s'
                }}
              >
                Toutes ({filteredApplications.length})
              </button>
              <button 
                className={`status-tab-btn ${applicationStatusFilter === 'pending' ? 'active' : ''}`}
                onClick={() => setApplicationStatusFilter('pending')}
                style={{ 
                  padding: '8px 16px', 
                  border: 'none', 
                  background: applicationStatusFilter === 'pending' ? '#3b82f6' : 'transparent',
                  color: applicationStatusFilter === 'pending' ? 'white' : '#6b7280',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: applicationStatusFilter === 'pending' ? '600' : '400',
                  transition: 'all 0.2s'
                }}
              >
                En attente ({filteredApplications.filter(a => a.status === 'pending').length})
              </button>
              <button 
                className={`status-tab-btn ${applicationStatusFilter === 'accepted' ? 'active' : ''}`}
                onClick={() => setApplicationStatusFilter('accepted')}
                style={{ 
                  padding: '8px 16px', 
                  border: 'none', 
                  background: applicationStatusFilter === 'accepted' ? '#3b82f6' : 'transparent',
                  color: applicationStatusFilter === 'accepted' ? 'white' : '#6b7280',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: applicationStatusFilter === 'accepted' ? '600' : '400',
                  transition: 'all 0.2s'
                }}
              >
                Acceptées ({filteredApplications.filter(a => a.status === 'accepted').length})
              </button>
              <button 
                className={`status-tab-btn ${applicationStatusFilter === 'rejected' ? 'active' : ''}`}
                onClick={() => setApplicationStatusFilter('rejected')}
                style={{ 
                  padding: '8px 16px', 
                  border: 'none', 
                  background: applicationStatusFilter === 'rejected' ? '#3b82f6' : 'transparent',
                  color: applicationStatusFilter === 'rejected' ? 'white' : '#6b7280',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: applicationStatusFilter === 'rejected' ? '600' : '400',
                  transition: 'all 0.2s'
                }}
              >
                Refusées ({filteredApplications.filter(a => a.status === 'rejected').length})
              </button>
            </div>

            {(() => {
              const displayApplications = filteredApplications.filter(app => {
                if (applicationStatusFilter === 'all') return true;
                return app.status === applicationStatusFilter;
              });

              return displayApplications.length === 0 ? (
                <div className="empty-state-vision">
                  <FileText size={48} />
                  <h3>
                    {applicationStatusFilter === 'all' ? 'Aucune candidature' :
                     applicationStatusFilter === 'pending' ? 'Aucune candidature en attente' :
                     applicationStatusFilter === 'accepted' ? 'Aucune candidature acceptée' :
                     'Aucune candidature refusée'}
                  </h3>
                  <p>
                    {applicationStatusFilter === 'all' ? 'Vous n\'avez pas encore postulé à des missions' :
                     applicationStatusFilter === 'pending' ? 'Vous n\'avez pas de candidatures en attente de réponse' :
                     applicationStatusFilter === 'accepted' ? 'Vous n\'avez pas encore de candidatures acceptées' :
                     'Vous n\'avez pas de candidatures refusées'}
                  </p>
                </div>
              ) : (
                <div className="applications-grid">
                  {displayApplications.map((app) => (
                    <div key={app.id} className="application-card-vision">
                      <div className="app-header">
                        <div className="app-icon">
                          <Briefcase size={20} />
                        </div>
                        <div className="app-info">
                          <h4>{app.mission?.title || 'Mission'}</h4>
                          <p>{app.mission?.establishment_name}</p>
                        </div>
                        <span className={`app-status ${app.status}`}>
                          {app.status === 'pending' && 'En attente'}
                          {app.status === 'accepted' && 'Acceptée'}
                          {app.status === 'rejected' && 'Refusée'}
                        </span>
                      </div>
                      <div className="app-footer">
                        <span className="app-date">
                          <Clock size={14} />
                          {new Date(app.created_at).toLocaleDateString('fr-FR')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        )}

        {/* Calendar Tab */}
        {activeTab === 'calendar' && (
          <div className="tab-content-vision">
            <CalendarTab profile={profile} />
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="tab-content-vision">
            <MessagingPanel userRole="worker" />
          </div>
        )}

        {/* CV Analyzer Tab */}
        {activeTab === 'cv-analyzer' && (
          <div className="tab-content-vision">
            <CVAnalyzer 
              workerProfile={profile ? {
                first_name: profile.first_name,
                last_name: profile.last_name,
                bio: profile.bio,
                phone: profile.phone,
                city_name: profile.city_name,
                region_name: profile.region_name,
                years_experience: profile.years_experience,
                daily_rate: profile.daily_rate,
                specialties: profile.specialties,
                diplomas: diplomas.map(d => ({ title: d.title, institution: d.institution }))
              } : undefined}
            />
          </div>
        )}

        {/* Documents Tab */}
        {activeTab === 'documents' && (
          <div className="tab-content-vision">
            <div className="documents-header">
              <h2>Mes diplômes et documents</h2>
              <button className="add-document-btn" onClick={() => setShowDiplomaModal(true)}>
                <Plus size={18} />
                Ajouter un diplôme
              </button>
            </div>
            <DiplomasCard diplomas={diplomas} onAdd={() => setShowDiplomaModal(true)} />
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="tab-content-vision">
            <div className="profile-page-vision">
              {/* Profile Header - Same style as ProfileCard */}
              <div className="profile-header-row">
                <div className="profile-card-vision profile-card-large">
                  {/* Full Background Image */}
                  <div className="profile-bg-image">
                    {profilePicturePreview || getProfilePictureUrl(profile?.profile_picture) ? (
                      <img src={profilePicturePreview || getProfilePictureUrl(profile?.profile_picture)!} alt="Profile" />
                    ) : (
                      <div className="profile-bg-placeholder">
                        <span>{profile?.first_name?.charAt(0) || 'U'}</span>
                      </div>
                    )}
                    <div className="profile-overlay"></div>
                  </div>
                  
                  {/* Content Over Image */}
                  <div className="profile-content">
                    {profile?.is_labeled && (
                      <div className="profile-badge animate-fade-in">
                        <Medal size={14} weight="fill" />
                        <span>Label Réseau</span>
                      </div>
                    )}
                    
                    {/* Upload button when editing */}
                    {isEditingProfile && (
                      <label className="profile-upload-overlay">
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={handleProfilePictureChange}
                          hidden 
                        />
                        <UploadSimple size={32} />
                        <span>Changer la photo</span>
                      </label>
                    )}
                    
                    <div className="profile-info-bottom">
                      <h3 className="profile-name animate-slide-up">
                        {formatName(profile?.first_name)} {formatName(profile?.last_name)}
                      </h3>
                      <p className="profile-role animate-slide-up delay-1">Travailleur Social</p>
                      
                      <div className="profile-stats animate-slide-up delay-2">
                        <div className="profile-stat">
                          <span className="stat-value">{profile?.total_missions || 0}</span>
                          <span className="stat-label">Missions</span>
                        </div>
                        <div className="profile-stat">
                          <span className="stat-value">{Number(profile?.average_rating || 0).toFixed(1)}</span>
                          <span className="stat-label">Note</span>
                        </div>
                        <div className="profile-stat">
                          <span className="stat-value">{profile?.years_experience || 0}</span>
                          <span className="stat-label">Années</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Actions Card */}
                <div className="profile-actions-card">
                  <h3>Actions</h3>
                  {!isEditingProfile ? (
                    <button className="btn-edit-profile" onClick={() => { initEditProfileForm(); setIsEditingProfile(true); }}>
                      <Gear size={18} />
                      Modifier le profil
                    </button>
                  ) : (
                    <div className="edit-actions-vertical">
                      <button className="btn-save-profile" onClick={handleSaveProfile} disabled={isSavingProfile}>
                        {isSavingProfile ? 'Enregistrement...' : 'Enregistrer les modifications'}
                      </button>
                      <button className="btn-cancel-edit" onClick={() => { setIsEditingProfile(false); setProfilePictureFile(null); setProfilePicturePreview(getProfilePictureUrl(profile?.profile_picture) || null); }}>
                        Annuler
                      </button>
                    </div>
                  )}
                  <div className="profile-status-info">
                    <span className={`status-badge ${profile?.status}`}>
                      {profile?.status === 'approved' ? 'Profil vérifié' : 'En attente de validation'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Profile Content Grid */}
              <div className="profile-content-grid">
                {/* Personal Information */}
                <div className="profile-section-card">
                  <div className="section-header">
                    <h3><User size={18} /> Informations personnelles</h3>
                  </div>
                  <div className="section-content">
                    {isEditingProfile ? (
                      <div className="edit-form-grid">
                        <div className="form-group">
                          <label>Prénom *</label>
                          <input 
                            type="text" 
                            value={editProfileForm.first_name}
                            onChange={(e) => setEditProfileForm({...editProfileForm, first_name: e.target.value})}
                          />
                        </div>
                        <div className="form-group">
                          <label>Nom *</label>
                          <input 
                            type="text" 
                            value={editProfileForm.last_name}
                            onChange={(e) => setEditProfileForm({...editProfileForm, last_name: e.target.value})}
                          />
                        </div>
                        <div className="form-group">
                          <label>CIN *</label>
                          <input 
                            type="text" 
                            value={editProfileForm.cin}
                            onChange={(e) => setEditProfileForm({...editProfileForm, cin: e.target.value.toUpperCase()})}
                          />
                        </div>
                        <div className="form-group">
                          <label>Téléphone</label>
                          <input 
                            type="tel" 
                            value={editProfileForm.phone}
                            onChange={(e) => setEditProfileForm({...editProfileForm, phone: e.target.value})}
                          />
                        </div>
                        <div className="form-group">
                          <label>Années d'expérience</label>
                          <input 
                            type="number" 
                            value={editProfileForm.years_experience}
                            onChange={(e) => setEditProfileForm({...editProfileForm, years_experience: e.target.value})}
                          />
                        </div>
                        <div className="form-group">
                          <label>Tarif journalier (DH)</label>
                          <input 
                            type="number" 
                            value={editProfileForm.daily_rate}
                            onChange={(e) => setEditProfileForm({...editProfileForm, daily_rate: e.target.value})}
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="info-grid">
                        <div className="info-item">
                          <span className="info-label">Prénom</span>
                          <span className="info-value">{profile?.first_name || '-'}</span>
                        </div>
                        <div className="info-item">
                          <span className="info-label">Nom</span>
                          <span className="info-value">{profile?.last_name || '-'}</span>
                        </div>
                        <div className="info-item">
                          <span className="info-label">CIN</span>
                          <span className="info-value">{profile?.cin || '-'}</span>
                        </div>
                        <div className="info-item">
                          <span className="info-label">Téléphone</span>
                          <span className="info-value">{profile?.phone || '-'}</span>
                        </div>
                        <div className="info-item">
                          <span className="info-label">Expérience</span>
                          <span className="info-value">{profile?.years_experience || 0} ans</span>
                        </div>
                        <div className="info-item">
                          <span className="info-label">Tarif journalier</span>
                          <span className="info-value">{profile?.daily_rate || 0} DH</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Location */}
                <div className="profile-section-card">
                  <div className="section-header">
                    <h3><MapPin size={18} /> Adresse</h3>
                  </div>
                  <div className="section-content">
                    {isEditingProfile ? (
                      <div className="edit-form-grid">
                        <div className="form-group">
                          <label>Région</label>
                          <select 
                            value={editProfileForm.region_id} 
                            onChange={(e) => handleEditRegionChange(e.target.value)}
                          >
                            <option value="">Sélectionner</option>
                            {regions.map((r) => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                          </select>
                        </div>
                        <div className="form-group">
                          <label>Ville</label>
                          <select 
                            value={editProfileForm.city_id} 
                            onChange={(e) => setEditProfileForm({...editProfileForm, city_id: e.target.value})}
                            disabled={!editProfileForm.region_id}
                          >
                            <option value="">Sélectionner</option>
                            {cities.map((c) => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                          </select>
                        </div>
                      </div>
                    ) : (
                      <div className="info-grid">
                        <div className="info-item full-width">
                          <span className="info-label">Localisation</span>
                          <span className="info-value">
                            {regions.find(r => r.id === profile?.region_id)?.name_fr || 'Non renseigné'}
                            {profile?.city_id && `, ${cities.find(c => c.id === profile?.city_id)?.name_fr || ''}`}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Account & Security */}
                <div className="profile-section-card">
                  <div className="section-header">
                    <h3><Envelope size={18} /> Compte & Sécurité</h3>
                  </div>
                  <div className="section-content">
                    <div className="info-grid">
                      <div className="info-item full-width">
                        <span className="info-label">Email</span>
                        <span className="info-value">{user?.email || '-'}</span>
                      </div>
                    </div>
                    <div className="security-actions">
                      <button className="btn-security" onClick={() => setShowPasswordModal(true)}>
                        <Gear size={16} />
                        Changer le mot de passe
                      </button>
                    </div>
                  </div>
                </div>

                {/* Bio - Same row as Account & Security */}
                <div className="profile-section-card">
                  <div className="section-header">
                    <h3><FileText size={18} /> Présentation</h3>
                  </div>
                  <div className="section-content">
                    {isEditingProfile ? (
                      <div className="form-group">
                        <textarea 
                          value={editProfileForm.bio}
                          onChange={(e) => setEditProfileForm({...editProfileForm, bio: e.target.value})}
                          placeholder="Décrivez votre parcours et vos compétences..."
                          rows={4}
                        />
                      </div>
                    ) : (
                      <p className="bio-text">{profile?.bio || 'Aucune description ajoutée.'}</p>
                    )}
                  </div>
                </div>

                {/* Specialties */}
                <div className="profile-section-card">
                  <div className="section-header">
                    <h3><Star size={18} /> Spécialités</h3>
                  </div>
                  <div className="section-content">
                    {profile?.specialties && profile.specialties.length > 0 ? (
                      <div className="specialties-tags">
                        {profile.specialties.map((s: any, i: number) => (
                          <span key={i} className="specialty-tag">{s.name}</span>
                        ))}
                      </div>
                    ) : (
                      <p className="no-data">Aucune spécialité ajoutée</p>
                    )}
                  </div>
                </div>

                {/* Stats */}
                <div className="profile-section-card">
                  <div className="section-header">
                    <h3><ChartLineUp size={18} /> Statistiques</h3>
                  </div>
                  <div className="section-content">
                    <div className="stats-grid">
                      <div className="stat-box">
                        <span className="stat-number">{profile?.total_missions || 0}</span>
                        <span className="stat-text">Missions</span>
                      </div>
                      <div className="stat-box">
                        <span className="stat-number">{Number(profile?.average_rating || 0).toFixed(1)}</span>
                        <span className="stat-text">Note</span>
                      </div>
                      <div className="stat-box">
                        <span className="stat-number">{myApplications.filter(a => a.status === 'accepted').length}</span>
                        <span className="stat-text">En cours</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="modal-overlay" onClick={() => setShowPasswordModal(false)}>
          <div className="modal-vision" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Changer le mot de passe</h2>
              <button className="modal-close" onClick={() => setShowPasswordModal(false)}>
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleChangePassword} className="modal-form">
              <div className="form-group">
                <label>Mot de passe actuel *</label>
                <input 
                  type="password" 
                  value={passwordForm.currentPassword}
                  onChange={(e) => setPasswordForm({...passwordForm, currentPassword: e.target.value})}
                  required 
                />
              </div>
              <div className="form-group">
                <label>Nouveau mot de passe *</label>
                <input 
                  type="password" 
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm({...passwordForm, newPassword: e.target.value})}
                  required 
                />
                <span className="form-hint">Minimum 8 caractères</span>
              </div>
              <div className="form-group">
                <label>Confirmer le mot de passe *</label>
                <input 
                  type="password" 
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm({...passwordForm, confirmPassword: e.target.value})}
                  required 
                />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-cancel" onClick={() => setShowPasswordModal(false)}>Annuler</button>
                <button type="submit" className="btn-submit">Changer</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Diploma Modal */}
      {showDiplomaModal && (
        <div className="modal-overlay" onClick={() => setShowDiplomaModal(false)}>
          <div className="modal-vision" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Ajouter un diplôme</h2>
              <button className="modal-close" onClick={() => setShowDiplomaModal(false)}>
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleUploadDiploma} className="modal-form">
              <div className="form-group">
                <label>Titre du diplôme *</label>
                <input type="text" value={diplomaForm.title} onChange={(e) => setDiplomaForm({ ...diplomaForm, title: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Institution *</label>
                <input type="text" value={diplomaForm.institution} onChange={(e) => setDiplomaForm({ ...diplomaForm, institution: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Date d'obtention</label>
                <input type="date" value={diplomaForm.obtained_date} onChange={(e) => setDiplomaForm({ ...diplomaForm, obtained_date: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Document (PDF)</label>
                <div className="file-upload-vision">
                  <input type="file" accept=".pdf" onChange={(e) => setDiplomaForm({ ...diplomaForm, file: e.target.files?.[0] || null })} />
                  <UploadSimple size={24} />
                  <span>{diplomaForm.file ? diplomaForm.file.name : 'Cliquez pour sélectionner'}</span>
                </div>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-cancel" onClick={() => setShowDiplomaModal(false)}>Annuler</button>
                <button type="submit" className="btn-submit" disabled={isUploadingDiploma}>
                  {isUploadingDiploma ? 'Ajout...' : 'Ajouter'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TravailleurDashboard;
