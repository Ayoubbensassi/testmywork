import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Briefcase, Users, Clock, Star, Plus, MagnifyingGlass, MapPin, CalendarBlank,
  Eye, CheckCircle, XCircle, Gear, TrendUp, ChatCircle, SignOut, CaretDown,
  Medal, X, FileText, CurrencyDollar, WarningCircle, Buildings, House, Moon, Sun,
  User, ArrowUp, ArrowDown, DotsThreeVertical, Lightning, Phone, Envelope,
  ChartLineUp, Receipt, UserCircle, Bell, CaretRight, Wallet
} from '@phosphor-icons/react';
import { useAuth } from '../../AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { missionAPI, applicationAPI, workerAPI, regionAPI, establishmentAPI, statsAPI, reviewAPI, messageAPI } from '../../services/api';
import { showSuccess, showError } from '../common/Toast';
import MessagingPanel from '../messaging/MessagingPanel';
import NotificationsDropdown from '../common/NotificationsDropdown';
import '../../styles/dashboard-unified.css';
import '../../styles/EtablissementDashboard.css';
import '../../styles/dashboard-light-mode.css';

// Types
interface EstablishmentProfile {
  id: number;
  name: string;
  legal_name: string;
  ice: string;
  type: string;
  phone?: string;
  email?: string;
  region_id?: number;
  city_id?: number;
  address?: string;
  description?: string;
  logo?: string;
  is_verified: boolean;
  average_rating: number;
  total_missions: number;
  region_name?: string;
  city_name?: string;
}

interface Mission {
  id: number;
  title: string;
  description: string;
  start_date: string;
  end_date: string;
  status: string;
  applications_count?: number;
  salary_min?: number;
  salary_max?: number;
  city_name?: string;
  region_name?: string;
  is_urgent?: boolean;
}

interface Application {
  id: number;
  mission_id: number;
  mission_title?: string;
  worker_id: number;
  first_name: string;
  last_name: string;
  profile_picture?: string;
  average_rating: number;
  total_missions: number;
  is_labeled: boolean;
  cover_letter: string;
  proposed_rate: number;
  status: string;
  created_at: string;
}

interface Worker {
  id: number;
  user_id: number;
  first_name: string;
  last_name: string;
  profile_picture?: string;
  bio?: string;
  daily_rate: number;
  years_experience: number;
  average_rating: number;
  total_missions: number;
  is_labeled: boolean;
  status: string;
  region_name?: string;
  city_name?: string;
  specialties?: any[];
}

interface Region {
  id: number;
  name_fr: string;
}

interface Specialty {
  id: number;
  name: string;
  category: string;
}

// Helper functions
const formatDate = (dateStr: string) => {
  return new Date(dateStr).toLocaleDateString('fr-FR', {
    day: 'numeric', month: 'short', year: 'numeric',
  });
};

const getProfilePictureUrl = (path: string | null | undefined): string | null => {
  if (!path) return null;
  if (path.startsWith('http://') || path.startsWith('https://')) return path;
  const apiUrl = (import.meta as any).env?.VITE_API_URL || 'http://localhost:5000/api';
  const backendUrl = apiUrl.replace('/api', '') || 'http://localhost:5000';
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  return `${backendUrl}/${cleanPath}`;
};

// ============================================
// VISION UI COMPONENTS
// ============================================

// Mini Statistics Card
const MiniStatCard = ({ 
  title, value, icon: Icon, gradient 
}: { 
  title: string; value: string | number; icon: any; gradient: 'blue' | 'green' | 'orange' | 'purple' | 'pink';
}) => (
  <div className="mini-stat-card">
    <div className="mini-stat-content">
      <p className="mini-stat-title">{title}</p>
      <h3 className="mini-stat-value">{value}</h3>
    </div>
    <div className={`mini-stat-icon gradient-${gradient}`}>
      <Icon size={22} weight="fill" />
    </div>
  </div>
);

// Quick Actions Card for Establishment
const EstablishmentQuickActions = ({ 
  profile, stats, onNavigate, onNewMission 
}: { 
  profile: EstablishmentProfile | null;
  stats: any;
  onNavigate: (tab: string) => void;
  onNewMission: () => void;
}) => {
  const today = new Date();
  const hour = today.getHours();
  const greeting = hour < 12 ? 'Bonjour' : hour < 18 ? 'Bon après-midi' : 'Bonsoir';
  
  return (
    <div className="quick-actions-card">
      <div className="quick-header">
        <div className="quick-greeting">
          <h2>{greeting} 👋</h2>
          <p>{today.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
        </div>
      </div>
      
      <div className="quick-summary">
        <div className="summary-item" onClick={() => onNavigate('missions')}>
          <div className="summary-icon blue">
            <Briefcase size={20} weight="fill" />
          </div>
          <div className="summary-info">
            <span className="summary-value">{stats.activeMissions}</span>
            <span className="summary-label">Missions actives</span>
          </div>
          <CaretRight size={18} className="summary-arrow" />
        </div>
        
        <div className="summary-item" onClick={() => onNavigate('applications')}>
          <div className="summary-icon orange">
            <FileText size={20} weight="fill" />
          </div>
          <div className="summary-info">
            <span className="summary-value">{stats.pendingApplications}</span>
            <span className="summary-label">Candidatures en attente</span>
          </div>
          <CaretRight size={18} className="summary-arrow" />
        </div>
        
        <div className="summary-item" onClick={() => onNavigate('workers')}>
          <div className="summary-icon green">
            <Users size={20} weight="fill" />
          </div>
          <div className="summary-info">
            <span className="summary-value">Rechercher</span>
            <span className="summary-label">Trouver des professionnels</span>
          </div>
          <CaretRight size={18} className="summary-arrow" />
        </div>
      </div>
      
      <div className="quick-actions-btns">
        <button className="quick-btn primary" onClick={onNewMission}>
          <Plus size={18} />
          Nouvelle mission
        </button>
        <button className="quick-btn secondary" onClick={() => onNavigate('profile')}>
          <Buildings size={18} />
          Mon établissement
        </button>
      </div>
    </div>
  );
};

// Satisfaction/Rating Card
const RatingCard = ({ rating, reviewsCount }: { rating: number; reviewsCount: number }) => {
  const numRating = Number(rating) || 0;
  const percentage = (numRating / 5) * 100;
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;
  
  return (
    <div className="satisfaction-card-compact">
      <div className="satisfaction-content">
        <div className="satisfaction-chart-small">
          <svg viewBox="0 0 100 100" className="circular-progress">
            <circle cx="50" cy="50" r="45" className="progress-bg" />
            <circle 
              cx="50" cy="50" r="45" 
              className="progress-fill"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
            />
          </svg>
          <div className="satisfaction-value">
            <span className="value">{numRating.toFixed(1)}</span>
            <span className="max">/5</span>
          </div>
        </div>
        <div className="satisfaction-info">
          <h3>Note moyenne</h3>
          <p>{reviewsCount} avis reçus</p>
        </div>
      </div>
    </div>
  );
};

// Profile Card for Establishment
const EstablishmentProfileCard = ({ profile }: { profile: EstablishmentProfile | null }) => (
  <div className="profile-card-vision">
    <div className="profile-bg-image">
      {profile?.logo ? (
        <img src={getProfilePictureUrl(profile.logo)!} alt="Logo" />
      ) : (
        <div className="profile-bg-placeholder establishment">
          <Buildings size={48} weight="fill" />
        </div>
      )}
      <div className="profile-overlay"></div>
    </div>
    
    <div className="profile-content">
      {profile?.is_verified && (
        <div className="profile-badge animate-fade-in verified">
          <CheckCircle size={14} weight="fill" />
          <span>Vérifié</span>
        </div>
      )}
      
      <div className="profile-info-bottom">
        <h3 className="profile-name animate-slide-up">{profile?.name || 'Établissement'}</h3>
        <p className="profile-role animate-slide-up delay-1">{profile?.type || 'Association'}</p>
        
        <div className="profile-stats animate-slide-up delay-2">
          <div className="profile-stat">
            <span className="stat-value">{profile?.total_missions || 0}</span>
            <span className="stat-label">Missions</span>
          </div>
          <div className="profile-stat">
            <span className="stat-value">{Number(profile?.average_rating || 0).toFixed(1)}</span>
            <span className="stat-label">Note</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Missions Table
const MissionsTable = ({ missions, onViewApplications }: { missions: Mission[]; onViewApplications: (id: number) => void }) => (
  <div className="projects-card">
    <div className="projects-header">
      <div>
        <h3 className="card-title">Mes missions</h3>
        <p className="card-subtitle">{missions.length} missions publiées</p>
      </div>
      <button className="icon-btn">
        <DotsThreeVertical size={20} />
      </button>
    </div>
    <div className="projects-table">
      <div className="table-header">
        <span className="col-mission">Mission</span>
        <span className="col-location">Lieu</span>
        <span className="col-salary">Salaire</span>
        <span className="col-date">Date</span>
        <span className="col-action">Candidatures</span>
      </div>
      <div className="table-body">
        {missions.length === 0 ? (
          <div className="table-empty">
            <Briefcase size={32} />
            <p>Aucune mission publiée</p>
          </div>
        ) : (
          missions.slice(0, 5).map((mission) => (
            <div key={mission.id} className="table-row">
              <div className="col-mission">
                <div className="mission-icon">
                  <Briefcase size={18} />
                </div>
                <div className="mission-info">
                  <h4>{mission.title}</h4>
                  <p>{mission.status === 'open' ? 'Ouverte' : mission.status === 'in_progress' ? 'En cours' : 'Terminée'}</p>
                </div>
                {mission.is_urgent && <span className="urgent-badge">Urgent</span>}
              </div>
              <div className="col-location">
                <MapPin size={14} />
                <span>{mission.city_name || 'Maroc'}</span>
              </div>
              <div className="col-salary">
                <span className="salary-value">{mission.salary_min || 0} - {mission.salary_max || 0} DH</span>
              </div>
              <div className="col-date">
                <Clock size={14} />
                <span>{formatDate(mission.start_date)}</span>
              </div>
              <div className="col-action">
                <button className="apply-btn" onClick={() => onViewApplications(mission.id)}>
                  <Users size={14} /> {mission.applications_count || 0}
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  </div>
);

// Applications Timeline
const ApplicationsTimeline = ({ applications, onAccept, onReject }: { 
  applications: Application[]; 
  onAccept: (id: number) => void;
  onReject: (id: number) => void;
}) => (
  <div className="activity-card">
    <div className="activity-header">
      <h3 className="card-title">Candidatures récentes</h3>
      <p className="card-subtitle">
        <Lightning size={14} weight="fill" className="text-orange" />
        <span>{applications.filter(a => a.status === 'pending').length} en attente</span>
      </p>
    </div>
    <div className="activity-timeline">
      {applications.length === 0 ? (
        <div className="timeline-empty">
          <p>Aucune candidature reçue</p>
        </div>
      ) : (
        applications.slice(0, 5).map((app) => (
          <div key={app.id} className="timeline-item application-timeline-item">
            <div className="applicant-avatar-small">
              {app.profile_picture ? (
                <img src={getProfilePictureUrl(app.profile_picture)!} alt="" />
              ) : (
                <span>{app.first_name?.charAt(0)}{app.last_name?.charAt(0)}</span>
              )}
              {app.is_labeled && <div className="label-dot"><Medal size={8} /></div>}
            </div>
            <div className="timeline-content">
              <h4>{app.first_name} {app.last_name}</h4>
              <p>{app.mission_title || 'Mission'}</p>
              <div className="applicant-meta">
                <span><Star size={12} /> {Number(app.average_rating || 0).toFixed(1)}</span>
                <span><Briefcase size={12} /> {app.total_missions || 0}</span>
              </div>
            </div>
            {app.status === 'pending' ? (
              <div className="timeline-actions">
                <button className="btn-accept-sm" onClick={() => onAccept(app.id)}><CheckCircle size={16} /></button>
                <button className="btn-reject-sm" onClick={() => onReject(app.id)}><XCircle size={16} /></button>
              </div>
            ) : (
              <span className={`timeline-status ${app.status}`}>
                {app.status === 'accepted' ? 'Acceptée' : 'Refusée'}
              </span>
            )}
          </div>
        ))
      )}
    </div>
  </div>
);

// Sidebar Component
const Sidebar = ({ 
  activeTab, setActiveTab, onLogout 
}: { 
  activeTab: string; 
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Tableau de bord', icon: House },
    { id: 'missions', label: 'Mes missions', icon: Briefcase },
    { id: 'applications', label: 'Candidatures', icon: FileText },
    { id: 'workers', label: 'Rechercher', icon: MagnifyingGlass },
    { id: 'messages', label: 'Messages', icon: ChatCircle },
    { id: 'profile', label: 'Mon établissement', icon: Buildings },
  ];

  return (
    <aside className="vision-sidebar">
      <Link to="/" className="sidebar-brand">
        <div className="brand-icon">
          <svg width="44" height="44" viewBox="0 0 48 48" fill="none">
            <rect width="48" height="48" rx="12" fill="url(#blueGrad)"/>
            <g fill="white">
              <path d="M14 20C14 15.5 18.5 12 24 12C29.5 12 34 15.5 34 20" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
              <circle cx="16" cy="28" r="3"/>
              <path d="M12 36C12 33 13.8 31 16 31C18.2 31 20 33 20 36" fill="white"/>
              <circle cx="24" cy="26" r="4"/>
              <path d="M18 36C18 32 20.5 29 24 29C27.5 29 30 32 30 36" fill="white"/>
              <circle cx="32" cy="28" r="3"/>
              <path d="M28 36C28 33 29.8 31 32 31C34.2 31 36 33 36 36" fill="white"/>
            </g>
            <defs>
              <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#4F6AF6"/>
                <stop offset="100%" stopColor="#3B5BDB"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div className="brand-text-group">
          <span className="brand-text">TADAMON</span>
          <span className="brand-subtext">SOCIAL</span>
        </div>
      </Link>

      <div className="sidebar-divider"></div>

      <nav className="sidebar-nav">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => setActiveTab(item.id)}
          >
            <item.icon size={20} weight={activeTab === item.id ? 'fill' : 'regular'} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="sidebar-divider"></div>
        <button className="nav-item logout" onClick={onLogout}>
          <SignOut size={20} />
          <span>Déconnexion</span>
        </button>
      </div>
    </aside>
  );
};

// Top Navbar
const TopNavbar = ({ 
  user, profile, activeTab, searchQuery, onSearchChange 
}: { 
  user: any; profile: EstablishmentProfile | null; activeTab: string;
  searchQuery: string; onSearchChange: (query: string) => void;
}) => {
  const { theme, toggleTheme } = useTheme();

  const getPageTitle = () => {
    const titles: { [key: string]: string } = {
      dashboard: 'Tableau de bord',
      missions: 'Mes missions',
      applications: 'Candidatures',
      workers: 'Rechercher des professionnels',
      messages: 'Messages',
      profile: 'Mon établissement',
    };
    return titles[activeTab] || 'Tableau de bord';
  };

  return (
    <header className="vision-navbar">
      <div className="navbar-left">
        <div className="breadcrumb">
          <span className="breadcrumb-item">Pages</span>
          <span className="breadcrumb-separator">/</span>
          <span className="breadcrumb-current">{getPageTitle()}</span>
        </div>
        <h1 className="page-title">{getPageTitle()}</h1>
      </div>
      <div className="navbar-right">
        <div className="search-box">
          <MagnifyingGlass size={18} />
          <input 
            type="text" 
            placeholder="Rechercher..." 
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
        <button className="navbar-btn" onClick={toggleTheme}>
          {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
        </button>
        <NotificationsDropdown />
        <div className="navbar-user">
          <div className="user-avatar establishment">
            <Buildings size={18} />
          </div>
        </div>
      </div>
    </header>
  );
};

// ============================================
// MAIN DASHBOARD COMPONENT
// ============================================

const EtablissementDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  // State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoading, setIsLoading] = useState(true);
  const [hasProfile, setHasProfile] = useState(false);
  const [profile, setProfile] = useState<EstablishmentProfile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showMissionModal, setShowMissionModal] = useState(false);
  const [isCreatingMission, setIsCreatingMission] = useState(false);
  const [showWorkerModal, setShowWorkerModal] = useState(false);
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [contactMessage, setContactMessage] = useState('');
  const [isContacting, setIsContacting] = useState(false);
  
  // Data
  const [missions, setMissions] = useState<Mission[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  const [cities, setCities] = useState<any[]>([]);
  const [myReviews, setMyReviews] = useState<any[]>([]);
  
  // Stats
  const [stats, setStats] = useState({
    activeMissions: 0,
    completedMissions: 0,
    pendingApplications: 0,
    averageRating: 0,
    totalMissions: 0,
    reviewsCount: 0,
  });
  
  // Forms
  const [missionForm, setMissionForm] = useState({
    title: '', description: '', start_date: '', end_date: '',
    salary_min: '', salary_max: '', region_id: '', city_id: '',
    mission_type: 'ponctuelle', is_urgent: false, required_experience: '0',
  });

  const [profileForm, setProfileForm] = useState({
    name: '', legal_name: '', ice: '', type: 'association',
    phone: '', email: '', region_id: '', city_id: '',
    address: '', description: '', contact_person_name: '', contact_person_phone: '',
  });
  
  const [workerFilters, setWorkerFilters] = useState({
    region_id: '', specialty_id: '', is_labeled: false,
    min_experience: '', min_rating: '', search: '',
  });

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    if (activeTab === 'workers') loadWorkers();
  }, [activeTab, workerFilters]);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const [regionsRes, specialtiesRes] = await Promise.all([
        regionAPI.getRegions(),
        regionAPI.getSpecialties(),
      ]);
      setRegions(regionsRes.data?.regions || []);
      setSpecialties(specialtiesRes.data?.specialties || []);

      try {
        const profileRes = await establishmentAPI.getProfile();
        if (profileRes.data?.profile) {
          setProfile(profileRes.data.profile);
          setHasProfile(true);
          
          const [missionsRes, appsRes, statsRes, reviewsRes] = await Promise.all([
            missionAPI.getMyMissions().catch(() => ({ data: { missions: [] } })),
            applicationAPI.getReceivedApplications().catch(() => ({ data: { applications: [] } })),
            statsAPI.getEstablishmentStats().catch(() => ({ data: null })),
            reviewAPI.getMyReviews().catch(() => ({ data: { reviews: [] } })),
          ]);
          
          const missionsList = missionsRes.data?.missions || [];
          const appsList = appsRes.data?.applications || [];
          
          setMissions(missionsList);
          setApplications(appsList);
          setMyReviews(reviewsRes.data?.reviews || []);
          
          const active = missionsList.filter((m: Mission) => m.status === 'open' || m.status === 'in_progress').length;
          const completed = missionsList.filter((m: Mission) => m.status === 'completed').length;
          const pending = appsList.filter((a: Application) => a.status === 'pending').length;
          
          setStats({
            activeMissions: statsRes.data?.missions?.open + statsRes.data?.missions?.in_progress || active,
            completedMissions: statsRes.data?.missions?.completed || completed,
            totalMissions: statsRes.data?.missions?.total || missionsList.length,
            pendingApplications: statsRes.data?.pending_applications || pending,
            averageRating: statsRes.data?.average_rating || profileRes.data.profile.average_rating || 0,
            reviewsCount: statsRes.data?.reviews_count || reviewsRes.data?.reviews?.length || 0,
          });
        }
      } catch (err: any) {
        if (err.response?.status !== 404) console.error('Error loading profile:', err);
        setHasProfile(false);
      }
    } catch (err) {
      console.error('Error loading data:', err);
      setError('Erreur lors du chargement des données');
    } finally {
      setIsLoading(false);
    }
  };

  const loadWorkers = async () => {
    try {
      const params: any = {};
      if (workerFilters.region_id) params.region_id = workerFilters.region_id;
      if (workerFilters.specialty_id) params.specialty_id = workerFilters.specialty_id;
      if (workerFilters.is_labeled) params.is_labeled = true;
      if (workerFilters.min_experience) params.min_experience = workerFilters.min_experience;
      if (workerFilters.min_rating) params.min_rating = workerFilters.min_rating;
      if (workerFilters.search) params.search = workerFilters.search;
      
      const res = await workerAPI.searchWorkers(params);
      setWorkers(res.data?.workers || []);
    } catch (error) {
      console.error('Error loading workers:', error);
      setWorkers([]);
    }
  };

  const handleRegionChange = async (regionId: string, formType: 'mission' | 'profile') => {
    if (formType === 'mission') {
      setMissionForm({ ...missionForm, region_id: regionId, city_id: '' });
    } else {
      setProfileForm({ ...profileForm, region_id: regionId, city_id: '' });
    }
    
    if (regionId) {
      try {
        const res = await regionAPI.getCitiesByRegion(parseInt(regionId));
        setCities(res.data?.cities || []);
      } catch (err) {
        setCities([]);
      }
    } else {
      setCities([]);
    }
  };

  const handleAcceptApplication = async (applicationId: number) => {
    try {
      await applicationAPI.acceptApplication(applicationId);
      showSuccess('Candidature acceptée!');
      loadData();
    } catch (error: any) {
      showError(error.response?.data?.message || 'Erreur lors de l\'acceptation');
    }
  };

  const handleRejectApplication = async (applicationId: number) => {
    try {
      await applicationAPI.rejectApplication(applicationId);
      showSuccess('Candidature refusée');
      loadData();
    } catch (error: any) {
      showError(error.response?.data?.message || 'Erreur lors du refus');
    }
  };

  const handleCreateMission = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreatingMission(true);
    try {
      const missionData: any = {
        title: missionForm.title.trim(),
        description: missionForm.description.trim(),
        mission_type: missionForm.mission_type,
        start_date: missionForm.start_date,
        is_urgent: missionForm.is_urgent,
        required_experience: parseInt(missionForm.required_experience) || 0,
      };

      if (missionForm.end_date) missionData.end_date = missionForm.end_date;
      if (missionForm.salary_min) missionData.salary_min = parseFloat(missionForm.salary_min);
      if (missionForm.salary_max) missionData.salary_max = parseFloat(missionForm.salary_max);
      if (missionForm.region_id) missionData.region_id = parseInt(missionForm.region_id);
      if (missionForm.city_id) missionData.city_id = parseInt(missionForm.city_id);

      await missionAPI.createMission(missionData);
      showSuccess('Mission créée avec succès!');
      setShowMissionModal(false);
      setMissionForm({
        title: '', description: '', start_date: '', end_date: '',
        salary_min: '', salary_max: '', region_id: '', city_id: '',
        mission_type: 'ponctuelle', is_urgent: false, required_experience: '0',
      });
      await loadData();
    } catch (error: any) {
      showError(error.response?.data?.message || 'Erreur lors de la création');
    } finally {
      setIsCreatingMission(false);
    }
  };

  const handleCreateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await establishmentAPI.createProfile({
        ...profileForm,
        region_id: parseInt(profileForm.region_id),
        city_id: parseInt(profileForm.city_id),
      });
      showSuccess('Profil créé avec succès!');
      await loadData();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Erreur lors de la création du profil');
      showError(err.response?.data?.message || 'Erreur');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingProfile(true);
    try {
      const updateData: any = {
        name: profileForm.name.trim(),
        legal_name: profileForm.legal_name.trim(),
        type: profileForm.type,
        phone: profileForm.phone || null,
        email: profileForm.email || null,
        address: profileForm.address || null,
        description: profileForm.description || null,
      };
      
      if (profileForm.region_id) updateData.region_id = parseInt(profileForm.region_id);
      if (profileForm.city_id) updateData.city_id = parseInt(profileForm.city_id);
      
      await establishmentAPI.updateProfile(updateData);
      showSuccess('Profil mis à jour avec succès!');
      setShowEditProfileModal(false);
      await loadData();
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors de la mise à jour');
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const openEditProfileModal = async () => {
    if (profile) {
      // Load cities if region is set
      if (profile.region_id) {
        try {
          const res = await regionAPI.getCitiesByRegion(profile.region_id);
          setCities(res.data?.cities || []);
        } catch (err) {
          setCities([]);
        }
      }
      
      setProfileForm({
        name: profile.name || '',
        legal_name: profile.legal_name || '',
        ice: profile.ice || '',
        type: profile.type || 'association',
        phone: profile.phone || '',
        email: profile.email || '',
        region_id: profile.region_id?.toString() || '',
        city_id: profile.city_id?.toString() || '',
        address: profile.address || '',
        description: profile.description || '',
        contact_person_name: '',
        contact_person_phone: '',
      });
      setShowEditProfileModal(true);
    }
  };

  const handleLogout = () => { logout(); navigate('/login'); };

  const handleContactWorker = async () => {
    if (!selectedWorker || !contactMessage.trim()) {
      showError('Veuillez écrire un message');
      return;
    }
    
    setIsContacting(true);
    try {
      await messageAPI.startConversation({
        receiver_id: selectedWorker.user_id,
        content: contactMessage.trim(),
      });
      showSuccess('Message envoyé avec succès!');
      setShowWorkerModal(false);
      setContactMessage('');
      setActiveTab('messages');
    } catch (error: any) {
      showError(error.response?.data?.message || 'Erreur lors de l\'envoi du message');
    } finally {
      setIsContacting(false);
    }
  };

  // Filter data based on search
  const filteredMissions = missions.filter(m => 
    !searchQuery || m.title?.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const filteredApplications = applications.filter(a => 
    !searchQuery || a.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.last_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Loading state
  if (isLoading && !profile) {
    return (
      <div className="vision-loading">
        <div className="loading-spinner"></div>
        <p>Chargement...</p>
      </div>
    );
  }

  // Profile creation form
  if (!hasProfile) {
    return (
      <div className="vision-profile-creation">
        <div className="creation-card">
          <div className="creation-header">
            <Buildings size={48} />
            <h1>Créer le profil de votre établissement</h1>
            <p>Complétez votre profil pour publier des missions</p>
          </div>

          {error && (
            <div className="error-alert">
              <WarningCircle size={18} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleCreateProfile} className="creation-form">
            <div className="form-row">
              <div className="form-group">
                <label>Nom de l'établissement *</label>
                <input type="text" value={profileForm.name} onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Raison sociale *</label>
                <input type="text" value={profileForm.legal_name} onChange={(e) => setProfileForm({ ...profileForm, legal_name: e.target.value })} required />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>ICE *</label>
                <input type="text" value={profileForm.ice} onChange={(e) => setProfileForm({ ...profileForm, ice: e.target.value })} maxLength={15} required />
              </div>
              <div className="form-group">
                <label>Type *</label>
                <select value={profileForm.type} onChange={(e) => setProfileForm({ ...profileForm, type: e.target.value })} required>
                  <option value="association">Association</option>
                  <option value="entreprise">Entreprise</option>
                  <option value="public">Établissement public</option>
                  <option value="autre">Autre</option>
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Région *</label>
                <select value={profileForm.region_id} onChange={(e) => handleRegionChange(e.target.value, 'profile')} required>
                  <option value="">Sélectionner</option>
                  {regions.map((r) => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Ville *</label>
                <select value={profileForm.city_id} onChange={(e) => setProfileForm({ ...profileForm, city_id: e.target.value })} required disabled={!profileForm.region_id}>
                  <option value="">Sélectionner</option>
                  {cities.map((c) => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Téléphone</label>
                <input type="tel" value={profileForm.phone} onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })} />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input type="email" value={profileForm.email} onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })} />
              </div>
            </div>

            <div className="form-group">
              <label>Description</label>
              <textarea value={profileForm.description} onChange={(e) => setProfileForm({ ...profileForm, description: e.target.value })} rows={4} />
            </div>

            <button type="submit" className="submit-btn" disabled={isLoading}>
              {isLoading ? 'Création...' : 'Créer le profil'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Main Dashboard Render
  return (
    <div className="vision-dashboard">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />
      
      <main className="vision-main">
        <TopNavbar user={user} profile={profile} activeTab={activeTab} searchQuery={searchQuery} onSearchChange={setSearchQuery} />

        {/* Verification Banner */}
        {!profile?.is_verified && (
          <div className="status-alert warning">
            <WarningCircle size={18} />
            <span>Votre établissement est en attente de vérification</span>
          </div>
        )}

        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="dashboard-content">
            {/* Row 1: Profile + Rating + Quick Actions */}
            <div className="dashboard-row row-top-new">
              <EstablishmentProfileCard profile={profile} />
              <RatingCard rating={stats.averageRating} reviewsCount={stats.reviewsCount} />
              <EstablishmentQuickActions 
                profile={profile} 
                stats={stats}
                onNavigate={setActiveTab}
                onNewMission={() => setShowMissionModal(true)}
              />
            </div>

            {/* Row 2: Mini Stats */}
            <div className="dashboard-row row-stats">
              <MiniStatCard title="Missions actives" value={stats.activeMissions} icon={Briefcase} gradient="blue" />
              <MiniStatCard title="Missions terminées" value={stats.completedMissions} icon={CheckCircle} gradient="green" />
              <MiniStatCard title="Candidatures" value={stats.pendingApplications} icon={Users} gradient="orange" />
              <MiniStatCard title="Note moyenne" value={Number(stats.averageRating || 0).toFixed(1)} icon={Star} gradient="purple" />
            </div>

            {/* Row 3: Missions Table + Applications */}
            <div className="dashboard-row row-main">
              <MissionsTable missions={filteredMissions} onViewApplications={() => setActiveTab('applications')} />
              <ApplicationsTimeline applications={filteredApplications} onAccept={handleAcceptApplication} onReject={handleRejectApplication} />
            </div>
          </div>
        )}

        {/* Missions Tab */}
        {activeTab === 'missions' && (
          <div className="tab-content-vision">
            <div className="tab-header-vision">
              <h2>Mes missions</h2>
              <button className="btn-primary-vision" onClick={() => setShowMissionModal(true)}>
                <Plus size={18} /> Nouvelle mission
              </button>
            </div>
            
            {filteredMissions.length === 0 ? (
              <div className="empty-state-vision">
                <Briefcase size={48} />
                <h3>Aucune mission</h3>
                <p>Publiez votre première mission pour trouver des professionnels</p>
                <button className="btn-primary-vision" onClick={() => setShowMissionModal(true)}>
                  <Plus size={18} /> Créer une mission
                </button>
              </div>
            ) : (
              <div className="missions-grid-vision">
                {filteredMissions.map((mission) => (
                  <div key={mission.id} className="mission-card-vision">
                    <div className="mission-card-header">
                      <h3>{mission.title}</h3>
                      <div className="mission-badges">
                        {mission.is_urgent && <span className="badge urgent">Urgent</span>}
                        <span className={`badge status-${mission.status}`}>
                          {mission.status === 'open' ? 'Ouverte' : mission.status === 'in_progress' ? 'En cours' : 'Terminée'}
                        </span>
                      </div>
                    </div>
                    <p className="mission-description">{mission.description?.substring(0, 120)}...</p>
                    <div className="mission-meta">
                      <span><CalendarBlank size={14} /> {formatDate(mission.start_date)}</span>
                      {mission.city_name && <span><MapPin size={14} /> {mission.city_name}</span>}
                      {mission.salary_min && <span><Wallet size={14} /> {mission.salary_min}-{mission.salary_max} DH</span>}
                    </div>
                    <div className="mission-card-footer">
                      <span className="applications-count"><Users size={16} /> {mission.applications_count || 0} candidatures</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Applications Tab */}
        {activeTab === 'applications' && (
          <div className="tab-content-vision">
            <div className="tab-header-vision">
              <h2>Candidatures reçues</h2>
              <span className="pending-count">{stats.pendingApplications} en attente</span>
            </div>
            
            {filteredApplications.length === 0 ? (
              <div className="empty-state-vision">
                <FileText size={48} />
                <h3>Aucune candidature</h3>
                <p>Publiez des missions pour recevoir des candidatures</p>
              </div>
            ) : (
              <div className="applications-grid-vision">
                {filteredApplications.map((app) => (
                  <div key={app.id} className={`application-card-vision ${app.status}`}>
                    <div className="applicant-header">
                      <div className="applicant-avatar">
                        {app.profile_picture ? (
                          <img src={getProfilePictureUrl(app.profile_picture)!} alt="" />
                        ) : (
                          <span>{app.first_name?.charAt(0)}{app.last_name?.charAt(0)}</span>
                        )}
                        {app.is_labeled && <div className="label-badge"><Medal size={12} /></div>}
                      </div>
                      <div className="applicant-info">
                        <h3>{app.first_name} {app.last_name}</h3>
                        <div className="applicant-stats">
                          <span><Star size={14} /> {Number(app.average_rating || 0).toFixed(1)}</span>
                          <span><Briefcase size={14} /> {app.total_missions || 0} missions</span>
                        </div>
                      </div>
                    </div>
                    <p className="mission-ref">Mission: {app.mission_title || `#${app.mission_id}`}</p>
                    {app.cover_letter && <p className="cover-letter">"{app.cover_letter.substring(0, 100)}..."</p>}
                    <div className="application-footer">
                      <span className="app-date"><Clock size={14} /> {formatDate(app.created_at)}</span>
                      {app.status === 'pending' ? (
                        <div className="action-buttons">
                          <button className="btn-accept" onClick={() => handleAcceptApplication(app.id)}><CheckCircle size={16} /> Accepter</button>
                          <button className="btn-reject" onClick={() => handleRejectApplication(app.id)}><XCircle size={16} /> Refuser</button>
                        </div>
                      ) : (
                        <span className={`status-badge ${app.status}`}>{app.status === 'accepted' ? 'Acceptée' : 'Refusée'}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Workers Search Tab */}
        {activeTab === 'workers' && (
          <div className="tab-content-vision">
            <div className="tab-header-vision">
              <h2>Rechercher des professionnels</h2>
            </div>
            
            <div className="search-filters-vision">
              <div className="search-input-large">
                <MagnifyingGlass size={20} />
                <input type="text" placeholder="Rechercher par nom..." value={workerFilters.search} onChange={(e) => setWorkerFilters({ ...workerFilters, search: e.target.value })} />
              </div>
              <select value={workerFilters.region_id} onChange={(e) => setWorkerFilters({ ...workerFilters, region_id: e.target.value })}>
                <option value="">Toutes les régions</option>
                {regions.map((r) => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
              </select>
              <select value={workerFilters.specialty_id} onChange={(e) => setWorkerFilters({ ...workerFilters, specialty_id: e.target.value })}>
                <option value="">Toutes spécialités</option>
                {specialties.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <label className="checkbox-filter">
                <input type="checkbox" checked={workerFilters.is_labeled} onChange={(e) => setWorkerFilters({ ...workerFilters, is_labeled: e.target.checked })} />
                <Medal size={16} /> Label uniquement
              </label>
            </div>

            {workers.length === 0 ? (
              <div className="empty-state-vision">
                <Users size={48} />
                <h3>Aucun professionnel trouvé</h3>
                <p>Modifiez vos critères de recherche</p>
              </div>
            ) : (
              <div className="workers-grid-vision">
                {workers.map((worker) => (
                  <div key={worker.id} className="worker-card-vision">
                    <div className="worker-header">
                      <div className="worker-avatar">
                        {worker.profile_picture ? (
                          <img src={getProfilePictureUrl(worker.profile_picture)!} alt="" />
                        ) : (
                          <span>{worker.first_name?.charAt(0)}{worker.last_name?.charAt(0)}</span>
                        )}
                        {worker.is_labeled && <div className="label-indicator"><Medal size={14} /></div>}
                      </div>
                      <div className="worker-info">
                        <h3>{worker.first_name} {worker.last_name}</h3>
                        {worker.is_labeled && <span className="label-tag"><Medal size={12} /> Label Réseau</span>}
                      </div>
                    </div>
                    <div className="worker-stats">
                      <span><Star size={14} /> {Number(worker.average_rating || 0).toFixed(1)}</span>
                      <span><Briefcase size={14} /> {worker.total_missions || 0}</span>
                      <span><Clock size={14} /> {worker.years_experience || 0} ans</span>
                    </div>
                    {worker.bio && <p className="worker-bio">{worker.bio.substring(0, 80)}...</p>}
                    <div className="worker-footer">
                      <span className="worker-location"><MapPin size={14} /> {worker.city_name || worker.region_name || 'Maroc'}</span>
                      <span className="worker-rate">{worker.daily_rate || 0} DH/jour</span>
                    </div>
                    <button className="btn-view-worker" onClick={() => { setSelectedWorker(worker); setShowWorkerModal(true); }}>
                      <Eye size={16} /> Voir profil
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="tab-content-vision">
            <MessagingPanel userRole="establishment" />
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="tab-content-vision">
            <div className="tab-header-vision">
              <h2>Mon établissement</h2>
              <button className="btn-primary-vision" onClick={openEditProfileModal}>
                <Gear size={18} /> Modifier le profil
              </button>
            </div>
            
            <div className="profile-page-vision">
              {/* Profile Header Card */}
              <div className="establishment-profile-header">
                <div className="establishment-logo-large">
                  {profile?.logo ? (
                    <img src={getProfilePictureUrl(profile.logo)!} alt="Logo" />
                  ) : (
                    <Buildings size={48} weight="fill" />
                  )}
                </div>
                <div className="establishment-header-info">
                  <div className="establishment-name-row">
                    <h2>{profile?.name}</h2>
                    {profile?.is_verified && (
                      <span className="verified-badge"><CheckCircle size={16} weight="fill" /> Vérifié</span>
                    )}
                  </div>
                  <p className="establishment-type">{profile?.legal_name} • {profile?.type || 'Association'}</p>
                  <div className="establishment-header-stats">
                    <div className="header-stat">
                      <span className="header-stat-value">{stats.totalMissions}</span>
                      <span className="header-stat-label">Missions</span>
                    </div>
                    <div className="header-stat">
                      <span className="header-stat-value">{Number(stats.averageRating || 0).toFixed(1)}</span>
                      <span className="header-stat-label">Note</span>
                    </div>
                    <div className="header-stat">
                      <span className="header-stat-value">{stats.reviewsCount}</span>
                      <span className="header-stat-label">Avis</span>
                    </div>
                    <div className="header-stat">
                      <span className="header-stat-value">{stats.completedMissions}</span>
                      <span className="header-stat-label">Terminées</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="profile-content-grid">
                <div className="profile-section-card">
                  <div className="section-header"><h3><Buildings size={18} /> Informations</h3></div>
                  <div className="section-content">
                    <div className="info-grid">
                      <div className="info-item"><span className="info-label">Nom</span><span className="info-value">{profile?.name}</span></div>
                      <div className="info-item"><span className="info-label">Raison sociale</span><span className="info-value">{profile?.legal_name}</span></div>
                      <div className="info-item"><span className="info-label">ICE</span><span className="info-value">{profile?.ice}</span></div>
                      <div className="info-item"><span className="info-label">Type</span><span className="info-value">{profile?.type}</span></div>
                    </div>
                  </div>
                </div>

                <div className="profile-section-card">
                  <div className="section-header"><h3><Phone size={18} /> Contact</h3></div>
                  <div className="section-content">
                    <div className="info-grid">
                      <div className="info-item"><span className="info-label">Téléphone</span><span className="info-value">{profile?.phone || '-'}</span></div>
                      <div className="info-item"><span className="info-label">Email</span><span className="info-value">{profile?.email || user?.email || '-'}</span></div>
                      <div className="info-item"><span className="info-label">Région</span><span className="info-value">{profile?.region_name || '-'}</span></div>
                      <div className="info-item"><span className="info-label">Ville</span><span className="info-value">{profile?.city_name || '-'}</span></div>
                      <div className="info-item full-width"><span className="info-label">Adresse</span><span className="info-value">{profile?.address || '-'}</span></div>
                    </div>
                  </div>
                </div>

                <div className="profile-section-card">
                  <div className="section-header"><h3><FileText size={18} /> Description</h3></div>
                  <div className="section-content">
                    <p className="bio-text">{profile?.description || 'Aucune description.'}</p>
                  </div>
                </div>

                <div className="profile-section-card">
                  <div className="section-header"><h3><ChartLineUp size={18} /> Statistiques</h3></div>
                  <div className="section-content">
                    <div className="stats-grid">
                      <div className="stat-box"><span className="stat-number">{stats.totalMissions}</span><span className="stat-text">Missions</span></div>
                      <div className="stat-box"><span className="stat-number">{stats.completedMissions}</span><span className="stat-text">Terminées</span></div>
                      <div className="stat-box"><span className="stat-number">{Number(stats.averageRating || 0).toFixed(1)}</span><span className="stat-text">Note</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Mission Creation Modal */}
      {showMissionModal && (
        <div className="modal-overlay" onClick={() => setShowMissionModal(false)}>
          <div className="modal-vision" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Nouvelle mission</h2>
              <button className="modal-close" onClick={() => setShowMissionModal(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleCreateMission} className="modal-form">
              <div className="form-group">
                <label>Titre *</label>
                <input type="text" value={missionForm.title} onChange={(e) => setMissionForm({ ...missionForm, title: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Description *</label>
                <textarea value={missionForm.description} onChange={(e) => setMissionForm({ ...missionForm, description: e.target.value })} rows={4} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Date de début *</label>
                  <input type="date" value={missionForm.start_date} onChange={(e) => setMissionForm({ ...missionForm, start_date: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label>Date de fin</label>
                  <input type="date" value={missionForm.end_date} onChange={(e) => setMissionForm({ ...missionForm, end_date: e.target.value })} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Salaire min (DH/jour)</label>
                  <input type="number" value={missionForm.salary_min} onChange={(e) => setMissionForm({ ...missionForm, salary_min: e.target.value })} />
                </div>
                <div className="form-group">
                  <label>Salaire max (DH/jour)</label>
                  <input type="number" value={missionForm.salary_max} onChange={(e) => setMissionForm({ ...missionForm, salary_max: e.target.value })} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Région</label>
                  <select value={missionForm.region_id} onChange={(e) => handleRegionChange(e.target.value, 'mission')}>
                    <option value="">Sélectionner</option>
                    {regions.map((r) => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Ville</label>
                  <select value={missionForm.city_id} onChange={(e) => setMissionForm({ ...missionForm, city_id: e.target.value })} disabled={!missionForm.region_id}>
                    <option value="">Sélectionner</option>
                    {cities.map((c) => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group checkbox-group">
                <label>
                  <input type="checkbox" checked={missionForm.is_urgent} onChange={(e) => setMissionForm({ ...missionForm, is_urgent: e.target.checked })} />
                  <WarningCircle size={16} /> Mission urgente
                </label>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn-cancel" onClick={() => setShowMissionModal(false)}>Annuler</button>
                <button type="submit" className="btn-submit" disabled={isCreatingMission}>{isCreatingMission ? 'Création...' : 'Publier'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Worker Profile Modal */}
      {showWorkerModal && selectedWorker && (
        <div className="modal-overlay" onClick={() => setShowWorkerModal(false)}>
          <div className="modal-vision" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Profil du professionnel</h2>
              <button className="modal-close" onClick={() => setShowWorkerModal(false)}><X size={20} /></button>
            </div>
            <div className="worker-profile-modal">
              <div className="worker-modal-header">
                <div className="worker-avatar-large">
                  {selectedWorker.profile_picture ? (
                    <img src={getProfilePictureUrl(selectedWorker.profile_picture)!} alt="" />
                  ) : (
                    <span>{selectedWorker.first_name?.charAt(0)}{selectedWorker.last_name?.charAt(0)}</span>
                  )}
                </div>
                <div className="worker-modal-info">
                  <h2>{selectedWorker.first_name} {selectedWorker.last_name}</h2>
                  {selectedWorker.is_labeled && <span className="label-badge-large"><Medal size={16} /> Label Réseau</span>}
                  <div className="worker-modal-stats">
                    <span><Star size={16} /> {Number(selectedWorker.average_rating || 0).toFixed(1)}</span>
                    <span><Briefcase size={16} /> {selectedWorker.total_missions || 0} missions</span>
                    <span><Clock size={16} /> {selectedWorker.years_experience || 0} ans</span>
                  </div>
                </div>
              </div>
              <div className="worker-modal-details">
                <p><MapPin size={16} /> {selectedWorker.city_name || selectedWorker.region_name || 'Maroc'}</p>
                <p><Wallet size={16} /> {selectedWorker.daily_rate || 0} DH/jour</p>
                {selectedWorker.bio && <p className="worker-bio-full">{selectedWorker.bio}</p>}
              </div>
              
              {/* Contact Form */}
              <div className="contact-form">
                <label>Envoyer un message</label>
                <textarea 
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  placeholder="Bonjour, je suis intéressé par votre profil pour une mission..."
                  rows={3}
                />
              </div>
              
              <div className="modal-actions">
                <button className="btn-cancel" onClick={() => { setShowWorkerModal(false); setContactMessage(''); }}>Fermer</button>
                <button className="btn-submit" onClick={handleContactWorker} disabled={isContacting || !contactMessage.trim()}>
                  {isContacting ? 'Envoi...' : <><ChatCircle size={16} /> Contacter</>}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {showEditProfileModal && (
        <div className="modal-overlay" onClick={() => setShowEditProfileModal(false)}>
          <div className="modal-vision" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Modifier le profil</h2>
              <button className="modal-close" onClick={() => setShowEditProfileModal(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleUpdateProfile} className="modal-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Nom de l'établissement *</label>
                  <input type="text" value={profileForm.name} onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })} required />
                </div>
                <div className="form-group">
                  <label>Raison sociale *</label>
                  <input type="text" value={profileForm.legal_name} onChange={(e) => setProfileForm({ ...profileForm, legal_name: e.target.value })} required />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>ICE</label>
                  <input type="text" value={profileForm.ice} disabled className="input-disabled" />
                  <span className="form-hint">L'ICE ne peut pas être modifié</span>
                </div>
                <div className="form-group">
                  <label>Type *</label>
                  <select value={profileForm.type} onChange={(e) => setProfileForm({ ...profileForm, type: e.target.value })} required>
                    <option value="association">Association</option>
                    <option value="entreprise">Entreprise</option>
                    <option value="public">Établissement public</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Région</label>
                  <select value={profileForm.region_id} onChange={(e) => handleRegionChange(e.target.value, 'profile')}>
                    <option value="">Sélectionner</option>
                    {regions.map((r) => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Ville</label>
                  <select value={profileForm.city_id} onChange={(e) => setProfileForm({ ...profileForm, city_id: e.target.value })} disabled={!profileForm.region_id}>
                    <option value="">Sélectionner</option>
                    {cities.map((c) => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Téléphone</label>
                  <input type="tel" value={profileForm.phone} onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })} placeholder="+212 6XX XXX XXX" />
                </div>
                <div className="form-group">
                  <label>Email</label>
                  <input type="email" value={profileForm.email} onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })} placeholder="contact@etablissement.ma" />
                </div>
              </div>

              <div className="form-group">
                <label>Adresse</label>
                <input type="text" value={profileForm.address} onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })} placeholder="Adresse complète" />
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea value={profileForm.description} onChange={(e) => setProfileForm({ ...profileForm, description: e.target.value })} rows={4} placeholder="Décrivez votre établissement, vos activités, votre mission..." />
              </div>

              <div className="modal-actions">
                <button type="button" className="btn-cancel" onClick={() => setShowEditProfileModal(false)}>Annuler</button>
                <button type="submit" className="btn-submit" disabled={isUpdatingProfile}>
                  {isUpdatingProfile ? 'Mise à jour...' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EtablissementDashboard;
