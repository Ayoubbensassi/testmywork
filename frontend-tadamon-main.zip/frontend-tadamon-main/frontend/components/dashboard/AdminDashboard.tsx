import { useState, useEffect, useCallback, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import {
  Users, FileText, Warning, CheckCircle, XCircle,
  Clock, Medal, SignOut, Eye, MagnifyingGlass, TrendUp,
  Buildings, Briefcase, ShieldCheck, Bell, ArrowsClockwise, UserPlus,
  House, Moon, Sun, Gear, User, CaretDown, MapPin, CalendarBlank, CurrencyDollar
} from '@phosphor-icons/react';
import { adminAPI, missionAPI } from '../../services/api';
import { showSuccess, showError } from '../common/Toast';
import NotificationsDropdown from '../common/NotificationsDropdown';
import RejectModal from '../common/RejectModal';
import ProfileDetailModal from '../common/ProfileDetailModal';
import '../../styles/dashboard-unified.css';
import '../../styles/AdminDashboard.css';

interface DashboardStats {
  total_users: number;
  total_workers: number;
  total_establishments: number;
  total_missions: number;
  pending_workers: number;
  pending_establishments: number;
  labeled_workers: number;
  pending_diplomas: number;
}

interface Worker {
  id: number;
  user_id: number;
  first_name: string;
  last_name: string;
  cin: string;
  phone: string;
  email?: string;
  bio?: string;
  daily_rate?: number;
  years_experience?: number;
  profile_picture?: string;
  status: string;
  is_labeled: boolean;
  created_at: string;
  region_name?: string;
  city_name?: string;
  specialties?: Array<{ name: string; years_experience?: number }>;
  diplomas?: Array<{ title: string; institution: string; obtained_date: string; is_verified: boolean }>;
}

interface Diploma {
  id: number;
  worker_id: number;
  title: string;
  institution: string;
  obtained_date: string;
  file_path: string;
  is_verified: boolean;
  first_name: string;
  last_name: string;
}

interface User {
  id: number;
  email: string;
  role: string;
  is_active: boolean;
  created_at: string;
  first_name?: string;
  last_name?: string;
}

interface Establishment {
  id: number;
  user_id: number;
  name: string;
  legal_name: string;
  ice: string;
  type: string;
  phone: string;
  email: string;
  description?: string;
  address?: string;
  website?: string;
  logo?: string;
  ice_document?: string;
  registration_document?: string;
  authorization_document?: string;
  is_verified: boolean;
  created_at: string;
  region_name?: string;
  city_name?: string;
}

interface Mission {
  id: number;
  title: string;
  description: string;
  establishment_name: string;
  status: string;
  start_date: string;
  end_date: string;
  salary_min: number;
  salary_max: number;
  city_name?: string;
  applications_count: number;
}

interface Application {
  id: number;
  mission_id: number;
  worker_id: number;
  status: string;
  created_at: string;
  mission_title: string;
  mission_status: string;
  start_date: string;
  end_date: string;
  worker_first_name: string;
  worker_last_name: string;
  is_labeled: boolean;
  establishment_name: string;
}

interface ApplicationStats {
  total: number;
  pending: number;
  accepted: number;
  rejected: number;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const profileDropdownRef = useRef<HTMLDivElement>(null);
  
  const [activeTab, setActiveTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [pendingWorkers, setPendingWorkers] = useState<Worker[]>([]);
  const [pendingDiplomas, setPendingDiplomas] = useState<Diploma[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [pendingEstablishments, setPendingEstablishments] = useState<Establishment[]>([]);
  const [allMissions, setAllMissions] = useState<Mission[]>([]);
  const [allApplications, setAllApplications] = useState<Application[]>([]);
  const [applicationStats, setApplicationStats] = useState<ApplicationStats | null>(null);
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [applicationFilter, setApplicationFilter] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  
  // Reject modal state
  const [rejectModal, setRejectModal] = useState<{
    isOpen: boolean;
    type: 'worker' | 'establishment' | null;
    id: number | null;
    name: string;
  }>({ isOpen: false, type: null, id: null, name: '' });
  const [isRejecting, setIsRejecting] = useState(false);

  // Profile detail modal state
  const [profileModal, setProfileModal] = useState<{
    isOpen: boolean;
    type: 'worker' | 'establishment';
    profile: Worker | Establishment | null;
  }>({ isOpen: false, type: 'worker', profile: null });

  // Open profile detail modal
  const openProfileModal = (type: 'worker' | 'establishment', profile: Worker | Establishment) => {
    setProfileModal({ isOpen: true, type, profile });
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(event.target as Node)) {
        setShowProfileDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const [statsRes, workersRes, diplomasRes, usersRes, missionsRes, appsRes] = await Promise.all([
        adminAPI.getDashboard(),
        adminAPI.getPendingWorkers(),
        adminAPI.getPendingDiplomas(),
        adminAPI.getUsers(),
        missionAPI.getMissions(),
        adminAPI.getAllApplications(),
      ]);
      
      setStats(statsRes.data?.stats || null);
      setPendingWorkers(workersRes.data?.workers || []);
      setPendingDiplomas(diplomasRes.data?.diplomas || []);
      setAllUsers(usersRes.data?.users || []);
      setAllMissions(missionsRes.data?.missions || missionsRes.missions || []);
      setAllApplications(appsRes.data?.applications || []);
      setApplicationStats(appsRes.data?.stats || null);
      
      // Try to load pending establishments
      try {
        const estabRes = await adminAPI.getPendingEstablishments();
        setPendingEstablishments(estabRes.data?.establishments || []);
      } catch {
        setPendingEstablishments([]);
      }
      
      setLastUpdated(new Date());
    } catch (err: any) {
      console.error('Error loading admin data:', err);
      setError('Erreur lors du chargement des données');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshData = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const [statsRes, workersRes, diplomasRes, usersRes, missionsRes, appsRes] = await Promise.all([
        adminAPI.getDashboard(),
        adminAPI.getPendingWorkers(),
        adminAPI.getPendingDiplomas(),
        adminAPI.getUsers(),
        missionAPI.getMissions(),
        adminAPI.getAllApplications(),
      ]);
      setStats(statsRes.data?.stats || null);
      setPendingWorkers(workersRes.data?.workers || []);
      setPendingDiplomas(diplomasRes.data?.diplomas || []);
      setAllUsers(usersRes.data?.users || []);
      setAllMissions(missionsRes.data?.missions || missionsRes.missions || []);
      setAllApplications(appsRes.data?.applications || []);
      setApplicationStats(appsRes.data?.stats || null);
      
      try {
        const estabRes = await adminAPI.getPendingEstablishments();
        setPendingEstablishments(estabRes.data?.establishments || []);
      } catch {
        setPendingEstablishments([]);
      }
      
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Error refreshing:', err);
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadData();
    const interval = setInterval(refreshData, 30000);
    return () => clearInterval(interval);
  }, [loadData, refreshData]);

  const handleApproveWorker = async (workerId: number) => {
    try {
      await adminAPI.approveWorker(workerId);
      showSuccess('Profil approuvé avec succès!');
      loadData();
    } catch (err: any) {
      showError(err.response?.data?.message || "Erreur lors de l'approbation");
    }
  };

  const handleRejectWorker = async (workerId: number, workerName: string) => {
    setRejectModal({
      isOpen: true,
      type: 'worker',
      id: workerId,
      name: workerName,
    });
  };

  const handleConfirmReject = async (reason: string) => {
    if (!rejectModal.id || !rejectModal.type) return;
    
    setIsRejecting(true);
    try {
      if (rejectModal.type === 'worker') {
        await adminAPI.rejectWorker(rejectModal.id, reason);
        showSuccess('Profil rejeté avec succès');
      } else if (rejectModal.type === 'establishment') {
        await adminAPI.rejectEstablishment(rejectModal.id);
        showSuccess('Établissement rejeté avec succès');
      }
      setRejectModal({ isOpen: false, type: null, id: null, name: '' });
      loadData();
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors du rejet');
    } finally {
      setIsRejecting(false);
    }
  };

  const handleVerifyDiploma = async (diplomaId: number) => {
    try {
      await adminAPI.verifyDiploma(diplomaId);
      showSuccess('Diplôme vérifié avec succès!');
      loadData();
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors de la vérification');
    }
  };

  const handleGrantLabel = async (workerId: number) => {
    try {
      await adminAPI.grantLabel(workerId);
      showSuccess('Label Réseau accordé!');
      loadData();
    } catch (err: any) {
      showError(err.response?.data?.message || 'Erreur lors de la labellisation');
    }
  };

  const handleApproveEstablishment = async (establishmentId: number) => {
    try {
      await adminAPI.approveEstablishment(establishmentId);
      showSuccess('Établissement approuvé avec succès!');
      loadData();
    } catch (err: any) {
      showError(err.response?.data?.message || "Erreur lors de l'approbation");
    }
  };

  const handleRejectEstablishment = (establishmentId: number, establishmentName?: string) => {
    setRejectModal({
      isOpen: true,
      type: 'establishment',
      id: establishmentId,
      name: establishmentName || 'Cet établissement',
    });
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  // Helper to get profile picture URL
  const getProfilePictureUrl = (path: string | null | undefined): string | null => {
    if (!path) return null;
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    return `http://localhost:5000${path}`;
  };

  if (isLoading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>
        <p>Chargement du tableau de bord...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      {/* Top Bar */}
      <div className="dashboard-topbar">
        <div className="topbar-left">
          <Link to="/" className="topbar-logo">
            <svg width="40" height="40" viewBox="0 0 48 48" fill="none">
              {/* Blue rounded square background */}
              <rect width="48" height="48" rx="12" fill="url(#topbarLogoGrad)"/>
              {/* People/social icon */}
              <g fill="white">
                {/* Top arc */}
                <path d="M14 20C14 15.5 18.5 12 24 12C29.5 12 34 15.5 34 20" stroke="white" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
                {/* Left person */}
                <circle cx="16" cy="28" r="3"/>
                <path d="M12 36C12 33 13.8 31 16 31C18.2 31 20 33 20 36" fill="white"/>
                {/* Center person (larger) */}
                <circle cx="24" cy="26" r="4"/>
                <path d="M18 36C18 32 20.5 29 24 29C27.5 29 30 32 30 36" fill="white"/>
                {/* Right person */}
                <circle cx="32" cy="28" r="3"/>
                <path d="M28 36C28 33 29.8 31 32 31C34.2 31 36 33 36 36" fill="white"/>
              </g>
              <defs>
                <linearGradient id="topbarLogoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#4F6AF6"/>
                  <stop offset="100%" stopColor="#3B5BDB"/>
                </linearGradient>
              </defs>
            </svg>
            <div className="topbar-logo-text">
              <span className="logo-title">TADAMON</span>
              <span className="logo-subtitle">SOCIAL</span>
            </div>
          </Link>
        </div>
        <div className="topbar-right">
          <button className="topbar-btn" onClick={toggleTheme} title={theme === 'light' ? 'Mode sombre' : 'Mode clair'}>
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          <NotificationsDropdown />
          <div className="topbar-profile" ref={profileDropdownRef}>
            <button className="profile-btn" onClick={() => setShowProfileDropdown(!showProfileDropdown)}>
              <div className="profile-avatar-small">
                <ShieldCheck size={16} />
              </div>
              <CaretDown size={16} className={showProfileDropdown ? 'rotated' : ''} />
            </button>
            {showProfileDropdown && (
              <div className="profile-dropdown">
                <div className="dropdown-header">
                  <div className="dropdown-avatar"><ShieldCheck size={20} /></div>
                  <div className="dropdown-info">
                    <span className="dropdown-name">Administrateur</span>
                    <span className="dropdown-email">{user?.email}</span>
                  </div>
                </div>
                <div className="dropdown-divider"></div>
                <button className="dropdown-item" onClick={() => { setActiveTab('settings'); setShowProfileDropdown(false); }}>
                  <User size={18} /><span>Mon profil</span>
                </button>
                <button className="dropdown-item" onClick={() => { setActiveTab('settings'); setShowProfileDropdown(false); }}>
                  <Gear size={18} /><span>Paramètres</span>
                </button>
                <div className="dropdown-divider"></div>
                <button className="dropdown-item logout" onClick={handleLogout}>
                  <SignOut size={18} /><span>Déconnexion</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <aside className="admin-sidebar">
        <nav className="sidebar-nav">
          <button className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>
            <TrendUp size={20} /><span>Vue d'ensemble</span>
          </button>
          <button className={`nav-item ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>
            <UserPlus size={20} /><span>Tous les utilisateurs</span>
            <span className="badge">{stats?.total_users || 0}</span>
          </button>
          <button className={`nav-item ${activeTab === 'workers' ? 'active' : ''}`} onClick={() => setActiveTab('workers')}>
            <Users size={20} /><span>Travailleurs en attente</span>
            {(stats?.pending_workers || 0) > 0 && <span className="badge">{stats?.pending_workers}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'diplomas' ? 'active' : ''}`} onClick={() => setActiveTab('diplomas')}>
            <FileText size={20} /><span>Diplômes</span>
            {(stats?.pending_diplomas || 0) > 0 && <span className="badge">{stats?.pending_diplomas}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'establishments' ? 'active' : ''}`} onClick={() => setActiveTab('establishments')}>
            <Buildings size={20} /><span>Établissements</span>
            {(stats?.pending_establishments || 0) > 0 && <span className="badge">{stats?.pending_establishments}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'missions' ? 'active' : ''}`} onClick={() => setActiveTab('missions')}>
            <Briefcase size={20} /><span>Missions</span>
            <span className="badge">{stats?.total_missions || 0}</span>
          </button>
          <button className={`nav-item ${activeTab === 'matchings' ? 'active' : ''}`} onClick={() => setActiveTab('matchings')}>
            <Users size={20} /><span>Mises en relation</span>
            {(applicationStats?.pending || 0) > 0 && <span className="badge">{applicationStats?.pending}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>
            <Gear size={20} /><span>Paramètres</span>
          </button>
        </nav>
      </aside>

      <aside className="admin-sidebar">
        <nav className="sidebar-nav">
          <button className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>
            <TrendUp size={20} /><span>Vue d'ensemble</span>
          </button>
          <button className={`nav-item ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>
            <UserPlus size={20} /><span>Tous les utilisateurs</span>
            <span className="badge">{stats?.total_users || 0}</span>
          </button>
          <button className={`nav-item ${activeTab === 'workers' ? 'active' : ''}`} onClick={() => setActiveTab('workers')}>
            <Users size={20} /><span>Travailleurs en attente</span>
            {(stats?.pending_workers || 0) > 0 && <span className="badge">{stats?.pending_workers}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'diplomas' ? 'active' : ''}`} onClick={() => setActiveTab('diplomas')}>
            <FileText size={20} /><span>Diplômes</span>
            {(stats?.pending_diplomas || 0) > 0 && <span className="badge">{stats?.pending_diplomas}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'establishments' ? 'active' : ''}`} onClick={() => setActiveTab('establishments')}>
            <Buildings size={20} /><span>Établissements</span>
            {(stats?.pending_establishments || 0) > 0 && <span className="badge">{stats?.pending_establishments}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'missions' ? 'active' : ''}`} onClick={() => setActiveTab('missions')}>
            <Briefcase size={20} /><span>Missions</span>
            <span className="badge">{stats?.total_missions || 0}</span>
          </button>
          <button className={`nav-item ${activeTab === 'matchings' ? 'active' : ''}`} onClick={() => setActiveTab('matchings')}>
            <Users size={20} /><span>Mises en relation</span>
            {(applicationStats?.pending || 0) > 0 && <span className="badge">{applicationStats?.pending}</span>}
          </button>
          <button className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>
            <Gear size={20} /><span>Paramètres</span>
          </button>
        </nav>
      </aside>

      <main className="admin-main">
        <header className="admin-header">
          <div className="header-left">
            <h1>Tableau de bord administrateur</h1>
            <p>Dernière mise à jour: {formatTime(lastUpdated)}</p>
          </div>
          <div className="header-right">
            <button className={`header-btn refresh-btn ${isRefreshing ? 'spinning' : ''}`} onClick={refreshData} title="Actualiser">
              <ArrowsClockwise size={20} />
            </button>
          </div>
        </header>

        {error && <div className="error-banner"><Warning size={18} /><span>{error}</span></div>}

        {activeTab === 'overview' && (
          <div className="tab-content">
            <div className="stats-grid">
              <div className="stat-card stat-blue">
                <div className="stat-icon"><Users size={24} /></div>
                <div className="stat-content">
                  <span className="stat-value">{stats?.total_users || 0}</span>
                  <span className="stat-label">Utilisateurs totaux</span>
                </div>
              </div>
              <div className="stat-card stat-green">
                <div className="stat-icon"><Users size={24} /></div>
                <div className="stat-content">
                  <span className="stat-value">{stats?.total_workers || 0}</span>
                  <span className="stat-label">Travailleurs</span>
                </div>
              </div>
              <div className="stat-card stat-purple">
                <div className="stat-icon"><Buildings size={24} /></div>
                <div className="stat-content">
                  <span className="stat-value">{stats?.total_establishments || 0}</span>
                  <span className="stat-label">Établissements</span>
                </div>
              </div>
              <div className="stat-card stat-yellow">
                <div className="stat-icon"><Briefcase size={24} /></div>
                <div className="stat-content">
                  <span className="stat-value">{stats?.total_missions || 0}</span>
                  <span className="stat-label">Missions</span>
                </div>
              </div>
            </div>
            <div className="pending-actions">
              <div className="action-card">
                <div className="action-header"><Clock size={20} /><h3>En attente de validation</h3></div>
                <div className="action-stats">
                  <div className="action-stat">
                    <span className="action-value">{stats?.pending_workers || 0}</span>
                    <span className="action-label">Profils travailleurs</span>
                  </div>
                  <div className="action-stat">
                    <span className="action-value">{stats?.pending_diplomas || 0}</span>
                    <span className="action-label">Diplômes à vérifier</span>
                  </div>
                </div>
              </div>
              <div className="action-card highlight">
                <div className="action-header"><Medal size={20} /><h3>Label Réseau</h3></div>
                <div className="action-stats">
                  <div className="action-stat">
                    <span className="action-value">{stats?.labeled_workers || 0}</span>
                    <span className="action-label">Travailleurs labellisés</span>
                  </div>
                </div>
              </div>
            </div>
            {pendingWorkers.length > 0 && (
              <section className="card">
                <div className="card-header">
                  <h2>Profils en attente</h2>
                  <button className="see-all" onClick={() => setActiveTab('workers')}>Voir tout →</button>
                </div>
                <div className="workers-list">
                  {pendingWorkers.slice(0, 3).map((worker) => (
                    <div key={worker.id} className="worker-item clickable" onClick={() => openProfileModal('worker', worker)}>
                      <div className="worker-info">
                        <div className="worker-avatar">
                          {worker.profile_picture ? (
                            <img src={getProfilePictureUrl(worker.profile_picture)!} alt="" />
                          ) : (
                            <span>{worker.first_name.charAt(0)}{worker.last_name.charAt(0)}</span>
                          )}
                        </div>
                        <div className="worker-details">
                          <h4>{worker.first_name} {worker.last_name}</h4>
                          <p>CIN: {worker.cin} • {worker.region_name || 'Maroc'}</p>
                          <span className="worker-date">Inscrit le {formatDate(worker.created_at)}</span>
                        </div>
                      </div>
                      <div className="worker-actions" onClick={(e) => e.stopPropagation()}>
                        <button className="btn-view" onClick={() => openProfileModal('worker', worker)}><Eye size={16} />Voir</button>
                        <button className="btn-approve" onClick={() => handleApproveWorker(worker.id)}><CheckCircle size={16} />Approuver</button>
                        <button className="btn-reject" onClick={() => handleRejectWorker(worker.id, `${worker.first_name} ${worker.last_name}`)}><XCircle size={16} />Rejeter</button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}

        {activeTab === 'users' && (
          <div className="tab-content">
            <div className="tab-header">
              <h2>Tous les utilisateurs</h2>
              <div className="tab-filters">
                <button className={`header-btn refresh-btn ${isRefreshing ? 'spinning' : ''}`} onClick={refreshData}><ArrowsClockwise size={18} /> Actualiser</button>
                <div className="search-box"><MagnifyingGlass size={18} /><input type="text" placeholder="Rechercher..." value={userSearchQuery} onChange={(e) => setUserSearchQuery(e.target.value)} /></div>
              </div>
            </div>
            {allUsers.length === 0 ? (
              <div className="empty-state">
                <Users size={48} />
                <h3>Aucun utilisateur</h3>
                <p>Les utilisateurs apparaîtront ici après inscription.</p>
              </div>
            ) : (
              <div className="workers-table">
                <table>
                  <thead>
                    <tr>
                      <th>Utilisateur</th>
                      <th>Email</th>
                      <th>Rôle</th>
                      <th>Date inscription</th>
                      <th>Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allUsers
                      .filter(u => {
                        if (!userSearchQuery) return true;
                        const query = userSearchQuery.toLowerCase();
                        return (
                          u.email.toLowerCase().includes(query) ||
                          (u.first_name && u.first_name.toLowerCase().includes(query)) ||
                          (u.last_name && u.last_name.toLowerCase().includes(query)) ||
                          u.role.toLowerCase().includes(query)
                        );
                      })
                      .map((user) => (
                      <tr key={user.id}>
                        <td>
                          <div className="table-user">
                            <div className="table-avatar">{(user.first_name || user.email).charAt(0).toUpperCase()}</div>
                            <span>{user.first_name && user.last_name ? `${user.first_name} ${user.last_name}` : user.email}</span>
                          </div>
                        </td>
                        <td>{user.email}</td>
                        <td><span className={`role-badge ${user.role}`}>{user.role === 'worker' ? 'Travailleur' : user.role === 'establishment' ? 'Établissement' : 'Admin'}</span></td>
                        <td>{formatDate(user.created_at)}</td>
                        <td><span className={`status-badge ${user.is_active ? 'active' : 'inactive'}`}>{user.is_active ? 'Actif' : 'Inactif'}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'workers' && (
          <div className="tab-content">
            <div className="tab-header">
              <h2>Travailleurs en attente de validation</h2>
              <div className="tab-filters"><div className="search-box"><MagnifyingGlass size={18} /><input type="text" placeholder="Rechercher..." /></div></div>
            </div>
            {pendingWorkers.length === 0 ? (
              <div className="empty-state"><CheckCircle size={48} /><h3>Aucun profil en attente</h3><p>Tous les profils ont été traités.</p></div>
            ) : (
              <div className="workers-table">
                <table>
                  <thead><tr><th>Nom</th><th>CIN</th><th>Téléphone</th><th>Région</th><th>Date inscription</th><th>Statut</th><th>Actions</th></tr></thead>
                  <tbody>
                    {pendingWorkers.map((worker) => (
                      <tr key={worker.id} className="clickable-row" onClick={() => openProfileModal('worker', worker)}>
                        <td>
                          <div className="table-user">
                            <div className="table-avatar">
                              {worker.profile_picture ? (
                                <img src={getProfilePictureUrl(worker.profile_picture)!} alt="" />
                              ) : (
                                <span>{worker.first_name.charAt(0)}{worker.last_name.charAt(0)}</span>
                              )}
                            </div>
                            <span>{worker.first_name} {worker.last_name}</span>
                          </div>
                        </td>
                        <td>{worker.cin}</td>
                        <td>{worker.phone || '-'}</td>
                        <td>{worker.region_name || '-'}</td>
                        <td>{formatDate(worker.created_at)}</td>
                        <td><span className={`status-badge ${worker.status}`}>{worker.status === 'pending' ? 'En attente' : worker.status}</span></td>
                        <td onClick={(e) => e.stopPropagation()}>
                          <div className="table-actions">
                            <button className="btn-icon view" onClick={() => openProfileModal('worker', worker)} title="Voir le profil"><Eye size={18} /></button>
                            <button className="btn-icon approve" onClick={() => handleApproveWorker(worker.id)} title="Approuver"><CheckCircle size={18} /></button>
                            <button className="btn-icon reject" onClick={() => handleRejectWorker(worker.id, `${worker.first_name} ${worker.last_name}`)} title="Rejeter"><XCircle size={18} /></button>
                            <button className="btn-icon label" onClick={() => handleGrantLabel(worker.id)} title="Accorder Label" disabled={worker.status !== 'approved'}><Medal size={18} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'diplomas' && (
          <div className="tab-content">
            <div className="tab-header"><h2>Vérification des diplômes</h2></div>
            {pendingDiplomas.length === 0 ? (
              <div className="empty-state"><CheckCircle size={48} /><h3>Aucun diplôme en attente</h3><p>Tous les diplômes ont été vérifiés.</p></div>
            ) : (
              <div className="diplomas-grid">
                {pendingDiplomas.map((diploma) => (
                  <div key={diploma.id} className="diploma-card">
                    <div className="diploma-header"><FileText size={24} /><span className="diploma-status pending">En attente</span></div>
                    <div className="diploma-content">
                      <h3>{diploma.title}</h3>
                      <p className="diploma-institution">{diploma.institution}</p>
                      <p className="diploma-worker"><Users size={14} />{diploma.first_name} {diploma.last_name}</p>
                      {diploma.obtained_date && <p className="diploma-date"><Clock size={14} />Obtenu le {formatDate(diploma.obtained_date)}</p>}
                    </div>
                    <div className="diploma-actions">
                      {diploma.file_path && <a href={`http://localhost:5000${diploma.file_path}`} target="_blank" rel="noopener noreferrer" className="btn-view"><Eye size={16} />Voir PDF</a>}
                      <button className="btn-verify" onClick={() => handleVerifyDiploma(diploma.id)}><CheckCircle size={16} />Vérifier</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'establishments' && (
          <div className="tab-content">
            <div className="tab-header">
              <h2>Établissements en attente de vérification</h2>
              <div className="tab-filters">
                <button className={`header-btn refresh-btn ${isRefreshing ? 'spinning' : ''}`} onClick={refreshData}><ArrowsClockwise size={18} /> Actualiser</button>
              </div>
            </div>
            {pendingEstablishments.length === 0 ? (
              <div className="empty-state"><CheckCircle size={48} /><h3>Aucun établissement en attente</h3><p>Tous les établissements ont été vérifiés.</p></div>
            ) : (
              <div className="workers-table">
                <table>
                  <thead>
                    <tr>
                      <th>Établissement</th>
                      <th>Type</th>
                      <th>ICE</th>
                      <th>Contact</th>
                      <th>Région</th>
                      <th>Date inscription</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pendingEstablishments.map((estab) => (
                      <tr key={estab.id} className="clickable-row" onClick={() => openProfileModal('establishment', estab)}>
                        <td>
                          <div className="table-user">
                            <div className="table-avatar"><Buildings size={16} /></div>
                            <div>
                              <span>{estab.name}</span>
                              <small style={{ display: 'block', color: 'var(--text-muted)', fontSize: '12px' }}>{estab.legal_name}</small>
                            </div>
                          </div>
                        </td>
                        <td><span className={`role-badge establishment`}>{estab.type}</span></td>
                        <td>{estab.ice}</td>
                        <td>
                          <div style={{ fontSize: '13px' }}>
                            <div>{estab.phone}</div>
                            <div style={{ color: 'var(--text-muted)' }}>{estab.email}</div>
                          </div>
                        </td>
                        <td>{estab.region_name || estab.city_name || '-'}</td>
                        <td>{formatDate(estab.created_at)}</td>
                        <td onClick={(e) => e.stopPropagation()}>
                          <div className="table-actions">
                            <button className="btn-icon view" onClick={() => openProfileModal('establishment', estab)} title="Voir le profil"><Eye size={18} /></button>
                            <button className="btn-icon approve" onClick={() => handleApproveEstablishment(estab.id)} title="Approuver"><CheckCircle size={18} /></button>
                            <button className="btn-icon reject" onClick={() => handleRejectEstablishment(estab.id, estab.name)} title="Rejeter"><XCircle size={18} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'missions' && (
          <div className="tab-content">
            <div className="tab-header">
              <h2>Toutes les missions</h2>
              <div className="tab-filters">
                <button className={`header-btn refresh-btn ${isRefreshing ? 'spinning' : ''}`} onClick={refreshData}><ArrowsClockwise size={18} /> Actualiser</button>
              </div>
            </div>
            {allMissions.length === 0 ? (
              <div className="empty-state"><Briefcase size={48} /><h3>Aucune mission</h3><p>Les missions apparaîtront ici une fois créées.</p></div>
            ) : (
              <div className="workers-table">
                <table>
                  <thead>
                    <tr>
                      <th>Mission</th>
                      <th>Établissement</th>
                      <th>Lieu</th>
                      <th>Période</th>
                      <th>Salaire</th>
                      <th>Candidatures</th>
                      <th>Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allMissions.map((mission) => (
                      <tr key={mission.id}>
                        <td>
                          <div className="table-user">
                            <div className="table-avatar"><Briefcase size={16} /></div>
                            <span>{mission.title}</span>
                          </div>
                        </td>
                        <td>{mission.establishment_name || '-'}</td>
                        <td><MapPin size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }} />{mission.city_name || '-'}</td>
                        <td>
                          <div style={{ fontSize: '12px' }}>
                            <div><CalendarBlank size={12} style={{ marginRight: '4px', verticalAlign: 'middle' }} />{formatDate(mission.start_date)}</div>
                            <div style={{ color: '#666' }}>→ {formatDate(mission.end_date)}</div>
                          </div>
                        </td>
                        <td><CurrencyDollar size={14} style={{ marginRight: '2px', verticalAlign: 'middle' }} />{mission.salary_min} - {mission.salary_max} DH</td>
                        <td><span className="badge">{mission.applications_count || 0}</span></td>
                        <td>
                          <span className={`status-badge ${mission.status}`}>
                            {mission.status === 'open' ? 'Ouverte' : mission.status === 'in_progress' ? 'En cours' : mission.status === 'completed' ? 'Terminée' : mission.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'matchings' && (
          <div className="tab-content">
            <div className="tab-header">
              <h2>Mises en relation (Candidatures)</h2>
              <div className="tab-filters">
                <select 
                  value={applicationFilter} 
                  onChange={(e) => setApplicationFilter(e.target.value)}
                  className="filter-select"
                >
                  <option value="">Tous les statuts</option>
                  <option value="pending">En attente</option>
                  <option value="accepted">Acceptées</option>
                  <option value="rejected">Refusées</option>
                </select>
                <button className={`header-btn refresh-btn ${isRefreshing ? 'spinning' : ''}`} onClick={refreshData}>
                  <ArrowsClockwise size={18} /> Actualiser
                </button>
              </div>
            </div>
            
            {/* Stats Cards */}
            <div className="matching-stats">
              <div className="matching-stat-card total">
                <span className="matching-stat-value">{applicationStats?.total || 0}</span>
                <span className="matching-stat-label">Total candidatures</span>
              </div>
              <div className="matching-stat-card pending">
                <span className="matching-stat-value">{applicationStats?.pending || 0}</span>
                <span className="matching-stat-label">En attente</span>
              </div>
              <div className="matching-stat-card accepted">
                <span className="matching-stat-value">{applicationStats?.accepted || 0}</span>
                <span className="matching-stat-label">Acceptées</span>
              </div>
              <div className="matching-stat-card rejected">
                <span className="matching-stat-value">{applicationStats?.rejected || 0}</span>
                <span className="matching-stat-label">Refusées</span>
              </div>
            </div>

            {allApplications.length === 0 ? (
              <div className="empty-state">
                <Users size={48} />
                <h3>Aucune candidature</h3>
                <p>Les candidatures apparaîtront ici une fois soumises.</p>
              </div>
            ) : (
              <div className="workers-table">
                <table>
                  <thead>
                    <tr>
                      <th>Travailleur</th>
                      <th>Mission</th>
                      <th>Établissement</th>
                      <th>Période</th>
                      <th>Date candidature</th>
                      <th>Statut</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allApplications
                      .filter(app => !applicationFilter || app.status === applicationFilter)
                      .map((app) => (
                      <tr key={app.id}>
                        <td>
                          <div className="table-user">
                            <div className="table-avatar">
                              {app.worker_first_name?.charAt(0)}{app.worker_last_name?.charAt(0)}
                            </div>
                            <div>
                              <span>{app.worker_first_name} {app.worker_last_name}</span>
                              {app.is_labeled && (
                                <small style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#F59E0B', fontSize: '11px' }}>
                                  <Medal size={12} /> Label Réseau
                                </small>
                              )}
                            </div>
                          </div>
                        </td>
                        <td>
                          <div>
                            <span>{app.mission_title}</span>
                            <small style={{ display: 'block', color: '#666', fontSize: '12px' }}>
                              {app.mission_status === 'open' ? 'Ouverte' : app.mission_status === 'in_progress' ? 'En cours' : 'Terminée'}
                            </small>
                          </div>
                        </td>
                        <td>{app.establishment_name}</td>
                        <td>
                          <div style={{ fontSize: '12px' }}>
                            <div><CalendarBlank size={12} style={{ marginRight: '4px', verticalAlign: 'middle' }} />{formatDate(app.start_date)}</div>
                            <div style={{ color: '#666' }}>→ {formatDate(app.end_date)}</div>
                          </div>
                        </td>
                        <td>{formatDate(app.created_at)}</td>
                        <td>
                          <span className={`status-badge ${app.status}`}>
                            {app.status === 'pending' ? 'En attente' : app.status === 'accepted' ? 'Acceptée' : 'Refusée'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="tab-content">
            <div className="tab-header"><h2>Paramètres</h2></div>
            <div className="settings-grid">
              <div className="settings-card">
                <div className="settings-card-header">
                  <User size={24} />
                  <h3>Profil administrateur</h3>
                </div>
                <div className="settings-card-content">
                  <div className="settings-item">
                    <label>Email</label>
                    <span>{user?.email}</span>
                  </div>
                  <div className="settings-item">
                    <label>Rôle</label>
                    <span className="role-badge admin">Administrateur</span>
                  </div>
                </div>
              </div>
              <div className="settings-card">
                <div className="settings-card-header">
                  <Gear size={24} />
                  <h3>Préférences</h3>
                </div>
                <div className="settings-card-content">
                  <div className="settings-item">
                    <label>Thème</label>
                    <button className="theme-toggle-btn" onClick={toggleTheme}>
                      {theme === 'light' ? <><Moon size={16} /> Mode sombre</> : <><Sun size={16} /> Mode clair</>}
                    </button>
                  </div>
                  <div className="settings-item">
                    <label>Notifications</label>
                    <span>Activées</span>
                  </div>
                </div>
              </div>
              <div className="settings-card">
                <div className="settings-card-header">
                  <ShieldCheck size={24} />
                  <h3>Sécurité</h3>
                </div>
                <div className="settings-card-content">
                  <div className="settings-item">
                    <label>Dernière connexion</label>
                    <span>{formatDate(new Date().toISOString())}</span>
                  </div>
                  <button className="btn-secondary" style={{ marginTop: '12px' }}>
                    Changer le mot de passe
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Reject Modal */}
      <RejectModal
        isOpen={rejectModal.isOpen}
        onClose={() => setRejectModal({ isOpen: false, type: null, id: null, name: '' })}
        onConfirm={handleConfirmReject}
        title={rejectModal.type === 'worker' ? 'Rejeter le profil' : 'Rejeter l\'établissement'}
        itemName={rejectModal.name}
        isLoading={isRejecting}
      />

      {/* Profile Detail Modal */}
      <ProfileDetailModal
        isOpen={profileModal.isOpen}
        onClose={() => setProfileModal({ isOpen: false, type: 'worker', profile: null })}
        type={profileModal.type}
        profile={profileModal.profile}
        onApprove={() => {
          if (profileModal.type === 'worker' && profileModal.profile) {
            handleApproveWorker((profileModal.profile as Worker).id);
            setProfileModal({ isOpen: false, type: 'worker', profile: null });
          } else if (profileModal.type === 'establishment' && profileModal.profile) {
            handleApproveEstablishment((profileModal.profile as Establishment).id);
            setProfileModal({ isOpen: false, type: 'worker', profile: null });
          }
        }}
        onReject={() => {
          if (profileModal.type === 'worker' && profileModal.profile) {
            const worker = profileModal.profile as Worker;
            setProfileModal({ isOpen: false, type: 'worker', profile: null });
            handleRejectWorker(worker.id, `${worker.first_name} ${worker.last_name}`);
          } else if (profileModal.type === 'establishment' && profileModal.profile) {
            const estab = profileModal.profile as Establishment;
            setProfileModal({ isOpen: false, type: 'worker', profile: null });
            handleRejectEstablishment(estab.id, estab.name);
          }
        }}
        onGrantLabel={() => {
          if (profileModal.type === 'worker' && profileModal.profile) {
            handleGrantLabel((profileModal.profile as Worker).id);
            setProfileModal({ isOpen: false, type: 'worker', profile: null });
          }
        }}
      />
    </div>
  );
};

export default AdminDashboard;


