
import React from 'react';
import { useAuth } from '../AuthContext';
import { motion } from 'framer-motion';

const CTA: React.FC = () => {
  const { openLoginModal } = useAuth();

  return (
    <section className="py-24 md:py-32 bg-slate-50 relative overflow-hidden">
         {/* Background Pattern */}
         <div className="absolute inset-0 opacity-30" 
             style={{ backgroundImage: 'radial-gradient(#CBD5E1 1px, transparent 1px)', backgroundSize: '24px 24px' }}>
         </div>

         <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
            {/* Simple Badge */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 text-white mb-8"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span className="text-xs font-semibold uppercase tracking-wider">Commencez maintenant</span>
            </motion.div>

            {/* Title */}
            <motion.h2 
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.6, delay: 0.1 }}
               className="text-4xl md:text-5xl lg:text-6xl font-bold font-display text-slate-900 mb-6 tracking-tight"
            >
               Rejoignez le <span className="text-blue-600">réseau</span>
            </motion.h2>

            {/* Subtitle */}
            <motion.p 
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.6, delay: 0.2 }}
               className="text-slate-500 text-lg md:text-xl mb-12 max-w-2xl mx-auto leading-relaxed"
            >
               Que vous soyez professionnel ou établissement, votre place est ici.
            </motion.p>

            <motion.div 
               initial={{ opacity: 0, scale: 0.9 }}
               whileInView={{ opacity: 1, scale: 1 }}
               transition={{ duration: 0.6, delay: 0.2 }}
               className="flex flex-col sm:flex-row justify-center gap-5 mb-12"
            >
               <button 
                  onClick={openLoginModal}
                  className="group relative px-10 py-5 bg-[#2563EB] text-white font-bold rounded-2xl shadow-xl shadow-blue-500/30 overflow-hidden transition-all hover:-translate-y-1 active:scale-95 cursor-pointer"
               >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
                  <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                  <div className="relative flex items-center justify-center gap-3">
                     <span className="material-symbols-outlined">person</span>
                     <span>Je suis travailleur social</span>
                     <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">arrow_forward</span>
                  </div>
               </button>
               
               <button 
                  onClick={openLoginModal}
                  className="group px-10 py-5 bg-white text-slate-900 border-2 border-slate-100 font-bold rounded-2xl shadow-lg hover:shadow-xl hover:border-blue-200 transition-all hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-3 cursor-pointer"
               >
                  <span className="material-symbols-outlined text-slate-400 group-hover:text-blue-600 transition-colors">domain</span>
                  <span>Je suis un établissement</span>
                  <span className="material-symbols-outlined text-slate-300 group-hover:translate-x-1 group-hover:text-blue-600 transition-all">arrow_forward</span>
               </button>
            </motion.div>

            <motion.div 
               initial={{ opacity: 0 }}
               whileInView={{ opacity: 1 }}
               transition={{ delay: 0.4 }}
               className="flex flex-wrap justify-center gap-6 text-[10px] font-bold text-slate-400 uppercase tracking-widest"
            >
               <span className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                  Inscription gratuite
               </span>
               <span className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                  Vérification sous 48h
               </span>
               <span className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
                  Aucun engagement
               </span>
            </motion.div>
         </div>
    </section>
  );
};

export default CTA;
