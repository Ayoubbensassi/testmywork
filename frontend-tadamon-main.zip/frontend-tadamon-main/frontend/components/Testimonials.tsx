import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Testimonial {
  id: string;
  name: string;
  role: string;
  userType: 'worker' | 'establishment';
  date: string;
  rating: number;
  avatar: string;
  quote: string;
}

const testimonials: Testimonial[] = [
  {
    id: 'amina',
    name: 'Amina Benali',
    role: "Directrice d'établissement",
    userType: 'establishment',
    date: '15 Jan, 2025',
    rating: 4.9,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
    quote: "Le système de vérification des diplômes nous rassure énormément. Nous avons trouvé des professionnels exceptionnels qui correspondent parfaitement à nos valeurs et à notre mission.",
  },
  {
    id: 'youssef',
    name: 'Youssef Tazi',
    role: 'Éducateur Spécialisé',
    userType: 'worker',
    date: '12 Jan, 2025',
    rating: 5.0,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
    quote: "Grâce à TADAMON, ma carrière a pris un nouvel élan. Je choisis des missions qui font sens, avec une flexibilité totale et une reconnaissance immédiate de mon travail.",
  },
  {
    id: 'kenza',
    name: 'Kenza El Amrani',
    role: 'Chef de Service',
    userType: 'establishment',
    date: '8 Jan, 2025',
    rating: 4.8,
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200',
    quote: "La précision du matching est bluffante. En moins de 48h, nous avons intégré un renfort qualifié parfaitement adapté à la spécificité de nos usagers.",
  },
  {
    id: 'omar',
    name: 'Omar Mansouri',
    role: 'Technicien Spécialisé',
    userType: 'worker',
    date: '3 Jan, 2025',
    rating: 4.9,
    avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&q=80&w=200',
    quote: "Une révolution dans le secteur médico-social marocain. La digitalisation du recrutement permet enfin de se concentrer sur l'essentiel : l'humain.",
  },
  {
    id: 'layla',
    name: 'Layla Belkhayat',
    role: 'Infirmière Coordinatrice',
    userType: 'worker',
    date: '28 Dec, 2024',
    rating: 5.0,
    avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&q=80&w=200',
    quote: "TADAMON n'est pas juste une plateforme, c'est une communauté de professionnels engagés. Le label qualité fait toute la différence.",
  },
];

const Testimonials: React.FC = () => {
  const [index, setIndex] = useState(1);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);

  const startAutoPlay = () => {
    stopAutoPlay();
    autoPlayRef.current = setInterval(() => {
      setIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);
  };

  const stopAutoPlay = () => {
    if (autoPlayRef.current) clearInterval(autoPlayRef.current);
  };

  useEffect(() => {
    startAutoPlay();
    return () => stopAutoPlay();
  }, []);

  const handleClick = (idx: number) => {
    stopAutoPlay();
    setIndex(idx);
    startAutoPlay();
  };

  // Get visible testimonials for the arc (previous, current, next)
  const getVisibleIndices = () => {
    const prev = (index - 1 + testimonials.length) % testimonials.length;
    const next = (index + 1) % testimonials.length;
    return [prev, index, next];
  };

  const visibleIndices = getVisibleIndices();

  const getUserTypeBadge = (userType: 'worker' | 'establishment') => {
    if (userType === 'worker') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-medium">
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
          </svg>
          Travailleur
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-medium">
        <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a1 1 0 110 2h-3a1 1 0 01-1-1v-2a1 1 0 00-1-1H9a1 1 0 00-1 1v2a1 1 0 01-1 1H4a1 1 0 110-2V4zm3 1h2v2H7V5zm2 4H7v2h2V9zm2-4h2v2h-2V5zm2 4h-2v2h2V9z" clipRule="evenodd" />
        </svg>
        Établissement
      </span>
    );
  };

  return (
    <section className="py-24 md:py-32 bg-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-slate-50/50 to-white"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-amber-50 border border-amber-100 mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            <span className="text-amber-700 text-xs font-semibold uppercase tracking-wider">Témoignages</span>
          </div>

          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold font-display text-slate-900 tracking-tight">
            Ils nous font <span className="text-blue-600 italic">confiance</span>
          </h2>
        </div>

        {/* Main Content - Arc Layout */}
        <div className="flex flex-col lg:flex-row items-center justify-center gap-12 lg:gap-16">
          
          {/* Left Side - Arc with Avatars */}
          <div className="relative w-64 h-80 flex-shrink-0">
            {/* Arc Line SVG */}
            <svg 
              className="absolute inset-0 w-full h-full" 
              viewBox="0 0 200 280" 
              fill="none"
              style={{ transform: 'translateX(-20px)' }}
            >
              <path
                d="M 160 30 Q 40 80 60 140 Q 80 200 160 250"
                stroke="#e2e8f0"
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
              />
            </svg>

            {/* Avatars on the Arc */}
            {testimonials.map((t, idx) => {
              const isActive = idx === index;
              const visiblePosition = visibleIndices.indexOf(idx);
              const isVisible = visiblePosition !== -1;
              
              // Position calculations for arc effect
              const positions = [
                { top: '0%', left: '55%' },      // Top
                { top: '38%', left: '15%' },     // Middle (active - bigger)
                { top: '76%', left: '55%' },     // Bottom
              ];
              
              const pos = isVisible ? positions[visiblePosition] : { top: '50%', left: '-20%' };
              
              return (
                <motion.button
                  key={t.id}
                  onClick={() => handleClick(idx)}
                  className={`absolute cursor-pointer ${
                    isActive ? 'z-20' : 'z-10'
                  }`}
                  initial={false}
                  animate={{ 
                    top: pos.top, 
                    left: pos.left,
                    scale: isActive ? 1 : 0.85,
                    opacity: isVisible ? 1 : 0,
                  }}
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                  style={{ transform: 'translate(-50%, -50%)' }}
                  whileHover={{ scale: isActive ? 1 : 1.1 }}
                >
                  {/* Avatar Container */}
                  <div className={`relative ${isActive ? 'w-20 h-20 md:w-24 md:h-24' : 'w-12 h-12 md:w-14 md:h-14'} transition-all duration-500`}>
                    <img
                      src={t.avatar}
                      alt={t.name}
                      className={`w-full h-full rounded-full object-cover border-2 ${
                        isActive 
                          ? 'border-blue-500 shadow-lg shadow-blue-500/20' 
                          : 'border-slate-200 grayscale opacity-70 hover:grayscale-0 hover:opacity-100'
                      } transition-all duration-500`}
                    />
                  </div>

                  {/* Name & Rating - Only for active */}
                  <div className={`mt-2 text-left transition-all duration-300 ${isActive ? 'opacity-100' : 'opacity-0'}`}>
                    <p className="text-sm font-semibold text-slate-900 whitespace-nowrap">{t.name}</p>
                    <div className="flex items-center gap-1">
                      <svg className="w-3 h-3 text-emerald-500 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      <span className="text-xs text-slate-500">{t.rating} le {t.date}</span>
                    </div>
                  </div>
                </motion.button>
              );
            })}
          </div>

          {/* Right Side - Quote */}
          <div className="flex-1 max-w-xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={testimonials[index].id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                {/* Quote Mark */}
                <span className="text-6xl md:text-7xl text-slate-200 font-serif leading-none block mb-4">"</span>
                
                {/* Quote Text */}
                <blockquote className="text-xl md:text-2xl lg:text-3xl text-slate-700 leading-relaxed italic" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                  <span className="text-3xl md:text-4xl not-italic" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>{testimonials[index].quote.charAt(0)}</span>
                  {testimonials[index].quote.slice(1)}
                </blockquote>

                {/* Author Info */}
                <div className="mt-8 flex items-center gap-4">
                  <div>
                    <p className="text-lg font-bold text-slate-900">{testimonials[index].name}</p>
                    <p className="text-sm text-slate-500 mb-2">{testimonials[index].role}</p>
                    {getUserTypeBadge(testimonials[index].userType)}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Navigation Dots */}
        <div className="flex justify-center gap-2 mt-16">
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => handleClick(i)}
              className={`h-2 rounded-full transition-all duration-500 cursor-pointer ${
                index === i ? 'w-8 bg-blue-600' : 'w-2 bg-slate-200 hover:bg-slate-300'
              }`}
              aria-label={`Voir témoignage ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
