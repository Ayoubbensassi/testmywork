import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Region {
  id: number;
  name_fr: string;
}

interface City {
  id: number;
  name_fr: string;
  region_id: number;
}

interface LocationAutocompleteProps {
  regions: Region[];
  cities: City[];
  value: string;
  onChange: (value: string, type: 'all' | 'region' | 'city') => void;
  placeholder?: string;
  variant?: 'dark' | 'light';
}

// Popular cities to show at top
const POPULAR_CITIES = ['Casablanca', 'Rabat', 'Marrakech', 'Fès', 'Tanger', 'Agadir'];

const LocationAutocomplete: React.FC<LocationAutocompleteProps> = ({
  regions,
  cities,
  value,
  onChange,
  placeholder = 'Où cherchez-vous ?',
  variant = 'dark',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [displayValue, setDisplayValue] = useState(value === 'all' || value === 'Toutes les régions' ? '' : value);
  const [expandedRegion, setExpandedRegion] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Get popular cities from data
  const popularCities = cities.filter(c => POPULAR_CITIES.includes(c.name_fr));

  // Group cities by region
  const citiesByRegion = cities.reduce((acc, city) => {
    if (!acc[city.region_id]) acc[city.region_id] = [];
    acc[city.region_id].push(city);
    return acc;
  }, {} as Record<number, City[]>);

  // Filter based on search
  const filteredRegions = searchTerm
    ? regions.filter(r => r.name_fr.toLowerCase().includes(searchTerm.toLowerCase()))
    : regions;

  const filteredCities = searchTerm
    ? cities.filter(c => c.name_fr.toLowerCase().includes(searchTerm.toLowerCase()))
    : [];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearchTerm('');
        setExpandedRegion(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    setDisplayValue(value === 'all' || value === 'Toutes les régions' ? '' : value);
  }, [value]);

  const handleSelect = (name: string, type: 'all' | 'region' | 'city') => {
    setDisplayValue(type === 'all' ? '' : name);
    onChange(type === 'all' ? 'Toutes les régions' : name, type);
    setIsOpen(false);
    setSearchTerm('');
    setExpandedRegion(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setDisplayValue(e.target.value);
    if (!isOpen) setIsOpen(true);
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDisplayValue('');
    setSearchTerm('');
    onChange('Toutes les régions', 'all');
    inputRef.current?.focus();
  };

  const toggleRegion = (regionId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedRegion(expandedRegion === regionId ? null : regionId);
  };

  const isDark = variant === 'dark';

  return (
    <div ref={containerRef} className="relative w-full">
      {/* Input */}
      <div onClick={() => setIsOpen(true)} className="flex items-center w-full cursor-text">
        <input
          ref={inputRef}
          type="text"
          value={displayValue || searchTerm}
          onChange={handleInputChange}
          onFocus={() => setIsOpen(true)}
          placeholder={placeholder}
          className={`w-full bg-transparent border-none focus:ring-0 outline-none text-[15px] font-medium ${
            isDark ? 'text-white placeholder-white/40' : 'text-slate-800 placeholder-slate-400'
          }`}
        />
        {(displayValue || searchTerm) ? (
          <button onClick={handleClear} className={`p-1 rounded-full transition-all cursor-pointer ${
            isDark ? 'hover:bg-white/10 text-white/40 hover:text-white' : 'hover:bg-slate-100 text-slate-400 hover:text-slate-600'
          }`}>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        ) : (
          <svg className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''} ${isDark ? 'text-white/40' : 'text-slate-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        )}
      </div>

      {/* Dropdown */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 mt-3 z-50 w-[320px] bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden"
          >
            {/* Search showing results */}
            {searchTerm ? (
              <div className="max-h-[300px] overflow-y-auto p-2">
                {filteredRegions.length === 0 && filteredCities.length === 0 ? (
                  <div className="p-6 text-center text-slate-400 text-sm">Aucun résultat</div>
                ) : (
                  <>
                    {filteredCities.map(city => {
                      const region = regions.find(r => r.id === city.region_id);
                      return (
                        <button
                          key={`city-${city.id}`}
                          onClick={() => handleSelect(city.name_fr, 'city')}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-blue-50 transition-colors cursor-pointer text-left"
                        >
                          <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                            <svg className="w-4 h-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            </svg>
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-900">{city.name_fr}</p>
                            <p className="text-xs text-slate-400">{region?.name_fr}</p>
                          </div>
                        </button>
                      );
                    })}
                    {filteredRegions.map(region => (
                      <button
                        key={`region-${region.id}`}
                        onClick={() => handleSelect(region.name_fr, 'region')}
                        className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-amber-50 transition-colors cursor-pointer text-left"
                      >
                        <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
                          <svg className="w-4 h-4 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                          </svg>
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-slate-900">{region.name_fr}</p>
                          <p className="text-xs text-slate-400">Région</p>
                        </div>
                      </button>
                    ))}
                  </>
                )}
              </div>
            ) : (
              /* Default view with popular cities and collapsible regions */
              <div className="max-h-[350px] overflow-y-auto">
                {/* All Morocco */}
                <div className="p-2 border-b border-slate-100">
                  <button
                    onClick={() => handleSelect('Toutes les régions', 'all')}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-blue-50 transition-colors cursor-pointer"
                  >
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-md">
                      <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-semibold text-slate-900">Tout le Maroc</p>
                      <p className="text-[11px] text-slate-400">Toutes les régions</p>
                    </div>
                  </button>
                </div>

                {/* Popular Cities */}
                {popularCities.length > 0 && (
                  <div className="p-2 border-b border-slate-100">
                    <p className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Villes populaires</p>
                    <div className="flex flex-wrap gap-1.5 px-2 pb-1">
                      {popularCities.map(city => (
                        <button
                          key={city.id}
                          onClick={() => handleSelect(city.name_fr, 'city')}
                          className="px-3 py-1.5 bg-slate-100 hover:bg-blue-100 hover:text-blue-700 text-slate-700 text-xs font-medium rounded-lg transition-colors cursor-pointer"
                        >
                          {city.name_fr}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Regions (Collapsible) */}
                <div className="p-2">
                  <p className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Régions</p>
                  {regions.map(region => {
                    const regionCities = citiesByRegion[region.id] || [];
                    const isExpanded = expandedRegion === region.id;
                    
                    return (
                      <div key={region.id} className="mb-0.5">
                        <div className="flex items-center">
                          <button
                            onClick={() => handleSelect(region.name_fr, 'region')}
                            className="flex-1 flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer text-left"
                          >
                            <svg className="w-4 h-4 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                            </svg>
                            <span className="text-sm font-medium text-slate-700">{region.name_fr}</span>
                          </button>
                          {regionCities.length > 0 && (
                            <button
                              onClick={(e) => toggleRegion(region.id, e)}
                              className="p-2 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            >
                              <svg className={`w-4 h-4 text-slate-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                              </svg>
                            </button>
                          )}
                        </div>
                        
                        {/* Expanded Cities */}
                        <AnimatePresence>
                          {isExpanded && regionCities.length > 0 && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.2 }}
                              className="overflow-hidden"
                            >
                              <div className="ml-6 pl-3 border-l-2 border-slate-100 py-1">
                                {regionCities.sort((a, b) => a.name_fr.localeCompare(b.name_fr)).map(city => (
                                  <button
                                    key={city.id}
                                    onClick={() => handleSelect(city.name_fr, 'city')}
                                    className="w-full text-left px-3 py-1.5 text-sm text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors cursor-pointer"
                                  >
                                    {city.name_fr}
                                  </button>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LocationAutocomplete;
