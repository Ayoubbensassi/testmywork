import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { establishmentAPI, regionsAPI } from '../../src/api';

interface Region { id: number; name_fr: string; }
interface City { id: number; name_fr: string; }

const EstablishmentOnboarding = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [regions, setRegions] = useState<Region[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  
  // Document files
  const [documents, setDocuments] = useState<{
    ice_document: File | null;
    registration_document: File | null;
    authorization_document: File | null;
    logo: File | null;
  }>({
    ice_document: null,
    registration_document: null,
    authorization_document: null,
    logo: null,
  });
  
  const [formData, setFormData] = useState({
    name: '', legal_name: '', ice: '', type: '', phone: '', email: '',
    region_id: '', city_id: '', address: '', website: '', description: '',
    contact_person_name: '', contact_person_phone: '', certify: false
  });

  useEffect(() => { regionsAPI.getAll().then(res => setRegions(res.regions || [])).catch(() => {}); }, []);

  useEffect(() => {
    if (formData.region_id) {
      regionsAPI.getCities(parseInt(formData.region_id)).then(res => setCities(res.cities || [])).catch(() => setCities([]));
    }
  }, [formData.region_id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: keyof typeof documents) => {
    const file = e.target.files?.[0] || null;
    setDocuments(prev => ({ ...prev, [fieldName]: file }));
  };

  const handleSubmit = async () => {
    if (!formData.certify) { setError('Veuillez certifier que vos informations sont exactes'); return; }
    if (!documents.ice_document) { setError('Veuillez télécharger votre certificat ICE'); return; }
    
    setIsSubmitting(true);
    setError(null);
    try {
      // First create the profile
      await establishmentAPI.createProfile({
        name: formData.name, legal_name: formData.legal_name, ice: formData.ice, type: formData.type,
        phone: formData.phone, email: formData.email || user?.email,
        region_id: parseInt(formData.region_id) || null, city_id: parseInt(formData.city_id) || null,
        address: formData.address, website: formData.website, description: formData.description,
        contact_person_name: formData.contact_person_name, contact_person_phone: formData.contact_person_phone
      });
      
      // Then upload documents
      const docFormData = new FormData();
      if (documents.ice_document) docFormData.append('ice_document', documents.ice_document);
      if (documents.registration_document) docFormData.append('registration_document', documents.registration_document);
      if (documents.authorization_document) docFormData.append('authorization_document', documents.authorization_document);
      if (documents.logo) docFormData.append('logo', documents.logo);
      
      if (docFormData.has('ice_document') || docFormData.has('registration_document') || docFormData.has('authorization_document') || docFormData.has('logo')) {
        await establishmentAPI.uploadDocuments(docFormData);
      }
      
      navigate('/establishment/dashboard');
    } catch (err: any) { setError(err.message || 'Erreur lors de la création du profil'); }
    finally { setIsSubmitting(false); }
  };

  const steps = [
    { num: 1, title: 'Identité', icon: 'domain' },
    { num: 2, title: 'Contact', icon: 'contact_phone' },
    { num: 3, title: 'Documents', icon: 'folder_open' },
    { num: 4, title: 'Confirmation', icon: 'check_circle' }
  ];

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-white overflow-hidden">
      <Link to="/" className="absolute top-6 left-6 z-50 w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors border border-slate-200">
        <span className="material-symbols-outlined">arrow_back</span>
      </Link>

      {/* LEFT COLUMN: FORM */}
      <div className="w-full lg:w-1/2 min-h-screen flex flex-col justify-center items-center p-6 lg:p-8 relative bg-white z-10 overflow-y-auto">
        <div className="w-full max-w-[500px] py-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#7C3AED] to-[#db2777] uppercase tracking-tighter mb-4">TADAMON</h2>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Créez votre profil établissement</h3>
            <p className="text-slate-500 text-sm">Ces informations permettent de vérifier votre structure</p>
          </div>

          {/* Progress Steps */}
          <div className="flex justify-between mb-8 relative px-4">
            <div className="absolute top-5 left-8 right-8 h-0.5 bg-slate-200 -z-10"></div>
            <div className="absolute top-5 left-8 h-0.5 bg-gradient-to-r from-purple-600 to-purple-400 -z-10 transition-all duration-500" style={{ width: `${((step - 1) / 3) * 100}%` }}></div>
            {steps.map((s) => (
              <div key={s.num} className="flex flex-col items-center">
                <motion.div animate={{ scale: step === s.num ? 1.1 : 1 }} className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all shadow-lg ${step >= s.num ? 'bg-gradient-to-r from-purple-600 to-purple-500 text-white shadow-purple-500/30' : 'bg-white border-2 border-slate-200 text-slate-400'}`}>
                  <span className="material-symbols-outlined text-lg">{step > s.num ? 'check' : s.icon}</span>
                </motion.div>
                <span className={`text-[10px] font-bold uppercase tracking-wide ${step >= s.num ? 'text-purple-600' : 'text-slate-400'}`}>{s.title}</span>
              </div>
            ))}
          </div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-3xl p-6 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border border-slate-100">
            {error && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl text-red-600 text-sm font-medium flex items-center gap-3">
                <span className="material-symbols-outlined">error</span>{error}
              </motion.div>
            )}

            <AnimatePresence mode="wait">
              {/* Step 1: Identity */}
              {step === 1 && (
                <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Nom établissement *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 transition-colors">domain</span>
                        <input type="text" name="name" value={formData.name} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Nom commercial" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Type *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 transition-colors">category</span>
                        <select name="type" value={formData.type} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 outline-none appearance-none cursor-pointer">
                          <option value="">Sélectionnez...</option>
                          <option value="association">Association</option>
                          <option value="entreprise">Entreprise</option>
                          <option value="public">Établissement public</option>
                          <option value="autre">Autre</option>
                        </select>
                        <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">expand_more</span>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Raison sociale</label>
                      <input type="text" name="legal_name" value={formData.legal_name} onChange={handleChange}
                        className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Raison sociale officielle" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">ICE</label>
                      <input type="text" name="ice" value={formData.ice} onChange={handleChange}
                        className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="001234567890123" />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Description</label>
                    <textarea name="description" value={formData.description} onChange={handleChange} rows={3}
                      className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none resize-none"
                      placeholder="Décrivez votre activité et vos missions..."></textarea>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Région *</label>
                      <div className="relative">
                        <select name="region_id" value={formData.region_id} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 outline-none appearance-none cursor-pointer">
                          <option value="">Sélectionnez...</option>
                          {regions.map(r => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">expand_more</span>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Ville</label>
                      <div className="relative">
                        <select name="city_id" value={formData.city_id} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 outline-none appearance-none cursor-pointer">
                          <option value="">Sélectionnez...</option>
                          {cities.map(c => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">expand_more</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Contact */}
              {step === 2 && (
                <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Téléphone *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 transition-colors">phone</span>
                        <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="05 22 00 00 00" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Email</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 transition-colors">mail</span>
                        <input type="email" name="email" value={formData.email} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="contact@etablissement.ma" />
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Site web</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 transition-colors">language</span>
                        <input type="url" name="website" value={formData.website} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="https://..." />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Adresse</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-purple-500 transition-colors">location_on</span>
                        <input type="text" name="address" value={formData.address} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Adresse complète" />
                      </div>
                    </div>
                  </div>
                  <div className="border-t border-slate-100 pt-5">
                    <h4 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <span className="material-symbols-outlined text-purple-500">person</span> Personne de contact
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Nom du responsable</label>
                        <input type="text" name="contact_person_name" value={formData.contact_person_name} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Nom complet" />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Téléphone</label>
                        <input type="tel" name="contact_person_phone" value={formData.contact_person_phone} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="06 00 00 00 00" />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Documents */}
              {step === 3 && (
                <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200 flex items-start gap-3 mb-4">
                    <span className="material-symbols-outlined text-blue-600 text-xl">info</span>
                    <p className="text-sm text-blue-800">Ces documents permettent de vérifier l'authenticité de votre établissement. Ils seront examinés par notre équipe.</p>
                  </div>
                  
                  {/* ICE Document - Required */}
                  <div className="space-y-2">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1 flex items-center gap-2">
                      <span className="material-symbols-outlined text-purple-500 text-base">description</span>
                      Certificat ICE *
                    </label>
                    <div className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer hover:border-purple-400 hover:bg-purple-50/30 ${documents.ice_document ? 'border-green-400 bg-green-50/30' : 'border-slate-200'}`}>
                      <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={(e) => handleFileChange(e, 'ice_document')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                      {documents.ice_document ? (
                        <div className="flex items-center justify-center gap-3">
                          <span className="material-symbols-outlined text-green-600 text-2xl">check_circle</span>
                          <span className="text-green-700 font-medium">{documents.ice_document.name}</span>
                        </div>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-slate-400 text-3xl mb-2">cloud_upload</span>
                          <p className="text-sm text-slate-600">Cliquez pour télécharger votre certificat ICE</p>
                          <p className="text-xs text-slate-400 mt-1">PDF, JPG ou PNG (max 5 Mo)</p>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Registration Document */}
                  <div className="space-y-2">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1 flex items-center gap-2">
                      <span className="material-symbols-outlined text-purple-500 text-base">article</span>
                      Registre de commerce
                    </label>
                    <div className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer hover:border-purple-400 hover:bg-purple-50/30 ${documents.registration_document ? 'border-green-400 bg-green-50/30' : 'border-slate-200'}`}>
                      <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={(e) => handleFileChange(e, 'registration_document')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                      {documents.registration_document ? (
                        <div className="flex items-center justify-center gap-3">
                          <span className="material-symbols-outlined text-green-600 text-2xl">check_circle</span>
                          <span className="text-green-700 font-medium">{documents.registration_document.name}</span>
                        </div>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-slate-400 text-3xl mb-2">cloud_upload</span>
                          <p className="text-sm text-slate-600">Extrait du registre de commerce (optionnel)</p>
                          <p className="text-xs text-slate-400 mt-1">PDF, JPG ou PNG (max 5 Mo)</p>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Authorization Document */}
                  <div className="space-y-2">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1 flex items-center gap-2">
                      <span className="material-symbols-outlined text-purple-500 text-base">verified</span>
                      Autorisation d'exercice
                    </label>
                    <div className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer hover:border-purple-400 hover:bg-purple-50/30 ${documents.authorization_document ? 'border-green-400 bg-green-50/30' : 'border-slate-200'}`}>
                      <input type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={(e) => handleFileChange(e, 'authorization_document')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                      {documents.authorization_document ? (
                        <div className="flex items-center justify-center gap-3">
                          <span className="material-symbols-outlined text-green-600 text-2xl">check_circle</span>
                          <span className="text-green-700 font-medium">{documents.authorization_document.name}</span>
                        </div>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-slate-400 text-3xl mb-2">cloud_upload</span>
                          <p className="text-sm text-slate-600">Autorisation d'exercice (optionnel)</p>
                          <p className="text-xs text-slate-400 mt-1">PDF, JPG ou PNG (max 5 Mo)</p>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Logo */}
                  <div className="space-y-2">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1 flex items-center gap-2">
                      <span className="material-symbols-outlined text-purple-500 text-base">image</span>
                      Logo de l'établissement
                    </label>
                    <div className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer hover:border-purple-400 hover:bg-purple-50/30 ${documents.logo ? 'border-green-400 bg-green-50/30' : 'border-slate-200'}`}>
                      <input type="file" accept=".jpg,.jpeg,.png" onChange={(e) => handleFileChange(e, 'logo')} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                      {documents.logo ? (
                        <div className="flex items-center justify-center gap-3">
                          <span className="material-symbols-outlined text-green-600 text-2xl">check_circle</span>
                          <span className="text-green-700 font-medium">{documents.logo.name}</span>
                        </div>
                      ) : (
                        <>
                          <span className="material-symbols-outlined text-slate-400 text-3xl mb-2">add_photo_alternate</span>
                          <p className="text-sm text-slate-600">Logo de votre établissement (optionnel)</p>
                          <p className="text-xs text-slate-400 mt-1">JPG ou PNG (max 2 Mo)</p>
                        </>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 4: Confirmation */}
              {step === 4 && (
                <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="bg-gradient-to-br from-slate-50 to-purple-50 rounded-2xl p-5 space-y-3 border border-slate-100">
                    {[
                      { label: 'Établissement', value: formData.name, icon: 'domain' },
                      { label: 'Type', value: formData.type || '-', icon: 'category' },
                      { label: 'ICE', value: formData.ice || '-', icon: 'numbers' },
                      { label: 'Téléphone', value: formData.phone, icon: 'phone' },
                      { label: 'Email', value: formData.email || user?.email || '-', icon: 'mail' },
                      { label: 'Responsable', value: formData.contact_person_name || '-', icon: 'person' },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-slate-200/50 last:border-0">
                        <div className="flex items-center gap-2 text-slate-500">
                          <span className="material-symbols-outlined text-lg">{item.icon}</span>
                          <span className="text-sm">{item.label}</span>
                        </div>
                        <span className="font-bold text-slate-900 text-sm capitalize">{item.value}</span>
                      </div>
                    ))}
                  </div>
                  <label className="flex items-start gap-3 p-4 rounded-2xl border-2 border-slate-200 cursor-pointer hover:border-purple-300 hover:bg-purple-50/30 transition-all group">
                    <input type="checkbox" name="certify" checked={formData.certify} onChange={handleChange} className="mt-0.5 w-5 h-5 rounded border-slate-300 text-purple-600 focus:ring-purple-500" />
                    <span className="text-sm text-slate-600 group-hover:text-slate-900 transition-colors">Je certifie que les informations fournies sont exactes et que je suis habilité(e) à représenter cet établissement.</span>
                  </label>
                  <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 flex items-start gap-3">
                    <span className="material-symbols-outlined text-amber-600 text-xl">schedule</span>
                    <p className="text-sm text-amber-800">Votre établissement sera vérifié sous <strong>24-48h</strong>. Vous pourrez ensuite publier des missions.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex justify-between mt-8 pt-6 border-t border-slate-100">
              {step > 1 ? (
                <button onClick={() => setStep(step - 1)} className="px-5 py-3 rounded-xl border-2 border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all flex items-center gap-2">
                  <span className="material-symbols-outlined text-lg">arrow_back</span> Précédent
                </button>
              ) : <div></div>}
              
              {step < 4 ? (
                <button onClick={() => setStep(step + 1)} className="px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-purple-500 text-white font-bold hover:shadow-lg hover:shadow-purple-500/30 transition-all flex items-center gap-2 active:scale-[0.98]">
                  Suivant <span className="material-symbols-outlined text-lg">arrow_forward</span>
                </button>
              ) : (
                <button onClick={handleSubmit} disabled={isSubmitting} className="px-6 py-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-500 text-white font-bold hover:shadow-lg hover:shadow-green-500/30 transition-all flex items-center gap-2 disabled:opacity-50 active:scale-[0.98]">
                  {isSubmitting ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <><span className="material-symbols-outlined text-lg">check_circle</span> Soumettre</>}
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>

      {/* RIGHT COLUMN: VISUALS */}
      <div className="hidden lg:flex w-1/2 h-screen bg-slate-900 relative flex-col justify-end pb-20 overflow-hidden sticky top-0">
        <div className="absolute inset-0 z-0">
          <motion.div animate={{ scale: [1, 1.05] }} transition={{ duration: 20, repeat: Infinity, repeatType: "reverse", ease: "linear" }} className="w-full h-full">
            <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1500" alt="Office" className="w-full h-full object-cover opacity-40" />
          </motion.div>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#581C87]/50 to-[#0F172A]/80"></div>
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-soft-light"></div>
        </div>

        <div className="relative z-20 text-center px-12 max-w-2xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 text-purple-200 text-xs font-bold tracking-wide mb-8 backdrop-blur-md">
              <span className="material-symbols-outlined text-lg">verified</span>
              Établissement Vérifié
            </div>
            
            <h3 className="text-4xl md:text-5xl font-bold font-display text-white mb-6 leading-tight">
              Recrutez les meilleurs <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-pink-200 to-purple-200">talents sociaux</span>
            </h3>
            
            <p className="text-purple-100/70 text-lg mb-10">Accédez à un réseau de professionnels qualifiés et vérifiés</p>

            <div className="flex justify-center gap-6">
              {[
                { icon: 'groups', label: 'Candidats', sub: 'Qualifiés' },
                { icon: 'speed', label: 'Recrutement', sub: 'Rapide' },
                { icon: 'security', label: 'Profils', sub: 'Vérifiés' }
              ].map((item, i) => (
                <div key={i} className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 text-center">
                  <span className="material-symbols-outlined text-2xl text-purple-300 mb-2">{item.icon}</span>
                  <div className="text-white font-bold text-sm">{item.label}</div>
                  <div className="text-purple-200/70 text-xs">{item.sub}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default EstablishmentOnboarding;
