import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { workerAPI, regionsAPI } from '../../src/api';

interface Region { id: number; name_fr: string; }
interface City { id: number; name_fr: string; }
interface Specialty { id: number; name: string; category: string; }

const WorkerOnboarding = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [regions, setRegions] = useState<Region[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [specialties, setSpecialties] = useState<Specialty[]>([]);
  
  const [formData, setFormData] = useState({
    first_name: '', last_name: '', cin: '', phone: '', birth_date: '',
    region_id: '', city_id: '', address: '', bio: '', daily_rate: '',
    years_experience: '', mobility_radius: '50', selectedSpecialties: [] as number[], certify: false
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [regionsRes, specialtiesRes] = await Promise.all([regionsAPI.getAll(), regionsAPI.getSpecialties()]);
        setRegions(regionsRes.regions || []);
        setSpecialties(specialtiesRes.specialties || []);
      } catch (err) { console.error(err); }
    };
    fetchData();
  }, []);

  useEffect(() => {
    if (formData.region_id) {
      regionsAPI.getCities(parseInt(formData.region_id)).then(res => setCities(res.cities || [])).catch(() => setCities([]));
    }
  }, [formData.region_id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value }));
  };

  const toggleSpecialty = (id: number) => {
    setFormData(prev => ({
      ...prev,
      selectedSpecialties: prev.selectedSpecialties.includes(id) ? prev.selectedSpecialties.filter(s => s !== id) : [...prev.selectedSpecialties, id]
    }));
  };

  const handleSubmit = async () => {
    if (!formData.certify) { setError('Veuillez certifier que vos informations sont exactes'); return; }
    setIsSubmitting(true);
    setError(null);
    try {
      await workerAPI.createProfile({
        first_name: formData.first_name, last_name: formData.last_name, cin: formData.cin,
        phone: formData.phone, birth_date: formData.birth_date || null,
        region_id: parseInt(formData.region_id) || null, city_id: parseInt(formData.city_id) || null,
        address: formData.address, bio: formData.bio, daily_rate: parseFloat(formData.daily_rate) || null,
        years_experience: parseInt(formData.years_experience) || 0, mobility_radius: parseInt(formData.mobility_radius) || 50
      });
      for (const specId of formData.selectedSpecialties) {
        try { await workerAPI.addSpecialty({ specialty_id: specId }); } catch {}
      }
      navigate('/worker/dashboard');
    } catch (err: any) { setError(err.message || 'Erreur lors de la création du profil'); }
    finally { setIsSubmitting(false); }
  };

  const steps = [
    { num: 1, title: 'Identité', icon: 'badge' },
    { num: 2, title: 'Professionnel', icon: 'work' },
    { num: 3, title: 'Préférences', icon: 'tune' },
    { num: 4, title: 'Confirmation', icon: 'check_circle' }
  ];

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-white overflow-hidden">
      {/* Back Button */}
      <Link to="/" className="absolute top-6 left-6 z-50 w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors border border-slate-200">
        <span className="material-symbols-outlined">arrow_back</span>
      </Link>

      {/* LEFT COLUMN: FORM */}
      <div className="w-full lg:w-1/2 min-h-screen flex flex-col justify-center items-center p-6 lg:p-8 relative bg-white z-10 overflow-y-auto">
        <div className="w-full max-w-[500px] py-8">
          {/* Header */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#2563EB] to-[#db2777] uppercase tracking-tighter mb-4">TADAMON</h2>
            <h3 className="text-xl font-bold text-slate-900 mb-2">Complétez votre profil</h3>
            <p className="text-slate-500 text-sm">Ces informations garantissent la fiabilité du réseau</p>
          </div>

          {/* Progress Steps */}
          <div className="flex justify-between mb-8 relative px-4">
            <div className="absolute top-5 left-8 right-8 h-0.5 bg-slate-200 -z-10"></div>
            <div className="absolute top-5 left-8 h-0.5 bg-gradient-to-r from-blue-600 to-blue-400 -z-10 transition-all duration-500" style={{ width: `${((step - 1) / 3) * 100}%` }}></div>
            {steps.map((s) => (
              <div key={s.num} className="flex flex-col items-center">
                <motion.div animate={{ scale: step === s.num ? 1.1 : 1 }} className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 transition-all shadow-lg ${step >= s.num ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-blue-500/30' : 'bg-white border-2 border-slate-200 text-slate-400'}`}>
                  <span className="material-symbols-outlined text-lg">{step > s.num ? 'check' : s.icon}</span>
                </motion.div>
                <span className={`text-[10px] font-bold uppercase tracking-wide ${step >= s.num ? 'text-blue-600' : 'text-slate-400'}`}>{s.title}</span>
              </div>
            ))}
          </div>

          {/* Form Card */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-3xl p-6 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] border border-slate-100">
            {error && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6 p-4 bg-red-50 border border-red-200 rounded-2xl text-red-600 text-sm font-medium flex items-center gap-3">
                <span className="material-symbols-outlined">error</span>{error}
              </motion.div>
            )}

            <AnimatePresence mode="wait">
              {/* Step 1: Identity */}
              {step === 1 && (
                <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Prénom *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">person</span>
                        <input type="text" name="first_name" value={formData.first_name} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Prénom" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Nom *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">badge</span>
                        <input type="text" name="last_name" value={formData.last_name} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Nom" />
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">CIN *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">id_card</span>
                        <input type="text" name="cin" value={formData.cin} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="AB123456" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Téléphone *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">phone</span>
                        <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="06 12 34 56 78" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Date de naissance</label>
                    <div className="relative group">
                      <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">calendar_month</span>
                      <input type="date" name="birth_date" value={formData.birth_date} onChange={handleChange}
                        className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 outline-none" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Région *</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">map</span>
                        <select name="region_id" value={formData.region_id} onChange={handleChange} required
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 outline-none appearance-none cursor-pointer">
                          <option value="">Sélectionnez...</option>
                          {regions.map(r => <option key={r.id} value={r.id}>{r.name_fr}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">expand_more</span>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Ville</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">location_city</span>
                        <select name="city_id" value={formData.city_id} onChange={handleChange}
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 outline-none appearance-none cursor-pointer">
                          <option value="">Sélectionnez...</option>
                          {cities.map(c => <option key={c.id} value={c.id}>{c.name_fr}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">expand_more</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Professional */}
              {step === 2 && (
                <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Bio / Présentation</label>
                    <textarea name="bio" value={formData.bio} onChange={handleChange} rows={3}
                      className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl px-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none resize-none"
                      placeholder="Décrivez votre parcours et vos compétences..."></textarea>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Années d'expérience</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">timeline</span>
                        <input type="number" name="years_experience" value={formData.years_experience} onChange={handleChange} min="0"
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="0" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Tarif journalier (DH)</label>
                      <div className="relative group">
                        <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">payments</span>
                        <input type="number" name="daily_rate" value={formData.daily_rate} onChange={handleChange} min="0"
                          className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="400" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Domaines d'intervention</label>
                    <div className="grid grid-cols-2 gap-2 max-h-[200px] overflow-y-auto pr-2">
                      {specialties.map(spec => (
                        <motion.label key={spec.id} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                          className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${formData.selectedSpecialties.includes(spec.id) ? 'border-blue-500 bg-blue-50' : 'border-slate-100 hover:border-blue-200'}`}>
                          <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${formData.selectedSpecialties.includes(spec.id) ? 'bg-blue-600 border-blue-600' : 'border-slate-300'}`}>
                            {formData.selectedSpecialties.includes(spec.id) && <span className="material-symbols-outlined text-white text-sm">check</span>}
                          </div>
                          <input type="checkbox" checked={formData.selectedSpecialties.includes(spec.id)} onChange={() => toggleSpecialty(spec.id)} className="hidden" />
                          <span className="text-xs font-medium text-slate-700">{spec.name}</span>
                        </motion.label>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Preferences */}
              {step === 3 && (
                <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-6">
                  <div className="space-y-4">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Rayon de mobilité</label>
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-100">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-slate-600 font-medium">Distance maximale</span>
                        <span className="text-2xl font-black text-blue-600">{formData.mobility_radius} km</span>
                      </div>
                      <input type="range" name="mobility_radius" value={formData.mobility_radius} onChange={handleChange} min="10" max="200" step="10"
                        className="w-full h-2 bg-white rounded-lg appearance-none cursor-pointer accent-blue-600" />
                      <div className="flex justify-between text-xs text-slate-400 mt-2 font-medium">
                        <span>10 km</span><span>100 km</span><span>200 km</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Adresse complète</label>
                    <div className="relative group">
                      <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">home</span>
                      <input type="text" name="address" value={formData.address} onChange={handleChange}
                        className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" placeholder="Votre adresse complète" />
                    </div>
                  </div>
                  <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100 flex items-start gap-3">
                    <span className="material-symbols-outlined text-blue-600 text-xl mt-0.5">info</span>
                    <p className="text-sm text-blue-800">Vous pourrez configurer vos disponibilités précises depuis votre tableau de bord après validation.</p>
                  </div>
                </motion.div>
              )}

              {/* Step 4: Confirmation */}
              {step === 4 && (
                <motion.div key="step4" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
                  <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl p-5 space-y-3 border border-slate-100">
                    {[
                      { label: 'Nom complet', value: `${formData.first_name} ${formData.last_name}`, icon: 'person' },
                      { label: 'CIN', value: formData.cin, icon: 'id_card' },
                      { label: 'Téléphone', value: formData.phone, icon: 'phone' },
                      { label: 'Expérience', value: `${formData.years_experience || 0} ans`, icon: 'timeline' },
                      { label: 'Tarif', value: formData.daily_rate ? `${formData.daily_rate} DH/jour` : 'Non défini', icon: 'payments' },
                      { label: 'Spécialités', value: `${formData.selectedSpecialties.length} sélectionnée(s)`, icon: 'category' },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center justify-between py-2 border-b border-slate-200/50 last:border-0">
                        <div className="flex items-center gap-2 text-slate-500">
                          <span className="material-symbols-outlined text-lg">{item.icon}</span>
                          <span className="text-sm">{item.label}</span>
                        </div>
                        <span className="font-bold text-slate-900 text-sm">{item.value}</span>
                      </div>
                    ))}
                  </div>
                  <label className="flex items-start gap-3 p-4 rounded-2xl border-2 border-slate-200 cursor-pointer hover:border-blue-300 hover:bg-blue-50/30 transition-all group">
                    <input type="checkbox" name="certify" checked={formData.certify} onChange={handleChange} className="mt-0.5 w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                    <span className="text-sm text-slate-600 group-hover:text-slate-900 transition-colors">Je certifie que les informations fournies sont exactes et j'accepte les conditions d'utilisation de TADAMON.</span>
                  </label>
                  <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 flex items-start gap-3">
                    <span className="material-symbols-outlined text-amber-600 text-xl">schedule</span>
                    <p className="text-sm text-amber-800">Votre profil sera vérifié sous <strong>24-48h</strong>. Vous recevrez une notification par email.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t border-slate-100">
              {step > 1 ? (
                <button onClick={() => setStep(step - 1)} className="px-5 py-3 rounded-xl border-2 border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-all flex items-center gap-2">
                  <span className="material-symbols-outlined text-lg">arrow_back</span> Précédent
                </button>
              ) : <div></div>}
              
              {step < 4 ? (
                <button onClick={() => setStep(step + 1)} className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 text-white font-bold hover:shadow-lg hover:shadow-blue-500/30 transition-all flex items-center gap-2 active:scale-[0.98]">
                  Suivant <span className="material-symbols-outlined text-lg">arrow_forward</span>
                </button>
              ) : (
                <button onClick={handleSubmit} disabled={isSubmitting} className="px-6 py-3 rounded-xl bg-gradient-to-r from-green-600 to-emerald-500 text-white font-bold hover:shadow-lg hover:shadow-green-500/30 transition-all flex items-center gap-2 disabled:opacity-50 active:scale-[0.98]">
                  {isSubmitting ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <><span className="material-symbols-outlined text-lg">check_circle</span> Soumettre</>}
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>

      {/* RIGHT COLUMN: VISUALS */}
      <div className="hidden lg:flex w-1/2 h-screen bg-slate-900 relative flex-col justify-end pb-20 overflow-hidden sticky top-0">
        <div className="absolute inset-0 z-0">
          <motion.div animate={{ scale: [1, 1.05] }} transition={{ duration: 20, repeat: Infinity, repeatType: "reverse", ease: "linear" }} className="w-full h-full">
            <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80&w=1500" alt="Professional" className="w-full h-full object-cover opacity-40" />
          </motion.div>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#1E3A8A]/50 to-[#0F172A]/80"></div>
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-soft-light"></div>
        </div>

        <div className="relative z-20 text-center px-12 max-w-2xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 text-blue-200 text-xs font-bold tracking-wide mb-8 backdrop-blur-md">
              <span className="material-symbols-outlined text-lg">verified</span>
              Profil Professionnel Vérifié
            </div>
            
            <h3 className="text-4xl md:text-5xl font-bold font-display text-white mb-6 leading-tight">
              Rejoignez le réseau <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-cyan-200 to-blue-200">des experts sociaux</span>
            </h3>
            
            <p className="text-blue-100/70 text-lg mb-10">Plus de 10 000 professionnels nous font confiance</p>

            <div className="flex justify-center gap-6">
              {[
                { icon: 'verified', label: 'Labellisation', sub: 'Rigoureuse' },
                { icon: 'school', label: 'Diplômes', sub: 'Vérifiés' },
                { icon: 'workspace_premium', label: 'Qualité', sub: 'Garantie' }
              ].map((item, i) => (
                <div key={i} className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 text-center">
                  <span className="material-symbols-outlined text-2xl text-blue-300 mb-2">{item.icon}</span>
                  <div className="text-white font-bold text-sm">{item.label}</div>
                  <div className="text-blue-200/70 text-xs">{item.sub}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default WorkerOnboarding;
