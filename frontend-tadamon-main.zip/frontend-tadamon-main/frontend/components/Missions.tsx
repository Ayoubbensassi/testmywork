import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../AuthContext';
import { useSearchParams } from 'react-router-dom';
import { missionsAPI, regionsAPI, applicationsAPI } from '../src/api';
import { useMissions, useSearchMissions } from '../hooks/useMissions';
import { useRegions, useAllCities } from '../hooks/useRegions';
import { useApplyToMission } from '../hooks/useApplications';
import LocationAutocomplete from './LocationAutocomplete';

interface Mission {
  id: number;
  title: string;
  description: string;
  mission_type: string;
  start_date: string;
  end_date: string;
  salary_min: string;
  salary_max: string;
  is_urgent: boolean;
  status: string;
  establishment_name: string;
  region_name: string;
  city_name: string;
  created_at: string;
}

interface Region { id: number; name_fr: string; code: string; }
interface City { id: number; name_fr: string; region_id: number; }

// Impact tags for emotional connection
const IMPACT_TAGS = [
  { id: 1, label: 'Impact social', icon: 'favorite', color: 'rose' },
  { id: 2, label: 'Mission humaine', icon: 'volunteer_activism', color: 'purple' },
  { id: 3, label: 'Insertion jeunes', icon: 'school', color: 'blue' },
  { id: 4, label: 'Aide aux familles', icon: 'family_restroom', color: 'emerald' },
];

const Missions = () => {
  const { user, openLoginModal } = useAuth();
  const [searchParams] = useSearchParams();
  
  // React Query hooks
  const { data: missions = [], isLoading: missionsLoading, error: missionsError } = useMissions();
  const { data: regions = [], isLoading: regionsLoading } = useRegions();
  const { data: cities = [] } = useAllCities();
  const { mutate: applyToMission, isPending: isApplying } = useApplyToMission();
  
  const isLoading = missionsLoading || regionsLoading;
  const error = missionsError ? 'Erreur lors du chargement des missions' : null;
  const [applyingTo, setApplyingTo] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('Toutes les régions');
  const [selectedMissionTypes, setSelectedMissionTypes] = useState<string[]>([]);
  const [selectedSort, setSelectedSort] = useState('Pertinence');

  const missionTypes = [
    { key: 'longue_duree', label: 'Longue durée', icon: 'work', color: 'emerald' },
    { key: 'courte_duree', label: 'Courte durée', icon: 'schedule', color: 'blue' },
    { key: 'ponctuelle', label: 'Ponctuelle', icon: 'event', color: 'purple' },
    { key: 'remplacement', label: 'Remplacement', icon: 'swap_horiz', color: 'orange' },
  ];

  // React Query handles data fetching automatically - no useEffect needed!
  
  useEffect(() => {
    const q = searchParams.get('q'), loc = searchParams.get('location');
    if (q) setSearchQuery(q);
    if (loc) setSelectedLocation(loc);
  }, [searchParams]);

  const filteredMissions = missions.filter(m => {
    const searchMatch = !searchQuery || m.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      m.establishment_name?.toLowerCase().includes(searchQuery.toLowerCase()) || m.description.toLowerCase().includes(searchQuery.toLowerCase());
    const locationMatch = selectedLocation === 'Toutes les régions' || m.region_name === selectedLocation || m.city_name === selectedLocation;
    const typeMatch = selectedMissionTypes.length === 0 || selectedMissionTypes.includes(m.mission_type);
    return searchMatch && locationMatch && typeMatch;
  }).sort((a, b) => {
    if (selectedSort === 'Date') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    if (selectedSort === 'Salaire') return (parseFloat(b.salary_max) || 0) - (parseFloat(a.salary_max) || 0);
    return 0;
  });

  const toggleType = (type: string) => setSelectedMissionTypes(prev => prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]);
  const clearFilters = () => { setSearchQuery(''); setSelectedLocation('Toutes les régions'); setSelectedMissionTypes([]); };

  const handleApply = (mission: Mission) => {
    if (!user) { openLoginModal(); return; }
    if (user.role !== 'worker') { alert('Seuls les travailleurs peuvent postuler'); return; }
    setApplyingTo(mission.id);
    applyToMission(
      { mission_id: mission.id },
      {
        onSuccess: () => {
          alert(`Candidature envoyée pour "${mission.title}" !`);
          setApplyingTo(null);
        },
        onError: () => {
          setApplyingTo(null);
        }
      }
    );
  };

  const formatDate = (d: string) => {
    const h = Math.floor((Date.now() - new Date(d).getTime()) / 3600000);
    if (h < 1) return "À l'instant";
    if (h < 24) return `Il y a ${h}h`;
    const days = Math.floor(h / 24);
    return days === 1 ? 'Hier' : `Il y a ${days}j`;
  };

  const formatSalary = (min: string, max: string) => {
    const a = parseFloat(min), b = parseFloat(max);
    if (!a && !b) return 'À négocier';
    if (a && b) return `${a}–${b} DH/j`;
    return `${b || a} DH/j`;
  };

  // Get random impact tag for mission (simulated)
  const getImpactTag = (id: number) => IMPACT_TAGS[id % IMPACT_TAGS.length];

  const hasActiveFilters = searchQuery || selectedLocation !== 'Toutes les régions' || selectedMissionTypes.length > 0;

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* ===== PREMIUM HERO ===== */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden pt-28 pb-32">
        {/* Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?q=80&w=2070')` }} />
          <div className="absolute inset-0 bg-gradient-to-br from-slate-950/95 via-slate-900/90 to-slate-950/95" />
          <div className="absolute inset-0 bg-gradient-to-tr from-blue-950/40 via-transparent to-indigo-950/30" />
          <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-cyan-500 rounded-full blur-[150px]" />
          <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.08, 0.15, 0.08] }} transition={{ duration: 10, repeat: Infinity, delay: 2 }} className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-500 rounded-full blur-[150px]" />
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-6">
                <span className="relative flex h-2 w-2"><span className="animate-ping absolute h-full w-full rounded-full bg-emerald-400 opacity-75"></span><span className="relative rounded-full h-2 w-2 bg-emerald-400"></span></span>
                <span className="text-emerald-400 text-sm font-medium">+312 professionnels vérifiés ce mois</span>
              </motion.div>

              <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-[1.1]">
                Trouvez une mission<br />qui a du <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 italic">sens</span>
              </motion.h1>

              <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="text-white/60 text-lg mb-8 max-w-lg">
                Rejoignez le réseau des travailleurs sociaux engagés. Missions vérifiées, établissements certifiés.
              </motion.p>

              {/* Process Steps - SIGNATURE ELEMENT */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="flex items-center gap-3 mb-10">
                {[
                  { icon: 'person_add', label: 'Inscription' },
                  { icon: 'verified', label: 'Vérification' },
                  { icon: 'work', label: 'Mission' },
                ].map((step, i) => (
                  <React.Fragment key={i}>
                    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 border border-white/10">
                      <span className="material-symbols-outlined text-blue-400 text-lg">{step.icon}</span>
                      <span className="text-white/80 text-sm font-medium">{step.label}</span>
                    </div>
                    {i < 2 && <span className="material-symbols-outlined text-white/30">arrow_forward</span>}
                  </React.Fragment>
                ))}
              </motion.div>

              {/* Trust Proof */}
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2 text-white/60 text-sm">
                  <span className="material-symbols-outlined text-amber-400">star</span>
                  <span>Noté <strong className="text-white">4.8/5</strong> par les professionnels</span>
                </div>
                <div className="flex items-center gap-2 text-white/60 text-sm">
                  <span className="material-symbols-outlined text-emerald-400">verified</span>
                  <span>Diplômes vérifiés manuellement</span>
                </div>
              </motion.div>
            </div>

            {/* Right - Search Card */}
            <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-indigo-500/20 rounded-[2rem] blur-2xl" />
              <div className="relative bg-white/[0.03] backdrop-blur-xl rounded-[1.5rem] border border-white/10 p-6 shadow-2xl">
                <h3 className="text-white font-semibold text-lg mb-5 flex items-center gap-2">
                  <span className="material-symbols-outlined text-blue-400">search</span>
                  Rechercher une mission
                </h3>
                
                {/* Search Input */}
                <div className="space-y-3 mb-5">
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-white/40">work</span>
                    <input type="text" placeholder="Poste, spécialité..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3.5 text-white placeholder-white/40 focus:outline-none focus:border-blue-500/50 transition-colors" />
                  </div>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 material-symbols-outlined text-white/40">location_on</span>
                    <div className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3.5">
                      <LocationAutocomplete regions={regions} cities={cities} value={selectedLocation} onChange={(val) => setSelectedLocation(val)} placeholder="Où cherchez-vous ?" variant="dark" />
                    </div>
                  </div>
                </div>

                {/* Quick Filters */}
                <div className="flex flex-wrap gap-2 mb-5">
                  {missionTypes.slice(0, 3).map(t => (
                    <button key={t.key} onClick={() => toggleType(t.key)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${selectedMissionTypes.includes(t.key) ? 'bg-blue-500 text-white' : 'bg-white/5 text-white/60 hover:bg-white/10'}`}>
                      {t.label}
                    </button>
                  ))}
                </div>

                <button className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all">
                  <span>Voir {filteredMissions.length} missions</span>
                  <span className="material-symbols-outlined">arrow_forward</span>
                </button>

                {/* Live Update */}
                <p className="text-center text-white/40 text-xs mt-4 flex items-center justify-center gap-1">
                  <span className="material-symbols-outlined text-emerald-400 text-sm">update</span>
                  Missions mises à jour en temps réel
                </p>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Wave */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden z-20">
          <svg className="relative block w-full h-[80px]" viewBox="0 0 1440 120" preserveAspectRatio="none">
            <path d="M0,64 C360,100 720,120 1080,80 C1260,60 1380,40 1440,64 L1440,120 L0,120 Z" fill="#f8fafc" />
          </svg>
        </div>
      </section>

      {/* ===== MAIN CONTENT ===== */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-20">
        
        {/* Active Filters Pills */}
        {hasActiveFilters && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap items-center gap-2 mb-6 p-4 bg-blue-50 rounded-2xl border border-blue-100">
            <span className="text-sm font-medium text-blue-900 mr-2">Filtres actifs:</span>
            {searchQuery && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg text-sm font-medium text-slate-700 border border-slate-200">
                <span className="material-symbols-outlined text-sm">search</span>"{searchQuery}"
                <button onClick={() => setSearchQuery('')} className="ml-1 hover:text-red-500 cursor-pointer"><span className="material-symbols-outlined text-sm">close</span></button>
              </span>
            )}
            {selectedLocation !== 'Toutes les régions' && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg text-sm font-medium text-slate-700 border border-slate-200">
                <span className="material-symbols-outlined text-sm">location_on</span>{selectedLocation}
                <button onClick={() => setSelectedLocation('Toutes les régions')} className="ml-1 hover:text-red-500 cursor-pointer"><span className="material-symbols-outlined text-sm">close</span></button>
              </span>
            )}
            {selectedMissionTypes.map(t => (
              <span key={t} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg text-sm font-medium text-slate-700 border border-slate-200">
                {missionTypes.find(m => m.key === t)?.label}
                <button onClick={() => toggleType(t)} className="ml-1 hover:text-red-500 cursor-pointer"><span className="material-symbols-outlined text-sm">close</span></button>
              </span>
            ))}
            <button onClick={clearFilters} className="text-sm font-medium text-blue-600 hover:text-blue-700 ml-auto cursor-pointer">Tout effacer</button>
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* ===== SIDEBAR FILTERS ===== */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 sticky top-24">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <span className="material-symbols-outlined text-blue-600">tune</span>Filtres
                </h3>
                {hasActiveFilters && <button onClick={clearFilters} className="text-xs font-medium text-blue-600 hover:underline cursor-pointer">Réinitialiser</button>}
              </div>

              {/* Mission Type Filter */}
              <div className="mb-6">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <span className="material-symbols-outlined text-sm">category</span>Type de mission
                </h4>
                <div className="space-y-2">
                  {missionTypes.map(t => {
                    const count = missions.filter(m => m.mission_type === t.key).length;
                    const isActive = selectedMissionTypes.includes(t.key);
                    return (
                      <button key={t.key} onClick={() => toggleType(t.key)}
                        className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all cursor-pointer ${isActive ? 'bg-blue-50 border-blue-200' : 'bg-slate-50 border-transparent hover:bg-slate-100'} border`}>
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isActive ? 'bg-blue-600 text-white' : 'bg-white text-slate-500'}`}>
                          <span className="material-symbols-outlined text-lg">{t.icon}</span>
                        </div>
                        <span className={`flex-1 text-left text-sm font-medium ${isActive ? 'text-blue-900' : 'text-slate-700'}`}>{t.label}</span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${isActive ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'}`}>{count}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Stats Card */}
              <div className="p-4 bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl text-white">
                <p className="text-xs text-white/60 mb-1">Missions actives</p>
                <p className="text-2xl font-bold">{missions.length}</p>
                <p className="text-xs text-emerald-400 mt-2 flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">trending_up</span>+12% cette semaine
                </p>
              </div>
            </div>
          </div>

          {/* ===== MISSIONS LIST ===== */}
          <div className="lg:col-span-9">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <h2 className="text-xl font-bold text-slate-900">Missions disponibles</h2>
                <span className="bg-slate-900 text-white text-xs font-bold px-2.5 py-1 rounded-full">{filteredMissions.length}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500">Trier:</span>
                <select value={selectedSort} onChange={(e) => setSelectedSort(e.target.value)}
                  className="text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500/20 cursor-pointer">
                  <option>Pertinence</option><option>Date</option><option>Salaire</option>
                </select>
              </div>
            </div>

            {/* Loading */}
            {isLoading && (
              <div className="bg-white rounded-2xl p-16 text-center border border-slate-100">
                <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-slate-500">Chargement des missions...</p>
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="bg-white rounded-2xl p-16 text-center border border-red-100">
                <span className="material-symbols-outlined text-5xl text-red-300 mb-4">error</span>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Erreur</h3>
                <p className="text-slate-500">{error}</p>
              </div>
            )}

            {/* Empty */}
            {!isLoading && !error && filteredMissions.length === 0 && (
              <div className="bg-white rounded-2xl p-16 text-center border border-slate-100">
                <span className="material-symbols-outlined text-5xl text-slate-300 mb-4">search_off</span>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Aucune mission trouvée</h3>
                <p className="text-slate-500 mb-6">Essayez de modifier vos critères de recherche</p>
                <button onClick={clearFilters} className="px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 cursor-pointer">Effacer les filtres</button>
              </div>
            )}

            {/* Missions */}
            {!isLoading && !error && filteredMissions.length > 0 && (
              <div className="space-y-4">
                <AnimatePresence>
                  {filteredMissions.map((mission) => {
                    const type = missionTypes.find(t => t.key === mission.mission_type);
                    const impact = getImpactTag(mission.id);
                    return (
                      <motion.div key={mission.id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                        className="bg-white rounded-2xl p-6 border border-slate-100 hover:border-blue-200 hover:shadow-lg transition-all group">
                        <div className="flex flex-col lg:flex-row gap-5">
                          {/* Icon */}
                          <div className={`w-14 h-14 rounded-xl bg-${type?.color || 'slate'}-100 flex items-center justify-center shrink-0`}>
                            <span className={`material-symbols-outlined text-2xl text-${type?.color || 'slate'}-600`}>{type?.icon || 'work'}</span>
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
                              <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{mission.title}</h3>
                              <div className="flex items-center gap-2">
                                {/* Impact Tag - EMOTIONAL */}
                                <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md bg-${impact.color}-50 text-${impact.color}-700 text-[10px] font-bold uppercase`}>
                                  <span className="material-symbols-outlined text-xs">{impact.icon}</span>{impact.label}
                                </span>
                                {mission.is_urgent && (
                                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-red-500 text-white text-[10px] font-bold uppercase">
                                    <span className="material-symbols-outlined text-xs">priority_high</span>Urgent
                                  </span>
                                )}
                              </div>
                            </div>

                            <p className="text-slate-500 text-sm mb-4 line-clamp-2">{mission.description}</p>

                            {/* Meta */}
                            <div className="flex flex-wrap items-center gap-4 text-sm">
                              <span className="flex items-center gap-1.5 text-slate-600">
                                <span className="material-symbols-outlined text-lg text-slate-400">business</span>{mission.establishment_name}
                              </span>
                              <span className="flex items-center gap-1.5 text-slate-600">
                                <span className="material-symbols-outlined text-lg text-slate-400">location_on</span>{mission.city_name || mission.region_name}
                              </span>
                              <span className="flex items-center gap-1.5 text-blue-600 font-semibold">
                                <span className="material-symbols-outlined text-lg">payments</span>{formatSalary(mission.salary_min, mission.salary_max)}
                              </span>
                              <span className="flex items-center gap-1.5 text-slate-400 text-xs ml-auto">
                                <span className="material-symbols-outlined text-sm">schedule</span>{formatDate(mission.created_at)}
                              </span>
                            </div>
                          </div>

                          {/* Action */}
                          <div className="flex lg:flex-col items-center lg:items-end gap-3 shrink-0">
                            <button onClick={() => handleApply(mission)} disabled={applyingTo === mission.id}
                              className="px-6 py-3 bg-slate-900 hover:bg-blue-600 text-white font-semibold rounded-xl transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50">
                              {applyingTo === mission.id ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : <><span>Postuler</span><span className="material-symbols-outlined text-lg">send</span></>}
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Missions;
