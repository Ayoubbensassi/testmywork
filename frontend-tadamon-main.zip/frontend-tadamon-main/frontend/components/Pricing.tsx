
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const Pricing: React.FC = () => {
  const { openLoginModal } = useAuth();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const faqs = [
    {
      question: "Comment créer un compte ?",
      answer: "L'inscription est simple et rapide. Cliquez sur 'Créer un compte', choisissez votre statut (Expert ou Structure), et remplissez les informations demandées. Notre équipe validera votre profil sous 24-48h."
    },
    {
      question: "Qu'est-ce que le Label Réseau ?",
      answer: "Le Label Réseau est une certification interne garantissant l'excellence. Il est attribué aux professionnels dont les diplômes, expériences et références ont été rigoureusement vérifiés par nos experts."
    },
    {
      question: "Combien coûte le service ?",
      answer: "L'inscription est gratuite pour tous. Nous prélevons une commission uniquement sur les missions réalisées : 5% pour les experts (déduits des revenus) et 10% pour les établissements (en sus de la rémunération)."
    },
    {
        question: "Comment sont calculées les commissions ?",
        answer: "Les commissions sont calculées sur le montant total de la mission. Elles couvrent les frais de gestion, la vérification des profils, l'assurance et le support 24/7."
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen font-sans">
        
        {/* 1. PREMIUM HERO SECTION */}
        <section className="relative pt-40 pb-56 lg:pt-48 lg:pb-64 overflow-hidden">
             {/* Background with image */}
             <div className="absolute inset-0">
               <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?q=80&w=2070')` }} />
               <div className="absolute inset-0 bg-gradient-to-br from-slate-950/95 via-slate-900/90 to-slate-950/95" />
               <div className="absolute inset-0 bg-gradient-to-tr from-blue-950/40 via-transparent to-indigo-950/30" />
             </div>
             
             {/* Animated orbs */}
             <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }} transition={{ duration: 8, repeat: Infinity }} className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-cyan-500 rounded-full blur-[150px]" />
             <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.08, 0.15, 0.08] }} transition={{ duration: 10, repeat: Infinity, delay: 2 }} className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-indigo-500 rounded-full blur-[150px]" />
             
             {/* Grid pattern */}
             <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px]" />
             
             {/* Floating icons */}
             <div className="absolute inset-0 overflow-hidden pointer-events-none">
               <motion.div animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }} transition={{ duration: 6, repeat: Infinity }} className="absolute top-[20%] left-[10%] w-16 h-16 bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 rounded-2xl flex items-center justify-center backdrop-blur-sm border border-emerald-500/20">
                 <span className="material-symbols-outlined text-emerald-400 text-2xl">savings</span>
               </motion.div>
               <motion.div animate={{ y: [0, -25, 0], rotate: [0, -5, 0] }} transition={{ duration: 7, repeat: Infinity, delay: 1 }} className="absolute top-[15%] right-[10%] w-14 h-14 bg-gradient-to-br from-amber-500/20 to-amber-600/10 rounded-xl flex items-center justify-center backdrop-blur-sm border border-amber-500/20">
                 <span className="material-symbols-outlined text-amber-400 text-xl">diamond</span>
               </motion.div>
               <motion.div animate={{ y: [0, -15, 0] }} transition={{ duration: 5, repeat: Infinity, delay: 2 }} className="absolute bottom-[30%] left-[15%] w-12 h-12 bg-gradient-to-br from-blue-500/20 to-blue-600/10 rounded-lg flex items-center justify-center backdrop-blur-sm border border-blue-500/20">
                 <span className="material-symbols-outlined text-blue-400 text-lg">verified</span>
               </motion.div>
             </div>

             <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
                   className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-8">
                   <span className="material-symbols-outlined text-emerald-400 text-lg">verified</span>
                   <span className="text-emerald-400 text-sm font-medium">Transparence totale • Zéro frais cachés</span>
                </motion.div>
                
                <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
                   className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight tracking-tight">
                   Investissez dans votre <span className="italic text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">avenir</span>
                </motion.h1>
                
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.2 }}
                   className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-10">
                   Une tarification adaptée au marché marocain. Inscription gratuite, commission uniquement à la performance.
                </motion.p>

                {/* Value props */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="flex flex-wrap justify-center gap-6">
                  <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-white/5 border border-white/10">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                      <span className="material-symbols-outlined text-blue-400">person</span>
                    </div>
                    <div className="text-left">
                      <p className="text-white font-bold">Experts</p>
                      <p className="text-white/50 text-sm">5% commission</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-white/5 border border-white/10">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                      <span className="material-symbols-outlined text-purple-400">domain</span>
                    </div>
                    <div className="text-left">
                      <p className="text-white font-bold">Structures</p>
                      <p className="text-white/50 text-sm">10% commission</p>
                    </div>
                  </div>
                </motion.div>
             </div>
             
             {/* Wave divider */}
             <div className="absolute bottom-0 left-0 w-full overflow-hidden z-20">
               <svg className="relative block w-full h-[60px] md:h-[80px]" viewBox="0 0 1440 120" preserveAspectRatio="none">
                 <path d="M0,64 C360,100 720,120 1080,80 C1260,60 1380,40 1440,64 L1440,120 L0,120 Z" fill="#f8fafc" />
               </svg>
             </div>
        </section>

        {/* 2. PRICING CARDS (Overlapping) */}
        <section className="relative z-20 -mt-32 md:-mt-40 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto pb-24">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                {/* Card 1: Expert */}
                <motion.div 
                   initial={{ opacity: 0, y: 50 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ duration: 0.6, delay: 0.3 }}
                   className="bg-white rounded-[2.5rem] p-8 md:p-12 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] relative overflow-hidden group hover:-translate-y-2 transition-transform duration-500 border border-white/50"
                >
                    <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    
                    <div className="relative z-10">
                        <div className="flex justify-between items-start mb-8">
                            <div>
                                <h3 className="text-3xl font-bold font-display text-slate-900 mb-2">Expert Social</h3>
                                <p className="text-slate-500 text-sm font-medium">Pour les travailleurs sociaux qualifiés</p>
                            </div>
                            <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-600 shadow-inner group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                                <span className="material-symbols-outlined text-2xl">person</span>
                            </div>
                        </div>

                        <div className="mb-10">
                            <div className="flex items-baseline gap-2 mb-2">
                                <span className="text-6xl font-black text-slate-900 font-display tracking-tight">0</span>
                                <span className="text-2xl font-bold text-slate-400">DH</span>
                                <span className="text-slate-400 font-medium ml-2">à l'inscription</span>
                            </div>
                            <p className="text-blue-600 font-bold text-sm flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                                Accès intégral sans frais initiaux.
                            </p>
                        </div>

                        <ul className="space-y-5 mb-12">
                            {[
                                "Vérification approfondie du profil & diplômes",
                                "Candidatures illimitées aux missions premium",
                                "Visibilité auprès des grands établissements",
                                "Messagerie sécurisée & support dédié"
                            ].map((feat, i) => (
                                <li key={i} className="flex items-start gap-3 text-slate-600 text-sm font-medium">
                                    <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                                        <span className="material-symbols-outlined text-[12px] font-bold">check</span>
                                    </div>
                                    {feat}
                                </li>
                            ))}
                        </ul>

                        <div className="bg-slate-50/80 backdrop-blur-sm rounded-3xl p-6 mb-8 border border-slate-100 flex items-center justify-between group-hover:border-blue-100 transition-colors">
                            <div>
                                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">COMMISSION</div>
                                <div className="text-[10px] text-slate-400 max-w-[200px] leading-tight font-medium">Appliquée uniquement sur les revenus générés.</div>
                            </div>
                            <div className="text-4xl font-black text-blue-600 font-display">5<span className="text-lg align-top font-bold">%</span></div>
                        </div>

                        <button 
                            onClick={openLoginModal}
                            className="w-full py-5 bg-white border-2 border-slate-100 text-slate-900 font-bold rounded-2xl hover:border-blue-600 hover:text-blue-600 transition-all shadow-sm hover:shadow-xl active:scale-95 relative overflow-hidden group/btn cursor-pointer"
                        >
                            <span className="relative z-10">Créer mon profil expert</span>
                        </button>
                    </div>
                </motion.div>

                {/* Card 2: Structure */}
                <motion.div 
                   initial={{ opacity: 0, y: 50 }}
                   animate={{ opacity: 1, y: 0 }}
                   transition={{ duration: 0.6, delay: 0.4 }}
                   className="bg-white rounded-[2.5rem] p-8 md:p-12 shadow-[0_30px_60px_-15px_rgba(37,99,235,0.2)] relative overflow-hidden group hover:-translate-y-2 transition-transform duration-500 border-2 border-blue-600/10 ring-4 ring-blue-50/50"
                >
                    <div className="absolute top-6 right-6 bg-[#0F172A] text-white text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-xl shadow-lg z-20">
                        Institutionnel
                    </div>
                    
                    {/* Subtle gradient glow */}
                    <div className="absolute -right-20 -top-20 w-64 h-64 bg-blue-100 rounded-full blur-[80px] opacity-50 group-hover:opacity-80 transition-opacity"></div>

                    <div className="relative z-10">
                        <div className="flex justify-between items-start mb-8">
                            <div>
                                <h3 className="text-3xl font-bold font-display text-slate-900 mb-2">Structure</h3>
                                <p className="text-slate-500 text-sm font-medium">Pour les établissements de soins & sociaux</p>
                            </div>
                            <div className="w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/30">
                                <span className="material-symbols-outlined text-2xl">domain</span>
                            </div>
                        </div>

                        <div className="mb-10">
                            <div className="flex items-baseline gap-2 mb-2">
                                <span className="text-6xl font-black text-slate-900 font-display tracking-tight">0</span>
                                <span className="text-2xl font-bold text-slate-400">DH</span>
                                <span className="text-slate-400 font-medium ml-2">à la publication</span>
                            </div>
                            <p className="text-blue-600 font-bold text-sm flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                                Recrutez sans risque. Payez au résultat.
                            </p>
                        </div>

                        <ul className="space-y-5 mb-12">
                            {[
                                "Accès exclusif aux profils certifiés TADAMON",
                                "Publication de missions illimitée",
                                "Outils de gestion de candidatures avancés",
                                "Facturation simplifiée conforme Maroc"
                            ].map((feat, i) => (
                                <li key={i} className="flex items-start gap-3 text-slate-600 text-sm font-medium">
                                    <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-md shadow-blue-200">
                                        <span className="material-symbols-outlined text-[12px] font-bold">check</span>
                                    </div>
                                    {feat}
                                </li>
                            ))}
                        </ul>

                        <div className="bg-slate-50/80 backdrop-blur-sm rounded-3xl p-6 mb-8 border border-slate-100 flex items-center justify-between group-hover:border-blue-100 transition-colors">
                            <div>
                                <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">COMMISSION DE SUCCÈS</div>
                                <div className="text-[10px] text-slate-400 max-w-[200px] leading-tight font-medium">Facturée uniquement lorsqu'une mission est pourvue.</div>
                            </div>
                            <div className="text-4xl font-black text-slate-900 font-display">10<span className="text-lg align-top font-bold">%</span></div>
                        </div>

                        <button 
                            onClick={openLoginModal}
                            className="w-full py-5 bg-[#2563EB] text-white font-bold rounded-2xl hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/30 hover:shadow-blue-500/50 active:scale-95 relative overflow-hidden group/btn cursor-pointer"
                        >
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover/btn:animate-[shimmer_1s_infinite]"></div>
                            <span className="relative flex items-center justify-center gap-2">
                                Inscrire mon établissement
                            </span>
                        </button>
                    </div>
                </motion.div>

            </div>
        </section>

        {/* 3. STEPS SECTION */}
        <section className="py-24 relative overflow-hidden bg-[#F8FAFC]">
             {/* Background Pattern */}
             <div className="absolute inset-0 opacity-[0.4]" 
                 style={{ backgroundImage: 'radial-gradient(#CBD5E1 1px, transparent 1px)', backgroundSize: '32px 32px' }}>
             </div>

             <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                 <div className="text-center mb-24">
                     <h2 className="text-4xl md:text-5xl font-bold font-display text-slate-900 mb-4 tracking-tight">Le parcours de confiance</h2>
                     <p className="text-slate-500 font-medium text-lg">Une mécanique fluide, adaptée aux spécificités locales.</p>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
                     {/* Connecting Line (Desktop) */}
                     <div className="hidden md:block absolute top-[3rem] left-[10%] right-[10%] h-0.5 bg-gradient-to-r from-blue-100 via-blue-200 to-blue-100 -z-10"></div>
                     {/* Pulsing Dot on Line */}
                     <div className="hidden md:block absolute top-[2.65rem] left-[10%] w-3 h-3 bg-blue-500 rounded-full animate-[moveRight_4s_linear_infinite] shadow-lg shadow-blue-500/50 z-0"></div>

                     {[
                         { step: 1, title: "Rencontre", desc: "L'établissement définit son besoin. Le talent marocain se positionne.", icon: "person_search" },
                         { step: 2, title: "Entente", desc: "Validation des modalités et confirmation de la mission.", icon: "handshake" },
                         { step: 3, title: "Réalisation", desc: "L'expert intervient. L'excellence est délivrée.", icon: "medical_services" },
                         { step: 4, title: "Règlement", desc: "Paiement sécurisé en DH et prélèvement de la commission.", icon: "payments" }
                     ].map((item, i) => (
                         <motion.div 
                            key={i} 
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.1 }}
                            className="flex flex-col items-center text-center group"
                        >
                             <div className="w-24 h-24 bg-white rounded-[2rem] shadow-xl shadow-blue-900/5 border border-slate-100 flex items-center justify-center mb-8 relative z-10 group-hover:scale-110 transition-transform duration-300 group-hover:border-blue-200 group-hover:shadow-blue-500/20">
                                 <span className="material-symbols-outlined text-4xl text-blue-600">{item.icon}</span>
                                 <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-[#0F172A] text-white flex items-center justify-center text-sm font-bold shadow-md border-2 border-white">
                                     {item.step}
                                 </div>
                             </div>
                             <h4 className="text-lg font-bold text-slate-900 mb-2 font-display">{item.title}</h4>
                             <p className="text-sm text-slate-500 leading-relaxed max-w-[200px] font-medium">{item.desc}</p>
                         </motion.div>
                     ))}
                 </div>
             </div>
             <style>{`
                @keyframes moveRight {
                    0% { left: 10%; opacity: 0; }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% { left: 90%; opacity: 0; }
                }
             `}</style>
        </section>

        {/* 4. VALUE PROPS */}
        <section className="py-24 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { title: "Zéro Risque", desc: "Aucun frais fixe. Aucun abonnement caché. Nous investissons dans votre réussite avant de percevoir le moindre Dirham.", icon: "shield" },
                        { title: "Qualité Garantie", desc: "Notre rémunération dépend de la qualité des missions. Cela nous oblige à maintenir les standards les plus élevés du marché.", icon: "diamond" },
                        { title: "Intérêts Alignés", desc: "Nous ne gagnons que lorsque vous gagnez. C'est la base d'un partenariat durable et sain entre professionnels.", icon: "balance" }
                    ].map((val, i) => (
                        <div key={i} className="bg-slate-50 rounded-[2rem] p-8 border border-slate-100 hover:shadow-2xl hover:shadow-blue-900/10 hover:bg-white hover:border-blue-100 transition-all duration-300 group cursor-default">
                            <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center text-blue-600 shadow-sm mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                                <span className="material-symbols-outlined text-2xl">{val.icon}</span>
                            </div>
                            <h4 className="text-xl font-bold text-slate-900 mb-3 font-display tracking-tight">{val.title}</h4>
                            <p className="text-slate-500 text-sm leading-relaxed font-medium">{val.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>

        {/* 5. FAQ SECTION */}
        <section className="py-24 bg-white relative border-t border-slate-100">
            <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <h2 className="text-4xl font-bold font-display text-slate-900 text-center mb-16 tracking-tight">Questions Fréquentes</h2>
                
                <div className="space-y-4">
                     {faqs.map((faq, idx) => (
                         <div 
                             key={idx} 
                             className={`border rounded-2xl transition-all duration-300 overflow-hidden ${
                                 openFaq === idx 
                                 ? 'bg-white border-blue-200 shadow-lg ring-1 ring-blue-100' 
                                 : 'bg-white border-slate-100 hover:border-blue-100'
                             }`}
                         >
                             <button 
                                 onClick={() => toggleFaq(idx)}
                                 className="w-full flex items-center justify-between p-6 text-left cursor-pointer"
                             >
                                 <span className={`text-base font-bold transition-colors ${openFaq === idx ? 'text-slate-900' : 'text-slate-700'}`}>
                                     {faq.question}
                                 </span>
                                 <span className={`material-symbols-outlined transition-transform duration-300 ${openFaq === idx ? 'rotate-180 text-blue-600' : 'text-slate-400'}`}>
                                     expand_more
                                 </span>
                             </button>
                             <div className={`grid transition-[grid-template-rows] duration-300 ease-out ${openFaq === idx ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`}>
                                 <div className="overflow-hidden">
                                     <p className="px-6 pb-6 text-slate-500 leading-relaxed text-sm font-medium">
                                         {faq.answer}
                                     </p>
                                 </div>
                             </div>
                         </div>
                     ))}
                </div>
                
                <div className="mt-12 text-center">
                    <Link to="/process" className="inline-flex items-center gap-2 text-blue-600 font-bold text-sm hover:underline group cursor-pointer">
                        En savoir plus sur TADAMON
                        <span className="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                    </Link>
                </div>
            </div>
        </section>

        {/* 6. BOTTOM CTA (Dark) */}
        <section className="py-32 bg-[#0B1120] relative overflow-hidden text-center">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1E293B] to-[#020617]"></div>
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-soft-light"></div>
            
            <div className="max-w-4xl mx-auto px-4 relative z-10">
                <h2 className="text-4xl md:text-6xl font-bold font-display text-white mb-6 tracking-tight">Prêt à commencer ?</h2>
                <p className="text-slate-400 text-lg md:text-xl mb-12 max-w-2xl mx-auto font-medium">
                    Rejoignez notre réseau de professionnels qualifiés et d'établissements engagés au Maroc.
                </p>
                
                <button 
                    onClick={openLoginModal}
                    className="px-10 py-5 bg-white text-slate-900 font-bold rounded-2xl hover:bg-blue-50 transition-all hover:scale-105 shadow-[0_0_40px_rgba(255,255,255,0.1)] flex items-center gap-3 mx-auto cursor-pointer"
                >
                    Créer un compte
                    <span className="material-symbols-outlined">arrow_forward</span>
                </button>
            </div>
        </section>

    </div>
  );
};

export default Pricing;
