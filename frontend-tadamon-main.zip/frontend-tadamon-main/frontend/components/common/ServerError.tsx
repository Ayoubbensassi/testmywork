import React from 'react';
import { Link } from 'react-router-dom';
import { Warning, ArrowClockwise, House } from '@phosphor-icons/react';

interface ServerErrorProps {
  statusCode?: number;
  message?: string;
  onRetry?: () => void;
}

const ServerError: React.FC<ServerErrorProps> = ({ 
  statusCode = 500, 
  message,
  onRetry 
}) => {
  const getErrorInfo = () => {
    switch (statusCode) {
      case 500:
        return {
          title: 'Erreur serveur',
          description: 'Une erreur interne est survenue. Notre équipe a été notifiée.',
        };
      case 502:
        return {
          title: 'Passerelle incorrecte',
          description: 'Le serveur a reçu une réponse invalide.',
        };
      case 503:
        return {
          title: 'Service indisponible',
          description: 'Le serveur est temporairement surchargé ou en maintenance.',
        };
      default:
        return {
          title: 'Erreur',
          description: message || 'Une erreur inattendue est survenue.',
        };
    }
  };

  const errorInfo = getErrorInfo();

  return (
    <div className="server-error-container">
      <div className="server-error-content">
        <div className="error-visual">
          <span className="error-code">{statusCode}</span>
          <div className="warning-icon">
            <Warning size={56} weight="duotone" />
          </div>
        </div>
        
        <h1>{errorInfo.title}</h1>
        <p>{errorInfo.description}</p>
        
        {message && message !== errorInfo.description && (
          <div className="error-details">
            <code>{message}</code>
          </div>
        )}

        <div className="server-error-actions">
          {onRetry && (
            <button onClick={onRetry} className="btn-retry">
              <ArrowClockwise size={20} />
              Réessayer
            </button>
          )}
          <Link to="/" className="btn-home">
            <House size={20} />
            Retour à l'accueil
          </Link>
        </div>

        <div className="support-info">
          <p>Si le problème persiste, contactez notre support :</p>
          <a href="mailto:support@tadamon.ma">support@tadamon.ma</a>
        </div>
      </div>

      <style>{`
        .server-error-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
          padding: 20px;
        }
        .server-error-content {
          text-align: center;
          max-width: 500px;
        }
        .error-visual {
          position: relative;
          margin-bottom: 32px;
        }
        .error-code {
          font-size: 7rem;
          font-weight: 900;
          background: linear-gradient(135deg, #f43f5e 0%, #f97316 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          line-height: 1;
          opacity: 0.4;
        }
        .warning-icon {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          color: #f59e0b;
          animation: shake 0.5s ease-in-out infinite alternate;
        }
        @keyframes shake {
          0% { transform: translate(-50%, -50%) rotate(-5deg); }
          100% { transform: translate(-50%, -50%) rotate(5deg); }
        }
        .server-error-content h1 {
          font-size: 2rem;
          font-weight: 700;
          color: #f8fafc;
          margin: 0 0 12px 0;
        }
        .server-error-content > p {
          font-size: 1.1rem;
          color: #94a3b8;
          margin: 0 0 24px 0;
          line-height: 1.6;
        }
        .error-details {
          background: rgba(244, 63, 94, 0.1);
          border: 1px solid rgba(244, 63, 94, 0.2);
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 24px;
        }
        .error-details code {
          font-size: 0.85rem;
          color: #fca5a5;
          word-break: break-word;
        }
        .server-error-actions {
          display: flex;
          gap: 12px;
          justify-content: center;
          margin-bottom: 32px;
        }
        .server-error-actions button,
        .server-error-actions a {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          border-radius: 14px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          text-decoration: none;
        }
        .btn-retry {
          background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
          border: none;
          color: white;
        }
        .btn-retry:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }
        .btn-home {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: #a78bfa;
        }
        .btn-home:hover {
          background: rgba(139, 92, 246, 0.2);
        }
        .support-info {
          padding-top: 24px;
          border-top: 1px solid rgba(139, 92, 246, 0.15);
        }
        .support-info p {
          font-size: 0.85rem;
          color: #64748b;
          margin: 0 0 8px 0;
        }
        .support-info a {
          color: #a78bfa;
          text-decoration: none;
          font-weight: 500;
        }
        .support-info a:hover {
          color: #c4b5fd;
        }
      `}</style>
    </div>
  );
};

export default ServerError;
