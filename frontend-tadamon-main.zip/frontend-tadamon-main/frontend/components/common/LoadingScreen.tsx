import React from 'react';

interface LoadingScreenProps {
  message?: string;
  fullScreen?: boolean;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ 
  message = 'Chargement...', 
  fullScreen = true 
}) => {
  return (
    <div className={`loading-screen ${fullScreen ? 'fullscreen' : ''}`}>
      <div className="loading-content">
        <div className="loading-spinner">
          <div className="spinner-ring"></div>
          <div className="spinner-ring"></div>
          <div className="spinner-ring"></div>
        </div>
        <p className="loading-message">{message}</p>
      </div>

      <style>{`
        .loading-screen {
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 40px;
        }
        .loading-screen.fullscreen {
          min-height: 100vh;
          background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
        }
        .loading-content {
          text-align: center;
        }
        .loading-spinner {
          position: relative;
          width: 60px;
          height: 60px;
          margin: 0 auto 20px;
        }
        .spinner-ring {
          position: absolute;
          width: 100%;
          height: 100%;
          border: 3px solid transparent;
          border-radius: 50%;
          animation: spin 1.5s linear infinite;
        }
        .spinner-ring:nth-child(1) {
          border-top-color: #8b5cf6;
          animation-delay: 0s;
        }
        .spinner-ring:nth-child(2) {
          border-right-color: #ec4899;
          animation-delay: 0.15s;
          width: 80%;
          height: 80%;
          top: 10%;
          left: 10%;
        }
        .spinner-ring:nth-child(3) {
          border-bottom-color: #06b6d4;
          animation-delay: 0.3s;
          width: 60%;
          height: 60%;
          top: 20%;
          left: 20%;
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        .loading-message {
          font-size: 0.95rem;
          color: #94a3b8;
          margin: 0;
          font-weight: 500;
        }
      `}</style>
    </div>
  );
};

export default LoadingScreen;
