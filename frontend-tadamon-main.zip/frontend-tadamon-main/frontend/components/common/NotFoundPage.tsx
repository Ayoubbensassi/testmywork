import React from 'react';
import { Link } from 'react-router-dom';
import { House, MagnifyingGlass, ArrowLeft } from '@phosphor-icons/react';

const NotFoundPage: React.FC = () => {
  return (
    <div className="not-found-container">
      <div className="not-found-content">
        <div className="not-found-visual">
          <span className="error-code">404</span>
          <div className="search-icon">
            <MagnifyingGlass size={48} weight="duotone" />
          </div>
        </div>
        
        <h1>Page introuvable</h1>
        <p>La page que vous recherchez n'existe pas ou a été déplacée.</p>
        
        <div className="not-found-actions">
          <Link to="/" className="btn-home">
            <House size={20} />
            Retour à l'accueil
          </Link>
          <button onClick={() => window.history.back()} className="btn-back">
            <ArrowLeft size={20} />
            Page précédente
          </button>
        </div>

        <div className="helpful-links">
          <p>Liens utiles :</p>
          <div className="links-grid">
            <Link to="/login">Connexion</Link>
            <Link to="/signup">Inscription</Link>
            <Link to="/missions">Missions</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
      </div>

      <style>{`
        .not-found-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
          padding: 20px;
        }
        .not-found-content {
          text-align: center;
          max-width: 500px;
        }
        .not-found-visual {
          position: relative;
          margin-bottom: 32px;
        }
        .error-code {
          font-size: 8rem;
          font-weight: 900;
          background: linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          line-height: 1;
          opacity: 0.3;
        }
        .search-icon {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          color: #a78bfa;
          animation: search 2s ease-in-out infinite;
        }
        @keyframes search {
          0%, 100% { transform: translate(-50%, -50%) rotate(-15deg); }
          50% { transform: translate(-50%, -50%) rotate(15deg); }
        }
        .not-found-content h1 {
          font-size: 2rem;
          font-weight: 700;
          color: #f8fafc;
          margin: 0 0 12px 0;
        }
        .not-found-content > p {
          font-size: 1.1rem;
          color: #94a3b8;
          margin: 0 0 32px 0;
        }
        .not-found-actions {
          display: flex;
          gap: 12px;
          justify-content: center;
          margin-bottom: 40px;
        }
        .not-found-actions a,
        .not-found-actions button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          border-radius: 14px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          text-decoration: none;
        }
        .btn-home {
          background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
          border: none;
          color: white;
        }
        .btn-home:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }
        .btn-back {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: #a78bfa;
        }
        .btn-back:hover {
          background: rgba(139, 92, 246, 0.2);
        }
        .helpful-links {
          padding-top: 32px;
          border-top: 1px solid rgba(139, 92, 246, 0.15);
        }
        .helpful-links > p {
          font-size: 0.85rem;
          color: #64748b;
          margin: 0 0 16px 0;
        }
        .links-grid {
          display: flex;
          gap: 16px;
          justify-content: center;
          flex-wrap: wrap;
        }
        .links-grid a {
          color: #a78bfa;
          text-decoration: none;
          font-size: 0.9rem;
          font-weight: 500;
          transition: color 0.3s ease;
        }
        .links-grid a:hover {
          color: #c4b5fd;
        }
      `}</style>
    </div>
  );
};

export default NotFoundPage;
