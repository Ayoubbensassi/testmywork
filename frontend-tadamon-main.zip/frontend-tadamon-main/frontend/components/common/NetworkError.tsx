import React, { useState, useEffect } from 'react';
import { WifiSlash, ArrowClockwise, House } from '@phosphor-icons/react';

interface NetworkErrorProps {
  onRetry?: () => void;
  message?: string;
}

const NetworkError: React.FC<NetworkErrorProps> = ({ onRetry, message }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isRetrying, setIsRetrying] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    if (isOnline && onRetry) {
      onRetry();
    }
  }, [isOnline]);

  const handleRetry = async () => {
    setIsRetrying(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    if (onRetry) onRetry();
    setIsRetrying(false);
  };

  return (
    <div className="network-error-container">
      <div className="network-error-content">
        <div className="network-error-icon">
          <WifiSlash size={80} weight="duotone" />
        </div>
        <h1>Connexion perdue</h1>
        <p>{message || "Impossible de se connecter au serveur. Vérifiez votre connexion internet."}</p>
        
        <div className="connection-status">
          <div className={`status-indicator ${isOnline ? 'online' : 'offline'}`}>
            <span className="status-dot"></span>
            {isOnline ? 'En ligne' : 'Hors ligne'}
          </div>
        </div>

        <div className="network-tips">
          <h3>Conseils de dépannage :</h3>
          <ul>
            <li>Vérifiez votre connexion Wi-Fi ou données mobiles</li>
            <li>Essayez de rafraîchir la page</li>
            <li>Le serveur peut être temporairement indisponible</li>
          </ul>
        </div>

        <div className="network-actions">
          <button onClick={handleRetry} className="btn-retry" disabled={isRetrying}>
            <ArrowClockwise size={20} className={isRetrying ? 'spinning' : ''} />
            {isRetrying ? 'Reconnexion...' : 'Réessayer'}
          </button>
          <a href="/" className="btn-home">
            <House size={20} />
            Accueil
          </a>
        </div>
      </div>

      <style>{`
        .network-error-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
          padding: 20px;
        }
        .network-error-content {
          text-align: center;
          max-width: 480px;
          background: rgba(18, 18, 26, 0.8);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(139, 92, 246, 0.15);
          border-radius: 24px;
          padding: 48px 40px;
        }
        .network-error-icon {
          color: #f59e0b;
          margin-bottom: 24px;
          animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        .network-error-content h1 {
          font-size: 1.75rem;
          font-weight: 700;
          color: #f8fafc;
          margin: 0 0 12px 0;
        }
        .network-error-content p {
          font-size: 1rem;
          color: #94a3b8;
          margin: 0 0 24px 0;
          line-height: 1.6;
        }
        .connection-status {
          margin-bottom: 24px;
        }
        .status-indicator {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 8px 16px;
          border-radius: 20px;
          font-size: 0.85rem;
          font-weight: 600;
        }
        .status-indicator.online {
          background: rgba(16, 185, 129, 0.15);
          color: #10b981;
        }
        .status-indicator.offline {
          background: rgba(244, 63, 94, 0.15);
          color: #f43f5e;
        }
        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: currentColor;
          animation: blink 1.5s infinite;
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        .network-tips {
          text-align: left;
          background: rgba(139, 92, 246, 0.08);
          border-radius: 16px;
          padding: 20px;
          margin-bottom: 24px;
        }
        .network-tips h3 {
          font-size: 0.9rem;
          font-weight: 600;
          color: #a78bfa;
          margin: 0 0 12px 0;
        }
        .network-tips ul {
          margin: 0;
          padding-left: 20px;
        }
        .network-tips li {
          font-size: 0.85rem;
          color: #94a3b8;
          margin-bottom: 8px;
        }
        .network-tips li:last-child {
          margin-bottom: 0;
        }
        .network-actions {
          display: flex;
          gap: 12px;
          justify-content: center;
        }
        .network-actions button,
        .network-actions a {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          border-radius: 14px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          text-decoration: none;
        }
        .btn-retry {
          background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
          border: none;
          color: white;
        }
        .btn-retry:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }
        .btn-retry:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        .btn-retry .spinning {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .btn-home {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: #a78bfa;
        }
        .btn-home:hover {
          background: rgba(139, 92, 246, 0.2);
        }
      `}</style>
    </div>
  );
};

export default NetworkError;
