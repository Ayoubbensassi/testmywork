import React from 'react';
import {
  X, User, Phone, MapPin, Briefcase, GraduationCap, Calendar,
  CheckCircle, XCircle, Medal, FileText, Buildings, EnvelopeSimple,
  IdentificationCard, Clock, Star
} from '@phosphor-icons/react';

interface WorkerProfile {
  id: number;
  user_id: number;
  first_name: string;
  last_name: string;
  cin: string;
  phone: string;
  email?: string;
  bio?: string;
  daily_rate?: number;
  years_experience?: number;
  profile_picture?: string;
  status: string;
  is_labeled: boolean;
  created_at: string;
  region_name?: string;
  city_name?: string;
  specialties?: Array<{ name: string; years_experience?: number }>;
  diplomas?: Array<{ title: string; institution: string; obtained_date: string; is_verified: boolean }>;
}

interface EstablishmentProfile {
  id: number;
  user_id: number;
  name: string;
  legal_name: string;
  ice: string;
  type: string;
  phone: string;
  email: string;
  description?: string;
  address?: string;
  website?: string;
  logo?: string;
  ice_document?: string;
  registration_document?: string;
  authorization_document?: string;
  is_verified: boolean;
  created_at: string;
  region_name?: string;
  city_name?: string;
}

interface ProfileDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'worker' | 'establishment';
  profile: WorkerProfile | EstablishmentProfile | null;
  onApprove?: () => void;
  onReject?: () => void;
  onGrantLabel?: () => void;
  isLoading?: boolean;
}

const ProfileDetailModal: React.FC<ProfileDetailModalProps> = ({
  isOpen,
  onClose,
  type,
  profile,
  onApprove,
  onReject,
  onGrantLabel,
  isLoading = false,
}) => {
  if (!isOpen || !profile) return null;

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const isWorker = type === 'worker';
  const workerProfile = profile as WorkerProfile;
  const establishmentProfile = profile as EstablishmentProfile;

  // Helper to get profile picture URL
  const getProfilePictureUrl = (path: string | null | undefined): string | null => {
    if (!path) return null;
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    return `http://localhost:5000${path}`;
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="profile-detail-modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>
          <X size={20} />
        </button>

        {/* Header */}
        <div className="profile-modal-header">
          <div className="profile-avatar-large">
            {isWorker ? (
              workerProfile.profile_picture ? (
                <img src={getProfilePictureUrl(workerProfile.profile_picture)!} alt="" />
              ) : (
                <span>{workerProfile.first_name?.charAt(0)}{workerProfile.last_name?.charAt(0)}</span>
              )
            ) : (
              establishmentProfile.logo ? (
                <img src={getProfilePictureUrl(establishmentProfile.logo)!} alt="" />
              ) : (
                <Buildings size={32} />
              )
            )}
          </div>
          <div className="profile-header-info">
            <h2>
              {isWorker 
                ? `${workerProfile.first_name} ${workerProfile.last_name}`
                : establishmentProfile.name
              }
            </h2>
            <div className="profile-badges">
              {isWorker && workerProfile.is_labeled && (
                <span className="badge labeled"><Medal size={14} /> Label Réseau</span>
              )}
              <span className={`badge status-${isWorker ? workerProfile.status : (establishmentProfile.is_verified ? 'approved' : 'pending')}`}>
                {isWorker 
                  ? (workerProfile.status === 'pending' ? 'En attente' : workerProfile.status === 'approved' ? 'Approuvé' : 'Rejeté')
                  : (establishmentProfile.is_verified ? 'Vérifié' : 'En attente')
                }
              </span>
            </div>
            <p className="profile-date">
              <Clock size={14} /> Inscrit le {formatDate(profile.created_at)}
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="profile-modal-content">
          {isWorker ? (
            <>
              {/* Worker Info Section */}
              <section className="profile-section">
                <h3><User size={18} /> Informations personnelles</h3>
                <div className="info-grid">
                  <div className="info-item">
                    <label><IdentificationCard size={14} /> CIN</label>
                    <span>{workerProfile.cin || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><Phone size={14} /> Téléphone</label>
                    <span>{workerProfile.phone || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><EnvelopeSimple size={14} /> Email</label>
                    <span>{workerProfile.email || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><MapPin size={14} /> Localisation</label>
                    <span>{workerProfile.city_name ? `${workerProfile.city_name}, ${workerProfile.region_name}` : 'Non renseigné'}</span>
                  </div>
                </div>
              </section>

              {/* Professional Info */}
              <section className="profile-section">
                <h3><Briefcase size={18} /> Informations professionnelles</h3>
                <div className="info-grid">
                  <div className="info-item">
                    <label><Star size={14} /> Expérience</label>
                    <span>{workerProfile.years_experience ? `${workerProfile.years_experience} ans` : 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><Briefcase size={14} /> Tarif journalier</label>
                    <span>{workerProfile.daily_rate ? `${workerProfile.daily_rate} MAD` : 'Non renseigné'}</span>
                  </div>
                </div>
                {workerProfile.bio && (
                  <div className="bio-section">
                    <label>Biographie</label>
                    <p>{workerProfile.bio}</p>
                  </div>
                )}
              </section>

              {/* Specialties */}
              {workerProfile.specialties && workerProfile.specialties.length > 0 && (
                <section className="profile-section">
                  <h3><Briefcase size={18} /> Spécialités</h3>
                  <div className="specialties-list">
                    {workerProfile.specialties.map((spec, idx) => (
                      <span key={idx} className="specialty-tag">
                        {spec.name}
                        {spec.years_experience && <small>({spec.years_experience} ans)</small>}
                      </span>
                    ))}
                  </div>
                </section>
              )}

              {/* Diplomas */}
              <section className="profile-section">
                <h3><GraduationCap size={18} /> Diplômes</h3>
                {workerProfile.diplomas && workerProfile.diplomas.length > 0 ? (
                  <div className="diplomas-list">
                    {workerProfile.diplomas.map((diploma, idx) => (
                      <div key={idx} className="diploma-item">
                        <div className="diploma-info">
                          <strong>{diploma.title}</strong>
                          <span>{diploma.institution}</span>
                          <small>{formatDate(diploma.obtained_date)}</small>
                        </div>
                        <span className={`diploma-status ${diploma.is_verified ? 'verified' : 'pending'}`}>
                          {diploma.is_verified ? <><CheckCircle size={14} /> Vérifié</> : <><Clock size={14} /> En attente</>}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="empty-text">Aucun diplôme enregistré</p>
                )}
              </section>
            </>
          ) : (
            <>
              {/* Establishment Info */}
              <section className="profile-section">
                <h3><Buildings size={18} /> Informations de l'établissement</h3>
                <div className="info-grid">
                  <div className="info-item">
                    <label><FileText size={14} /> Raison sociale</label>
                    <span>{establishmentProfile.legal_name || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><IdentificationCard size={14} /> ICE</label>
                    <span>{establishmentProfile.ice || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><Briefcase size={14} /> Type</label>
                    <span className="type-badge">{establishmentProfile.type || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><Phone size={14} /> Téléphone</label>
                    <span>{establishmentProfile.phone || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><EnvelopeSimple size={14} /> Email</label>
                    <span>{establishmentProfile.email || 'Non renseigné'}</span>
                  </div>
                  <div className="info-item">
                    <label><MapPin size={14} /> Localisation</label>
                    <span>{establishmentProfile.city_name ? `${establishmentProfile.city_name}, ${establishmentProfile.region_name}` : 'Non renseigné'}</span>
                  </div>
                </div>
                {establishmentProfile.address && (
                  <div className="bio-section">
                    <label>Adresse complète</label>
                    <p>{establishmentProfile.address}</p>
                  </div>
                )}
                {establishmentProfile.description && (
                  <div className="bio-section">
                    <label>Description</label>
                    <p>{establishmentProfile.description}</p>
                  </div>
                )}
              </section>

              {/* Verification Documents */}
              <section className="profile-section">
                <h3><FileText size={18} /> Documents de vérification</h3>
                <div className="documents-list">
                  <div className="document-item">
                    <div className="document-info">
                      <span className="document-icon">
                        <IdentificationCard size={20} />
                      </span>
                      <div>
                        <strong>Certificat ICE</strong>
                        <small>Document obligatoire</small>
                      </div>
                    </div>
                    {establishmentProfile.ice_document ? (
                      <a href={getProfilePictureUrl(establishmentProfile.ice_document)!} target="_blank" rel="noopener noreferrer" className="document-link">
                        <CheckCircle size={16} /> Voir le document
                      </a>
                    ) : (
                      <span className="document-missing">
                        <XCircle size={16} /> Non fourni
                      </span>
                    )}
                  </div>
                  
                  <div className="document-item">
                    <div className="document-info">
                      <span className="document-icon">
                        <FileText size={20} />
                      </span>
                      <div>
                        <strong>Registre de commerce</strong>
                        <small>Extrait RC</small>
                      </div>
                    </div>
                    {establishmentProfile.registration_document ? (
                      <a href={getProfilePictureUrl(establishmentProfile.registration_document)!} target="_blank" rel="noopener noreferrer" className="document-link">
                        <CheckCircle size={16} /> Voir le document
                      </a>
                    ) : (
                      <span className="document-missing">
                        <Clock size={16} /> Non fourni
                      </span>
                    )}
                  </div>
                  
                  <div className="document-item">
                    <div className="document-info">
                      <span className="document-icon">
                        <Briefcase size={20} />
                      </span>
                      <div>
                        <strong>Autorisation d'exercice</strong>
                        <small>Licence ou agrément</small>
                      </div>
                    </div>
                    {establishmentProfile.authorization_document ? (
                      <a href={getProfilePictureUrl(establishmentProfile.authorization_document)!} target="_blank" rel="noopener noreferrer" className="document-link">
                        <CheckCircle size={16} /> Voir le document
                      </a>
                    ) : (
                      <span className="document-missing">
                        <Clock size={16} /> Non fourni
                      </span>
                    )}
                  </div>
                </div>
              </section>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="profile-modal-actions">
          {isWorker && workerProfile.status === 'approved' && !workerProfile.is_labeled && onGrantLabel && (
            <button className="btn-label" onClick={onGrantLabel} disabled={isLoading}>
              <Medal size={18} /> Accorder le Label
            </button>
          )}
          {((isWorker && workerProfile.status === 'pending') || (!isWorker && !establishmentProfile.is_verified)) && (
            <>
              <button className="btn-approve" onClick={onApprove} disabled={isLoading}>
                <CheckCircle size={18} /> Approuver
              </button>
              <button className="btn-reject" onClick={onReject} disabled={isLoading}>
                <XCircle size={18} /> Rejeter
              </button>
            </>
          )}
          <button className="btn-close" onClick={onClose}>
            Fermer
          </button>
        </div>
      </div>

      <style>{`
        .profile-detail-modal {
          background: var(--bg-secondary, #12121A);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 24px;
          width: 100%;
          max-width: 680px;
          max-height: 90vh;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          position: relative;
          animation: slideUp 0.3s ease;
        }
        .profile-modal-header {
          padding: 32px;
          background: linear-gradient(135deg, rgba(139, 92, 246, 0.15) 0%, rgba(236, 72, 153, 0.1) 100%);
          border-bottom: 1px solid rgba(139, 92, 246, 0.15);
          display: flex;
          align-items: center;
          gap: 20px;
        }
        .profile-avatar-large {
          width: 80px;
          height: 80px;
          border-radius: 20px;
          background: linear-gradient(135deg, var(--primary, #8B5CF6) 0%, var(--accent, #EC4899) 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 1.5rem;
          font-weight: 700;
          flex-shrink: 0;
          overflow: hidden;
        }
        .profile-avatar-large img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        .profile-avatar-large span {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
        }
        .profile-header-info {
          flex: 1;
        }
        .profile-header-info h2 {
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text-primary, #F8FAFC);
          margin: 0 0 8px 0;
        }
        .profile-badges {
          display: flex;
          gap: 8px;
          margin-bottom: 8px;
        }
        .profile-badges .badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: 600;
        }
        .badge.labeled {
          background: rgba(245, 158, 11, 0.15);
          color: #F59E0B;
        }
        .badge.status-pending {
          background: rgba(245, 158, 11, 0.15);
          color: #F59E0B;
        }
        .badge.status-approved {
          background: rgba(16, 185, 129, 0.15);
          color: #10B981;
        }
        .badge.status-rejected {
          background: rgba(244, 63, 94, 0.15);
          color: #F43F5E;
        }
        .profile-date {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 0.85rem;
          color: var(--text-muted, #64748B);
          margin: 0;
        }
        .profile-modal-content {
          flex: 1;
          overflow-y: auto;
          padding: 24px 32px;
        }
        .profile-section {
          margin-bottom: 24px;
        }
        .profile-section:last-child {
          margin-bottom: 0;
        }
        .profile-section h3 {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 1rem;
          font-weight: 600;
          color: var(--text-primary, #F8FAFC);
          margin: 0 0 16px 0;
          padding-bottom: 8px;
          border-bottom: 1px solid rgba(139, 92, 246, 0.1);
        }
        .profile-section h3 svg {
          color: var(--primary, #8B5CF6);
        }
        .info-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }
        .info-item {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .info-item label {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 0.75rem;
          font-weight: 600;
          color: var(--text-muted, #64748B);
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .info-item span {
          font-size: 0.95rem;
          color: var(--text-primary, #F8FAFC);
          font-weight: 500;
        }
        .bio-section {
          margin-top: 16px;
        }
        .bio-section label {
          display: block;
          font-size: 0.75rem;
          font-weight: 600;
          color: var(--text-muted, #64748B);
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 8px;
        }
        .bio-section p {
          font-size: 0.9rem;
          color: var(--text-secondary, #CBD5E1);
          line-height: 1.6;
          margin: 0;
          padding: 12px 16px;
          background: rgba(139, 92, 246, 0.05);
          border-radius: 12px;
          border: 1px solid rgba(139, 92, 246, 0.1);
        }
        .specialties-list {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .specialty-tag {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 20px;
          font-size: 0.85rem;
          color: var(--primary-light, #A78BFA);
          font-weight: 500;
        }
        .specialty-tag small {
          font-size: 0.75rem;
          color: var(--text-muted, #64748B);
        }
        .diplomas-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .diploma-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px 16px;
          background: rgba(139, 92, 246, 0.05);
          border: 1px solid rgba(139, 92, 246, 0.1);
          border-radius: 12px;
        }
        .diploma-info {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .diploma-info strong {
          font-size: 0.9rem;
          color: var(--text-primary, #F8FAFC);
        }
        .diploma-info span {
          font-size: 0.8rem;
          color: var(--text-secondary, #CBD5E1);
        }
        .diploma-info small {
          font-size: 0.75rem;
          color: var(--text-muted, #64748B);
        }
        .diploma-status {
          display: flex;
          align-items: center;
          gap: 4px;
          font-size: 0.75rem;
          font-weight: 600;
          padding: 4px 10px;
          border-radius: 12px;
        }
        .diploma-status.verified {
          background: rgba(16, 185, 129, 0.15);
          color: #10B981;
        }
        .diploma-status.pending {
          background: rgba(245, 158, 11, 0.15);
          color: #F59E0B;
        }
        .empty-text {
          font-size: 0.9rem;
          color: var(--text-muted, #64748B);
          font-style: italic;
          margin: 0;
        }
        .type-badge {
          display: inline-block;
          padding: 4px 12px;
          background: rgba(59, 130, 246, 0.15);
          color: #3B82F6;
          border-radius: 12px;
          font-size: 0.85rem;
          font-weight: 500;
          text-transform: capitalize;
        }
        .documents-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .document-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px 16px;
          background: rgba(139, 92, 246, 0.05);
          border: 1px solid rgba(139, 92, 246, 0.1);
          border-radius: 12px;
        }
        .document-info {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .document-icon {
          width: 40px;
          height: 40px;
          border-radius: 10px;
          background: rgba(139, 92, 246, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--primary, #8B5CF6);
        }
        .document-info div {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .document-info strong {
          font-size: 0.9rem;
          color: var(--text-primary, #F8FAFC);
        }
        .document-info small {
          font-size: 0.75rem;
          color: var(--text-muted, #64748B);
        }
        .document-link {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          background: rgba(16, 185, 129, 0.15);
          border-radius: 10px;
          color: #10B981;
          font-size: 0.8rem;
          font-weight: 600;
          text-decoration: none;
          transition: all 0.3s ease;
        }
        .document-link:hover {
          background: rgba(16, 185, 129, 0.25);
        }
        .document-missing {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          background: rgba(244, 63, 94, 0.1);
          border-radius: 10px;
          color: #F43F5E;
          font-size: 0.8rem;
          font-weight: 500;
        }
        .profile-modal-actions {
          padding: 20px 32px;
          border-top: 1px solid rgba(139, 92, 246, 0.15);
          display: flex;
          gap: 12px;
          justify-content: flex-end;
          background: rgba(139, 92, 246, 0.03);
        }
        .profile-modal-actions button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 20px;
          border-radius: 12px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .btn-approve {
          background: linear-gradient(135deg, #10B981 0%, #34D399 100%);
          border: none;
          color: white;
        }
        .btn-approve:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(16, 185, 129, 0.4);
        }
        .btn-reject {
          background: rgba(244, 63, 94, 0.15);
          border: 1px solid rgba(244, 63, 94, 0.3);
          color: #F43F5E;
        }
        .btn-reject:hover:not(:disabled) {
          background: rgba(244, 63, 94, 0.25);
        }
        .btn-label {
          background: linear-gradient(135deg, #F59E0B 0%, #FBBF24 100%);
          border: none;
          color: white;
        }
        .btn-label:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(245, 158, 11, 0.4);
        }
        .btn-close {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: var(--text-secondary, #CBD5E1);
        }
        .btn-close:hover {
          background: rgba(139, 92, 246, 0.2);
        }
        .profile-modal-actions button:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        /* Light mode */
        [data-theme="light"] .profile-detail-modal {
          background: white;
          border-color: rgba(139, 92, 246, 0.15);
        }
        [data-theme="light"] .profile-modal-header {
          background: linear-gradient(135deg, rgba(139, 92, 246, 0.08) 0%, rgba(236, 72, 153, 0.05) 100%);
        }
        [data-theme="light"] .profile-header-info h2 {
          color: #1e293b;
        }
        [data-theme="light"] .profile-section h3 {
          color: #1e293b;
        }
        [data-theme="light"] .info-item span {
          color: #1e293b;
        }
        [data-theme="light"] .bio-section p {
          color: #475569;
          background: rgba(139, 92, 246, 0.03);
        }
        [data-theme="light"] .diploma-info strong {
          color: #1e293b;
        }
        [data-theme="light"] .diploma-info span {
          color: #475569;
        }
        [data-theme="light"] .profile-modal-actions {
          background: rgba(139, 92, 246, 0.02);
        }

        @media (max-width: 600px) {
          .profile-detail-modal {
            max-height: 95vh;
            border-radius: 20px 20px 0 0;
          }
          .profile-modal-header {
            flex-direction: column;
            text-align: center;
            padding: 24px;
          }
          .info-grid {
            grid-template-columns: 1fr;
          }
          .profile-modal-actions {
            flex-wrap: wrap;
          }
          .profile-modal-actions button {
            flex: 1;
            min-width: 120px;
            justify-content: center;
          }
        }
      `}</style>
    </div>
  );
};

export default ProfileDetailModal;
