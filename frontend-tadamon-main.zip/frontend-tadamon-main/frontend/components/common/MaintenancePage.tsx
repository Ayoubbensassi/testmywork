import React from 'react';
import { Wrench, ArrowClockwise } from '@phosphor-icons/react';

interface MaintenancePageProps {
  estimatedTime?: string;
  onRetry?: () => void;
}

const MaintenancePage: React.FC<MaintenancePageProps> = ({ 
  estimatedTime,
  onRetry 
}) => {
  return (
    <div className="maintenance-container">
      <div className="maintenance-content">
        <div className="maintenance-icon">
          <Wrench size={64} weight="duotone" />
        </div>
        
        <h1>Maintenance en cours</h1>
        <p>
          Notre plateforme est actuellement en maintenance pour améliorer votre expérience.
          Nous serons de retour très bientôt !
        </p>
        
        {estimatedTime && (
          <div className="estimated-time">
            <span className="material-symbols-outlined">schedule</span>
            Temps estimé : {estimatedTime}
          </div>
        )}

        <div className="maintenance-features">
          <div className="feature-item">
            <span className="material-symbols-outlined">security</span>
            <span>Mise à jour de sécurité</span>
          </div>
          <div className="feature-item">
            <span className="material-symbols-outlined">speed</span>
            <span>Amélioration des performances</span>
          </div>
          <div className="feature-item">
            <span className="material-symbols-outlined">auto_awesome</span>
            <span>Nouvelles fonctionnalités</span>
          </div>
        </div>

        {onRetry && (
          <button onClick={onRetry} className="btn-retry">
            <ArrowClockwise size={20} />
            Vérifier la disponibilité
          </button>
        )}

        <div className="contact-info">
          <p>Des questions ? Contactez-nous :</p>
          <a href="mailto:support@tadamon.ma">support@tadamon.ma</a>
        </div>
      </div>

      <style>{`
        .maintenance-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
          padding: 20px;
        }
        .maintenance-content {
          text-align: center;
          max-width: 520px;
          background: rgba(18, 18, 26, 0.8);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(139, 92, 246, 0.15);
          border-radius: 24px;
          padding: 48px 40px;
        }
        .maintenance-icon {
          color: #f59e0b;
          margin-bottom: 24px;
          animation: rotate 4s ease-in-out infinite;
        }
        @keyframes rotate {
          0%, 100% { transform: rotate(-10deg); }
          50% { transform: rotate(10deg); }
        }
        .maintenance-content h1 {
          font-size: 1.75rem;
          font-weight: 700;
          color: #f8fafc;
          margin: 0 0 12px 0;
        }
        .maintenance-content > p {
          font-size: 1rem;
          color: #94a3b8;
          margin: 0 0 24px 0;
          line-height: 1.6;
        }
        .estimated-time {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 10px 20px;
          background: rgba(245, 158, 11, 0.15);
          border-radius: 12px;
          color: #f59e0b;
          font-size: 0.9rem;
          font-weight: 600;
          margin-bottom: 24px;
        }
        .maintenance-features {
          display: flex;
          flex-direction: column;
          gap: 12px;
          margin-bottom: 28px;
          padding: 20px;
          background: rgba(139, 92, 246, 0.08);
          border-radius: 16px;
        }
        .feature-item {
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 0.9rem;
          color: #cbd5e1;
        }
        .feature-item .material-symbols-outlined {
          color: #8b5cf6;
          font-size: 1.25rem;
        }
        .btn-retry {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
          border: none;
          border-radius: 14px;
          color: white;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          margin-bottom: 24px;
        }
        .btn-retry:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }
        .contact-info {
          padding-top: 20px;
          border-top: 1px solid rgba(139, 92, 246, 0.15);
        }
        .contact-info p {
          font-size: 0.85rem;
          color: #64748b;
          margin: 0 0 8px 0;
        }
        .contact-info a {
          color: #a78bfa;
          text-decoration: none;
          font-weight: 500;
        }
        .contact-info a:hover {
          color: #c4b5fd;
        }
      `}</style>
    </div>
  );
};

export default MaintenancePage;
