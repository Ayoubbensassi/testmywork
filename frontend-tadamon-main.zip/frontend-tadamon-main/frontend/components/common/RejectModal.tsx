import React, { useState, useEffect, useRef } from 'react';
import { X, Warning } from '@phosphor-icons/react';

interface RejectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => void;
  title?: string;
  itemName?: string;
  isLoading?: boolean;
}

const RejectModal: React.FC<RejectModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title = 'Rejeter le profil',
  itemName,
  isLoading = false,
}) => {
  const [reason, setReason] = useState('');
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isOpen) {
      setReason('');
      setError('');
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Veuillez indiquer une raison');
      return;
    }
    if (reason.trim().length < 10) {
      setError('La raison doit contenir au moins 10 caractères');
      return;
    }
    onConfirm(reason.trim());
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container reject-modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>
          <X size={20} />
        </button>

        <div className="modal-header">
          <div className="modal-icon warning">
            <Warning size={28} weight="fill" />
          </div>
          <h2>{title}</h2>
          {itemName && <p className="modal-subtitle">Vous êtes sur le point de rejeter : <strong>{itemName}</strong></p>}
        </div>

        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-group">
            <label htmlFor="reject-reason">Raison du rejet <span className="required">*</span></label>
            <textarea
              ref={inputRef}
              id="reject-reason"
              value={reason}
              onChange={(e) => { setReason(e.target.value); setError(''); }}
              placeholder="Expliquez la raison du rejet (documents manquants, informations incorrectes, etc.)"
              rows={4}
              className={error ? 'error' : ''}
            />
            {error && <span className="error-message">{error}</span>}
            <span className="char-count">{reason.length} caractères</span>
          </div>

          <div className="modal-actions">
            <button type="button" className="btn-cancel" onClick={onClose} disabled={isLoading}>
              Annuler
            </button>
            <button type="submit" className="btn-reject" disabled={isLoading}>
              {isLoading ? (
                <span className="spinner"></span>
              ) : (
                <>
                  <X size={18} />
                  Confirmer le rejet
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <style>{`
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          padding: 20px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .modal-container {
          background: var(--bg-secondary, #12121A);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 20px;
          width: 100%;
          max-width: 480px;
          position: relative;
          animation: slideUp 0.3s ease;
        }
        @keyframes slideUp {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .modal-close {
          position: absolute;
          top: 16px;
          right: 16px;
          width: 36px;
          height: 36px;
          border-radius: 10px;
          border: 1px solid rgba(139, 92, 246, 0.2);
          background: rgba(139, 92, 246, 0.1);
          color: var(--text-muted, #64748B);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s ease;
        }
        .modal-close:hover {
          background: rgba(244, 63, 94, 0.2);
          border-color: rgba(244, 63, 94, 0.3);
          color: #f43f5e;
        }
        .modal-header {
          padding: 32px 32px 20px;
          text-align: center;
          border-bottom: 1px solid rgba(139, 92, 246, 0.1);
        }
        .modal-icon {
          width: 64px;
          height: 64px;
          border-radius: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 16px;
        }
        .modal-icon.warning {
          background: rgba(245, 158, 11, 0.15);
          color: #f59e0b;
        }
        .modal-header h2 {
          font-size: 1.25rem;
          font-weight: 700;
          color: var(--text-primary, #F8FAFC);
          margin: 0 0 8px 0;
        }
        .modal-subtitle {
          font-size: 0.9rem;
          color: var(--text-muted, #64748B);
          margin: 0;
        }
        .modal-subtitle strong {
          color: var(--text-secondary, #CBD5E1);
        }
        .modal-body {
          padding: 24px 32px 32px;
        }
        .form-group {
          margin-bottom: 20px;
        }
        .form-group label {
          display: block;
          font-size: 0.85rem;
          font-weight: 600;
          color: var(--text-secondary, #CBD5E1);
          margin-bottom: 8px;
        }
        .form-group .required {
          color: #f43f5e;
        }
        .form-group textarea {
          width: 100%;
          padding: 14px 16px;
          background: rgba(139, 92, 246, 0.08);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 12px;
          color: var(--text-primary, #F8FAFC);
          font-size: 0.9rem;
          font-family: inherit;
          resize: vertical;
          min-height: 100px;
          transition: all 0.3s ease;
        }
        .form-group textarea:focus {
          outline: none;
          border-color: var(--primary, #8B5CF6);
          box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.15);
        }
        .form-group textarea.error {
          border-color: #f43f5e;
        }
        .form-group textarea::placeholder {
          color: var(--text-muted, #64748B);
        }
        .error-message {
          display: block;
          font-size: 0.8rem;
          color: #f43f5e;
          margin-top: 6px;
        }
        .char-count {
          display: block;
          font-size: 0.75rem;
          color: var(--text-muted, #64748B);
          text-align: right;
          margin-top: 4px;
        }
        .modal-actions {
          display: flex;
          gap: 12px;
          justify-content: flex-end;
        }
        .modal-actions button {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 12px 24px;
          border-radius: 12px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .btn-cancel {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: var(--text-secondary, #CBD5E1);
        }
        .btn-cancel:hover:not(:disabled) {
          background: rgba(139, 92, 246, 0.2);
        }
        .btn-reject {
          background: linear-gradient(135deg, #f43f5e 0%, #dc2626 100%);
          border: none;
          color: white;
        }
        .btn-reject:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(244, 63, 94, 0.4);
        }
        .btn-reject:disabled, .btn-cancel:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        .spinner {
          width: 18px;
          height: 18px;
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        /* Light mode */
        [data-theme="light"] .modal-container {
          background: white;
          border-color: rgba(139, 92, 246, 0.15);
        }
        [data-theme="light"] .form-group textarea {
          background: rgba(139, 92, 246, 0.05);
        }
      `}</style>
    </div>
  );
};

export default RejectModal;
