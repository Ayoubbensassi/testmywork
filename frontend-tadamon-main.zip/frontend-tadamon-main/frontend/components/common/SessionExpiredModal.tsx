import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Timer, SignIn } from '@phosphor-icons/react';

const SessionExpiredModal: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleLogout = (event: CustomEvent) => {
      if (event.detail?.reason === 'TOKEN_EXPIRED' || event.detail?.reason === 'TOKEN_INVALID') {
        setIsVisible(true);
      }
    };

    window.addEventListener('auth:logout', handleLogout as EventListener);
    return () => window.removeEventListener('auth:logout', handleLogout as EventListener);
  }, []);

  const handleLogin = () => {
    setIsVisible(false);
    navigate('/login');
  };

  const handleClose = () => {
    setIsVisible(false);
    navigate('/');
  };

  if (!isVisible) return null;

  return (
    <div className="session-modal-overlay">
      <div className="session-modal">
        <div className="session-modal-icon">
          <Timer size={48} weight="duotone" />
        </div>
        <h2>Session expirée</h2>
        <p>Votre session a expiré pour des raisons de sécurité. Veuillez vous reconnecter pour continuer.</p>
        
        <div className="session-modal-actions">
          <button onClick={handleLogin} className="btn-login">
            <SignIn size={20} />
            Se reconnecter
          </button>
          <button onClick={handleClose} className="btn-close">
            Retour à l'accueil
          </button>
        </div>
      </div>

      <style>{`
        .session-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          padding: 20px;
          animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .session-modal {
          background: rgba(18, 18, 26, 0.95);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 24px;
          padding: 40px;
          max-width: 420px;
          text-align: center;
          animation: slideUp 0.3s ease;
        }
        @keyframes slideUp {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .session-modal-icon {
          color: #f59e0b;
          margin-bottom: 20px;
        }
        .session-modal h2 {
          font-size: 1.5rem;
          font-weight: 700;
          color: #f8fafc;
          margin: 0 0 12px 0;
        }
        .session-modal p {
          font-size: 0.95rem;
          color: #94a3b8;
          margin: 0 0 28px 0;
          line-height: 1.6;
        }
        .session-modal-actions {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .session-modal-actions button {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 14px 24px;
          border-radius: 14px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .btn-login {
          background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
          border: none;
          color: white;
        }
        .btn-login:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }
        .btn-close {
          background: transparent;
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: #94a3b8;
        }
        .btn-close:hover {
          background: rgba(139, 92, 246, 0.1);
          color: #a78bfa;
        }
      `}</style>
    </div>
  );
};

export default SessionExpiredModal;
