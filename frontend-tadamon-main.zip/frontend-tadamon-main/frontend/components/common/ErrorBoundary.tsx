import React, { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="error-boundary-container">
          <div className="error-boundary-content">
            <div className="error-icon">
              <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 8v4M12 16h.01" />
              </svg>
            </div>
            <h1>Oups ! Une erreur est survenue</h1>
            <p>Quelque chose s'est mal passé. Veuillez réessayer.</p>
            <div className="error-details">
              <code>{this.state.error?.message || 'Erreur inconnue'}</code>
            </div>
            <div className="error-actions">
              <button onClick={this.handleRetry} className="btn-primary">
                <span className="material-symbols-outlined">refresh</span>
                Réessayer
              </button>
              <button onClick={() => window.history.back()} className="btn-secondary">
                <span className="material-symbols-outlined">arrow_back</span>
                Retour
              </button>
            </div>
          </div>
          <style>{`
            .error-boundary-container {
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
              background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
              padding: 20px;
            }
            .error-boundary-content {
              text-align: center;
              max-width: 500px;
            }
            .error-icon {
              color: #f43f5e;
              margin-bottom: 24px;
              animation: pulse 2s infinite;
            }
            @keyframes pulse {
              0%, 100% { opacity: 1; transform: scale(1); }
              50% { opacity: 0.7; transform: scale(1.05); }
            }
            .error-boundary-content h1 {
              font-size: 1.75rem;
              font-weight: 700;
              color: #f8fafc;
              margin: 0 0 12px 0;
            }
            .error-boundary-content p {
              font-size: 1rem;
              color: #94a3b8;
              margin: 0 0 20px 0;
            }
            .error-details {
              background: rgba(244, 63, 94, 0.1);
              border: 1px solid rgba(244, 63, 94, 0.2);
              border-radius: 12px;
              padding: 16px;
              margin-bottom: 24px;
            }
            .error-details code {
              font-size: 0.85rem;
              color: #fca5a5;
              word-break: break-word;
            }
            .error-actions {
              display: flex;
              gap: 12px;
              justify-content: center;
            }
            .error-actions button {
              display: flex;
              align-items: center;
              gap: 8px;
              padding: 12px 24px;
              border-radius: 12px;
              font-size: 0.9rem;
              font-weight: 600;
              cursor: pointer;
              transition: all 0.3s ease;
            }
            .error-actions .btn-primary {
              background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
              border: none;
              color: white;
            }
            .error-actions .btn-primary:hover {
              transform: translateY(-2px);
              box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
            }
            .error-actions .btn-secondary {
              background: rgba(139, 92, 246, 0.1);
              border: 1px solid rgba(139, 92, 246, 0.2);
              color: #a78bfa;
            }
            .error-actions .btn-secondary:hover {
              background: rgba(139, 92, 246, 0.2);
            }
          `}</style>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
