import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { CheckCircle, XCircle, Warning, Info, X } from '@phosphor-icons/react';

type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  addToast: (message: string, type: ToastType) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

let toastId = 0;
let globalAddToast: ((message: string, type: ToastType) => void) | null = null;

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (message: string, type: ToastType) => {
    const id = ++toastId;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  useEffect(() => {
    globalAddToast = addToast;
    return () => { globalAddToast = null; };
  }, []);

  const removeToast = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const getIcon = (type: ToastType) => {
    switch (type) {
      case 'success': return <CheckCircle size={20} weight="fill" />;
      case 'error': return <XCircle size={20} weight="fill" />;
      case 'warning': return <Warning size={20} weight="fill" />;
      case 'info': return <Info size={20} weight="fill" />;
    }
  };

  return (
    <ToastContext.Provider value={{ addToast }}>
      {children}
      <div className="toast-container">
        {toasts.map(toast => (
          <div key={toast.id} className={`toast toast-${toast.type}`}>
            <span className="toast-icon">{getIcon(toast.type)}</span>
            <span className="toast-message">{toast.message}</span>
            <button className="toast-close" onClick={() => removeToast(toast.id)}>
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
      <style>{`
        .toast-container {
          position: fixed;
          top: 20px;
          right: 20px;
          z-index: 9999;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .toast {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 18px;
          border-radius: 12px;
          background: white;
          box-shadow: 0 4px 20px rgba(0,0,0,0.15);
          animation: slideIn 0.3s ease;
          min-width: 300px;
        }
        .toast-success { border-left: 4px solid #10b981; }
        .toast-success .toast-icon { color: #10b981; }
        .toast-error { border-left: 4px solid #ef4444; }
        .toast-error .toast-icon { color: #ef4444; }
        .toast-warning { border-left: 4px solid #f59e0b; }
        .toast-warning .toast-icon { color: #f59e0b; }
        .toast-info { border-left: 4px solid #3b82f6; }
        .toast-info .toast-icon { color: #3b82f6; }
        .toast-message { flex: 1; font-size: 14px; color: #1f2937; }
        .toast-close { background: none; border: none; cursor: pointer; color: #9ca3af; padding: 4px; }
        .toast-close:hover { color: #6b7280; }
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        [data-theme="dark"] .toast { background: #1f2937; }
        [data-theme="dark"] .toast-message { color: #f3f4f6; }
      `}</style>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used within ToastProvider');
  return context;
};

// Global toast functions
export const showSuccess = (message: string) => globalAddToast?.(message, 'success');
export const showError = (message: string) => globalAddToast?.(message, 'error');
export const showWarning = (message: string) => globalAddToast?.(message, 'warning');
export const showInfo = (message: string) => globalAddToast?.(message, 'info');
