import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldWarning, House, SignIn } from '@phosphor-icons/react';

interface AccessDeniedProps {
  message?: string;
  showLogin?: boolean;
}

const AccessDenied: React.FC<AccessDeniedProps> = ({ 
  message = "Vous n'avez pas les droits pour accéder à cette page.",
  showLogin = true 
}) => {
  return (
    <div className="access-denied-container">
      <div className="access-denied-content">
        <div className="access-denied-icon">
          <ShieldWarning size={80} weight="duotone" />
        </div>
        
        <h1>Accès refusé</h1>
        <p>{message}</p>
        
        <div className="access-denied-actions">
          <Link to="/" className="btn-home">
            <House size={20} />
            Retour à l'accueil
          </Link>
          {showLogin && (
            <Link to="/login" className="btn-login">
              <SignIn size={20} />
              Se connecter
            </Link>
          )}
        </div>

        <div className="help-text">
          <p>Si vous pensez qu'il s'agit d'une erreur, contactez l'administrateur.</p>
        </div>
      </div>

      <style>{`
        .access-denied-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
          padding: 20px;
        }
        .access-denied-content {
          text-align: center;
          max-width: 480px;
          background: rgba(18, 18, 26, 0.8);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(244, 63, 94, 0.2);
          border-radius: 24px;
          padding: 48px 40px;
        }
        .access-denied-icon {
          color: #f43f5e;
          margin-bottom: 24px;
        }
        .access-denied-content h1 {
          font-size: 1.75rem;
          font-weight: 700;
          color: #f8fafc;
          margin: 0 0 12px 0;
        }
        .access-denied-content > p {
          font-size: 1rem;
          color: #94a3b8;
          margin: 0 0 32px 0;
          line-height: 1.6;
        }
        .access-denied-actions {
          display: flex;
          gap: 12px;
          justify-content: center;
          margin-bottom: 24px;
        }
        .access-denied-actions a {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 14px 28px;
          border-radius: 14px;
          font-size: 0.9rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          text-decoration: none;
        }
        .btn-home {
          background: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.2);
          color: #a78bfa;
        }
        .btn-home:hover {
          background: rgba(139, 92, 246, 0.2);
        }
        .btn-login {
          background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
          border: none;
          color: white;
        }
        .btn-login:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4);
        }
        .help-text p {
          font-size: 0.85rem;
          color: #64748b;
          margin: 0;
        }
      `}</style>
    </div>
  );
};

export default AccessDenied;
