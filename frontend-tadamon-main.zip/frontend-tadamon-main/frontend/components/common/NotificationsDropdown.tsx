import React, { useState, useEffect, useRef } from 'react';
import { Bell, Check, Trash } from '@phosphor-icons/react';
import { notificationAPI } from '../../services/api';

interface Notification {
  id: number;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

const NotificationsDropdown: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => !n.is_read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen) loadNotifications();
  }, [isOpen]);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const res = await notificationAPI.getNotifications();
      setNotifications(res.data?.notifications || res.notifications || []);
    } catch (err) {
      console.error('Error loading notifications:', err);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id: number) => {
    try {
      await notificationAPI.markAsRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    } catch (err) {
      console.error('Error marking as read:', err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await notificationAPI.markAllAsRead();
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    } catch (err) {
      console.error('Error marking all as read:', err);
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'À l\'instant';
    if (minutes < 60) return `Il y a ${minutes}min`;
    if (hours < 24) return `Il y a ${hours}h`;
    if (days < 7) return `Il y a ${days}j`;
    return date.toLocaleDateString('fr-FR');
  };

  return (
    <div className="notifications-dropdown" ref={dropdownRef}>
      <button className="notifications-btn" onClick={() => setIsOpen(!isOpen)}>
        <Bell size={20} />
        {unreadCount > 0 && <span className="notifications-badge">{unreadCount}</span>}
      </button>

      {isOpen && (
        <div className="notifications-panel">
          <div className="notifications-header">
            <h3>Notifications</h3>
            {unreadCount > 0 && (
              <button className="mark-all-btn" onClick={markAllAsRead}>
                <Check size={14} /> Tout marquer lu
              </button>
            )}
          </div>

          <div className="notifications-list">
            {loading ? (
              <div className="notifications-loading">Chargement...</div>
            ) : notifications.length === 0 ? (
              <div className="notifications-empty">
                <Bell size={32} />
                <p>Aucune notification</p>
              </div>
            ) : (
              notifications.slice(0, 10).map(notification => (
                <div
                  key={notification.id}
                  className={`notification-item ${!notification.is_read ? 'unread' : ''}`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <div className="notification-content">
                    <h4>{notification.title}</h4>
                    <p>{notification.message}</p>
                    <span className="notification-time">{formatTime(notification.created_at)}</span>
                  </div>
                  {!notification.is_read && <span className="notification-dot"></span>}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      <style>{`
        .notifications-dropdown { position: relative; }
        .notifications-btn {
          position: relative;
          background: transparent;
          border: none;
          padding: 8px;
          border-radius: 10px;
          cursor: pointer;
          color: #64748b;
          transition: all 0.2s;
        }
        .notifications-btn:hover { background: rgba(59, 130, 246, 0.1); color: #3b82f6; }
        .notifications-badge {
          position: absolute;
          top: 2px;
          right: 2px;
          background: #ef4444;
          color: white;
          font-size: 10px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 10px;
          min-width: 18px;
          text-align: center;
        }
        .notifications-panel {
          position: absolute;
          top: calc(100% + 8px);
          right: 0;
          width: 360px;
          background: white;
          border-radius: 16px;
          box-shadow: 0 10px 40px rgba(0,0,0,0.15);
          z-index: 1000;
          overflow: hidden;
        }
        .notifications-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px 20px;
          border-bottom: 1px solid #e5e7eb;
        }
        .notifications-header h3 { font-size: 16px; font-weight: 600; color: #1f2937; margin: 0; }
        .mark-all-btn {
          display: flex;
          align-items: center;
          gap: 4px;
          background: none;
          border: none;
          color: #3b82f6;
          font-size: 12px;
          cursor: pointer;
        }
        .notifications-list { max-height: 400px; overflow-y: auto; }
        .notification-item {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          padding: 14px 20px;
          cursor: pointer;
          transition: background 0.2s;
          border-bottom: 1px solid #f3f4f6;
        }
        .notification-item:hover { background: #f9fafb; }
        .notification-item.unread { background: #eff6ff; }
        .notification-content { flex: 1; }
        .notification-content h4 { font-size: 14px; font-weight: 500; color: #1f2937; margin: 0 0 4px; }
        .notification-content p { font-size: 13px; color: #6b7280; margin: 0 0 6px; line-height: 1.4; }
        .notification-time { font-size: 11px; color: #9ca3af; }
        .notification-dot { width: 8px; height: 8px; background: #3b82f6; border-radius: 50%; flex-shrink: 0; margin-top: 6px; }
        .notifications-empty, .notifications-loading {
          padding: 40px 20px;
          text-align: center;
          color: #9ca3af;
        }
        .notifications-empty p { margin: 12px 0 0; }
        [data-theme="dark"] .notifications-panel { background: #1f2937; }
        [data-theme="dark"] .notifications-header { border-color: #374151; }
        [data-theme="dark"] .notifications-header h3 { color: #f3f4f6; }
        [data-theme="dark"] .notification-item { border-color: #374151; }
        [data-theme="dark"] .notification-item:hover { background: #374151; }
        [data-theme="dark"] .notification-item.unread { background: rgba(59, 130, 246, 0.1); }
        [data-theme="dark"] .notification-content h4 { color: #f3f4f6; }
        [data-theme="dark"] .notification-content p { color: #9ca3af; }
      `}</style>
    </div>
  );
};

export default NotificationsDropdown;
