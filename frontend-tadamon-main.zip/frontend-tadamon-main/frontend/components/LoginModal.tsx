import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../AuthContext';

const LoginModal = () => {
  const { isLoginModalOpen, closeLoginModal, login, signup, error, clearError } = useAuth();
  const [isRegister, setIsRegister] = useState(false);
  const [role, setRole] = useState<'worker' | 'establishment' | null>(null);
  const [signupStep, setSignupStep] = useState(0);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    if (!isLoginModalOpen) {
      setTimeout(() => {
        setIsRegister(false);
        setRole(null);
        setSignupStep(0);
        setEmail('');
        setPassword('');
        clearError();
      }, 300);
    }
  }, [isLoginModalOpen, clearError]);

  if (!isLoginModalOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    clearError();
    const success = await login(email, password);
    setIsLoading(false);
    if (success) closeLoginModal();
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!role) return;
    setIsLoading(true);
    clearError();
    const success = await signup({ email, password, role });
    setIsLoading(false);
    if (success) closeLoginModal();
  };

  const handleRoleSelect = (selectedRole: 'worker' | 'establishment') => {
    setRole(selectedRole);
    setSignupStep(1);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={closeLoginModal}></motion.div>
      
      <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ type: "spring", duration: 0.5 }}
        className="relative bg-white rounded-[2.5rem] w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col lg:flex-row min-h-[600px] max-h-[90vh]">
        
        <button onClick={closeLoginModal} className="absolute top-6 right-6 lg:left-6 lg:right-auto z-50 w-10 h-10 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-colors">
          <span className="material-symbols-outlined">close</span>
        </button>

        <div className="w-full lg:w-1/2 p-8 md:p-12 lg:p-16 flex flex-col justify-center relative order-2 lg:order-1 bg-white">
            <div className="text-center mb-8">
                <h2 className="text-3xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#2563EB] to-[#db2777] uppercase tracking-tighter mb-6">TADAMON</h2>
                <div className="bg-slate-100 p-1 rounded-full inline-flex relative">
                    <motion.div layout className="absolute top-1 left-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-full shadow-sm z-0"
                        animate={{ x: isRegister ? '100%' : '0%' }} transition={{ type: "spring", stiffness: 300, damping: 30 }} />
                    <button onClick={() => { setIsRegister(false); clearError(); }}
                        className={`relative z-10 px-8 py-2.5 rounded-full text-sm font-bold transition-colors ${!isRegister ? 'text-slate-900' : 'text-slate-500'}`}>Connexion</button>
                    <button onClick={() => { setIsRegister(true); clearError(); }}
                        className={`relative z-10 px-8 py-2.5 rounded-full text-sm font-bold transition-colors ${isRegister ? 'text-slate-900' : 'text-slate-500'}`}>Inscription</button>
                </div>
            </div>

            <div className="relative overflow-hidden">
                <AnimatePresence mode="wait">
                    {!isRegister ? (
                        <motion.form key="login" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
                            transition={{ duration: 0.3 }} onSubmit={handleLogin} className="space-y-5">
                            {error && <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm font-medium">{error}</div>}
                            <div className="space-y-1.5">
                                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Adresse email</label>
                                <div className="relative group">
                                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">mail</span>
                                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                                        className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3.5 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" 
                                        placeholder="Adresse email" required />
                                </div>
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Mot de passe</label>
                                <div className="relative group">
                                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">lock</span>
                                    <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                                        className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3.5 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none" 
                                        placeholder="Mot de passe" required />
                                </div>
                            </div>
                            <button type="submit" disabled={isLoading}
                                className="w-full py-4 bg-gradient-to-r from-[#2563EB] to-[#3B82F6] hover:shadow-lg hover:shadow-blue-500/30 text-white font-bold rounded-2xl transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50">
                                {isLoading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : 'Se connecter'}
                            </button>
                        </motion.form>
                    ) : (
                        <motion.div key="signup" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.3 }}>
                            {signupStep === 0 ? (
                                <div className="space-y-6">
                                    <h3 className="text-center text-xl font-bold text-slate-900">Choisissez votre profil</h3>
                                    <div className="grid grid-cols-2 gap-4">
                                        <button onClick={() => handleRoleSelect('worker')}
                                            className="group p-6 rounded-[2rem] border-2 border-slate-100 hover:border-blue-500 hover:bg-blue-50/50 transition-all flex flex-col items-center text-center gap-4">
                                            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                                                <span className="material-symbols-outlined text-3xl">person</span>
                                            </div>
                                            <div>
                                                <div className="font-bold text-slate-900 group-hover:text-blue-700">Travailleur social</div>
                                                <div className="text-[10px] text-slate-500 mt-1 font-medium">Candidats chercheurs d'emploi</div>
                                            </div>
                                        </button>
                                        <button onClick={() => handleRoleSelect('establishment')}
                                            className="group p-6 rounded-[2rem] border-2 border-slate-100 hover:border-purple-500 hover:bg-purple-50/50 transition-all flex flex-col items-center text-center gap-4">
                                            <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 group-hover:scale-110 transition-transform">
                                                <span className="material-symbols-outlined text-3xl">domain</span>
                                            </div>
                                            <div>
                                                <div className="font-bold text-slate-900 group-hover:text-purple-700">Établissement</div>
                                                <div className="text-[10px] text-slate-500 mt-1 font-medium">Employeurs et organismes</div>
                                            </div>
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                <form onSubmit={handleSignup} className="space-y-4">
                                    <button type="button" onClick={() => { setSignupStep(0); clearError(); }}
                                        className="flex items-center text-sm font-bold text-slate-400 hover:text-slate-600 mb-2">
                                        <span className="material-symbols-outlined text-lg mr-1">arrow_back</span>Retour
                                    </button>
                                    {error && <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm font-medium">{error}</div>}
                                    <div className="space-y-1.5">
                                        <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Email</label>
                                        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3.5 text-sm font-medium outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10" 
                                            placeholder="email@exemple.com" required />
                                    </div>
                                    <div className="space-y-1.5">
                                        <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900">Mot de passe</label>
                                        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3.5 text-sm font-medium outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10" 
                                            placeholder="Min. 8 caractères, 1 majuscule, 1 chiffre" required />
                                    </div>
                                    <button type="submit" disabled={isLoading}
                                        className="w-full py-4 bg-gradient-to-r from-[#2563EB] to-[#3B82F6] hover:shadow-lg text-white font-bold rounded-2xl transition-all mt-4 flex items-center justify-center gap-2 disabled:opacity-50">
                                        {isLoading ? <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span> : 'Créer mon compte'}
                                    </button>
                                </form>
                            )}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>

        <div className="hidden lg:flex w-1/2 relative bg-slate-900 overflow-hidden order-1 lg:order-2 flex-col justify-end p-12">
            <div className="absolute inset-0">
                <img src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=1000" alt="Medical Team" 
                    className="w-full h-full object-cover opacity-40 mix-blend-overlay" />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/90 via-blue-900/40 to-blue-900/20"></div>
            </div>
            <div className="relative z-10 text-center">
                <h3 className="text-3xl font-bold font-display text-white mb-8 drop-shadow-lg">
                    {isRegister ? 'Trouvez votre rôle idéal' : 'Plateforme leader d\'emploi'}
                </h3>
                <div className="flex gap-4 justify-center">
                    {[{ icon: 'timer', label: 'Débutez en', sub: '30 secondes' }, { icon: 'work', label: 'Plus de', sub: '10 000 offres' }, { icon: 'headset_mic', label: 'Support', sub: '24/7' }].map((stat, i) => (
                        <div key={i} className="bg-white rounded-2xl p-3 flex flex-col items-center justify-center w-28 shadow-lg">
                            <span className="material-symbols-outlined text-slate-900 text-xl mb-1">{stat.icon}</span>
                            <div className="text-[10px] text-slate-500 font-medium leading-tight">{stat.label}</div>
                            <div className="text-xs font-bold text-slate-900 leading-tight">{stat.sub}</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </motion.div>
    </div>
  );
};

export default LoginModal;
