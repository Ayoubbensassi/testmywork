
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { workerAPI, establishmentAPI } from '../src/api';

const API_BASE_URL = 'http://localhost:5000/api';

const Login: React.FC = () => {
    const { login, error: authError, clearError, user } = useAuth();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [googleEnabled, setGoogleEnabled] = useState(false);
    const [localError, setLocalError] = useState<string | null>(null);
    
    // Combine auth error and local error
    const error = localError || authError;

    // Check if Google OAuth is configured and handle token from OAuth callback
    useEffect(() => {
        // Check Google OAuth status
        fetch(`${API_BASE_URL}/auth/google/status`)
            .then(res => res.json())
            .then(data => setGoogleEnabled(data.data?.configured || false))
            .catch(() => setGoogleEnabled(false));

        // Handle token from Google OAuth callback
        const token = searchParams.get('token');
        if (token) {
            localStorage.setItem('token', token);
            window.location.href = '/#/'; // Reload to trigger auth check
        }

        // Handle Google OAuth error
        const googleError = searchParams.get('error');
        if (googleError === 'google_failed') {
            clearError();
        }
    }, [searchParams]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setLocalError(null);
        clearError();
        
        try {
            const success = await login(email, password);
            setIsLoading(false);
            
            if (success) {
                // Check if user has profile, redirect accordingly
                try {
                    const userData = JSON.parse(atob(localStorage.getItem('token')?.split('.')[1] || '{}'));
                    if (userData.role === 'admin') {
                        navigate('/admin/dashboard');
                    } else if (userData.role === 'worker') {
                        const profile = await workerAPI.getMyProfile().catch(() => null);
                        navigate(profile?.profile ? '/worker/dashboard' : '/onboarding/worker');
                    } else if (userData.role === 'establishment') {
                        const profile = await establishmentAPI.getMyProfile().catch(() => null);
                        navigate(profile?.profile ? '/establishment/dashboard' : '/onboarding/establishment');
                    } else {
                        navigate('/');
                    }
                } catch {
                    navigate('/');
                }
            } else {
                // Keep the error from AuthContext visible
                setLocalError(authError || 'Email ou mot de passe incorrect');
            }
        } catch (err: any) {
            setIsLoading(false);
            setLocalError(err.message || 'Une erreur est survenue lors de la connexion');
        }
    };

    const handleGoogleLogin = () => {
        if (googleEnabled) {
            // Redirect to backend Google OAuth endpoint
            window.location.href = `${API_BASE_URL}/auth/google?role=worker`;
        } else {
            alert('🚧 Connexion Google\n\nGoogle OAuth n\'est pas configuré sur ce serveur.\n\nPour l\'activer, ajoutez GOOGLE_CLIENT_ID et GOOGLE_CLIENT_SECRET dans le fichier .env.local du backend.');
        }
    };

    return (
        <div className="h-screen w-full flex flex-col lg:flex-row bg-white overflow-hidden relative">
            {/* Back Button */}
            <Link
                to="/"
                className="absolute top-6 left-6 z-50 w-10 h-10 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors border border-slate-200"
                title="Retour à l'accueil"
            >
                <span className="material-symbols-outlined">arrow_back</span>
            </Link>

            {/* LEFT COLUMN: FORM */}
            <div className="w-full lg:w-1/2 h-full flex flex-col justify-center items-center p-6 lg:p-8 relative bg-white z-10">
                <div className="w-full max-w-[420px]">

                    {/* Header Section */}
                    <div className="text-center mb-6">
                        <h2 className="text-3xl font-black font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#2563EB] to-[#db2777] uppercase tracking-tighter mb-6">
                            TADAMON
                        </h2>

                        {/* Navigation Toggle - Matching Design */}
                        <div className="bg-slate-100 p-1.5 rounded-full inline-flex w-full max-w-[320px] relative">
                            {/* Active Tab Background (Left for Connexion) */}
                            <div className="absolute top-1.5 bottom-1.5 left-1.5 w-[calc(50%-6px)] bg-white rounded-full shadow-sm z-0 transition-all duration-300"></div>

                            <span className="relative z-10 w-1/2 py-2.5 text-sm font-bold text-[#2563EB] cursor-default text-center transition-colors">
                                Connexion
                            </span>
                            <Link
                                to="/signup"
                                className="relative z-10 w-1/2 py-2.5 text-sm font-bold text-slate-500 hover:text-slate-700 transition-colors text-center"
                            >
                                Inscription
                            </Link>
                        </div>
                    </div>

                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4 }}
                    >
                        {error && (
                            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3">
                                <span className="material-symbols-outlined text-red-500 text-xl flex-shrink-0">error</span>
                                <div className="flex-1">
                                    <p className="text-red-700 text-sm font-semibold mb-1">Échec de la connexion</p>
                                    <p className="text-red-600 text-sm">{error}</p>
                                </div>
                            </div>
                        )}
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="space-y-1.5">
                                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Adresse email</label>
                                <div className="relative group">
                                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">mail</span>
                                    <input
                                        type="email"
                                        value={email}
                                        onChange={(e) => { setEmail(e.target.value); setLocalError(null); }}
                                        className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none"
                                        placeholder="Adresse email"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-900 ml-1">Mot de passe</label>
                                <div className="relative group">
                                    <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors">lock</span>
                                    <input
                                        type="password"
                                        value={password}
                                        onChange={(e) => { setPassword(e.target.value); setLocalError(null); }}
                                        className="w-full bg-white border border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 rounded-xl pl-11 pr-4 py-3 font-medium transition-all text-sm text-slate-900 placeholder:text-slate-400 outline-none"
                                        placeholder="Mot de passe"
                                        required
                                    />
                                </div>
                            </div>

                            <div className="flex items-center justify-between text-xs sm:text-sm pt-1">
                                <label className="flex items-center gap-2 cursor-pointer group">
                                    <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500 bg-slate-50" />
                                    <span className="text-slate-500 font-medium group-hover:text-slate-700 transition-colors">Se souvenir de moi</span>
                                </label>
                                <Link to="/forgot-password" className="text-blue-600 font-bold hover:underline hover:text-blue-700">
                                    Mot de passe oublié ?
                                </Link>
                            </div>

                            <button
                                type="submit"
                                disabled={isLoading}
                                className="w-full py-3.5 bg-gradient-to-r from-[#2563EB] to-[#3B82F6] hover:from-[#1d4ed8] hover:to-[#2563eb] text-white font-bold rounded-2xl transition-all transform active:scale-[0.98] shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2 mt-2"
                            >
                                {isLoading ? (
                                    <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                                ) : (
                                    'Se connecter'
                                )}
                            </button>

                            <div className="relative py-3">
                                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                                <div className="relative flex justify-center text-[10px] uppercase"><span className="bg-white px-3 text-slate-400 font-bold tracking-widest">ou</span></div>
                            </div>

                            <button
                                type="button"
                                onClick={handleGoogleLogin}
                                className="w-full py-3 border border-slate-200 hover:bg-slate-50 hover:border-slate-300 text-slate-700 font-bold rounded-2xl transition-all flex items-center justify-center gap-3"
                            >
                                <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="w-5 h-5" alt="Google" />
                                Continuer avec Google
                            </button>
                        </form>
                    </motion.div>

                    <div className="mt-6 text-center">
                        <p className="text-slate-400 text-[11px] font-medium leading-relaxed max-w-xs mx-auto">
                            En vous connectant, vous acceptez nos <a href="#" className="underline hover:text-slate-600">Conditions Générales</a> et notre <a href="#" className="underline hover:text-slate-600">Politique de Confidentialité</a>.
                        </p>
                    </div>
                </div>
            </div>

            {/* RIGHT COLUMN: VISUALS */}
            <div className="hidden lg:flex w-1/2 h-full bg-slate-900 relative flex-col justify-end pb-20 overflow-hidden">
                {/* Background Image with Slow Zoom (Ken Burns Effect) */}
                <div className="absolute inset-0 z-0">
                    <motion.div
                        animate={{ scale: [1, 1.05] }}
                        transition={{ duration: 20, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
                        className="w-full h-full"
                    >
                        <img
                            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=1500"
                            alt="Medical Team"
                            className="w-full h-full object-cover opacity-50"
                        />
                    </motion.div>
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#1E3A8A]/40 to-[#0F172A]/80"></div>
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-soft-light"></div>
                </div>

                {/* Content anchored at bottom */}
                <div className="relative z-20 text-center px-12 max-w-2xl mx-auto mt-auto mb-16">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
                    >
                        <h3 className="text-4xl md:text-5xl font-bold font-display text-white mb-6 leading-tight drop-shadow-xl">
                            Plateforme leader <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-white to-blue-200">
                                de l'emploi social
                            </span>
                        </h3>

                        <div className="flex justify-center gap-8 border-t border-white/10 pt-8 mt-8">
                            <div className="text-center group">
                                <div className="text-3xl font-black text-white mb-1">10k+</div>
                                <div className="text-[10px] font-bold text-blue-200 uppercase tracking-widest opacity-80">Membres</div>
                            </div>
                            <div className="w-px h-12 bg-white/10"></div>
                            <div className="text-center group">
                                <div className="text-3xl font-black text-white mb-1">98%</div>
                                <div className="text-[10px] font-bold text-blue-200 uppercase tracking-widest opacity-80">Satisfaction</div>
                            </div>
                            <div className="w-px h-12 bg-white/10"></div>
                            <div className="text-center group">
                                <div className="text-3xl font-black text-white mb-1">24/7</div>
                                <div className="text-[10px] font-bold text-blue-200 uppercase tracking-widest opacity-80">Support</div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            </div>
        </div>
    );
};

export default Login;
