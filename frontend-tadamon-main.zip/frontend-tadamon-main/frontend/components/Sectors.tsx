import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const Sectors: React.FC = () => {
  const navigate = useNavigate();
  const [activeIndex, setActiveIndex] = useState(0);

  const sectors = [
    {
      title: 'Handicap & Autonomie',
      subtitle: 'Inclusion • Accompagnement • Dignité',
      description: 'Accompagnement expert vers l\'autonomie et l\'inclusion sociale. Nos professionnels certifiés interviennent auprès de tous types de handicaps.',
      image: 'https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?auto=format&fit=crop&q=80&w=1200',
      icon: 'accessible',
      stats: { experts: 45, missions: 128, satisfaction: 98 },
      color: 'blue',
      gradient: 'from-blue-600 to-indigo-700',
      filterValue: 'Handicap',
    },
    {
      title: 'Protection de l\'Enfance',
      subtitle: 'Sécurité • Développement • Avenir',
      description: 'Sécurité et épanouissement pour les mineurs vulnérables. Éducateurs spécialisés et assistants familiaux qualifiés.',
      image: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=1200',
      icon: 'family_restroom',
      stats: { experts: 38, missions: 94, satisfaction: 97 },
      color: 'rose',
      gradient: 'from-rose-500 to-pink-700',
      filterValue: 'Protection enfance',
    },
    {
      title: 'Insertion Sociale',
      subtitle: 'Emploi • Logement • Réintégration',
      description: 'Soutien actif vers l\'emploi et le logement. Conseillers en insertion et médiateurs sociaux expérimentés.',
      image: 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?auto=format&fit=crop&q=80&w=1200',
      icon: 'handshake',
      stats: { experts: 52, missions: 156, satisfaction: 96 },
      color: 'emerald',
      gradient: 'from-emerald-500 to-teal-700',
      filterValue: 'Insertion',
    },
    {
      title: 'Grand Âge',
      subtitle: 'Bienveillance • Soins • Dignité',
      description: 'Présence bienveillante pour nos aînés. Auxiliaires de vie et aides-soignants formés aux spécificités du grand âge.',
      image: 'https://images.unsplash.com/photo-1581579438747-1dc8d17bbce4?auto=format&fit=crop&q=80&w=1200',
      icon: 'elderly',
      stats: { experts: 64, missions: 203, satisfaction: 99 },
      color: 'amber',
      gradient: 'from-amber-500 to-orange-700',
      filterValue: 'Grand Âge',
    },
    {
      title: 'Santé Mentale',
      subtitle: 'Écoute • Thérapie • Réhabilitation',
      description: 'Soutien spécialisé en réhabilitation psychosociale. Psychologues et infirmiers psychiatriques certifiés.',
      image: 'https://images.unsplash.com/photo-1470116892389-0de5d9770b2c?auto=format&fit=crop&q=80&w=1200',
      icon: 'psychology',
      stats: { experts: 29, missions: 67, satisfaction: 98 },
      color: 'violet',
      gradient: 'from-violet-500 to-purple-700',
      filterValue: 'Santé Mentale',
    },
  ];

  const activeSector = sectors[activeIndex];

  return (
    <section className="relative overflow-hidden">
      {/* Light Header Section */}
      <div className="bg-slate-50 py-20 relative">
        {/* Background decoration */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.02)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          {/* Badge */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 border border-blue-100 mb-6"
          >
            <span className="material-symbols-outlined text-blue-600 text-sm">category</span>
            <span className="text-blue-700 text-xs font-bold uppercase tracking-wider">Secteurs d'intervention</span>
          </motion.div>

          {/* Title */}
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 tracking-tight mb-6 font-display"
          >
            Nos domaines d'<span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">excellence</span>
          </motion.h2>

          {/* Subtitle */}
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-slate-500 text-lg max-w-2xl mx-auto leading-relaxed"
          >
            Découvrez nos secteurs d'expertise et trouvez les professionnels qualifiés pour répondre à vos besoins spécifiques.
          </motion.p>
        </div>
      </div>

      {/* Dark Immersive Section */}
      <div className="relative min-h-[85vh] bg-[#030712] overflow-hidden">
      {/* Background Image with Parallax */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeIndex}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7 }}
          className="absolute inset-0"
        >
          <img
            src={activeSector.image}
            alt={activeSector.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/70 to-black/40"></div>
          <div className={`absolute inset-0 bg-gradient-to-t ${activeSector.gradient} opacity-30 mix-blend-multiply`}></div>
        </motion.div>
      </AnimatePresence>

      {/* Noise Texture */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.03] pointer-events-none"></div>

      {/* Grid Lines */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:100px_100px]"></div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 min-h-[85vh] flex flex-col">

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center my-auto">
          
          {/* Left - Active Sector Info */}
          <div>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeIndex}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 30 }}
                transition={{ duration: 0.5 }}
              >
                {/* Icon */}
                <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${activeSector.gradient} flex items-center justify-center mb-8 shadow-2xl`}>
                  <span className="material-symbols-outlined text-4xl text-white">{activeSector.icon}</span>
                </div>

                {/* Subtitle */}
                <p className="text-white/50 text-sm font-medium tracking-widest uppercase mb-4">
                  {activeSector.subtitle}
                </p>

                {/* Title */}
                <h2 className="text-5xl lg:text-7xl font-bold text-white mb-6 leading-[1.1] tracking-tight font-display">
                  {activeSector.title}
                </h2>

                {/* Description */}
                <p className="text-white/60 text-lg leading-relaxed mb-10 max-w-lg">
                  {activeSector.description}
                </p>

                {/* Stats */}
                <div className="flex gap-8 mb-10">
                  {[
                    { value: activeSector.stats.experts, label: 'Experts', suffix: '+' },
                    { value: activeSector.stats.missions, label: 'Missions', suffix: '' },
                    { value: activeSector.stats.satisfaction, label: 'Satisfaction', suffix: '%' },
                  ].map((stat, i) => (
                    <div key={i}>
                      <div className="text-3xl lg:text-4xl font-bold text-white mb-1">
                        {stat.value}<span className="text-white/40">{stat.suffix}</span>
                      </div>
                      <div className="text-xs text-white/40 uppercase tracking-wider">{stat.label}</div>
                    </div>
                  ))}
                </div>

                {/* CTA Button */}
                <button
                  onClick={() => navigate(`/missions?sector=${encodeURIComponent(activeSector.filterValue)}`)}
                  className={`group px-8 py-4 bg-gradient-to-r ${activeSector.gradient} text-white font-bold rounded-2xl shadow-2xl transition-all hover:scale-105 hover:shadow-${activeSector.color}-500/30 flex items-center gap-3 cursor-pointer`}
                >
                  <span>Explorer ce secteur</span>
                  <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">arrow_forward</span>
                </button>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right - Sector Selector */}
          <div className="relative">
            {/* Decorative circle */}
            <div className={`absolute -inset-10 bg-gradient-to-br ${activeSector.gradient} opacity-10 blur-3xl rounded-full transition-all duration-700`}></div>
            
            <div className="relative space-y-3">
              {sectors.map((sector, index) => (
                <motion.button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`w-full group relative overflow-hidden rounded-2xl transition-all duration-500 cursor-pointer ${
                    activeIndex === index 
                      ? 'bg-white/10 backdrop-blur-xl border-white/20' 
                      : 'bg-white/[0.02] hover:bg-white/[0.05] border-white/5'
                  } border p-5 text-left`}
                >
                  {/* Active indicator bar */}
                  <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${sector.gradient} transition-all duration-300 ${
                    activeIndex === index ? 'opacity-100' : 'opacity-0'
                  }`}></div>

                  <div className="flex items-center gap-5">
                    {/* Number */}
                    <div className={`text-4xl font-bold transition-colors duration-300 ${
                      activeIndex === index ? 'text-white' : 'text-white/20'
                    }`}>
                      0{index + 1}
                    </div>

                    {/* Icon */}
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 ${
                      activeIndex === index 
                        ? `bg-gradient-to-br ${sector.gradient}` 
                        : 'bg-white/5'
                    }`}>
                      <span className={`material-symbols-outlined text-xl transition-colors duration-300 ${
                        activeIndex === index ? 'text-white' : 'text-white/40'
                      }`}>{sector.icon}</span>
                    </div>

                    {/* Text */}
                    <div className="flex-1 min-w-0">
                      <h3 className={`font-bold text-lg transition-colors duration-300 truncate ${
                        activeIndex === index ? 'text-white' : 'text-white/50'
                      }`}>
                        {sector.title}
                      </h3>
                      <p className={`text-sm transition-colors duration-300 ${
                        activeIndex === index ? 'text-white/60' : 'text-white/30'
                      }`}>
                        {sector.stats.experts}+ experts disponibles
                      </p>
                    </div>

                    {/* Arrow */}
                    <span className={`material-symbols-outlined transition-all duration-300 ${
                      activeIndex === index 
                        ? 'text-white translate-x-0 opacity-100' 
                        : 'text-white/20 -translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-100'
                    }`}>chevron_right</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Navigation Dots */}
        <div className="mt-auto flex items-center justify-center gap-2">
          {sectors.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`transition-all duration-300 rounded-full cursor-pointer ${
                activeIndex === index 
                  ? `w-10 h-2 bg-gradient-to-r ${sectors[index].gradient}` 
                  : 'w-2 h-2 bg-white/20 hover:bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-white/30 text-xs uppercase tracking-widest">Scroll</span>
        <motion.div 
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-5 h-8 rounded-full border-2 border-white/20 flex items-start justify-center p-1"
        >
          <div className="w-1 h-2 bg-white/40 rounded-full"></div>
        </motion.div>
      </motion.div>
      </div>
    </section>
  );
};

export default Sectors;
