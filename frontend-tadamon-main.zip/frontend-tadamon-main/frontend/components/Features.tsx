
import React, { useRef, useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface Feature {
  title: string;
  description: string;
  icon: string;
  bgIcon: string;
  statLabel: string;
  statValue: string;
  trendIcon: string | null;
  badgeType: string | null;
}

interface FeatureCardProps {
  feature: Feature;
  isActive: boolean;
  onClick: () => void;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ feature, isActive, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className={`relative flex-shrink-0 w-[350px] md:w-[450px] rounded-[2.5rem] p-8 transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1) cursor-pointer border group snap-center overflow-hidden
        ${isActive 
          ? 'bg-[#0F172A] border-slate-700/50 scale-100 md:scale-105 shadow-[0_50px_100px_-20px_rgba(15,23,42,0.6)] z-20 ring-1 ring-white/10' 
          : 'bg-white border-slate-100 scale-95 shadow-lg opacity-70 hover:opacity-100 hover:scale-[0.98] hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.1)] hover:border-blue-100 z-10'
        }`}
    >
      {/* --- ACTIVE STATE OVERLAYS --- */}
      {isActive && (
        <>
            {/* Top-Right Glow */}
            <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px] pointer-events-none mix-blend-screen animate-pulse"></div>
            {/* Bottom-Left Glow */}
            <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-600/20 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>
            
            {/* Subtle Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
            
            {/* Giant Background Icon */}
            <div className="absolute top-6 right-6 opacity-[0.03] pointer-events-none transform rotate-12 transition-transform duration-700 group-hover:rotate-6 group-hover:scale-110">
               <span className="material-symbols-outlined text-[200px] leading-none text-white">
                 {feature.bgIcon || feature.icon}
               </span>
            </div>
        </>
      )}

      {/* --- INACTIVE STATE OVERLAYS (Hover) --- */}
      {!isActive && (
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/0 to-blue-50/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
      )}

      <div className="relative z-10 flex flex-col h-full">
        {/* Icon */}
        <div className={`w-16 h-16 rounded-3xl flex items-center justify-center mb-8 transition-all duration-300 ${
            isActive 
            ? 'bg-gradient-to-br from-white/10 to-white/5 text-blue-400 border border-white/10 shadow-[0_0_30px_rgba(59,130,246,0.15)] backdrop-blur-sm' 
            : 'bg-blue-50 text-[#2563EB] group-hover:scale-110 group-hover:bg-[#2563EB] group-hover:text-white group-hover:shadow-lg group-hover:shadow-blue-500/30'
        }`}>
          <span className="material-symbols-outlined text-3xl font-bold">
            {feature.icon}
          </span>
        </div>

        <h3 className={`text-2xl font-bold font-display mb-4 transition-colors duration-300 ${isActive ? 'text-white drop-shadow-sm' : 'text-slate-900'}`}>
          {feature.title}
        </h3>
        
        <p className={`text-sm leading-relaxed mb-10 flex-grow transition-colors duration-300 ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
           {feature.description.split(/(35 points de données|disponible immédiatement)/g).map((part: string, i: number) => 
              (part === '35 points de données' || part === 'disponible immédiatement') 
              ? <strong key={i} className={isActive ? 'text-white font-extrabold' : 'text-slate-900 font-bold'}>{part}</strong> 
              : part
           )}
        </p>

        <div className={`pt-6 border-t flex items-center justify-between mt-auto transition-colors duration-300 ${isActive ? 'border-white/10' : 'border-slate-100 group-hover:border-blue-100'}`}>
          <div className="flex flex-col">
            <span className={`text-[10px] font-bold uppercase tracking-widest mb-1 transition-colors ${isActive ? 'text-slate-400' : 'text-slate-400'}`}>
              {feature.statLabel}
            </span>
            <div className={`flex items-center gap-2 text-lg font-black transition-colors ${isActive ? 'text-white' : 'text-slate-900'}`}>
              {feature.statValue}
              {feature.trendIcon === 'trending_up' && (
                <span className={`material-symbols-outlined text-xl ${isActive ? 'text-blue-400' : 'text-blue-500'}`}>trending_up</span>
              )}
            </div>
          </div>
          
          {/* Status Badge */}
          {(feature.badgeType === 'star' || feature.badgeType === 'live') && (
             <div className={`h-9 px-4 rounded-full flex items-center justify-center gap-2 text-xs font-bold transition-all duration-300 ${
                 isActive 
                 ? 'bg-blue-500/20 text-blue-200 border border-blue-500/30 shadow-[0_0_20px_rgba(59,130,246,0.2)]' 
                 : 'bg-slate-50 text-slate-600 group-hover:bg-blue-50 group-hover:text-blue-600'
             }`}>
                {feature.badgeType === 'star' && (
                    <>
                        <span>4.9/5</span>
                        <span className="material-symbols-outlined text-yellow-400 text-sm fill-current">star</span>
                    </>
                )}
                {feature.badgeType === 'live' && (
                    <>
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                        </span>
                        <span>24/7 Live</span>
                    </>
                )}
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Features = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(1);
  const [isDown, setIsDown] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const features: Feature[] = [
    {
      title: 'Matching Intelligent',
      description: 'Notre algorithme propriétaire analyse 35 points de données pour connecter instantanément les besoins institutionnels aux compétences vérifiées.',
      icon: 'hub',
      bgIcon: 'hub',
      statLabel: 'PRÉCISION',
      statValue: '98.5%',
      trendIcon: 'trending_up',
      badgeType: null
    },
    {
      title: 'Suivi Performance',
      description: 'Un tableau de bord complet pour piloter la qualité de vos interventions. Évaluations 360°, feedback continu et métriques d\'impact social.',
      icon: 'analytics', // Chart icon
      bgIcon: 'bar_chart',
      statLabel: 'SATISFACTION',
      statValue: '4.9/5',
      trendIcon: null,
      badgeType: 'star'
    },
    {
      title: 'Temps Réel',
      description: 'Synchronisation instantanée des agendas. Réservez un professionnel disponible immédiatement pour vos urgences sociales critiques.',
      icon: 'schedule', // Clock icon
      bgIcon: 'schedule',
      statLabel: 'DISPONIBILITÉ',
      statValue: '24/7 Live',
      trendIcon: null,
      badgeType: 'live'
    },
    {
      title: 'Sécurité RGPD',
      description: 'Vos données et celles des usagers sont protégées par les plus hauts standards de cryptage européens (ISO 27001).',
      icon: 'gpp_good',
      bgIcon: 'security',
      statLabel: 'SÉCURITÉ',
      statValue: '100%',
      trendIcon: null,
      badgeType: null
    },
    {
      title: 'Support Expert',
      description: 'Une équipe d\'experts métiers vous accompagne personnellement dans chaque étape de votre recrutement.',
      icon: 'support_agent',
      bgIcon: 'headset_mic',
      statLabel: 'RÉPONSE',
      statValue: '< 2h',
      trendIcon: 'trending_up',
      badgeType: null
    }
  ];

  // Center the initial card (Index 1) on mount
  useEffect(() => {
    scrollToIndex(1, 'auto');
  }, []);

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    
    // Find the card closest to the center
    const containerCenter = container.scrollLeft + container.clientWidth / 2;
    let minDiff = Infinity;
    let newIndex = 0;

    const children = Array.from(container.children);
    const cardElements = children.slice(1, -1);

    cardElements.forEach((child, index) => {
        const div = child as HTMLElement;
        const childCenter = div.offsetLeft + div.offsetWidth / 2;
        const diff = Math.abs(containerCenter - childCenter);
        
        if (diff < minDiff) {
            minDiff = diff;
            newIndex = index;
        }
    });

    if (newIndex !== activeIndex) {
        setActiveIndex(newIndex);
    }
  };

  const scrollToIndex = (index: number, behavior: ScrollBehavior = 'smooth') => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    const cardElements = Array.from(container.children).slice(1, -1);
    const targetCard = cardElements[index] as HTMLElement;

    if (targetCard) {
        const offset = targetCard.offsetLeft - (container.clientWidth / 2) + (targetCard.clientWidth / 2);
        container.scrollTo({
            left: offset,
            behavior: behavior
        });
    }
  };

  // Drag Logic
  const handleMouseDown = (e: React.MouseEvent) => {
    if(!scrollRef.current) return;
    setIsDown(true);
    setStartX(e.pageX - scrollRef.current.offsetLeft);
    setScrollLeft(scrollRef.current.scrollLeft);
  };
  const handleMouseLeave = () => setIsDown(false);
  const handleMouseUp = () => setIsDown(false);
  const handleMouseMove = (e: React.MouseEvent) => {
    if(!isDown || !scrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    scrollRef.current.scrollLeft = scrollLeft - walk;
  };

  return (
    <section className="py-24 relative overflow-hidden bg-slate-50">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-soft-light"></div>
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-blue-100 rounded-full blur-3xl opacity-40 -z-0 translate-x-1/3 -translate-y-1/3"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-indigo-100 rounded-full blur-3xl opacity-40 -z-0 -translate-x-1/3 translate-y-1/3"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16 relative z-10">
        {/* Simple Badge */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 border border-blue-100 mb-8"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
          <span className="text-blue-700 text-xs font-semibold uppercase tracking-wider">Technologie & Humain</span>
        </motion.div>

        {/* Title */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-5xl lg:text-6xl font-bold font-display text-slate-900 mb-6 tracking-tight"
        >
          L'Excellence <span className="text-blue-600 italic">Inégalée</span>
        </motion.h2>

        {/* Subtitle */}
        <motion.p 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="text-slate-500 max-w-2xl mx-auto text-lg md:text-xl leading-relaxed"
        >
          Une architecture conçue pour l'action sociale, optimisée pour la{' '}
          <span className="text-slate-900 font-semibold">fluidité</span> et la{' '}
          <span className="text-slate-900 font-semibold">sécurité</span>.
        </motion.p>
      </div>

      {/* Horizontal Scroll Container */}
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex overflow-x-auto items-center gap-6 py-10 carousel-container cursor-grab active:cursor-grabbing hide-scrollbar snap-x snap-mandatory relative z-10"
        onMouseDown={handleMouseDown}
        onMouseLeave={handleMouseLeave}
        onMouseUp={handleMouseUp}
        onMouseMove={handleMouseMove}
      >
        {/* Left Spacer for Centering */}
        <div className="flex-shrink-0 w-[calc(50%-175px)] md:w-[calc(50%-225px)]"></div>
        
        {features.map((feature, idx) => (
          <FeatureCard 
            key={idx} 
            feature={feature} 
            isActive={idx === activeIndex} 
            onClick={() => scrollToIndex(idx)}
          />
        ))}

        {/* Right Spacer for Centering */}
        <div className="flex-shrink-0 w-[calc(50%-175px)] md:w-[calc(50%-225px)]"></div>
      </div>
    </section>
  );
};

export default Features;
