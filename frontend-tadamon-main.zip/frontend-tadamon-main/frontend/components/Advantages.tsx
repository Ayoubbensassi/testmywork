import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const Advantages: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'workers' | 'establishments' | 'quality'>('workers');
  const navigate = useNavigate();

  const content = {
    workers: {
      title: 'Développez votre carrière en toute',
      highlight: 'liberté',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800',
      points: [
        { text: 'Choisissez vos missions selon vos disponibilités', icon: 'calendar_month' },
        { text: 'Fixez vos tarifs et conditions de travail', icon: 'payments' },
        { text: 'Accédez à des établissements vérifiés', icon: 'verified' },
        { text: 'Construisez votre réputation professionnelle', icon: 'star' }
      ],
      cta: 'Créer mon profil',
      stats: { count: '+2k', label: 'membres', sublabel: 'Actifs aujourd\'hui' }
    },
    establishments: {
      title: 'Recrutez les meilleurs talents en toute',
      highlight: 'simplicité',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800',
      points: [
        { text: 'Accès immédiat aux profils certifiés', icon: 'bolt' },
        { text: 'Gestion administrative automatisée', icon: 'description' },
        { text: 'Réduction des coûts de recrutement', icon: 'savings' },
        { text: 'Continuité de service garantie', icon: 'schedule' }
      ],
      cta: 'Publier une mission',
      stats: { count: '+500', label: 'établissements', sublabel: 'Nous font confiance' }
    },
    quality: {
      title: 'Des standards élevés pour une',
      highlight: 'confiance totale',
      image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&q=80&w=800',
      points: [
        { text: 'Vérification rigoureuse des diplômes', icon: 'school' },
        { text: 'Contrôle des références employeurs', icon: 'fact_check' },
        { text: 'Évaluation continue des compétences', icon: 'trending_up' },
        { text: 'Charte éthique signée par tous', icon: 'handshake' }
      ],
      cta: 'Voir les garanties',
      stats: { count: '100%', label: 'vérifiés', sublabel: 'Profils certifiés' }
    }
  };

  const current = content[activeTab];

  const tabs = [
    { id: 'workers' as const, label: 'Travailleurs', sublabel: 'Gérez votre carrière', icon: 'person' },
    { id: 'establishments' as const, label: 'Établissements', sublabel: 'Recrutez les meilleurs', icon: 'business' },
    { id: 'quality' as const, label: 'Qualité', sublabel: 'Standards élevés', icon: 'workspace_premium' }
  ];

  return (
    <section className="py-28 md:py-36 relative overflow-hidden">
      {/* Premium Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-50 via-blue-50/30 to-slate-50"></div>
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-gradient-to-br from-blue-100/60 to-indigo-100/40 rotate-45 -translate-x-1/2 -translate-y-1/2 rounded-[4rem]"></div>
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-gradient-to-tl from-purple-100/40 to-pink-100/30 rotate-12 translate-x-1/3 translate-y-1/3 rounded-[3rem]"></div>
      
      {/* Floating Dots Pattern */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-blue-300/30 rounded-full"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          {/* Simple Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 border border-emerald-100 mb-8">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
            <span className="text-emerald-700 text-xs font-semibold uppercase tracking-wider">Avantages exclusifs</span>
          </div>

          {/* Title */}
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-slate-900 tracking-tight mb-6 font-display">
            Une plateforme, <span className="text-blue-600 italic">plusieurs avantages</span>
          </h2>

          {/* Subtitle */}
          <p className="text-slate-500 text-lg max-w-2xl mx-auto leading-relaxed">
            Découvrez comment notre réseau transforme votre expérience sociale au quotidien.
          </p>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* LEFT: Navigation Cards */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-3 flex flex-col gap-3"
          >
            {tabs.map((tab, index) => (
              <motion.button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 + index * 0.1 }}
                className={`relative flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 text-left w-full group cursor-pointer ${
                  activeTab === tab.id 
                    ? 'bg-gradient-to-r from-blue-600 to-blue-500 shadow-xl shadow-blue-500/25' 
                    : 'bg-white/80 backdrop-blur-sm hover:bg-white shadow-sm hover:shadow-lg border border-slate-100/80'
                }`}
              >
                {/* Active Indicator */}
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-500 rounded-2xl"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                
                <div className={`relative z-10 w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-all ${
                  activeTab === tab.id 
                    ? 'bg-amber-400 shadow-lg shadow-amber-400/30' 
                    : 'bg-slate-100 group-hover:bg-blue-50'
                }`}>
                  <span className={`material-symbols-outlined text-xl ${
                    activeTab === tab.id ? 'text-slate-900' : 'text-slate-500 group-hover:text-blue-600'
                  }`}>{tab.icon}</span>
                </div>
                
                <div className="relative z-10 flex flex-col">
                  <span className={`text-[15px] font-bold leading-tight ${
                    activeTab === tab.id ? 'text-white' : 'text-slate-900'
                  }`}>{tab.label}</span>
                  <span className={`text-xs mt-0.5 ${
                    activeTab === tab.id ? 'text-blue-100' : 'text-slate-400'
                  }`}>{tab.sublabel}</span>
                </div>

                {/* Arrow for active */}
                {activeTab === tab.id && (
                  <motion.div 
                    initial={{ opacity: 0, x: -5 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="relative z-10 ml-auto"
                  >
                    <svg className="w-5 h-5 text-white/70" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                    </svg>
                  </motion.div>
                )}
              </motion.button>
            ))}
          </motion.div>

          {/* CENTER: Image Card */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-4 relative"
          >
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-200/50 via-indigo-200/30 to-purple-200/50 blur-3xl scale-110 rounded-full"></div>
            
            {/* Image Container */}
            <div className="relative w-full max-w-[320px] mx-auto">
              {/* Main Card */}
              <div className="relative bg-white rounded-[2rem] p-2 shadow-2xl shadow-slate-900/10">
                <div className="relative rounded-[1.5rem] overflow-hidden aspect-[3/4]">
                  <AnimatePresence mode="wait">
                    <motion.img 
                      key={activeTab}
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.5 }}
                      src={current.image}
                      alt="Professional"
                      className="w-full h-full object-cover"
                    />
                  </AnimatePresence>
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/20 via-transparent to-transparent"></div>
                </div>
                
                {/* Stats Badge */}
                <motion.div 
                  key={`stats-${activeTab}`}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-white rounded-2xl shadow-xl shadow-slate-900/10 px-5 py-3 flex items-center gap-3"
                >
                  <div className="flex -space-x-2">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 border-2 border-white"></div>
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 border-2 border-white"></div>
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-400 to-indigo-500 border-2 border-white"></div>
                  </div>
                  <div className="border-l border-slate-200 pl-3">
                    <p className="text-sm font-bold text-blue-600">{current.stats.count} {current.stats.label}</p>
                    <p className="text-[10px] text-slate-400">{current.stats.sublabel}</p>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.div>

          {/* RIGHT: Content */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="lg:col-span-5"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                {/* Title */}
                <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-8 leading-tight">
                  {current.title}{' '}
                  <span className="text-blue-600 italic font-serif">{current.highlight}</span>
                </h3>

                {/* Points */}
                <ul className="space-y-5 mb-10">
                  {current.points.map((point, i) => (
                    <motion.li 
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + i * 0.1 }}
                      className="flex items-start gap-4"
                    >
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shrink-0 mt-0.5 shadow-md shadow-blue-500/20">
                        <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-slate-600 text-[15px] leading-relaxed">{point.text}</span>
                    </motion.li>
                  ))}
                </ul>

                {/* CTA Button */}
                <motion.button 
                  onClick={() => navigate('/signup')}
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold rounded-xl shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all cursor-pointer"
                >
                  <span>{current.cta}</span>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </motion.button>
              </motion.div>
            </AnimatePresence>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Advantages;
