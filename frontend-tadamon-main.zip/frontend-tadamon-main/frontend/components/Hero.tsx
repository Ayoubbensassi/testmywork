import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { regionsAPI } from '../src/api';
import LocationAutocomplete from './LocationAutocomplete';

interface Region {
  id: number;
  name_fr: string;
  code?: string;
}

interface City {
  id: number;
  name_fr: string;
  region_id: number;
}

const Hero = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [search, setSearch] = useState({ specialty: '', location: '' });
  const [isSearching, setIsSearching] = useState(false);
  const [userRole, setUserRole] = useState<'recruiter' | 'worker'>('recruiter');
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isTyping, setIsTyping] = useState(true);
  const [regions, setRegions] = useState<Region[]>([]);
  const [cities, setCities] = useState<City[]>([]);

  // Fetch regions and cities
  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const [regionsRes, citiesRes] = await Promise.all([
          regionsAPI.getAll(),
          regionsAPI.getAllCities()
        ]);
        setRegions(regionsRes.regions || []);
        setCities(citiesRes.cities || []);
      } catch (err) {
        console.error('Failed to load locations:', err);
      }
    };
    fetchLocations();
  }, []);

  const phrases = [
    "Action Sociale",
    "Médico-Social", 
    "Protection de l'Enfance",
    "Insertion Professionnelle",
    "Grand Âge"
  ];

  // Typewriter effect
  useEffect(() => {
    const currentPhrase = phrases[phraseIndex];
    
    if (isTyping) {
      if (displayText.length < currentPhrase.length) {
        const timeout = setTimeout(() => {
          setDisplayText(currentPhrase.slice(0, displayText.length + 1));
        }, 80);
        return () => clearTimeout(timeout);
      } else {
        const timeout = setTimeout(() => {
          setIsTyping(false);
        }, 2000);
        return () => clearTimeout(timeout);
      }
    } else {
      if (displayText.length > 0) {
        const timeout = setTimeout(() => {
          setDisplayText(displayText.slice(0, -1));
        }, 40);
        return () => clearTimeout(timeout);
      } else {
        setPhraseIndex((prev) => (prev + 1) % phrases.length);
        setIsTyping(true);
      }
    }
  }, [displayText, isTyping, phraseIndex]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    
    // Build query params for search
    const params = new URLSearchParams();
    if (search.specialty.trim()) {
      params.set('q', search.specialty.trim());
    }
    if (search.location.trim()) {
      params.set('location', search.location.trim());
    }
    params.set('role', userRole);
    
    const queryString = params.toString();
    const url = queryString ? `/missions?${queryString}` : '/missions';
    
    setTimeout(() => {
      setIsSearching(false);
      navigate(url);
    }, 400);
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden pt-32 pb-40">

      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&family=Inter:wght@300;400;500;600;700&display=swap');
        .font-display { font-family: 'Cormorant Garamond', Georgia, serif; }
        .font-body { font-family: 'Inter', system-ui, sans-serif; }
      `}</style>

      {/* Premium Background with Image Overlay */}
      <div className="absolute inset-0 z-0">
        {/* Background image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?q=80&w=2070&auto=format&fit=crop')`,
          }}
        />
        
        {/* Dark overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950/95 via-slate-900/90 to-slate-950/95"></div>
        
        {/* Color accent overlays */}
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-950/50 via-transparent to-indigo-950/30"></div>
        
        {/* Animated gradient orbs */}
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.08, 0.15, 0.08]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-cyan-500 rounded-full blur-[180px]"
        />
        <motion.div 
          animate={{ 
            scale: [1, 1.3, 1],
            opacity: [0.05, 0.12, 0.05]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-indigo-500 rounded-full blur-[180px]"
        />
        
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:72px_72px]"></div>
        
        {/* Vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(0,0,0,0.5)_100%)]"></div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
          className="absolute top-20 left-[5%] w-48 h-48 border border-white/[0.03] rounded-full"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-32 right-[8%] w-64 h-64 border border-white/[0.03] rounded-full"
        />
        
        {/* Floating particles */}
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              y: [0, -30, 0],
              opacity: [0.1, 0.3, 0.1]
            }}
            transition={{ 
              duration: 5 + i, 
              repeat: Infinity, 
              ease: "easeInOut", 
              delay: i * 0.8 
            }}
            className="absolute w-1.5 h-1.5 bg-white/30 rounded-full"
            style={{
              top: `${25 + i * 12}%`,
              left: `${8 + i * 18}%`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">

        {/* Top Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="inline-flex items-center gap-2.5 px-6 py-2.5 rounded-full bg-white/[0.03] border border-white/[0.08] backdrop-blur-2xl mb-14"
        >
          <div className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
          </div>
          <span className="font-body text-[13px] font-medium text-white/70 tracking-wide">Réseau sélectif • Professionnels vérifiés</span>
        </motion.div>

        {/* Main Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15, ease: "easeOut" }}
          className="font-display font-semibold text-[3.5rem] md:text-[5.5rem] lg:text-[7rem] text-white tracking-[-0.02em] leading-[0.95] mb-2"
        >
          Connectez les talents
        </motion.h1>

        {/* Typewriter Animated Phrase */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="h-[70px] md:h-[100px] flex items-center justify-center mb-10"
        >
          <span className="font-display font-semibold text-[2.5rem] md:text-[4rem] lg:text-[5rem] text-white/90 tracking-[-0.02em] mr-4">
            du
          </span>
          <span className="font-display font-semibold italic text-[2.5rem] md:text-[4rem] lg:text-[5rem] tracking-[-0.02em] text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-teal-200 to-cyan-300">
            {displayText}
          </span>
          <motion.span
            animate={{ opacity: [1, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, repeatType: "reverse" }}
            className="inline-block w-[3px] h-[2.5rem] md:h-[4rem] lg:h-[5rem] bg-gradient-to-b from-cyan-300 to-teal-300 ml-1 rounded-full"
          />
        </motion.div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45, duration: 0.8, ease: "easeOut" }}
          className="font-body text-base md:text-lg text-white/50 max-w-2xl mx-auto leading-relaxed mb-14 font-light"
        >
          Travailleurs sociaux indépendants, profils labellisés et établissements vérifiés.{' '}
          <br className="hidden md:block" />
          <span className="text-white/80 font-normal">Plus qu'une mise en relation — une garantie de qualité.</span>
        </motion.p>

        {/* Toggle Switch */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          className="flex justify-center mb-14"
        >
          <div className="relative p-1 bg-white/[0.03] border border-white/[0.08] rounded-full flex items-center backdrop-blur-2xl">
            <motion.div
              className="absolute top-1 bottom-1 bg-white rounded-full"
              animate={{
                x: userRole === 'recruiter' ? 0 : 148,
                width: userRole === 'recruiter' ? 140 : 208
              }}
              transition={{ type: "spring", stiffness: 350, damping: 30 }}
              style={{ left: 4 }}
            />
            <button
              onClick={() => setUserRole('recruiter')}
              className={`relative z-10 w-[140px] py-3.5 rounded-full font-body text-sm font-semibold transition-colors duration-300 cursor-pointer ${
                userRole === 'recruiter' ? 'text-slate-900' : 'text-white/50 hover:text-white/70'
              }`}
            >
              Je recrute
            </button>
            <button
              onClick={() => setUserRole('worker')}
              className={`relative z-10 w-[208px] py-3.5 rounded-full font-body text-sm font-semibold transition-colors duration-300 cursor-pointer ${
                userRole === 'worker' ? 'text-slate-900' : 'text-white/50 hover:text-white/70'
              }`}
            >
              Je cherche une mission
            </button>
          </div>
        </motion.div>

        {/* Premium Search Bar */}
        <motion.form
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65 }}
          onSubmit={handleSearch}
          className="relative z-20 w-full max-w-4xl mx-auto"
        >
          {/* Animated glow effect */}
          <motion.div 
            animate={{ 
              opacity: [0.5, 0.8, 0.5],
              scale: [1, 1.01, 1]
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -inset-[3px] bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 rounded-[32px] blur-xl"
          />
          
          {/* Search Container */}
          <div className="relative bg-white rounded-[28px] shadow-2xl shadow-black/10 p-1.5">
            <div className="flex flex-col md:flex-row">
              
              {/* Keyword Search */}
              <div className="flex-1 group">
                <div className="flex items-center h-[60px] px-5 rounded-[22px] hover:bg-slate-50 transition-all m-0.5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center mr-4 shadow-lg shadow-blue-500/20">
                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Recherche</label>
                    <input
                      type="text"
                      placeholder="Poste, spécialité, mot-clé..."
                      value={search.specialty}
                      onChange={(e) => setSearch({ ...search, specialty: e.target.value })}
                      className="w-full bg-transparent border-none p-0 font-body text-slate-800 text-[15px] font-medium focus:ring-0 focus:outline-none placeholder:text-slate-400"
                    />
                  </div>
                </div>
              </div>

              {/* Divider */}
              <div className="hidden md:flex items-center px-2">
                <div className="w-px h-10 bg-gradient-to-b from-transparent via-slate-200 to-transparent"></div>
              </div>

              {/* Location Search */}
              <div className="flex-1 group">
                <div className="flex items-center h-[60px] px-5 rounded-[22px] hover:bg-slate-50 transition-all m-0.5">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center mr-4 shadow-lg shadow-indigo-500/20">
                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Localisation</label>
                    <LocationAutocomplete
                      regions={regions}
                      cities={cities}
                      value={search.location}
                      onChange={(val) => setSearch({ ...search, location: val === 'Toutes les régions' ? '' : val })}
                      placeholder="Où cherchez-vous ?"
                      variant="light"
                    />
                  </div>
                </div>
              </div>

              {/* Search Button */}
              <div className="p-1">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isSearching}
                  className="h-[60px] px-10 bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 hover:from-blue-400 hover:via-blue-500 hover:to-indigo-500 text-white font-semibold text-[15px] rounded-[22px] shadow-xl shadow-blue-500/30 hover:shadow-blue-500/40 flex items-center justify-center gap-3 cursor-pointer transition-all w-full md:w-auto"
                >
                  {isSearching ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>Rechercher</span>
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                      </svg>
                    </>
                  )}
                </motion.button>
              </div>
            </div>
          </div>
        </motion.form>

        {/* Trust Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.85 }}
          className="flex flex-wrap items-center justify-center gap-3 mt-16"
        >
          <motion.div
            whileHover={{ y: -2 }}
            className="flex items-center gap-2.5 px-5 py-3 rounded-full bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl"
          >
            <div className="w-7 h-7 rounded-full bg-emerald-500/10 flex items-center justify-center">
              <svg className="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <span className="font-body text-white/70 text-sm font-medium">Labellisation rigoureuse</span>
          </motion.div>
          
          <motion.div
            whileHover={{ y: -2 }}
            className="flex items-center gap-2.5 px-5 py-3 rounded-full bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl"
          >
            <div className="w-7 h-7 rounded-full bg-blue-500/10 flex items-center justify-center">
              <svg className="w-4 h-4 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0z" />
              </svg>
            </div>
            <span className="font-body text-white/70 text-sm font-medium">Vérification des diplômes</span>
          </motion.div>
          
          <motion.div
            whileHover={{ y: -2 }}
            className="flex items-center gap-2.5 px-5 py-3 rounded-full bg-white/[0.03] border border-white/[0.08] backdrop-blur-xl"
          >
            <div className="w-7 h-7 rounded-full bg-amber-500/10 flex items-center justify-center">
              <svg className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 10a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zM12 2a1 1 0 01.967.744L14.146 7.2 17.5 9.134a1 1 0 010 1.732l-3.354 1.935-1.18 4.455a1 1 0 01-1.933 0L9.854 12.8 6.5 10.866a1 1 0 010-1.732l3.354-1.935 1.18-4.455A1 1 0 0112 2z" clipRule="evenodd" />
              </svg>
            </div>
            <span className="font-body text-white/70 text-sm font-medium">Qualité de service garantie</span>
          </motion.div>
        </motion.div>

      </div>

      {/* Wave Divider */}
      <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none">
        <svg className="relative block w-full h-[80px] md:h-[120px]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" preserveAspectRatio="none">
          <path d="M0,64 C360,100 720,120 1080,80 C1260,60 1380,40 1440,64 L1440,120 L0,120 Z" fill="white"></path>
        </svg>
      </div>

    </section>
  );
};

export default Hero;
