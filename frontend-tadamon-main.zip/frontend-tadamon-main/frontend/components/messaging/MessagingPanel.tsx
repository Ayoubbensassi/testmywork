import React, { useState, useEffect, useRef } from 'react';
import { X, PaperPlaneTilt, User, MagnifyingGlass } from '@phosphor-icons/react';
import { messageAPI } from '../../services/api';

interface Conversation {
  id: number;
  other_user_id: number;
  other_user_name: string;
  other_user_avatar?: string;
  last_message: string;
  last_message_time: string;
  unread_count: number;
}

interface Message {
  id: number;
  sender_id: number;
  content: string;
  created_at: string;
  is_mine: boolean;
}

interface MessagingPanelProps {
  isOpen?: boolean;
  onClose?: () => void;
}

const MessagingPanel: React.FC<MessagingPanelProps> = ({ isOpen = true, onClose }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) loadConversations();
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadConversations = async () => {
    setLoading(true);
    try {
      const res = await messageAPI.getConversations();
      setConversations(res.data?.conversations || res.conversations || []);
    } catch (err) {
      console.error('Error loading conversations:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async (conversationId: number) => {
    try {
      const res = await messageAPI.getMessages(conversationId);
      setMessages(res.data?.messages || res.messages || []);
    } catch (err) {
      console.error('Error loading messages:', err);
    }
  };

  const selectConversation = (conv: Conversation) => {
    setSelectedConversation(conv);
    loadMessages(conv.id);
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation) return;

    try {
      await messageAPI.sendMessage({
        conversation_id: selectedConversation.id,
        content: newMessage.trim(),
      });
      setNewMessage('');
      loadMessages(selectedConversation.id);
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    if (date.toDateString() === today.toDateString()) return 'Aujourd\'hui';
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) return 'Hier';
    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  };

  if (!isOpen) return null;

  return (
    <div className="messaging-panel">
      <div className="messaging-sidebar">
        <div className="messaging-header">
          <h3>Messages</h3>
          {onClose && (
            <button className="close-btn" onClick={onClose}>
              <X size={20} />
            </button>
          )}
        </div>

        <div className="search-box">
          <MagnifyingGlass size={18} />
          <input
            type="text"
            placeholder="Rechercher..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="conversations-list">
          {loading ? (
            <div className="loading">Chargement...</div>
          ) : conversations.length === 0 ? (
            <div className="empty">Aucune conversation</div>
          ) : (
            conversations
              .filter(c => c.other_user_name.toLowerCase().includes(searchQuery.toLowerCase()))
              .map(conv => (
                <div
                  key={conv.id}
                  className={`conversation-item ${selectedConversation?.id === conv.id ? 'active' : ''}`}
                  onClick={() => selectConversation(conv)}
                >
                  <div className="conv-avatar">
                    {conv.other_user_avatar ? (
                      <img src={conv.other_user_avatar} alt="" />
                    ) : (
                      <User size={20} />
                    )}
                  </div>
                  <div className="conv-info">
                    <div className="conv-header">
                      <span className="conv-name">{conv.other_user_name}</span>
                      <span className="conv-time">{formatDate(conv.last_message_time)}</span>
                    </div>
                    <p className="conv-preview">{conv.last_message}</p>
                  </div>
                  {conv.unread_count > 0 && (
                    <span className="unread-badge">{conv.unread_count}</span>
                  )}
                </div>
              ))
          )}
        </div>
      </div>

      <div className="messaging-main">
        {selectedConversation ? (
          <>
            <div className="chat-header">
              <div className="chat-user">
                <div className="chat-avatar">
                  {selectedConversation.other_user_avatar ? (
                    <img src={selectedConversation.other_user_avatar} alt="" />
                  ) : (
                    <User size={24} />
                  )}
                </div>
                <span>{selectedConversation.other_user_name}</span>
              </div>
            </div>

            <div className="messages-container">
              {messages.map(msg => (
                <div key={msg.id} className={`message ${msg.is_mine ? 'mine' : 'theirs'}`}>
                  <div className="message-content">{msg.content}</div>
                  <span className="message-time">{formatTime(msg.created_at)}</span>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <form className="message-input" onSubmit={sendMessage}>
              <input
                type="text"
                placeholder="Écrire un message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <button type="submit" disabled={!newMessage.trim()}>
                <PaperPlaneTilt size={20} weight="fill" />
              </button>
            </form>
          </>
        ) : (
          <div className="no-conversation">
            <p>Sélectionnez une conversation</p>
          </div>
        )}
      </div>

      <style>{`
        .messaging-panel {
          display: flex;
          height: 100%;
          background: rgba(18, 18, 26, 0.9);
          border-radius: 16px;
          overflow: hidden;
          border: 1px solid rgba(139, 92, 246, 0.15);
        }
        .messaging-sidebar {
          width: 320px;
          border-right: 1px solid rgba(139, 92, 246, 0.15);
          display: flex;
          flex-direction: column;
          background: rgba(18, 18, 26, 0.95);
        }
        .messaging-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 20px;
          border-bottom: 1px solid rgba(139, 92, 246, 0.15);
        }
        .messaging-header h3 { 
          font-size: 18px; 
          font-weight: 600; 
          margin: 0; 
          color: #F8FAFC;
        }
        .close-btn { background: none; border: none; cursor: pointer; color: #94A3B8; }
        .search-box {
          display: flex;
          align-items: center;
          gap: 10px;
          margin: 16px;
          padding: 10px 14px;
          background: rgba(0, 0, 0, 0.3);
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 10px;
          color: #94A3B8;
        }
        .search-box input {
          flex: 1;
          border: none;
          background: none;
          outline: none;
          font-size: 14px;
          color: #F8FAFC;
        }
        .search-box input::placeholder {
          color: #64748B;
        }
        .conversations-list { flex: 1; overflow-y: auto; }
        .conversation-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 20px;
          cursor: pointer;
          transition: background 0.2s;
          border-bottom: 1px solid rgba(139, 92, 246, 0.08);
        }
        .conversation-item:hover { background: rgba(139, 92, 246, 0.1); }
        .conversation-item.active { background: rgba(139, 92, 246, 0.2); }
        .conv-avatar {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: rgba(139, 92, 246, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          color: #A78BFA;
        }
        .conv-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .conv-info { flex: 1; min-width: 0; }
        .conv-header { display: flex; justify-content: space-between; margin-bottom: 4px; }
        .conv-name { font-weight: 500; font-size: 14px; color: #F8FAFC; }
        .conv-time { font-size: 11px; color: #64748B; }
        .conv-preview { font-size: 13px; color: #94A3B8; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .unread-badge {
          background: #8B5CF6;
          color: white;
          font-size: 11px;
          padding: 2px 8px;
          border-radius: 10px;
        }
        .messaging-main { 
          flex: 1; 
          display: flex; 
          flex-direction: column; 
          background: rgba(10, 10, 15, 0.5);
        }
        .chat-header {
          padding: 16px 20px;
          border-bottom: 1px solid rgba(139, 92, 246, 0.15);
          background: rgba(18, 18, 26, 0.8);
        }
        .chat-user { display: flex; align-items: center; gap: 12px; }
        .chat-user span { color: #F8FAFC; font-weight: 500; }
        .chat-avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: rgba(139, 92, 246, 0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          color: #A78BFA;
        }
        .chat-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .messages-container {
          flex: 1;
          padding: 20px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        .message { max-width: 70%; }
        .message.mine { align-self: flex-end; }
        .message.theirs { align-self: flex-start; }
        .message-content {
          padding: 12px 16px;
          border-radius: 16px;
          font-size: 14px;
          line-height: 1.4;
        }
        .message.mine .message-content { 
          background: linear-gradient(135deg, #8B5CF6, #7C3AED); 
          color: white; 
          border-bottom-right-radius: 4px; 
        }
        .message.theirs .message-content { 
          background: rgba(139, 92, 246, 0.15); 
          color: #F8FAFC; 
          border-bottom-left-radius: 4px; 
        }
        .message-time { font-size: 11px; color: #64748B; margin-top: 4px; display: block; }
        .message.mine .message-time { text-align: right; }
        .message-input {
          display: flex;
          gap: 12px;
          padding: 16px 20px;
          border-top: 1px solid rgba(139, 92, 246, 0.15);
          background: rgba(18, 18, 26, 0.8);
        }
        .message-input input {
          flex: 1;
          padding: 12px 16px;
          border: 1px solid rgba(139, 92, 246, 0.2);
          border-radius: 24px;
          outline: none;
          font-size: 14px;
          background: rgba(0, 0, 0, 0.3);
          color: #F8FAFC;
        }
        .message-input input::placeholder {
          color: #64748B;
        }
        .message-input input:focus { border-color: #8B5CF6; }
        .message-input button {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: linear-gradient(135deg, #8B5CF6, #7C3AED);
          color: white;
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s ease;
        }
        .message-input button:hover {
          transform: scale(1.05);
          box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
        }
        .message-input button:disabled { background: #4B5563; cursor: not-allowed; transform: none; box-shadow: none; }
        .no-conversation {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #64748B;
        }
        .no-conversation p {
          color: #94A3B8;
        }
        .loading, .empty { 
          padding: 40px; 
          text-align: center; 
          color: #94A3B8; 
        }
        
        /* Light mode overrides */
        [data-theme="light"] .messaging-panel { 
          background: white; 
          border-color: rgba(139, 92, 246, 0.15);
        }
        [data-theme="light"] .messaging-sidebar { 
          background: #f8fafc;
          border-color: #e2e8f0; 
        }
        [data-theme="light"] .messaging-header { 
          border-color: #e2e8f0; 
        }
        [data-theme="light"] .messaging-header h3 { 
          color: #1e293b; 
        }
        [data-theme="light"] .search-box { 
          background: white; 
          border-color: #e2e8f0;
        }
        [data-theme="light"] .search-box input { 
          color: #1e293b; 
        }
        [data-theme="light"] .conversation-item { 
          border-color: #e2e8f0; 
        }
        [data-theme="light"] .conversation-item:hover { 
          background: #f1f5f9; 
        }
        [data-theme="light"] .conversation-item.active { 
          background: rgba(139, 92, 246, 0.1); 
        }
        [data-theme="light"] .conv-avatar {
          background: #e2e8f0;
          color: #8B5CF6;
        }
        [data-theme="light"] .conv-name { 
          color: #1e293b; 
        }
        [data-theme="light"] .conv-preview { 
          color: #64748b; 
        }
        [data-theme="light"] .messaging-main {
          background: white;
        }
        [data-theme="light"] .chat-header { 
          border-color: #e2e8f0;
          background: #f8fafc;
        }
        [data-theme="light"] .chat-user span {
          color: #1e293b;
        }
        [data-theme="light"] .chat-avatar {
          background: #e2e8f0;
          color: #8B5CF6;
        }
        [data-theme="light"] .message.theirs .message-content { 
          background: #f1f5f9; 
          color: #1e293b; 
        }
        [data-theme="light"] .message-input { 
          border-color: #e2e8f0;
          background: #f8fafc;
        }
        [data-theme="light"] .message-input input { 
          background: white; 
          border-color: #e2e8f0; 
          color: #1e293b; 
        }
        [data-theme="light"] .no-conversation p {
          color: #64748b;
        }
        [data-theme="light"] .loading, 
        [data-theme="light"] .empty { 
          color: #64748b; 
        }
      `}</style>
    </div>
  );
};

export default MessagingPanel;
