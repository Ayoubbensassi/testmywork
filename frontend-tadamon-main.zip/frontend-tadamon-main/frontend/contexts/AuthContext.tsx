// Re-export from root AuthContext for compatibility
export { AuthProvider, useAuth } from '../AuthContext';
