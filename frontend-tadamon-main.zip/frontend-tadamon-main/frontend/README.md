# 🚀 LKHEDMA SOCIAL - Frontend

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![React](https://img.shields.io/badge/React-18.3.1-61DAFB?logo=react)
![Vite](https://img.shields.io/badge/Vite-5.0.0-646CFF?logo=vite)
![TailwindCSS](https://img.shields.io/badge/Tailwind-3.4.0-38B2AC?logo=tailwind-css)
![License](https://img.shields.io/badge/license-MIT-green.svg)

**Plateforme de mise en relation entre travailleurs sociaux indépendants et établissements au Maroc**

[Démo Live](#) • [Documentation](#) • [Rapport de bugs](#)

</div>

---

## 📋 Table des matières

- [À propos](#-à-propos)
- [Fonctionnalités](#-fonctionnalités)
- [Technologies](#-technologies)
- [Prérequis](#-prérequis)
- [Installation](#-installation)
- [Configuration](#-configuration)
- [Utilisation](#-utilisation)
- [Structure du projet](#-structure-du-projet)
- [Scripts disponibles](#-scripts-disponibles)
- [Architecture](#-architecture)
- [Composants clés](#-composants-clés)
- [État global](#-état-global)
- [API Integration](#-api-integration)
- [Styling](#-styling)
- [Tests](#-tests)
- [Déploiement](#-déploiement)
- [Performances](#-performances)
- [Accessibilité](#-accessibilité)
- [Navigateurs supportés](#-navigateurs-supportés)
- [Contribution](#-contribution)
- [Équipe](#-équipe)
- [Licence](#-licence)

---

## 🎯 À propos

**TADAMON** est une plateforme web moderne qui connecte les travailleurs sociaux indépendants qualifiés avec les établissements du secteur médico-social au Maroc.

### Contexte du projet

Ce projet a été développé dans le cadre de notre **projet de fin d'études** (2025-2026) et vise à résoudre les problématiques de recrutement dans le secteur social marocain.

### Problématiques résolues

- ✅ Difficulté à trouver des professionnels qualifiés rapidement
- ✅ Manque de confiance (vérification CIN, ICE, diplômes)
- ✅ Processus de recrutement long et coûteux
- ✅ Absence de système de notation et retours d'expérience
- ✅ Multiplication des intervenants dans les établissements

---

## ✨ Fonctionnalités

### 🔐 Authentification
- Inscription avec validation email
- Connexion sécurisée (JWT)
- Gestion des sessions
- Récupération de mot de passe (à venir)

### 👤 Espace Travailleur
- Création de profil détaillé (CV, diplômes, expériences)
- Recherche de missions par région et spécialité
- Système de candidature en un clic
- Suivi des candidatures en temps réel
- Messagerie interne avec établissements
- Tableau de bord avec statistiques
- Gestion des évaluations reçues

### 🏢 Espace Établissement
- Profil établissement avec vérification ICE
- Publication de missions
- Réception et gestion des candidatures
- Recherche de travailleurs qualifiés
- Système de favoris
- Paiements sécurisés (simulation)
- Évaluation des travailleurs

### 👨‍💼 Espace Admin
- Validation des profils (CIN, ICE, diplômes)
- Tableau de bord avec analytics
- Gestion des missions et utilisateurs
- Système de modération (avertissements, sanctions)
- Résolution de litiges
- Statistiques en temps réel

### 🌍 Fonctionnalités transverses
- Système de régions marocaines (12 régions)
- Calcul de distance automatique
- Notifications en temps réel
- Recherche avancée avec filtres multiples
- Mode sombre (à venir)
- Interface responsive (mobile, tablet, desktop)
- Multilingue FR/AR (à venir)

---

## 🛠️ Technologies

### Core
- **[React 18.3.1](https://react.dev/)** - Bibliothèque UI
- **[Vite 5.0.0](https://vitejs.dev/)** - Build tool ultra-rapide
- **[React Router 6.21.0](https://reactrouter.com/)** - Routing côté client

### State Management
- **[Zustand 4.4.7](https://github.com/pmndrs/zustand)** - State management léger
- **[React Query 5.15.0](https://tanstack.com/query/)** - Data fetching & caching

### UI & Styling
- **[TailwindCSS 3.4.0](https://tailwindcss.com/)** - Utility-first CSS
- **[Shadcn/ui](https://ui.shadcn.com/)** - Composants réutilisables
- **[Lucide React](https://lucide.dev/)** - Icônes modernes
- **[Framer Motion 10.18.0](https://www.framer.com/motion/)** - Animations

### Forms & Validation
- **[React Hook Form 7.49.0](https://react-hook-form.com/)** - Gestion formulaires
- **[Zod 3.22.4](https://zod.dev/)** - Validation TypeScript-first

### Utilities
- **[Axios 1.6.2](https://axios-http.com/)** - HTTP client
- **[Date-fns 3.0.0](https://date-fns.org/)** - Manipulation de dates
- **[React Hot Toast](https://react-hot-toast.com/)** - Notifications toast

---

## ⚡ Prérequis

Avant de commencer, assurez-vous d'avoir installé :

- **Node.js** >= 18.0.0 ([Télécharger](https://nodejs.org/))
- **npm** >= 9.0.0 ou **yarn** >= 1.22.0
- **Git** ([Télécharger](https://git-scm.com/))

Vérification :
```bash
node --version  # doit afficher v18.x.x ou supérieur
npm --version   # doit afficher 9.x.x ou supérieur
```

---

## 📦 Installation

### 1. Cloner le repository

```bash
git clone https://github.com/Elmouddenlhoussen/plateforme-travailleurs-sociaux.git  
cd plateforme-travailleurs-sociaux/frontend-tadamon
```

### 2. Installer les dépendances

**Avec npm :**
```bash
npm install
```

**Avec yarn :**
```bash
yarn install
```

### 3. Configuration de l'environnement

Créer un fichier `.env` à la racine du dossier frontend :

```bash
cp .env.example .env
```

Éditer le fichier `.env` avec vos configurations :

```env
# API Backend
VITE_API_URL=http://localhost:5000/api

# Environment
VITE_ENV=development

# App Info
VITE_APP_NAME=TADAMON
VITE_APP_VERSION=1.0.0

# Features Flags (optionnel)
VITE_ENABLE_DARK_MODE=false
VITE_ENABLE_ANALYTICS=false
```

### 4. Démarrer le serveur de développement

```bash
npm run dev
```

L'application sera accessible sur **http://localhost:5173**

---

## 🔧 Configuration

### Variables d'environnement

| Variable | Description | Valeur par défaut |
|----------|-------------|-------------------|
| `VITE_API_URL` | URL de l'API backend | `http://localhost:5000/api` |
| `VITE_ENV` | Environnement (dev/prod) | `development` |
| `VITE_APP_NAME` | Nom de l'application | `TADAMON` |
| `VITE_ENABLE_DARK_MODE` | Activer le mode sombre | `false` |

### TailwindCSS

Configuration personnalisée dans `tailwind.config.js` :

```javascript
export default {
  theme: {
    extend: {
      colors: {
        primary: { /* ... */ },
        secondary: { /* ... */ },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
}
```

---

## 🚀 Utilisation

### Développement

```bash
# Lancer le serveur de développement
npm run dev

# Lancer avec host exposé (accessible depuis réseau local)
npm run dev -- --host

# Lancer sur un port spécifique
npm run dev -- --port 3000
```

### Build de production

```bash
# Créer un build optimisé
npm run build

# Prévisualiser le build
npm run preview
```

### Linting & Formatting

```bash
# Vérifier le code
npm run lint

# Corriger automatiquement
npm run lint:fix

# Formater avec Prettier
npm run format
```

---

## 📁 Structure du projet

```
frontend/
├── public/                    # Assets statiques
│   ├── logo.svg
│   └── favicon.ico
│
├── src/
│   ├── assets/               # Images, fonts, etc.
│   │   ├── images/
│   │   └── icons/
│   │
│   ├── components/           # Composants React
│   │   ├── common/          # Composants réutilisables
│   │   │   ├── Button.jsx
│   │   │   ├── Input.jsx
│   │   │   ├── Card.jsx
│   │   │   ├── Modal.jsx
│   │   │   └── ...
│   │   │
│   │   ├── layout/          # Layout & structure
│   │   │   ├── Header.jsx
│   │   │   ├── Sidebar.jsx
│   │   │   ├── Footer.jsx
│   │   │   └── DashboardLayout.jsx
│   │   │
│   │   ├── auth/            # Composants authentification
│   │   ├── worker/          # Composants travailleurs
│   │   ├── establishment/   # Composants établissements
│   │   └── admin/           # Composants admin
│   │
│   ├── pages/               # Pages de l'application
│   │   ├── Home.jsx
│   │   ├── Login.jsx
│   │   ├── Register.jsx
│   │   ├── worker/
│   │   ├── establishment/
│   │   └── admin/
│   │
│   ├── services/            # Services API
│   │   ├── api.js          # Configuration Axios
│   │   ├── authService.js
│   │   ├── workerService.js
│   │   └── ...
│   │
│   ├── store/               # State management (Zustand)
│   │   ├── authStore.js
│   │   └── notificationStore.js
│   │
│   ├── hooks/               # Custom React hooks
│   │   ├── useAuth.js
│   │   ├── useDebounce.js
│   │   └── ...
│   │
│   ├── utils/               # Fonctions utilitaires
│   │   ├── constants.js
│   │   ├── formatters.js
│   │   └── validators.js
│   │
│   ├── App.jsx              # Composant racine
│   ├── main.jsx             # Point d'entrée
│   └── index.css            # Styles globaux
│
├── .env                      # Variables d'environnement
├── .env.example             # Exemple de configuration
├── .gitignore               # Fichiers ignorés par Git
├── index.html               # Template HTML
├── package.json             # Dépendances npm
├── postcss.config.js        # Configuration PostCSS
├── tailwind.config.js       # Configuration Tailwind
├── vite.config.js           # Configuration Vite
└── README.md                # Ce fichier
```

---

## 🏗️ Architecture

### Flux de données

```
User Interaction
      ↓
  Component
      ↓
   Event Handler
      ↓
Service (API Call) → Zustand Store
      ↓                    ↓
  Response            State Update
      ↓                    ↓
  Component Re-render ← ───┘
```

### Pattern de composants

Nous utilisons le pattern **Container/Presenter** :

```jsx
// Container Component (logique)
function MissionListContainer() {
  const { missions, loading } = useMissions();
  return <MissionList missions={missions} loading={loading} />;
}

// Presenter Component (affichage)
function MissionList({ missions, loading }) {
  if (loading) return <Spinner />;
  return missions.map(mission => <MissionCard key={mission.id} {...mission} />);
}
```

---

## 🧩 Composants clés

### Button

Composant de bouton réutilisable avec variants.

```jsx
import Button from '@/components/common/Button';

<Button variant="primary" size="lg" onClick={handleClick}>
  Cliquez ici
</Button>
```

**Props :**
- `variant`: primary, secondary, danger, outline, ghost
- `size`: sm, md, lg
- `loading`: boolean
- `disabled`: boolean
- `icon`: Lucide React icon

### Input

Champ de formulaire avec validation intégrée.

```jsx
import Input from '@/components/common/Input';

<Input
  label="Email"
  type="email"
  name="email"
  value={email}
  onChange={handleChange}
  error={errors.email}
  icon={Mail}
  required
/>
```

### Card

Conteneur de contenu stylisé.

```jsx
import Card from '@/components/common/Card';

<Card
  title="Titre de la carte"
  subtitle="Sous-titre"
  footer={<Button>Action</Button>}
>
  Contenu de la carte
</Card>
```

### Modal

Boîte de dialogue modale.

```jsx
import Modal from '@/components/common/Modal';

<Modal
  isOpen={isOpen}
  onClose={handleClose}
  title="Titre du modal"
  size="md"
>
  Contenu du modal
</Modal>
```

---

## 🗄️ État global

Nous utilisons **Zustand** pour la gestion d'état globale.

### Auth Store

```javascript
import { useAuthStore } from '@/store/authStore';

function Component() {
  const { user, login, logout, isAuthenticated } = useAuthStore();
  
  return (
    <div>
      {isAuthenticated ? (
        <p>Bienvenue {user.email}</p>
      ) : (
        <button onClick={() => login(email, password)}>Connexion</button>
      )}
    </div>
  );
}
```

### Création d'un store

```javascript
import { create } from 'zustand';

export const useMyStore = create((set) => ({
  data: [],
  loading: false,
  
  fetchData: async () => {
    set({ loading: true });
    const data = await api.get('/data');
    set({ data, loading: false });
  },
}));
```

---

## 🔌 API Integration

### Configuration de base (api.js)

```javascript
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: 10000,
});

// Intercepteur pour ajouter le token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
```

### Services

```javascript
// authService.js
import api from './api';

export const authService = {
  login: (email, password) => 
    api.post('/auth/login', { email, password }),
  
  register: (data) => 
    api.post('/auth/register', data),
  
  logout: () => {
    localStorage.removeItem('token');
  },
};
```

### Utilisation dans un composant

```jsx
import { authService } from '@/services/authService';

async function handleLogin() {
  try {
    const response = await authService.login(email, password);
    // Traiter la réponse
  } catch (error) {
    console.error(error);
  }
}
```

---

## 🎨 Styling

### TailwindCSS

Nous utilisons TailwindCSS avec des classes utilitaires :

```jsx
<div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-md">
  <h2 className="text-2xl font-bold text-gray-900">Titre</h2>
  <Button className="bg-primary-600 hover:bg-primary-700">Action</Button>
</div>
```

### Classes personnalisées

Définies dans `index.css` :

```css
@layer components {
  .btn-primary {
    @apply bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors;
  }
  
  .input-field {
    @apply w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500;
  }
}
```

### Animations

Avec Framer Motion :

```jsx
import { motion } from 'framer-motion';

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.5 }}
>
  Contenu animé
</motion.div>
```

---

## 🧪 Tests

### Tests unitaires

```bash
npm run test
```

### Tests E2E

```bash
npm run test:e2e
```

### Coverage

```bash
npm run test:coverage
```

---

## 🚢 Déploiement

### Vercel (Recommandé)

```bash
# Installer Vercel CLI
npm install -g vercel

# Déployer
vercel

# Déployer en production
vercel --prod
```

### Netlify

```bash
# Build
npm run build

# Le dossier dist/ est prêt à être déployé
```

### Configuration Nginx (VPS)

```nginx
server {
    listen 80;
    server_name votre-domaine.com;
    root /var/www/lkhedma-social/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## ⚡ Performances

### Optimisations appliquées

- ✅ Code splitting automatique (Vite)
- ✅ Lazy loading des routes
- ✅ Optimisation des images
- ✅ Minification CSS/JS
- ✅ Tree shaking
- ✅ Compression Gzip

### Scores Lighthouse

| Métrique | Score |
|----------|-------|
| Performance | 95+ |
| Accessibility | 90+ |
| Best Practices | 100 |
| SEO | 90+ |

---

## ♿ Accessibilité

Nous respectons les standards **WCAG 2.1 AA** :

- ✅ Contraste des couleurs suffisant
- ✅ Navigation au clavier
- ✅ Labels ARIA appropriés
- ✅ Textes alternatifs pour les images
- ✅ Focus visible

---

## 🌐 Navigateurs supportés

| Navigateur | Version minimale |
|------------|------------------|
| Chrome | 90+ |
| Firefox | 88+ |
| Safari | 14+ |
| Edge | 90+ |

---

## 🤝 Contribution

Les contributions sont les bienvenues ! Voici comment contribuer :

1. Fork le projet
2. Créer une branche (`git checkout -b feature/AmazingFeature`)
3. Commit vos changements (`git commit -m 'Add AmazingFeature'`)
4. Push sur la branche (`git push origin feature/AmazingFeature`)
5. Ouvrir une Pull Request

### Conventions de code

- Utiliser ESLint et Prettier
- Commenter le code complexe
- Écrire des commits descriptifs
- Suivre la structure existante

---

## 👥 Équipe

- **[ELMOUDDEN LHOUSSAINE]** - Leader & Full Stack Developer - [@github](https://github.com/Elmouddenlhoussen)
- **[BENSASSI AYOUB]** - UI/UX Designer & Frontend Developer - [@github](https://github.com/Ayoubbensassi)
- **[MOHAMMED BERGHOUT]** - Full Stack Developer - [@github](https://github.com/MohmadBERGHOUT)
- **[RAISS SAID]** - Frontend Developer - [@github](https://github.com/saiddesu)

---

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

## 📞 Contact

**TADAMON** - [@TADAMON](https://twitter.com/TADAMON)

Email : contact@TADAMON.ma

Site web : [https://tadamon.ma](https://tadamon.ma)

---

## 🙏 Remerciements

- [React](https://react.dev/) - La bibliothèque UI
- [Vite](https://vitejs.dev/) - Le build tool ultra-rapide
- [TailwindCSS](https://tailwindcss.com/) - Le framework CSS
- [Shadcn/ui](https://ui.shadcn.com/) - Les composants
- [Lucide](https://lucide.dev/) - Les icônes
- Nos professeurs et encadrants
- La communauté open-source

---

<div align="center">

**Fait avec ❤️ par l'équipe TADAMON**

[⬆ Retour en haut](#-tadamon---frontend)

</div>