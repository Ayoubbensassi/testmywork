// API Configuration and Services
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// French error messages for common errors
const ERROR_MESSAGES: Record<string, string> = {
  'NETWORK_ERROR': 'Impossible de se connecter au serveur. Vérifiez votre connexion internet.',
  'INVALID_CREDENTIALS': 'Email ou mot de passe incorrect',
  'EMAIL_EXISTS': 'Cet email est déjà utilisé',
  'ACCOUNT_DISABLED': 'Votre compte a été désactivé',
  'TOKEN_EXPIRED': 'Votre session a expiré. Veuillez vous reconnecter.',
  'UNAUTHORIZED': 'Vous devez être connecté pour accéder à cette ressource',
  'FORBIDDEN': 'Vous n\'avez pas les droits pour effectuer cette action',
  'NOT_FOUND': 'Ressource non trouvée',
  'SERVER_ERROR': 'Une erreur serveur est survenue. Veuillez réessayer.',
  'WEAK_PASSWORD': 'Le mot de passe doit contenir au moins 8 caractères, une majuscule et un chiffre',
};

// Parse error message to get French translation
function translateError(message: string, status: number): string {
  const lowerMsg = message.toLowerCase();
  
  if (status === 401) {
    if (lowerMsg.includes('email') || lowerMsg.includes('mot de passe') || lowerMsg.includes('incorrect')) {
      return ERROR_MESSAGES['INVALID_CREDENTIALS'];
    }
    return ERROR_MESSAGES['UNAUTHORIZED'];
  }
  if (status === 403) return ERROR_MESSAGES['FORBIDDEN'];
  if (status === 404) return ERROR_MESSAGES['NOT_FOUND'];
  if (status >= 500) return ERROR_MESSAGES['SERVER_ERROR'];
  
  if (lowerMsg.includes('email deja') || lowerMsg.includes('email already')) return ERROR_MESSAGES['EMAIL_EXISTS'];
  if (lowerMsg.includes('desactive') || lowerMsg.includes('disabled')) return ERROR_MESSAGES['ACCOUNT_DISABLED'];
  if (lowerMsg.includes('8 char') || lowerMsg.includes('majuscule')) return ERROR_MESSAGES['WEAK_PASSWORD'];
  if (lowerMsg.includes('token') && lowerMsg.includes('expire')) return ERROR_MESSAGES['TOKEN_EXPIRED'];
  
  return message;
}

// Helper function for API requests with enhanced error handling
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = localStorage.getItem('token');
  
  const config: RequestInit = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    
    // Handle non-JSON responses
    const contentType = response.headers.get('content-type');
    let data;
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      const text = await response.text();
      data = { message: text || 'Réponse invalide du serveur' };
    }

    if (!response.ok || data.status === 'error') {
      const errorMessage = translateError(data.message || 'Une erreur est survenue', response.status);
      const error = new Error(errorMessage);
      (error as any).status = response.status;
      (error as any).code = data.code;
      throw error;
    }

    // Return the data property if it exists, otherwise return the whole response
    return data.data || data;
  } catch (error: any) {
    // Handle network errors
    if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
      const networkError = new Error(ERROR_MESSAGES['NETWORK_ERROR']);
      (networkError as any).code = 'NETWORK_ERROR';
      (networkError as any).status = 0;
      throw networkError;
    }
    
    throw error;
  }
}

// Auth API
export const authAPI = {
  login: (email: string, password: string) =>
    apiRequest<{ token: string; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  signup: (userData: {
    email: string;
    password: string;
    role: string;
  }) =>
    apiRequest<{ userId: number; email: string; role: string; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    }),

  getProfile: () =>
    apiRequest<{ user: any }>('/auth/me'),

  updateProfile: (userData: any) =>
    apiRequest<{ message: string; user: any }>('/auth/me', {
      method: 'PUT',
      body: JSON.stringify(userData),
    }),
};

// Missions API
export const missionsAPI = {
  getAll: (params?: { region_id?: number; city_id?: number; mission_type?: string; page?: number; limit?: number }) => {
    const queryString = params
      ? '?' + new URLSearchParams(params as any).toString()
      : '';
    return apiRequest<{ missions: any[]; pagination?: any }>(`/missions${queryString}`);
  },

  search: (params: { q?: string; region_id?: number; mission_type?: string }) => {
    const queryString = '?' + new URLSearchParams(params as any).toString();
    return apiRequest<{ missions: any[] }>(`/missions/search${queryString}`);
  },

  getById: (id: number) =>
    apiRequest<{ mission: any }>(`/missions/${id}`),

  create: (missionData: any) =>
    apiRequest<{ message: string; missionId: number }>('/missions', {
      method: 'POST',
      body: JSON.stringify(missionData),
    }),

  update: (id: number, missionData: any) =>
    apiRequest<{ message: string }>(`/missions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(missionData),
    }),

  delete: (id: number) =>
    apiRequest<{ message: string }>(`/missions/${id}`, {
      method: 'DELETE',
    }),

  getMyMissions: () =>
    apiRequest<{ missions: any[] }>('/missions/my'),
};

// Donations API
export const donationsAPI = {
  create: (donationData: {
    campaignId?: number;
    amount: number;
    donationType: string;
    isAnonymous?: boolean;
    message?: string;
  }) =>
    apiRequest<{ message: string; donationId: number }>('/donations', {
      method: 'POST',
      body: JSON.stringify(donationData),
    }),

  getMyDonations: () =>
    apiRequest<{ donations: any[] }>('/donations/my-donations'),

  getById: (id: number) =>
    apiRequest<{ donation: any }>(`/donations/${id}`),
};

// Campaigns API
export const campaignsAPI = {
  getAll: (params?: { category?: string; status?: string; page?: number; limit?: number }) => {
    const queryString = params
      ? '?' + new URLSearchParams(params as any).toString()
      : '';
    return apiRequest<{ campaigns: any[]; pagination: any }>(`/campaigns${queryString}`);
  },

  getById: (id: number) =>
    apiRequest<{ campaign: any }>(`/campaigns/${id}`),

  getFeatured: () =>
    apiRequest<{ campaigns: any[] }>('/campaigns/featured'),

  getCategories: () =>
    apiRequest<{ categories: any[] }>('/campaigns/categories'),
};

// Volunteer API
export const volunteerAPI = {
  getOpportunities: (params?: { category?: string; location?: string }) => {
    const queryString = params
      ? '?' + new URLSearchParams(params as any).toString()
      : '';
    return apiRequest<{ opportunities: any[] }>(`/volunteer/opportunities${queryString}`);
  },

  apply: (opportunityId: number, applicationData: { message?: string; availability?: string }) =>
    apiRequest<{ message: string }>(`/volunteer/opportunities/${opportunityId}/apply`, {
      method: 'POST',
      body: JSON.stringify(applicationData),
    }),

  getMyApplications: () =>
    apiRequest<{ applications: any[] }>('/volunteer/my-applications'),
};

// Contact API
export const contactAPI = {
  submit: (contactData: {
    name: string;
    email: string;
    userType: 'worker' | 'establishment' | 'other';
    subject: string;
    message: string;
  }) =>
    apiRequest<{ message: string }>('/contact', {
      method: 'POST',
      body: JSON.stringify(contactData),
    }),
};

// Applications API
export const applicationsAPI = {
  apply: (applicationData: { mission_id: number; cover_letter?: string; proposed_rate?: number }) =>
    apiRequest<{ message: string; applicationId: number }>('/applications', {
      method: 'POST',
      body: JSON.stringify(applicationData),
    }),

  getMyApplications: () =>
    apiRequest<{ applications: any[] }>('/applications/my'),

  getReceivedApplications: () =>
    apiRequest<{ applications: any[] }>('/applications/received'),

  getMissionApplications: (missionId: number) =>
    apiRequest<{ applications: any[] }>(`/applications/mission/${missionId}`),

  accept: (id: number) =>
    apiRequest<{ message: string }>(`/applications/${id}/accept`, {
      method: 'PATCH',
    }),

  reject: (id: number) =>
    apiRequest<{ message: string }>(`/applications/${id}/reject`, {
      method: 'PATCH',
    }),

  withdraw: (id: number) =>
    apiRequest<{ message: string }>(`/applications/${id}`, {
      method: 'DELETE',
    }),
};

// Regions API
export const regionsAPI = {
  getAll: () =>
    apiRequest<{ regions: any[] }>('/regions'),

  getCities: (regionId: number) =>
    apiRequest<{ cities: any[] }>(`/regions/${regionId}/cities`),

  getAllCities: () =>
    apiRequest<{ cities: any[] }>('/cities'),

  getSpecialties: () =>
    apiRequest<{ specialties: any[] }>('/specialties'),
};

// Worker Profile API
export const workerAPI = {
  createProfile: (profileData: any) =>
    apiRequest<{ message: string; profileId: number }>('/workers/profile', {
      method: 'POST',
      body: JSON.stringify(profileData),
    }),

  getMyProfile: () =>
    apiRequest<{ profile: any }>('/workers/profile'),

  updateProfile: (profileData: any) =>
    apiRequest<{ message: string }>('/workers/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    }),

  uploadDocuments: async (formData: FormData) => {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/workers/profile/documents`, {
      method: 'POST',
      headers: {
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: formData,
    });
    const data = await response.json();
    if (!response.ok || data.status === 'error') {
      throw new Error(data.message || 'Upload failed');
    }
    return data.data || data;
  },

  getPublicProfile: (id: number) =>
    apiRequest<{ profile: any }>(`/workers/profile/${id}`),

  addSpecialty: (specialtyData: { specialty_id: number; years_experience?: number }) =>
    apiRequest<{ message: string }>('/workers/specialties', {
      method: 'POST',
      body: JSON.stringify(specialtyData),
    }),
};

// Establishment Profile API
export const establishmentAPI = {
  createProfile: (profileData: any) =>
    apiRequest<{ message: string; profileId: number }>('/establishments/profile', {
      method: 'POST',
      body: JSON.stringify(profileData),
    }),

  getMyProfile: () =>
    apiRequest<{ profile: any }>('/establishments/profile'),

  updateProfile: (profileData: any) =>
    apiRequest<{ message: string }>('/establishments/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    }),

  uploadDocuments: async (formData: FormData) => {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/establishments/profile/documents`, {
      method: 'POST',
      headers: {
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: formData,
    });
    const data = await response.json();
    if (!response.ok || data.status === 'error') {
      throw new Error(data.message || 'Upload failed');
    }
    return data.data || data;
  },

  uploadLogo: async (formData: FormData) => {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/establishments/profile/logo`, {
      method: 'POST',
      headers: {
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: formData,
    });
    const data = await response.json();
    if (!response.ok || data.status === 'error') {
      throw new Error(data.message || 'Upload failed');
    }
    return data.data || data;
  },

  getPublicProfile: (id: number) =>
    apiRequest<{ profile: any }>(`/establishments/profile/${id}`),
};

export default {
  auth: authAPI,
  missions: missionsAPI,
  applications: applicationsAPI,
  regions: regionsAPI,
  worker: workerAPI,
  establishment: establishmentAPI,
  donations: donationsAPI,
  campaigns: campaignsAPI,
  volunteer: volunteerAPI,
  contact: contactAPI,
};
