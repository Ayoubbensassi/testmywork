import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authAPI } from './src/api';

interface User {
  id: number;
  email: string;
  role: string;
  firstName?: string;
  lastName?: string;
  is_verified?: boolean;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  error: string | null;
  isLoginModalOpen: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (userData: SignupData) => Promise<boolean>;
  logout: () => void;
  clearError: () => void;
  openLoginModal: () => void;
  closeLoginModal: () => void;
}

interface SignupData {
  email: string;
  password: string;
  role: 'worker' | 'establishment';
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);

  // Check for existing token on mount only
  useEffect(() => {
    let isMounted = true;
    
    const checkAuth = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const response = await authAPI.getProfile();
          if (isMounted) {
            setUser(response.user);
          }
        } catch (err) {
          localStorage.removeItem('token');
        }
      }
      if (isMounted) {
        setIsLoading(false);
      }
    };
    
    checkAuth();
    
    return () => {
      isMounted = false;
    };
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await authAPI.login(email, password);
      localStorage.setItem('token', response.token);
      setUser(response.user);
      setIsLoading(false);
      return true;
    } catch (err: any) {
      const errorMessage = err.message || 'Email ou mot de passe incorrect';
      setError(errorMessage);
      setIsLoading(false);
      // Don't clear error automatically - let it persist
      return false;
    }
  };

  const signup = async (userData: SignupData): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await authAPI.signup(userData);
      // Registration returns token directly
      localStorage.setItem('token', response.token);
      // Fetch full user profile
      const profileResponse = await authAPI.getProfile();
      setUser(profileResponse.user);
      setIsLoading(false);
      return true;
    } catch (err: any) {
      setError(err.message || "Échec de l'inscription");
      setIsLoading(false);
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider value={{ user, isLoading, error, isLoginModalOpen, login, signup, logout, clearError, openLoginModal, closeLoginModal }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
