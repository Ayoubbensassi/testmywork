import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Sectors from './components/Sectors';
import Advantages from './components/Advantages';
import Testimonials from './components/Testimonials';
import Pricing from './components/Pricing';
import Process from './components/Process';
import Contact from './components/Contact';
import Missions from './components/Missions';
import CTA from './components/CTA';
import Footer from './components/Footer';
import Login from './components/Login';
import Signup from './components/Signup';
import LoginModal from './components/LoginModal';
import WorkerOnboarding from './components/onboarding/WorkerOnboarding';
import EstablishmentOnboarding from './components/onboarding/EstablishmentOnboarding';
import WorkerDashboard from './components/dashboard/WorkerDashboard';
import EstablishmentDashboard from './components/dashboard/EstablishmentDashboard';
import AdminDashboard from './components/dashboard/AdminDashboard';
import ForgotPassword from './components/ForgotPassword';
import { AuthProvider, useAuth } from './AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './components/common/Toast';
import ErrorBoundary from './components/common/ErrorBoundary';
import NotFoundPage from './components/common/NotFoundPage';
import AccessDenied from './components/common/AccessDenied';
import SessionExpiredModal from './components/common/SessionExpiredModal';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
};

// Protected Route Component
const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode; allowedRoles?: string[] }) => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-900"><div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div></div>;
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <AccessDenied message="Vous n'avez pas les droits pour accéder à cette page." />;
  }
  
  return <>{children}</>;
};

const AppContent = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const hiddenNavbarPaths = ['/login', '/signup', '/forgot-password', '/onboarding/worker', '/onboarding/establishment', '/worker/dashboard', '/establishment/dashboard', '/admin/dashboard'];
  const isHiddenNavbar = hiddenNavbarPaths.some(p => location.pathname.startsWith(p));

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {!isHiddenNavbar && <Navbar isScrolled={isScrolled} />}
      <main className={isHiddenNavbar ? "" : "flex-grow"}>
        <Routes>
          {/* Public Pages */}
          <Route path="/" element={<><Hero /><Features /><Sectors /><Advantages /><Testimonials /><CTA /></>} />
          <Route path="/missions" element={<Missions />} />
          <Route path="/process" element={<div className="pt-20"><Process /><CTA /></div>} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />

          {/* Onboarding Routes */}
          <Route path="/onboarding/worker" element={<ProtectedRoute allowedRoles={['worker']}><WorkerOnboarding /></ProtectedRoute>} />
          <Route path="/onboarding/establishment" element={<ProtectedRoute allowedRoles={['establishment']}><EstablishmentOnboarding /></ProtectedRoute>} />

          {/* Dashboard Routes */}
          <Route path="/worker/dashboard" element={<ProtectedRoute allowedRoles={['worker']}><WorkerDashboard /></ProtectedRoute>} />
          <Route path="/establishment/dashboard" element={<ProtectedRoute allowedRoles={['establishment']}><EstablishmentDashboard /></ProtectedRoute>} />
          <Route path="/admin/dashboard" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />

          {/* Fallback - 404 Page */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      {!isHiddenNavbar && <Footer />}
    </div>
  );
};

// React Query Client Configuration
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime in v4)
    },
  },
});

const App = () => {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <ThemeProvider>
            <ToastProvider>
              <HashRouter>
                <ScrollToTop />
                <AppContent />
                <LoginModal />
                <SessionExpiredModal />
              </HashRouter>
            </ToastProvider>
          </ThemeProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

export default App;
