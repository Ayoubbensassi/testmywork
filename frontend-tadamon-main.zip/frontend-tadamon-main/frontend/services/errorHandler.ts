// Error Handler Service - Centralized error management with French messages

export interface ApiError {
  message: string;
  code: string;
  status: number;
  details?: any;
}

// French error messages mapping
const ERROR_MESSAGES: Record<string, string> = {
  // Authentication errors
  'INVALID_CREDENTIALS': 'Email ou mot de passe incorrect',
  'EMAIL_NOT_FOUND': 'Aucun compte associé à cet email',
  'WRONG_PASSWORD': 'Mot de passe incorrect',
  'ACCOUNT_DISABLED': 'Votre compte a été désactivé. Contactez le support.',
  'ACCOUNT_NOT_VERIFIED': 'Veuillez vérifier votre email avant de vous connecter',
  'TOKEN_EXPIRED': 'Votre session a expiré. Veuillez vous reconnecter.',
  'TOKEN_INVALID': 'Session invalide. Veuillez vous reconnecter.',
  'UNAUTHORIZED': 'Vous devez être connecté pour accéder à cette ressource',
  'FORBIDDEN': 'Vous n\'avez pas les droits pour effectuer cette action',
  
  // Registration errors
  'EMAIL_EXISTS': 'Cet email est déjà utilisé',
  'INVALID_EMAIL': 'Format d\'email invalide',
  'WEAK_PASSWORD': 'Le mot de passe doit contenir au moins 8 caractères, une majuscule et un chiffre',
  'INVALID_ROLE': 'Rôle invalide',
  
  // Profile errors
  'PROFILE_NOT_FOUND': 'Profil non trouvé',
  'PROFILE_INCOMPLETE': 'Veuillez compléter votre profil',
  'PROFILE_PENDING': 'Votre profil est en attente de validation',
  
  // Mission errors
  'MISSION_NOT_FOUND': 'Mission non trouvée',
  'MISSION_CLOSED': 'Cette mission n\'est plus disponible',
  'ALREADY_APPLIED': 'Vous avez déjà postulé à cette mission',
  'APPLICATION_NOT_FOUND': 'Candidature non trouvée',
  
  // Network errors
  'NETWORK_ERROR': 'Impossible de se connecter au serveur. Vérifiez votre connexion internet.',
  'TIMEOUT': 'La requête a pris trop de temps. Veuillez réessayer.',
  'SERVER_ERROR': 'Une erreur serveur est survenue. Veuillez réessayer plus tard.',
  
  // Validation errors
  'VALIDATION_ERROR': 'Données invalides. Vérifiez les champs du formulaire.',
  'REQUIRED_FIELD': 'Ce champ est obligatoire',
  'INVALID_FORMAT': 'Format invalide',
  
  // File upload errors
  'FILE_TOO_LARGE': 'Le fichier est trop volumineux (max 5 Mo)',
  'INVALID_FILE_TYPE': 'Type de fichier non autorisé',
  'UPLOAD_FAILED': 'Échec du téléchargement du fichier',
  
  // Generic errors
  'UNKNOWN_ERROR': 'Une erreur inattendue est survenue',
  'NOT_FOUND': 'Ressource non trouvée',
  'BAD_REQUEST': 'Requête invalide',
};

// HTTP status to error code mapping
const STATUS_TO_CODE: Record<number, string> = {
  400: 'BAD_REQUEST',
  401: 'UNAUTHORIZED',
  403: 'FORBIDDEN',
  404: 'NOT_FOUND',
  408: 'TIMEOUT',
  409: 'EMAIL_EXISTS',
  422: 'VALIDATION_ERROR',
  429: 'TOO_MANY_REQUESTS',
  500: 'SERVER_ERROR',
  502: 'SERVER_ERROR',
  503: 'SERVER_ERROR',
};

// Parse backend error message to get error code
function parseErrorCode(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('email') && lowerMessage.includes('incorrect')) return 'INVALID_CREDENTIALS';
  if (lowerMessage.includes('mot de passe') && lowerMessage.includes('incorrect')) return 'INVALID_CREDENTIALS';
  if (lowerMessage.includes('email ou mot de passe')) return 'INVALID_CREDENTIALS';
  if (lowerMessage.includes('email deja utilise') || lowerMessage.includes('email already')) return 'EMAIL_EXISTS';
  if (lowerMessage.includes('compte desactive') || lowerMessage.includes('account disabled')) return 'ACCOUNT_DISABLED';
  if (lowerMessage.includes('token') && lowerMessage.includes('expire')) return 'TOKEN_EXPIRED';
  if (lowerMessage.includes('token') && lowerMessage.includes('invalid')) return 'TOKEN_INVALID';
  if (lowerMessage.includes('non trouve') || lowerMessage.includes('not found')) return 'NOT_FOUND';
  if (lowerMessage.includes('deja postule') || lowerMessage.includes('already applied')) return 'ALREADY_APPLIED';
  if (lowerMessage.includes('8 char') || lowerMessage.includes('majuscule')) return 'WEAK_PASSWORD';
  if (lowerMessage.includes('format email')) return 'INVALID_EMAIL';
  
  return 'UNKNOWN_ERROR';
}

// Main error handler function
export function handleApiError(error: any): ApiError {
  // Network error (no response)
  if (!error.response && error.message === 'Failed to fetch') {
    return {
      message: ERROR_MESSAGES['NETWORK_ERROR'],
      code: 'NETWORK_ERROR',
      status: 0,
    };
  }

  // Timeout error
  if (error.name === 'AbortError' || error.message?.includes('timeout')) {
    return {
      message: ERROR_MESSAGES['TIMEOUT'],
      code: 'TIMEOUT',
      status: 408,
    };
  }

  // API error with response
  if (error.response) {
    const { status, data } = error.response;
    const backendMessage = data?.message || '';
    
    // Try to get specific error code from backend message
    let code = parseErrorCode(backendMessage);
    
    // Fallback to status-based code
    if (code === 'UNKNOWN_ERROR' && STATUS_TO_CODE[status]) {
      code = STATUS_TO_CODE[status];
    }

    // Special handling for 401 on login
    if (status === 401 && backendMessage) {
      code = 'INVALID_CREDENTIALS';
    }

    return {
      message: ERROR_MESSAGES[code] || backendMessage || ERROR_MESSAGES['UNKNOWN_ERROR'],
      code,
      status,
      details: data,
    };
  }

  // Generic error
  return {
    message: error.message || ERROR_MESSAGES['UNKNOWN_ERROR'],
    code: 'UNKNOWN_ERROR',
    status: 500,
  };
}

// Check if error is a network error
export function isNetworkError(error: ApiError): boolean {
  return error.code === 'NETWORK_ERROR' || error.status === 0;
}

// Check if error requires re-authentication
export function isAuthError(error: ApiError): boolean {
  return ['TOKEN_EXPIRED', 'TOKEN_INVALID', 'UNAUTHORIZED'].includes(error.code);
}

// Get user-friendly error message
export function getErrorMessage(error: any): string {
  if (typeof error === 'string') return error;
  
  const apiError = handleApiError(error);
  return apiError.message;
}

export default {
  handleApiError,
  isNetworkError,
  isAuthError,
  getErrorMessage,
  ERROR_MESSAGES,
};
