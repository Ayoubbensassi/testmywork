// API Services - Compatible with new dashboards
import { handleApiError, isAuthError, ApiError } from './errorHandler';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Custom error class with enhanced information
export class ApiRequestError extends Error {
  code: string;
  status: number;
  details?: any;

  constructor(apiError: ApiError) {
    super(apiError.message);
    this.name = 'ApiRequestError';
    this.code = apiError.code;
    this.status = apiError.status;
    this.details = apiError.details;
  }
}

// Helper function for API requests with enhanced error handling
async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('token');
  
  const config: RequestInit = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    
    // Handle non-JSON responses
    const contentType = response.headers.get('content-type');
    let data;
    
    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      const text = await response.text();
      data = { message: text || 'Réponse invalide du serveur' };
    }

    if (!response.ok || data.status === 'error') {
      const error: any = new Error(data.message || 'Une erreur est survenue');
      error.response = { data, status: response.status };
      const apiError = handleApiError(error);
      
      // Handle auth errors - redirect to login
      if (isAuthError(apiError) && !endpoint.includes('/auth/')) {
        localStorage.removeItem('token');
        window.dispatchEvent(new CustomEvent('auth:logout', { detail: { reason: apiError.code } }));
      }
      
      throw new ApiRequestError(apiError);
    }

    return data;
  } catch (error: any) {
    // Handle network errors
    if (error instanceof ApiRequestError) {
      throw error;
    }
    
    // Handle fetch errors (network issues)
    if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
      const apiError = handleApiError({ message: 'Failed to fetch' });
      throw new ApiRequestError(apiError);
    }
    
    // Handle other errors
    const apiError = handleApiError(error);
    throw new ApiRequestError(apiError);
  }
}

// Worker API
export const workerAPI = {
  getProfile: () => apiRequest<any>('/workers/profile'),
  createProfile: (data: any) => apiRequest<any>('/workers/profile', { method: 'POST', body: JSON.stringify(data) }),
  updateProfile: (data: any) => apiRequest<any>('/workers/profile', { method: 'PUT', body: JSON.stringify(data) }),
  searchWorkers: (params: any) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest<any>(`/workers/search?${query}`);
  },
  getPublicProfile: (id: number) => apiRequest<any>(`/workers/${id}`),
  uploadDocuments: async (formData: FormData) => {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/workers/profile/documents`, {
      method: 'POST',
      headers: { ...(token && { Authorization: `Bearer ${token}` }) },
      body: formData,
    });
    const data = await response.json();
    if (!response.ok || data.status === 'error') {
      throw new Error(data.message || 'Upload failed');
    }
    return data.data || data;
  },
};

// Mission API
export const missionAPI = {
  getMissions: (params?: any) => {
    const query = params ? '?' + new URLSearchParams(params).toString() : '';
    return apiRequest<any>(`/missions${query}`);
  },
  getMyMissions: () => apiRequest<any>('/missions/my'),
  getMission: (id: number) => apiRequest<any>(`/missions/${id}`),
  createMission: (data: any) => apiRequest<any>('/missions', { method: 'POST', body: JSON.stringify(data) }),
  updateMission: (id: number, data: any) => apiRequest<any>(`/missions/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteMission: (id: number) => apiRequest<any>(`/missions/${id}`, { method: 'DELETE' }),
  searchMissions: (params: any) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest<any>(`/missions/search?${query}`);
  },
};

// Application API
export const applicationAPI = {
  apply: (data: any) => apiRequest<any>('/applications', { method: 'POST', body: JSON.stringify(data) }),
  getMyApplications: () => apiRequest<any>('/applications/my'),
  getReceivedApplications: () => apiRequest<any>('/applications/received'),
  getMissionApplications: (missionId: number) => apiRequest<any>(`/applications/mission/${missionId}`),
  acceptApplication: (id: number) => apiRequest<any>(`/applications/${id}/accept`, { method: 'PATCH' }),
  rejectApplication: (id: number) => apiRequest<any>(`/applications/${id}/reject`, { method: 'PATCH' }),
  withdrawApplication: (id: number) => apiRequest<any>(`/applications/${id}`, { method: 'DELETE' }),
};

// Diploma API
export const diplomaAPI = {
  getMyDiplomas: () => apiRequest<any>('/diplomas/my'),
  addDiploma: (data: any) => apiRequest<any>('/diplomas', { method: 'POST', body: JSON.stringify(data) }),
  deleteDiploma: (id: number) => apiRequest<any>(`/diplomas/${id}`, { method: 'DELETE' }),
  uploadDiploma: async (formData: FormData) => {
    const token = localStorage.getItem('token');
    const response = await fetch(`${API_BASE_URL}/diplomas/upload`, {
      method: 'POST',
      headers: { ...(token && { Authorization: `Bearer ${token}` }) },
      body: formData,
    });
    return response.json();
  },
};

// Availability API
export const availabilityAPI = {
  getMyAvailabilities: (year?: number, month?: number) => {
    const params = year && month ? `?year=${year}&month=${month}` : '';
    return apiRequest<any>(`/availabilities/my${params}`);
  },
  setAvailability: (data: any) => apiRequest<any>('/availabilities', { method: 'POST', body: JSON.stringify(data) }),
  bulkSetAvailabilities: (availabilities: any[]) => apiRequest<any>('/availabilities/bulk', { method: 'POST', body: JSON.stringify({ availabilities }) }),
  updateAvailability: (id: number, data: any) => apiRequest<any>(`/availabilities/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteAvailability: (id: number) => apiRequest<any>(`/availabilities/${id}`, { method: 'DELETE' }),
};

// Region API
export const regionAPI = {
  getRegions: () => apiRequest<any>('/regions'),
  getCitiesByRegion: (regionId: number) => apiRequest<any>(`/regions/${regionId}/cities`),
  getAllCities: () => apiRequest<any>('/cities'),
  getSpecialties: () => apiRequest<any>('/specialties'),
};

// Establishment API
export const establishmentAPI = {
  getProfile: () => apiRequest<any>('/establishments/profile'),
  createProfile: (data: any) => apiRequest<any>('/establishments/profile', { method: 'POST', body: JSON.stringify(data) }),
  updateProfile: (data: any) => apiRequest<any>('/establishments/profile', { method: 'PUT', body: JSON.stringify(data) }),
};

// Admin API
export const adminAPI = {
  getDashboard: () => apiRequest<any>('/admin/dashboard'),
  getUsers: () => apiRequest<any>('/admin/users'),
  getPendingWorkers: () => apiRequest<any>('/admin/workers/pending'),
  getPendingEstablishments: () => apiRequest<any>('/admin/establishments/pending'),
  getPendingDiplomas: () => apiRequest<any>('/admin/diplomas/pending'),
  getAllApplications: (status?: string) => apiRequest<any>(`/admin/applications${status ? `?status=${status}` : ''}`),
  approveWorker: (id: number) => apiRequest<any>(`/admin/workers/${id}/approve`, { method: 'PATCH' }),
  rejectWorker: (id: number, reason: string) => apiRequest<any>(`/admin/workers/${id}/reject`, { method: 'PATCH', body: JSON.stringify({ reason }) }),
  approveEstablishment: (id: number) => apiRequest<any>(`/admin/establishments/${id}/approve`, { method: 'PATCH' }),
  rejectEstablishment: (id: number) => apiRequest<any>(`/admin/establishments/${id}/reject`, { method: 'PATCH' }),
  verifyDiploma: (id: number) => apiRequest<any>(`/admin/diplomas/${id}/verify`, { method: 'PATCH' }),
  grantLabel: (workerId: number) => apiRequest<any>(`/admin/workers/${workerId}/label`, { method: 'PATCH' }),
};

// Notification API
export const notificationAPI = {
  getNotifications: () => apiRequest<any>('/notifications'),
  markAsRead: (id: number) => apiRequest<any>(`/notifications/${id}/read`, { method: 'PATCH' }),
  markAllAsRead: () => apiRequest<any>('/notifications/read-all', { method: 'PATCH' }),
};

// Review API
export const reviewAPI = {
  createReview: (data: { mission_id: number; rating: number; comment?: string; is_public?: boolean }) =>
    apiRequest<any>('/reviews', { method: 'POST', body: JSON.stringify(data) }),
  getWorkerReviews: (workerId: number) => apiRequest<any>(`/reviews/worker/${workerId}`),
  getEstablishmentReviews: (establishmentId: number) => apiRequest<any>(`/reviews/establishment/${establishmentId}`),
  getMyReviews: () => apiRequest<any>('/reviews/my'),
};

// Stats API
export const statsAPI = {
  getPublicStats: () => apiRequest<any>('/stats/public'),
  getWorkerStats: () => apiRequest<any>('/stats/worker'),
  getEstablishmentStats: () => apiRequest<any>('/stats/establishment'),
};

// CV Analysis API
export const cvAPI = {
  analyzeCV: async (file: File) => {
    const token = localStorage.getItem('token');
    const formData = new FormData();
    formData.append('cv', file);
    
    const response = await fetch(`${API_BASE_URL}/cv/analyze`, {
      method: 'POST',
      headers: { ...(token && { Authorization: `Bearer ${token}` }) },
      body: formData,
    });
    
    const data = await response.json();
    if (!response.ok || data.status === 'error') {
      throw new Error(data.message || 'CV analysis failed');
    }
    return data;
  },
};

// Message API
export const messageAPI = {
  getConversations: () => apiRequest<any>('/messages/conversations'),
  getMessages: (conversationId: number) => apiRequest<any>(`/messages/conversations/${conversationId}`),
  sendMessage: (data: { conversation_id?: number; content: string; mission_id?: number; receiver_id?: number }) => 
    apiRequest<any>('/messages/send', { method: 'POST', body: JSON.stringify(data) }),
  markAsRead: (messageId: number) => 
    apiRequest<any>(`/messages/${messageId}/read`, { method: 'PATCH' }),
  startConversation: (data: { receiver_id: number; content: string; mission_id?: number }) =>
    apiRequest<any>('/messages/send', { method: 'POST', body: JSON.stringify(data) }),
};

export default {
  worker: workerAPI,
  mission: missionAPI,
  application: applicationAPI,
  diploma: diplomaAPI,
  availability: availabilityAPI,
  region: regionAPI,
  establishment: establishmentAPI,
  admin: adminAPI,
  notification: notificationAPI,
  message: messageAPI,
  review: reviewAPI,
  stats: statsAPI,
  cv: cvAPI,
};
