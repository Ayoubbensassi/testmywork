# 🤝 TADAMON

**Plateforme de Mise en Relation pour Travailleurs Sociaux au Maroc**

[![Node.js](https://img.shields.io/badge/Node.js-18+-green.svg)](https://nodejs.org/)
[![React](https://img.shields.io/badge/React-18-blue.svg)](https://reactjs.org/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0+-orange.svg)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

TADAMON connecte les **travailleurs sociaux indépendants** avec les **établissements** (associations, fondations, entreprises sociales) à travers tout le Maroc.

---

## 📋 Table des Matières

- [Fonctionnalités](#-fonctionnalités)
- [Architecture](#-architecture)
- [Prérequis](#-prérequis)
- [Installation](#-installation)
- [Configuration](#-configuration)
- [Démarrage](#-démarrage)
- [Comptes de Test](#-comptes-de-test)
- [Structure du Projet](#-structure-du-projet)
- [API Documentation](#-api-documentation)
- [Technologies](#-technologies)
- [Contribution](#-contribution)

---

## ✨ Fonctionnalités

### Pour les Travailleurs Sociaux
- 📝 Création de profil professionnel complet
- 📅 Gestion des disponibilités (calendrier)
- 🔍 Recherche et candidature aux missions
- 🎓 Upload et vérification des diplômes
- ⭐ Système de notation et avis
- 💬 Messagerie avec les établissements
- 🏅 Label Réseau TADAMON (certification qualité)

### Pour les Établissements
- 🏢 Profil établissement avec vérification ICE
- 📋 Publication de missions (ponctuelles, longue durée, remplacement)
- 👥 Recherche de travailleurs par compétences/disponibilité
- 📨 Gestion des candidatures reçues
- ⭐ Évaluation des travailleurs après mission

### Pour les Administrateurs
- 📊 Dashboard avec statistiques en temps réel
- ✅ Validation des profils (travailleurs & établissements)
- 🎓 Vérification des diplômes
- 🏅 Attribution du Label Réseau
- 👁️ Suivi des mises en relation

---

## 🏗 Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│    Frontend     │────▶│    Backend      │────▶│    MySQL        │
│    (React)      │     │    (Express)    │     │    Database     │
│    Port 5173    │     │    Port 5000    │     │    Port 3306    │
│                 │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                              │
                              ▼
                        ┌─────────────────┐
                        │   Socket.io     │
                        │   (Real-time)   │
                        └─────────────────┘
```

---

## 📦 Prérequis

Avant de commencer, assurez-vous d'avoir installé :

| Outil | Version | Vérification |
|-------|---------|--------------|
| Node.js | 18+ | `node --version` |
| npm | 9+ | `npm --version` |
| MySQL | 8.0+ | `mysql --version` |
| Git | 2.0+ | `git --version` |

---

## 🚀 Installation

### 1. Cloner le repository

```bash
git clone https://github.com/votre-username/tadamon.git
cd tadamon
```

### 2. Installer les dépendances Backend

```bash
cd backend
npm install
```

### 3. Installer les dépendances Frontend

```bash
cd ../frontend
npm install
```

---

## ⚙️ Configuration

### Backend (.env)

Créez le fichier `backend/.env.local` (prioritaire) ou `backend/.env` :

```env
# Base de données
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=votre_mot_de_passe
DB_NAME=tadamon_db
DB_PORT=3306

# JWT
JWT_SECRET=votre_secret_jwt_tres_long_et_securise
JWT_EXPIRES_IN=7d

# Serveur
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

# Email (optionnel - pour vérification email)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=votre_email@gmail.com
SMTP_PASS=votre_mot_de_passe_app

# Google OAuth (optionnel)
GOOGLE_CLIENT_ID=votre_client_id
GOOGLE_CLIENT_SECRET=votre_client_secret
```

### Base de données

```bash
# Créer la base de données
mysql -u root -p -e "CREATE DATABASE tadamon_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# Importer le schéma
mysql -u root -p tadamon_db < backend/database/schema.sql

# Importer les données de test (optionnel)
mysql -u root -p tadamon_db < backend/database/seed.sql

# Importer les régions/villes du Maroc
mysql -u root -p tadamon_db < backend/database/more_cities.sql
```

---

## 🎯 Démarrage

### Option 1 : Démarrage séparé (recommandé pour le développement)

**Terminal 1 - Backend :**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend :**
```bash
cd frontend
npm run dev
```

### Option 2 : Démarrage avec un seul terminal

```bash
# Depuis la racine du projet
cd backend && npm run dev &
cd frontend && npm run dev
```

### Accès aux applications

| Application | URL |
|-------------|-----|
| 🌐 Frontend | http://localhost:5173 |
| 🔌 API Backend | http://localhost:5000/api |
| 📚 Documentation API | http://localhost:5000/api-docs |
| 💚 Health Check | http://localhost:5000/api/health |

---

## 🔑 Comptes de Test

Après avoir exécuté `seed.sql`, utilisez ces comptes :

| Rôle | Email | Mot de passe | Dashboard |
|------|-------|--------------|-----------|
| 👷 Travailleur | `worker@test.com` | `password123` | `/worker/dashboard` |
| 🏢 Établissement | `establishment@test.com` | `password123` | `/establishment/dashboard` |
| 👑 Admin | `admin@lkhedma.ma` | `Admin123!` | `/admin/dashboard` |

---

## 📁 Structure du Projet

```
tadamon/
├── 📂 backend/                    # API Express.js
│   ├── 📂 database/
│   │   ├── migrations/           # Migrations SQL
│   │   ├── schema.sql            # Structure de la BDD
│   │   └── seed.sql              # Données de test
│   ├── 📂 src/
│   │   ├── 📂 config/            # Configuration (DB, Multer, Passport, Swagger)
│   │   ├── 📂 controllers/       # Logique métier
│   │   ├── 📂 middlewares/       # Auth, Rate Limiting, Validation
│   │   ├── 📂 models/            # Modèles de données
│   │   ├── 📂 routes/            # Définition des routes API
│   │   ├── 📂 services/          # Services (Email, etc.)
│   │   └── server.js             # Point d'entrée
│   ├── 📂 uploads/               # Fichiers uploadés (gitignored)
│   ├── .env.example              # Template de configuration
│   └── package.json
│
├── 📂 frontend/                   # Application React + Vite
│   ├── 📂 components/
│   │   ├── 📂 common/            # Composants réutilisables
│   │   ├── 📂 dashboard/         # Dashboards (Worker, Establishment, Admin)
│   │   ├── 📂 messaging/         # Système de messagerie
│   │   └── 📂 onboarding/        # Flux d'inscription
│   ├── 📂 contexts/              # React Contexts (Auth, Theme)
│   ├── 📂 hooks/                 # Custom Hooks
│   ├── 📂 services/              # Services API
│   ├── 📂 styles/                # CSS (Tailwind + Custom)
│   ├── App.tsx                   # Composant racine
│   ├── AuthContext.tsx           # Gestion authentification
│   └── package.json
│
├── README.md                      # Ce fichier
└── SWAGGER_ANNOTATIONS_COMPLETE.md  # Documentation API détaillée
```

---

## 📚 API Documentation

### Swagger UI (Interactive)

Accédez à la documentation interactive : **http://localhost:5000/api-docs**

![Swagger UI](https://swagger.io/swagger/media/assets/images/swagger-ui-screenshot.png)

### Endpoints Principaux

| Catégorie | Base URL | Description |
|-----------|----------|-------------|
| 🔐 Auth | `/api/auth` | Inscription, connexion, OAuth |
| 👷 Workers | `/api/workers` | Profils travailleurs |
| 🏢 Establishments | `/api/establishments` | Profils établissements |
| 📋 Missions | `/api/missions` | Gestion des missions |
| 📝 Applications | `/api/applications` | Candidatures |
| ⭐ Reviews | `/api/reviews` | Évaluations |
| 💬 Messages | `/api/messages` | Messagerie |
| 🔔 Notifications | `/api/notifications` | Notifications |
| 👑 Admin | `/api/admin` | Administration |

### Authentification

L'API utilise **JWT (JSON Web Tokens)**. Incluez le token dans le header :

```
Authorization: Bearer <votre_token>
```

### Rate Limiting

| Endpoint | Limite | Fenêtre |
|----------|--------|---------|
| Général | 100 req | 15 min |
| Login | 5 req | 15 min |
| Inscription | 5 req | 1 heure |
| Admin | 500 req | 15 min |

---

## 🛠 Technologies

### Backend
| Technologie | Usage |
|-------------|-------|
| **Express.js** | Framework API REST |
| **MySQL2** | Base de données |
| **JWT** | Authentification |
| **Passport.js** | OAuth (Google) |
| **Multer** | Upload de fichiers |
| **Socket.io** | Messagerie temps réel |
| **Swagger** | Documentation API |
| **Helmet** | Sécurité HTTP |
| **Express Rate Limit** | Protection DDoS |

### Frontend
| Technologie | Usage |
|-------------|-------|
| **React 18** | Framework UI |
| **Vite** | Build tool |
| **TypeScript** | Typage statique |
| **TailwindCSS** | Styling |
| **Framer Motion** | Animations |
| **React Router** | Navigation |
| **React Query** | Gestion état serveur |

---

## 🔧 Scripts Disponibles

### Backend

```bash
npm run dev      # Démarrage avec hot-reload (nodemon)
npm start        # Démarrage production
npm test         # Lancer les tests
```

### Frontend

```bash
npm run dev      # Démarrage développement
npm run build    # Build production
npm run preview  # Prévisualiser le build
```

---

## 🐛 Dépannage

### Erreur de connexion MySQL

```bash
# Vérifier que MySQL est démarré
sudo service mysql status

# Vérifier les credentials dans .env
mysql -u root -p
```

### Port déjà utilisé

```bash
# Trouver le processus utilisant le port
netstat -ano | findstr :5000
# ou sur Linux/Mac
lsof -i :5000

# Tuer le processus
taskkill /PID <PID> /F
```

### Erreur CORS

Vérifiez que `FRONTEND_URL` dans `.env` correspond à l'URL du frontend.

---

## 🤝 Contribution

1. Fork le projet
2. Créer une branche (`git checkout -b feature/nouvelle-fonctionnalite`)
3. Commit (`git commit -m 'Ajout nouvelle fonctionnalité'`)
4. Push (`git push origin feature/nouvelle-fonctionnalite`)
5. Ouvrir une Pull Request

### Conventions de Code

- **Commits** : Messages en français, format conventionnel
- **Code** : ESLint + Prettier
- **Branches** : `feature/`, `fix/`, `docs/`

---

## 📄 License

Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

## 👥 Équipe

- **Développement** : Équipe TADAMON
- **Contact** : support@tadamon.ma

---

<p align="center">
  <strong>🇲🇦 Fait avec ❤️ au Maroc</strong>
</p>
